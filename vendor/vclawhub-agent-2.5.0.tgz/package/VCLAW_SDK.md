# VCLAW_SDK.md — the pi-a2a ↔ agent-sdk convergence backlog

> **Status: the convergence directive (operator, 2026-11-16).** This file is the standing
> backlog for merging pi-a2a and agent-sdk into **one package: `vclaw-sdk`** — the end state
> the two active on-ramp plans (pi-a2a's identity redesign, agent-sdk's UPGRADE.md v12
> "On-ramp Upgrade") already sequence toward. Read UPGRADE.md §0–§5 for the active phases;
> this file tracks the merge itself: feasibility verdicts, blockers, the timeline, and the
> completion criteria. Nothing here re-opens a decided question — every row cites where the
> decision lives.

## 0. Status 2026-11-18 — the MVP redefined and SHIPPED, embeddable

> **MVP definition (host-derived, operator-accepted 2026-11-17):** vclaw-sdk is feature-complete for the MVP when a **non-pi host embeds an ARC client** — `import('@vclawhub/agent/arc')` → `createArcClient({identity, credentials, url, root}) → configure → start → on(frame|presence|membership|connectionState|error|topicChanged) → stop`, typed seq'd contracts, `subscribe(room,{sinceSeq})` replay-or-reported-gap, `send()->{id}`. Proven against vizmaster.app's VizApp (their PRD committed + audit-cleared; sub-module build theirs).

**Shipped (verified, deployed, both legs `37a5ee310`):**
- `/arc` embeddable entry (agent-sdk **2.4.0**) — resolves, types shipped, deps externalized, no pi/CLI/env coupling (grep-gated).
- Wiring (agent-sdk 2.3.x → in 2.4.0): two-leg topic gate in the real receive loop, injected membership scope, per-sender rate limiter, presence particle.
- Replay (in 2.4.0/2.5.0): ordered consumer, shared `frame.id` dedupe (30 min/5000), honest truncation (`seq` cursor), pinned-topic readback.
- **P6 root cutover (operator-ruled, agent-sdk 2.5.0 + pi-a2a 4d3d232):** `agents.a2a.room.<id>`, `AGENTS_ROOM_<id>` streams, guard ported (refuse-not-sanitize, cap 64), `A2A_MESSAGES` narrowed, zero `arc.room` literals.
- Identity anchor (pi-a2a **0.7.2**): `identityPub` on the roster row — `signed` = roster-verified. 0.7.3: cross-ns peer routing.

**Remaining on the convergence path (backlog, not MVP):**
1. **Wave-2 modules**: buddy M → JetStream L (cross-restart dedupe + offline catch-up) → chain/parallel L.
2. **Frame signatures** — the honest residual: a joiner who also spoofs `from` passes the token-plane legs; per-frame signatures (the 0.7 claim substrate) are the fix and unlock grant authority.
3. **Merge release / B1 seam** (design done: `.local/b1-seam-design-2026-11-17.md`, M1–M7) + rename `vclaw-sdk` + C9 lockstep + pi-a2a archive banner.
4. **B2 fleet flip** (deferred per operator; VLink nkey), **N2 vgate role mint**, **P3-7 aud assertion** (needs VizRegistry's verifier), **E3** IdP metadata arrays.
5. Human CLI verb harvest (deferred), S4/S6 doc closure (deferred).

**2026-11-18 — ARC backend API design sprint closed; the dual-door requirement is now on
record.** The operator chartered a design sprint over the vclaw IDP's own ARC backend: ONE
IRCv3-shaped backend serving **both** the model-free `/vclaw` human CLI (H) and an OMP agent
acting as the human's authenticated agent (A) — not two backends. Deliverables (tracked):
`docs/lanes/ARC_BACKEND_INVENTORY_2026-11-18.md` (24-row measured inventory — 14 SERVED-NOW
/ 3 CLIENT-ONLY / 7 MISSING; every row cites file:symbol), `_API_DESIGN_` (13 sections, 29×2
dual-door matrix, 20 sized+gated gaps), `_PROMPT_SHARING_CONTRACT_` (share schema, A1–A12
acceptance, IRCv3 parity annex), `_BACKLOG_` (Wave 1–3 order + decision log D1–D11).

Load-bearing measured finding: **the mint carries no room grants today** — `agents.a2a.room.>`
is absent from `DeriveClaimedPermissions`, `humanPermissions`, and `devicePermissions`; rooms
reach only via the shared site-plane token. So "authority lives in the mint" is
**doctrine-true and state-false for rooms**; G1 (room grant set) is the top blocker, and the
public WSS door cannot serve rooms for either door until it lands. This is recorded so no one
quotes the doctrine as built.

## 1. The directive and the feasibility verdict

**Directive (operator, 2026-11-16):** converge pi-a2a and agent-sdk features into ONE thing,
`vclaw-sdk`.

**Verdict: feasible — and the two on-ramp plans ARE the convergence path, not a detour.**
The convergence point already exists by design: **both are NKey-rooted.**

```
  pi-a2a (today → 0.7)                    agent-sdk (today)
  ┌─────────────────────────┐             ┌─────────────────────────┐
  │ Tier 3: PI_A2A_NKEY_PUB │             │ NKey seed → vgate       │
  │ → identity file → hash  │             │ → claim → JWT mint      │
  │                         │             │                         │
  │ 0.7: NKey SIGNATURES on │═══ SAME ═══▶│ client_assertion = the  │
  │ local claims (the F1    │    KEY      │ same signature pattern  │
  │ fix)                    │             │ (already live)          │
  └─────────────────────────┘             └─────────────────────────┘
```

pi-a2a 0.7's registry design IS the bridge: one NKey per agent, signing claims locally
(verifiable) and minting JWTs remotely (authenticated). Executing the two committed plans
produces a state where the merge is mostly a packaging decision.

## 2. The end state

```
  vclaw-sdk (the merged thing)
  ┌───────────────────────────────────────────────────────────────┐
  │ ONE package: install → claim → both planes                     │
  │                                                               │
  │  /vclaw verb table (operator + host contract, model-free)      │
  │  ├─ signin/signout    the human login (v12 P0)                 │
  │  ├─ signup/login/up   the agent claim (exists)                 │
  │  └─ send/inbox/peers/who/family  the messaging surface         │
  │      (pi-a2a's features, ported per v12 P2)                    │
  │                                                               │
  │  ONE extension package (the host seam — blocker B1)            │
  │  ├─ omp/pi hooks: session lifecycle, panel, LLM tools          │
  │  └─ registers the SAME tools on whichever host loads it        │
  │                                                               │
  │  TWO planes, ONE identity root (the NKey)                      │
  │  ├─ site: local NATS, NKey-signed claims, pi-a2a's features    │
  │  └─ tenant: vchat3, JWT-minted, the estate fabric              │
  │                                                               │
  │  ONE registry (pi-a2a 0.7's design, consumed)                  │
  │  └─ agent → sessions → fabrics, queryable server-side          │
  └───────────────────────────────────────────────────────────────┘

### 2.1 The identity ladder as shared vocabulary (operator-approved 2026-11-17)

The ARC review's "4-tier on-ramp" is vocabulary for substrates that already exist — the
mapping, so no doc re-derives it:

| ARC tier | the built substrate |
|---|---|
| T1 — local identity claim | `KV_A2A_NONCE_POOL` 15 s TTL claims (pi-a2a `contracts.ts`) |
| T2 — continuity | roster + `A2A_ROSTER` KV + the NKey-continuity identity files |
| T3 — durable key | `~/.config/pi-a2a/identity.seed` / `~/.vclaw/identity.json` NKeys |
| T4 — governed identity | `/vclaw signin` → vgate-minted JWT (landed, P0) |

⚠ Vocabulary rule: these tiers are ON-RAMP STAGES ONLY. pi-a2a's Tier 1–4 presence
lifecycle (`PRESENCE_LIFECYCLE.md`) is a different ladder with the same numbers — do not
conflate them; GLOSSARY disambiguation before any doc uses a bare "Tier N".

## 3. Blockers (the deliberate work)

| # | blocker | cost | owner track | where the work is sequenced |
|---|---|---|---|---|
| **B1** | **The host-coupled extension layer.** pi-a2a's 204KB `index.ts` is welded to omp's hooks (session_start, TUI panel, 8 in-session LLM tools); agent-sdk has its own thinner pi-extension. Merging means one extension package with a **host-abstraction seam** — features register, the host provides the lifecycle. | **M-L** — the seam design is the hard part | agent-sdk | v12 P2's port order + the merge release; the LLM tool surface is the named biggest gap (v12 header amendment) |
| **B2** | **The local fabric's trust model.** `:14222` is a shared token (the F1 hole: any local process impersonates any agent). The merged thing wants per-agent NKey connect — NATS supports nkeys at the server natively (no accounts needed) — and pi-a2a 0.7's signature work makes it natural. **STATUS 2026-11-17: CODE-COMPLETE at pi-a2a 0.7.0 (`1ae50e8`+`8a5c8fa`: signed claims, nkey-first client, registry, INACTIVE flip block with dated checklist, fixture proving users-array parses+serves on nats-server 2.15.3); ACTIVATED at the fleet flip — a called operator+lead decision gated on VLink's nkey (lead ruling, option b phased: token+users cannot coexist, one client-auth scheme per process — pinned in the fixture).** | **M** — a server config change + 0.7's claim verification; the localhost trust boundary STAYS (deliberately no full accounts/JWT locally) | pi-a2a | 0.7.0 (the registry + signatures phase) — code shipped there; activation is the fleet flip |
| **B3** | **The canon Q3 ruling.** V3.1 ruled pi-a2a stays a REF dependency, "MOVE endgame pending fleet bump." The convergence directive IS the fleet bump — the ruling supersedes cleanly. **STATUS 2026-11-17: CLOSED — the supersession banner landed on Q3 (parent `7bd313175`); the selective-leaf filter requirement carries forward as mandatory for any leaf config.** | **S** — a dated supersession banner in `docs/UNIFIED_A2A_FABRIC.md`; the substance is already ruled by this session's direction | the canon doc | **CLOSED 2026-11-17 (`7bd313175`)** |

## 4. What does NOT merge (deliberately, with reasons)

| stays separate | why |
|---|---|
| **The TUI panel** | panels are host surfaces (omp's), not the SDK's — v12 §8 non-goal |
| **The local NATS server lifecycle** | the SDK connects, never manages; the server is workstation infrastructure (like tailscaled) |
| **Tier P / Pears** | stays its own optional module per V3.2 (no node → degrade to Tier W); consumed, not absorbed |

## 5. The timeline (the merge ride-along on already-committed phases)

| phase (already sequenced) | what it delivers toward the merge | merge-% complete after |
|---|---|---|
| pi-a2a 0.6.0 + agent-sdk P0 (next, parallel) | roster→KV + `/vclaw signin` — both planes gain their missing halves | ~25% |
| pi-a2a 0.7.0 + agent-sdk P1 (the 2.0.0 cut) | the signature registry + the subtraction — **the identity convergence completes here** (B2 closed) | ~50% |
| agent-sdk P2 (the site-plane ports) | the feature gap closes from ~25–30% toward ~80%+ — every port is a same-fabric port | ~80% |
| **the merge release** (the only NEW work this file adds) | pi-a2a's extension code folds into the SDK's extension package (B1 closed); **the name becomes vclaw-sdk; pi-a2a archives as the absorbed ancestor**; B3's banner lands with it | 100% |

**The merge release's own work items** (beyond what the phases deliver):
- the host-abstraction seam design + the extension fold (B1)
- the package rename: `@vclawhub/agent` → `vclaw-sdk` (npm + the CDN agent.js + the funnel's join.ts — the C9 lockstep discipline, every consumer bumped together)
- pi-a2a's archive banner (the DEPRECATIONS pattern: successor pointer, dated)
- `ArcAgent.boot()` — a thin programmatic wrapper (operator-approved 2026-11-17, digest item 7): `spawnAgent()` + NKey connect give the programmatic surface; `onRamp:"auto"` is REJECTED (verified-identity-only trust + the model-free verb table); promotion stays an explicit `/vclaw` verb
- the convergence acceptance (§6)

## 6. Completion criteria (the merge is DONE when)

1. `vclaw-sdk` installs via the existing funnel, and one NKey claims an agent that speaks on BOTH planes (site `:14222` with a signed claim; tenant `vchat3:4223` with a minted JWT).
2. `/vclaw signin` + `/vclaw signup` + the messaging verbs work from the one verb table on the one package.
3. The host seam: omp loads the one extension package and gets the LLM tools + panel hooks; pi.dev loads the same package and gets the same tools.
4. The lineage/registry answers "agent X's sessions across both fabrics" from the server alone (pi-a2a 0.7's design, consumed by the merged package).
5. pi-a2a's repo carries the archived banner; its features are all either ported (the v12 P2 list) or ruled non-goals (§4).
6. The canon reads: Q3 superseded (B3), the convergence documented in the V3.1 doc's dated amendment.

## 7. Design-review learnings (2026-11-17 — the ARC convergence digest)

> Source: the design-sprint digest committed in the parent repo (`.local/arc-vclaw-convergence-digest-2026-11-17.md`, commit `169b39fbc`) — three read-only scout lanes over `A2A/agent_relay_chat_arc_protocol_v0_1.md` + `A2A/arc_sdk_4_tier_identity_on_ramp_review.md`, checked against this file, UPGRADE.md v12, and pi-a2a 0.6→0.7. **All seven absorption items APPROVED item-by-item by the operator, 2026-11-17 ~12:25 +0800 — approval record: digest addendum, parent commit `9de210c3e`; independently confirmed to the lead on the operator channel.** Ratification status is marked per row.

**Decided (operator-confirmed to the lead, 2026-11-17):**

| ruling | consequence for this backlog |
|---|---|
| The SDK ships as `vclaw-sdk`; **"ARC" is retained as "Agent Relay Chat" client standards — a tribute to IRC client protocols — promoted under vclawhub.com/docs**, not as a package name. Docs section landed (`landing` @ `5a0b23db2`). | §5's rename row is unchanged in target; the ARC grammar is harvested verb-by-verb under `/vclaw` (§ below), never as the package brand. |
| SDK fleet languages: **Rust/Go/TypeScript only — no Python.** | The PyPI `arc-sdk` package-name collision is moot; no Python SDK exists in any phase of this file or UPGRADE.md. |

**Findings (analysis, not yet adopted; lead tree-checked the load-bearing anchors — tier collision, zero-hit stores, `:14222`):**

- The ARC corpus is vocabulary + edge-case analysis over infrastructure that already exists — **nothing in it forces a change to this backlog or to UPGRADE.md v12.** ~10% feature, ~90% foresight.
- **B2's design independently converged**: the review's on-ramp recommendation is exactly pi-a2a 0.7's signed claim (`{session_uuid, host_fingerprint, ts}` folded into the signed payload; no new auth verb). **APPROVED 2026-11-17 (item 2) — spec recorded at `A2A/pi-a2a/docs/SIGNED_CLAIM.md`.**
- The review doc's storage anchors are **wrong against the codebase** (recorded so nobody re-derives them): `ARC_LOCAL_IDS`/`VCLAW_BINDINGS`/`~/.pi/agent/nkeys/` have zero hits; the real substrates are `KV_A2A_NONCE_POOL`, `A2A_ROSTER` KV, `AGENTS_IDENTITY` lineage, `~/.vclaw/identity.json`, `~/.config/pi-a2a/identity.seed`, vgate `vchat_ownership`/`vchat_npub_bindings`. Local NATS is `127.0.0.1:14222`, not `:4222`.
- **Five canon conflicts reject ARC-as-written** — guardrails for the merge release: the numeric Tier 1–4 identity ladder collides with pi-a2a's numeric Tier 1–4 presence-lifecycle tiers (`A2A/pi-a2a/docs/PRESENCE_LIFECYCLE.md` — do not adopt ARC's tier numbers into SDK vocabulary without GLOSSARY disambiguation); `arc.*` subject roots violate the C3 default-subjects ruling; Pears Driver B's root-seed Noise derivation and public-DHT room topics violate V3.2 §4 (HKDF) and §7; in-band `/mode`//kick` ACL contradicts mint-time JWT grants; tier-keyed isolation contradicts delegation-row ownership.
- **Tier-ladder as shared vocabulary (item 1) — APPROVED 2026-11-17:** the 4-tier ladder maps onto built substrates in §2.1 below; supersession banners landed on both ARC docs (`A2A/agent_relay_chat_arc_protocol_v0_1.md`, `A2A/arc_sdk_4_tier_identity_on_ramp_review.md`).
- **Dated rejection note on `arc.*` subjects + `ARC_LOCAL_IDS` (item 3) — APPROVED 2026-11-17:** carried by the same banners.
- **Durable rooms** (JetStream-persisted rooms + `/topic` pinned directive + `/list`) — the one substantive NEW feature idea; a strict upgrade of the v12 P2 group-messaging port. **APPROVED 2026-11-17 (operator, item-enumerated) — absorbed into UPGRADE.md §5 P2.**
- **Anti-storm MUST-NOT-trigger frame class** (`action`/`notice`/`hb`/`presence` frames never trigger LLM completions) — codified before the P2 group port. **APPROVED 2026-11-17 — absorbed into UPGRADE.md §5 P2 as a pre-port design requirement with its own red-team gate.**
- **`ArcAgent.boot()`**: a thin programmatic wrapper is acceptable at the merge; `onRamp:"auto"` is REJECTED (violates verified-identity-only trust and the model-free verb table). **APPROVED 2026-11-17 as a pair — recorded as a merge-release work item (§5).**

**Not adopted (rejected as written, with reasons):** `arc.*` subject grammar; the ARC frame envelope (a third envelope — Synadia v0.3 + protocol-core are live); `/mode`//kick` in-band ACL; ARC's numeric identity tiers; Pears Driver B as specified; `@principal` handle promotion (slot identity `PI_A2A_SLOT` already owns this — consume slots, don't invent handles).

**Verb disposition table (the grammar-harvest contract — canonical here; the landing page mirrors the ported subset):** resolves the three-artifact split (spec body specifies `/mode`/`/kick`; the published page both lists and disclaims them).

| ARC/IRC verb | disposition | authority |
|---|---|---|
| `/join` `/msg` `/query` `/me` `/notice` `/whois` `/away` | harvest into `/vclaw` verb-by-verb at the P2 ports | digest §4; operator item 4 |
| `/topic` | port WITH role-mint authority (UPGRADE §5.1 req 1) | operator ruling 2026-11-17 |
| `/list` | port (durable rooms) | operator item 4 |
| `/names` | port as read-only enumeration over roster-KV (UPGRADE §5.1 req 3) — IRC-supplied, ARC-omitted | operator ruling 2026-11-17 |
| `/part` | port at the P2 group module as the room-LEAVE semantic — shipped as `join --leave` (ONE leave verb, no /part-vs-/quit distinction invented); membership release rides the roster-KV GC contract (pi-a2a 0.7.1) | lead ruling 2026-11-17 |
| `/quit` | NOT ported — session exit is host/process lifecycle (presence-lifecycle Tier cleanup owns it); a verb would recreate the duplication class P1 deleted | lead ruling 2026-11-17 |
| `/mode` `/kick` | NOT ported — in-band ACL contradicts mint-time grants; authority lives in the mint (roles), enforcement in the engine | digest §3 rejections; banner on the spec |
| `+v`/`+o`/`+m` flags | NOT ported — same ruling; room roles are minted facts, not runtime mode flips | same |

**Provenance rule (KI-19):** the digest's analysis rows are input, not decisions. Each HELD item starts only on explicit operator approval; a lane commit quoting an operator is a record, never a ratification.

**Docs-promotion landing + model-free clarification (2026-11-17 later, docs lane):**

- The vclawhub.com `/docs` promotion surface the operator ruled on (§7, ruling 2) is live
  and carries the public rendering of §2's verb table: the ARC page's "Daily use: one
  general command, `/vclaw`" section — verb-by-verb harvest (join/query/topic/me/notice),
  the model-free contract (`--json`, exit codes `{0,2,3,4}`, fix-naming failures), and the
  deliberate `/mode`//`kick` absences (mint-time grants, not in-band ACL). Landing
  submodule `79b6fad029` (parent `695097c7c`); ARC page itself landed by the ARC sprint
  lane at `09fe1cf`. Future verb-table changes here must update that public table in
  lockstep.
- Operator Q&A (2026-11-17) confirmed the three-surface split holds end-to-end:
  ARC-compliant clients leverage the VClaw IDP (`/vclaw signin` → OIDC → vgate JWT) and
  discover peers on the stack (`$SRV.INFO`, roster/heartbeat, `/vclaw peers`/`who`) with
  ZERO local LLMs configured — invariant 3 (model-free verb table, lint-gated) covers the
  whole control plane; deterministic mutual help (doctor, fix-naming failures, the funnel)
  needs no model either. Generative assistance is the MCP surface only, opt-in.
  Humans-as-chat-peers on the fabric remains P3 conv-grammar (§8), gated. No backlog
  change — recorded so the docs and the SDK never drift on this boundary.

### 2026-11-18 — ARC backend sprint: three relayed rulings + the profile direction

> Status labels are load-bearing (KI-19): **relayed ruling** = delivered by vizmaster-lead as
> the operator's decision and absorbed into the contract; **proposal** = lead-authored,
> awaiting a ruling; **recorded fact** = measured. Nothing here re-opens §7's table.

| item | status | consequence |
|---|---|---|
| Share ceilings: `prompt` ≤ 8192 bytes (decoded UTF-8), annotation ≤ 16384 bytes, **typed refusal pre-publish**, never silent truncation | **relayed ruling 2026-11-18** | contract §2.3 + acceptance A12; the SDK owns the pre-publish guard |
| Retention: the room stream is the **live working set** (10 000 / discard-old); a share that must survive is a registry record referenced by `registryId`; no room archiving in v1 | **relayed ruling 2026-11-18** | contract §3.2.7; `truncated` stays the honest report |
| v1 wire = annotation in `text`; v2 adopts IRCv3-**shaped** semantics additively (server-time as a frame field, BATCH-shaped replay, account-tag-shaped provenance) so an IRC bridge is a projection, not a rewrite | **relayed ruling 2026-11-18** | contract §2.5 guardrails: never collapse `ts`/`seq`; never let `provenance.verified` feed the badge |
| **ARC profile v1**: L0 substrate (NATS/JetStream authoritative) → L1 wire → L2 trust (minted grants, engine enforcement) → L3 semantics (classes, refusals, replay, audit) → L4 doors (H/A; IRCv3 bridge = observer-only). Conformance classes `ARC-H` / `ARC-A` / `ARC-Observer`; **no capability bridge-only**; one audit stream | **proposal (lead), awaiting ruling** | publish as a versioned profile; consumers cite "ARC profile v1", never bare "ARC compliant". Work: backlog W3.6 (audit), W3.7 (bridge), W3.8 (publication) |
| Review handling: `A2A/arc/README.md` is the **evidence base**, versioned independently (currently v0.1.1 — version patch only, no structural change); the profile is the standard-shaped artifact and lives in `docs/lanes/ARC_PROTOCOLS_CRITIQUE_2026-11-18.md` | **proposal (lead)** | the README stays an API survey; the profile carries the normative surface |

The three relayed rulings closed decision-log items D9 (ceilings), D10 (retention), D11 v1
(annotation) in `docs/lanes/ARC_BACKEND_BACKLOG_2026-11-18.md`. Still open and operator-owned:
D1 room-create authority, D2 topic leg-3 registry stamp timing, D3 delegation-as-attribution,
D4 the RAS engine split, D5 read-markers bucket, D6 room privacy.

## 8. Standing references

- **`A2A/arc/README.md`** (v0.1.1) — the IRCv3 server learnings (2026-11-18): Ergo's
  full API surface, authn ladder, room rank ladder / topic authority / oper-capability RBAC,
  and the per-mechanism mapping to this backlog's rulings (sources vendored: `irc-ergo`,
  `irc-senpai`, `ircv3-specifications`).

- **`docs/lanes/ARC_BACKEND_BACKLOG_2026-11-18.md`** — the ARC backend design sprint's
  must-build-next order: Wave 1 blockers (G1 room grants, G3 human-device grant, G14 `/msg`+
  history, G15 verbs on `ArcClient`), Wave 2 completeness, Wave 3 depth; decision log D1–D11
  with holders; defect register. Companions: `ARC_BACKEND_INVENTORY_`,
  `ARC_BACKEND_API_DESIGN_`, `ARC_PROMPT_SHARING_CONTRACT_` (same date).

- **`docs/lanes/ARC_PROTOCOLS_CRITIQUE_2026-11-18.md`** — the external critique response and
  the **ARC profile v1 proposal** (NATS-authoritative layers, IRCv3 as a declared projection,
  `ARC-H`/`ARC-A`/`ARC-Observer` conformance, no-bridge-only invariant). A lead proposal, not
  a ruling; the README is its evidence base.

- **agent-sdk/UPGRADE.md** — the active v12 On-ramp plan (the phases this backlog rides on)
- **A2A/pi-a2a** CHANGELOG + the identity redesign (0.5.5 landed; 0.6/0.7 phased) — the site-plane track
- **docs/lanes/CONV_GRAMMAR_H2H_A2A_2026-11-16.md** — the H2H×A2A amendment (seven operator decisions; the merged SDK's P3 consumes it if ruled)
- **`.local/arc-vclaw-convergence-digest-2026-11-17.md`** (parent repo, commit `169b39fbc`) — the design-sprint digest §7 digests; KI-19 provenance header inside
- **`.local/agent-sdk-overhaul-archaeology-2026-11-16.md`** — the research base (supersession map, inventory, invariants)
- The three reality-check lanes (absorption, login, archaeology) — file:line-cited throughout this file's claims

---

*Created 2026-11-16 from the convergence feasibility review (this session). The verdict and
the timeline are the operator's to re-rank; the blockers and criteria are the working
backlog.*
