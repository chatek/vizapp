## 2.5.0 — 2026-11-26

**S4 KB publish + ARC wire additions.** Additive release; version pins stay
`sdk 2.5.0 · arc_protocol 1 · Ergo 2.19.1`.

- **`omp --publish-kb <glob…>`** — the omp command boundary resolves
  `VCLAW_AGENT_ENTRY` / `vclaw-agent` / `~/.vclaw/agent.js` and spawns
  `vclaw publish-kb -- <globs>`; no NATS code enters the vendored fork.
- **`vclaw publish-kb`** — watcher (literal + single-level glob, sha256 content
  gate, 150 ms debounce), published-path allowlist (lexical + realpath), one
  `msg` plus one display-plane `kb-update` notice per content change, and a
  signed `AgentCard` heartbeat (15 s / 45 s TTL) in `AGENT_CARDS`.
- **`ArcClient`** — optional display-plane `tags` on `WireFrame`/`send` (outside
  the signed canonical bytes) and `kvPut` on the same connection; `NatsWire`
  create-opens the KV bucket.
- **Agent assertions** carry `sdk_version`, `arc_protocol: "1"`, sorted
  `features`, and `features_digest`; the production token path uses the same
  builder.
- **Schema** — `WireFrame.tags` additive for the S4 tip; S4 tests pin route
  mount, KB units, and default S1 SKIP behavior.

## Unreleased

### install-sdk.sh — the one-command on-ramp (2026-11-27)

- **`bin/install-sdk.sh`** (served at `https://vclawhub.com/install-sdk.sh`) — one command
  replaces the bun pipe invocation:
  `curl -fsSL https://vclawhub.com/install-sdk.sh | sh -s -- --runtime omp my-agent`.
  Same contract as `bin/join.sh` (bun >= 1.2 gate, consent-gated bun install per ruling R2,
  arg passthrough to `join.ts`); retries are folded into the handoff and `--help` documents
  the grammar. `sh -s --` is required: `sh` parses its own argv, so `| sh --runtime …` dies
  with "invalid option" (measured on macOS /bin/sh).
- **Mirror is test-enforced**: `landing/src/pages/install-sdk.sh.ts` must stay byte-identical
  to `bin/install-sdk.sh` — `test/unit/install-sdk-sh-shim.test.ts` fails on drift. That test
  also covers the consent gate, junk-version refusal, `--install-bun` filtering, and exit-code
  propagation.

### pi-a2a convergence + on-ramp review records (2026-11-25)

*(Review records only — no code changed today.)*

- **Incorporation state measured (pi-a2a 0.7.4 vs this package).** The a2a-net V2 core is inlined
  canonically (`src/net/`, `src/agent/lifecycle.ts:1-11`); `A2A_ROSTER` KV is consumed as the
  membership store (`src/arc/membership-kv.ts:24-25`, "pi-a2a 0.6.0+ owns it" — live-confirmed);
  room grammar and buddy subjects are hoisted with lineage comments. NOT incorporated: the
  `a2a_*` tool surface (this SDK exposes 26 `vclaw` verbs + 12 MCP tools + `/arc` instead),
  workflow chain/parallel, panel UI (2.0.0 ruling), signed-claim registry/lineage, and the buddy
  protocol client (subjects only, no handshake). Cross-file facts: `vclaw peers` reads pi-a2a's
  `cross_buddies.*.json`; `ext-synadia` consumes pi-a2a's launchd server + `server.seed` as a client.
- **Local self-host measured live (bare nats-server, no vgate).** The `/arc` library path WORKS:
  two clients, `nkeySeed` credentials, room frame sent and received — prerequisites measured:
  JetStream enabled, `A2A_ROSTER` bucket pre-created (the SDK never provisions it), `configure()`
  before `start()`. `start --dev` connects (plain NKey, presence + A2A subscribed); `send`/`inbox`/`who`
  still mint a vgate JWT and exit 4 (`agent_not_claimed`) even with `--dev`/`--allow-unknown`
  (`src/vclaw/fabric.ts:216-224` — no dev branch); room verbs require a human IdP session
  (`src/vclaw/room-client.ts:59`); `peers`/`status`/`doctor`/`pears` are cloud-free. Asymmetry
  measured: `start --dev` ignores `config.json server` (uses `--server`/`VCLAW_DEV_NATS_URL`,
  default `:4222`) while verbs read `config.json` first (`src/vclaw/fabric.ts:220-221`).
- **On-ramp readiness.** Cloud funnel steps implemented + E2E-executed, but: 2.1.1 was never
  published to JSR (registry latest 2.1.0; no 2.x tag — release procedure step 2/3 not executed),
  JOIN_FUNNEL.md/E2E_tests.md teach the retired prime-agent funnel and the superseded proof-bearing
  claim URL, and the bundle-update oracle keys on the frozen JSR `latestVersion` (measured: a
  workstation bundle stamped 1.5.0). Local: `VCLAW_DEV`/`--dev` documented nowhere user-facing;
  no first-party local sender; the JSR tarball carries neither the CLI bin nor the `pi.extensions`
  dist bundles. Backlog rows for all of it land in BACKLOG.md in the same change.

Review records: ../docs/lanes/SDK_VS_PI_A2A_SELFHOST_REVIEW_2026-11-25.md · ../docs/lanes/SDK_2_1_1_CONVERGENCE_ONRAMP_REVIEW_2026-11-25.md

- **`send` publishes on the canonical U-form mailbox, whichever key spelling it
  is given (E-5).** The register accepts a peer key as the canonical U-form
  (56 chars) or as raw base64url (43 chars, the `agent_nkey` spelling), but the
  granted mailbox — and therefore `inbox` and the session drainer's
  subscription — is always `tenant.<t>.a2a.<U-form>.>`. `vclaw send <raw key>`
  interpolated the raw token verbatim, published `tenant.default.a2a.<raw>.req`
  to nobody, and still reported success; a window opened before the send printed
  `received 0`. `canonicalPeerKey` now resolves either spelling to the U-form
  (official `@nats-io/nkeys` codec, no hand-rolled encoding) before both the
  register lookup and the publish. `--json` reports `to` canonically and adds
  `peerInput` when the operator's spelling differed; the human output says so.

## 2.1.1 — 2026-11-24

**E2E defect fixes.** No API changes; behaviour corrections from the kuai E2E lanes:

- **`vclaw who` can no longer hang unbounded.** A 10 s deadline covers the
  connect + first-subscribe phase (`FabricTimeoutError`, classified as exit 3,
  text `cannot reach the fabric at <redacted server> — timeout`). Pending-claim
  (4) and ungranted-segment (3) classifications are unchanged.
- **`buildAgentAssertion` refuses a seed/public-key mismatch locally** — it now
  derives the public key from the seed and throws (message carries only the
  U-form public key, never seed material). The server already refused these
  with `invalid_client: signature verification failed`.
- **`vclaw doctor` exit contract pinned at the process surface** — the reported
  "exits 0 on failure" does not reproduce: the published bundle exits 4 on
  failing checks under the documented 0/2/3/4 contract; regression tests now
  assert `process.exitCode` is set on failure and untouched on all-pass.
- **`vclaw pears` is a verb, not an unknown one.** `src/commands/pears.ts` and
  the top-level `pears [action]` registration existed, but the model-free verb
  table had no `pears` entry, so `vclaw-agent vclaw pears` printed
  `unknown verb "pears"` (exit 2). The verb now answers with the same
  `pearsStatus` probe the `tier P` row in `status`/`doctor` summarises
  (`--deep` probes the native binding and connect-answers the socket), reports
  an unavailable optional tier as `degraded` with exit 0, and leaves the
  stateful `send`/`recv` wire actions on the top-level
  `vclaw-agent pears` helper.

## 2.1.0 — 2026-11-24

**Embed-friendly release.** Two additive changes requested by the VizMaster
prompt-help client lane, neither breaking existing consumers:

- **`./assertion` subpath.** `buildAgentAssertion` and its verification helpers
  are now importable: `import { buildAgentAssertion } from
  "@vclawhub/agent/assertion"`. The 1.5.x/2.0.x exports map hid the module, so
  embedded hosts had to vendor ~60 lines of signing code. Both the JSR export
  (`./src/lib/agent-assertion.ts`) and the npm export
  (`./dist/lib/agent-assertion.js`) ship.
- **`connectViaJWT(..., hooks)`** — an optional fifth argument
  `{ onUnexpectedClose(err) }`. When provided, an error close calls the hook and
  does NOT `process.exit(1)`; the host owns the restart policy. The default
  (CLI/supervisor) behaviour is unchanged: loud log + exit 1.

Why: a library that exits its host is hostile to embedders — the observed case
was an Electron/OMP host being taken down by a NATS reconnect failure.

## 2.0.3 — 2026-11-19

**Packaging patch, take two.** The `./package.json` export now also lives in the
JSR publish set (`jsr.json` exports + `publish.include`), so the synthesized
npm-compat tarball can carry it — 2.0.2's entry only reached npm/git installs,
and npm-compat is how Electron hosts vendor us.

## 2.0.2 — 2026-11-19

**Packaging patch.** Host-embedding ergonomics (VizMaster desktop lane).

- **`./package.json` export.** The exports map now lists `./package.json`, so
  `require.resolve('<pkg>/package.json')` no longer throws
  `ERR_PACKAGE_PATH_NOT_EXPORTED` for npm/git consumers (Electron packaged
  builds included). JSR npm-compat tarballs synthesize their own exports map;
  see the release notes for the measured state there.
- **Exit codes are API.** `0` ok · `2` usage · `3` missing dependency ·
  `4` identity not ready — documented in the README (the published page).

## 2.0.1 — 2026-11-19

**CLI patch.** The package page and the installed CLI now agree.

- **`vclaw <verb>` bin.** A second entry (`vclaw`) beside `vclaw-agent`, calling the
  same verb table — no second parser. `vclaw-agent vclaw <verb>` still works.
- **README** teaches `vclaw status` / `vclaw doctor` / `vclaw signin` … instead of the
  nested form, and remains the only markdown shipped on the package page.
- The installed shim written by `join.sh` routes through the stable `vclaw` subcommand.

## 2.0.0 — 2026-11-19

**BREAKING.** First published 2.x; replaces the yanked 1.5.0. What a 1.x
consumer has to know:

- **CLI.** The 24-verb 1.x top-level table is now 10 verbs: `vclaw` (the
  verb table), the lifecycle verbs `onboard` `start` `retire` `uninstall`
  `runtime`, and the infra verbs `mcp` `update` `check-update` `pears`.
  Removed outright: `serve` `spawn` `steer` `kill` `panel` `eval` `keygen`
  `export` `import` `health` `clear` `reset` `offline` `online`; the verbs
  that survive (`status` `doctor` `who` `send` `inbox` `up` `down` `login`
  `logout`, …) moved under `vclaw-agent vclaw <verb>`. That table also
  carries the new **`capabilities [--json]`** verb — the typed capability
  manifest (declared vs probed, with `absent/{not-implemented|not-granted|gated}`
  reasons).
- **Rooms.** The wire grammar is now `agents.a2a.room.<id>.msg|.control`
  (streams `AGENTS_ROOM_<id>`, was `ARC_ROOM_<id>`), with no alias window:
  a 2.x client cannot see 1.x room frames, and vice versa.
- **`/arc` client** — new subpath, `@vclawhub/agent/arc` (JSR npm alias:
  `@jsr/vclawhub__agent/arc`). `createArcClient` / `createRoomsClient` with
  idempotent `configure → start → stop`, `send(room, {text})`, ordered
  `subscribe(room, {sinceSeq})`, and `replay(room, sinceSeq)` reporting
  `truncated`. `identity`, `credentials`, `url`, and `membership {ns, fabric}`
  are injected — the client reads no env.
- **Types.** The published declarations are generated correctly and typecheck
  under `strict` without `skipLibCheck` (1.5.0's `.d.ts` had broken
  `readonly` modifiers).
- **Unchanged.** The root identity/onboarding exports (`VgateClient`,
  `onboard`, `connectViaNKey` / `connectViaJWT`, credentials
  save/load/clear) and the `contracts` / `constants` subpaths keep their 1.x
  shapes; 2.x is additive there.

## Development milestones folded into 2.0.0 (never published on their own)

### 2.5.0 — the P6 room-root rewrite: `agents.a2a.room.*` (OPERATOR-RULED) — 2026-11-18

THE cutover the operator ruled: durable rooms move off the private
ARC-era room root onto `agents.a2a.room.<id>`, and the stream prefix is
renamed in the same breath (no alias, no transition window).

- **Wire grammar** (both copies — `packages/ext-synadia/src/group.ts` and
  the `src/vclaw/site-fabric.ts` hoist, conformance-pinned): subjects
  `agents.a2a.room.<id>.msg` / `.control`, wildcard seam
  `roomWildcardSubject()` = `agents.a2a.room.>`, streams
  `AGENTS_ROOM_<id>` (was `ARC_ROOM_<id>`). `/arc` needed no change —
  it rides the builders.
- **Guard port**: `roomSegment` now REFUSES reserved names before
  sanitizing — `$SYS`/`$JS`/`$KV`, `_INBOX`, wildcards, whitespace all
  throw (`$SYS` is never silently mangled to `sys`). Cap 48 → **64**,
  matching pi-a2a's `roomRefusalReason`/`MAX_KEY_SEGMENT` so both sides
  refuse identically (above 64 the roster-KV `keySegment` digest-collides
  room ids).
- **Orphan cleanup**: `deleteLegacyRoomStreams()` deletes pre-rewrite
  `ARC_ROOM_*` streams, best-effort on every `/vclaw join` (a no-op
  listing once clean). Old frames NOT migrated — room streams are
  discard-old transport working-set, not mail.
- **Acceptance**: a publish→RECEIVE round-trip test through the seam whose
  stub `js.publish` THROWS on any subject outside the ensured stream — a
  stale wildcard or stale stream prefix fails loudly, never silently
  receives nothing. Guard-port refusal + cap tests on both copies.
- Counterpart: pi-a2a narrows A2A_MESSAGES to the enumerated ns list
  (`agents.a2a.{pi,omp,group}.>`) so room frames are captured only by the
  per-room `AGENTS_ROOM_<id>` streams.


### 2.4.0 — the `/arc` embeddable entry: typed contracts + client (BUILD-2) — 2026-11-17

The first non-pi host surface: `@vclawhub/agent/arc` (an ESM subpath with
`.d.ts`, Electron-main compatible). One factory, two ratified names —
`createArcClient` / `createRoomsClient` — over the host-free ext-synadia
modules:

- **`src/arc/contracts.ts`** (moved from `packages/ext-synadia/src/arc/` in 2.0.0; the published tree) — the SINGLE declaration
  site: `WireFrame`, `RoomFrame = WireFrame & {seq: number}` (seq REQUIRED,
  consumer-filled from JsMsg — never sender-claimed), `FRAME_CLASSES`,
  `RoomRecord`, `MembershipRow`, `ReplayResult`, `ARC_CONTRACT_VERSION = 1`
  (additive-only within v1). The bundle re-exports, never copies.
- **`client.ts`** — idempotent lifecycle (`configure → start → on → stop`),
  credentials/url/membership `{ns, fabric}` INJECTED (zero env reads under
  src/arc — grep-gated), per-instance state (no module singletons; two
  clients coexist), `publishPresence` + `agentParticle` options (default
  off/undefined — never "pi"), `send → {id}` with own-echo carrying the SAME
  id (reconcile on id, not seq), ordered ephemeral consumers so every
  delivered frame carries ascending `seq`, and `replay(room, sinceSeq)` with
  the truncation indicator. Subjects come from the group.ts builders only.
- **`wire.ts` / `seam.ts`** — the default @nats-io wire (token or NKey seed)
  behind a structural seam tests can fake.
- **Packaging**: `exports["./arc"]` → `dist/arc/index.js` + `.d.ts`;
  `scripts/build-arc.mjs` EXTERNALIZES `@nats-io/*` + `@sinclair/typebox`
  (lead delta D1 — inlining duplicates nats-core in the host, ~350 KB) and
  flattens the tsc declarations into `dist/arc/`; jsr.json gains the same
  subpath; `dist/arc/` committed (bundle-freshness gate extended);
  `verify:pack` requires the arc files.
- **Gates**: `test/unit/arc-entry-gates.test.ts` — no pi import under
  src/arc, no `process.env` under src/arc, re-exports-only entry + real
  import probe (side-effect-free, no new active resources), ./arc present in
  BOTH publish sets. New client tests: lifecycle idempotency, two concurrent
  clients on one fabric, seq on every delivered frame, send→echo id
  reconciliation, replay truncation honesty.


### 2.3.1 — the roster-KV membership reconciliation (Lane B's contract consumed) — 2026-11-17
Lane B's substrate landed (pi-a2a `94dd056`, 0.7.1; ROSTER.md §4.7 = the
contract doc) — the §5.1-3 seam is now CONSUMED, not stubbed:

- **`packages/ext-synadia/src/membership-kv.ts`** — `RosterKvMembership`
  implements `RoomMembershipStore` over the contract grammar
  `room.<ns>.<fabric>.<roomId>.<owner>.<name>` (the A2A_ROSTER bucket; one
  prefix scan per /names). Single-writer discipline: a session writes ONLY
  its own row; other principals' rows are pi-a2a's joinRoom/leaveRoom API.
  The bucket is pi-a2a's — `open`, never `create`; absence throws (the
  caller degrades, never fabricates membership).
- **`src/vclaw/membership-kv.ts`** — the verb-side read hoist (publish-set
  safety: src cannot import the jsr-published extension); `/vclaw names`
  now consumes the contract and falls back to the transport frame count
  (stating why) when the bucket is unavailable.
- **Conformance extended**: `test/unit/room-grammar-conformance.test.ts`
  now pins the membership grammar across BOTH SDK copies against one
  fixture table — key, prefix, parse, garbage refusal, and roster-row
  blindness (the record-class separation).
- Lead's `/part`//`/quit` disposition rows (VCLAW_SDK, lead commit
  `d12ca71`) resolve our FLAG: `join --leave` IS the ruled leave semantic;
  `/quit` stays unported (session exit = host lifecycle). No code change
  needed — the shipped shape matches the ruling.
- Versions: sdk 2.3.0 → **2.3.1**, ext-synadia 0.5.0 → **0.5.1**.
- Tests: 9 adapter tests new (ext-synadia 116 pass / 2 skipped); root suite
  969/969; bun:test suites 31 green under bun (pre-existing topology);
  bundles rebuilt (freshness gate green); tsc clean.

### 2.3.0 — group: durable rooms with role-mint authority (UPGRADE.md §2 order #3, §5.1 reqs 1–4) — 2026-11-17

P2 Wave 1, module 3 of 3 (group M — the crown jewel; every §5.1 pre-port
requirement was codified before this file was written, and each lands here):

- **§5.1-1 role-mint topic authority** (operator ruling 2026-11-17):
  `RoleResolver` + `MintedRoles` — member ≠ topic-writer. `setTopic` and the
  receive-side `acceptTopic` BOTH default-deny: no minted `author` role ⇒
  refusal (`not-author`), the topic never lands. The mint's role map is the
  source (the invite already carries {principal, rooms, role}); the CLI reads
  the mint file `~/.config/pi-a2a/room-roles.json` — absent file ⇒ nobody
  writes topics. `/mode`//`kick`//`+v/+o/+m` remain NOT ported (disposition).
- **§5.1-2 anti-storm + red-team gate**: `routeFrame` routes through
  rate-limit.ts's `triggersCompletion` (exact-match default-deny, ONE source).
  The red-team tests run the ADVERSARIAL frames through the real routing
  point and prove ZERO completions for `action`/`notice`/`presence`/`topic`
  (including impersonated `from`) — it fails red when violated by
  construction: the completion handler is reachable only past the gate.
- **§5.1-3 roster-KV membership**: `RoomMembershipStore` is the consumer
  seam — Lane B's KV contract (rooms-as-roster-keys, presence-lifecycle GC)
  reconciles behind it at integration; `InMemoryMembership` is the stated
  default. `/names` reports the seam's state and NEVER fabricates a roster
  from transport state (the conflation the ruling rejected).
- **§5.1-4 volume**: room streams are created via rate-limit.ts's
  `roomStreamRetention` (MaxMsgs 10k + DiscardOld — one source); inbound
  room frames ride the caller's `SenderRateLimiter`; notice-class frames
  never buffer (contract lines 2–3 consumed, line 1 shared).
- **The verb harvest** (disposition-table PORTED set): `vclaw join` (with
  `--leave`), `topic`, `list`, `names`, `me`, `notice` — each a thin shell
  over the site fabric via `src/vclaw/site-fabric.ts` (the connect + grammar
  hoist; wire compatibility pinned by
  `test/unit/room-grammar-conformance.test.ts` against ONE fixture table).
  `/msg`=send, `/whois`=who already exist. **FLAG**: `/part` + `/quit` are
  UNDISPOSED — implemented as ONE leave semantic, no distinction invented;
  **`/query`** is disposition-PORTED but its substrate (stateful H2A
  sessions) is not in this wave's modules — harvest deferred with reason;
  **`/away`** likewise needs the presence write path (buddy/presence wave).
- Architecture: `RoomsCore` (pure — roles, gates, membership, routing) +
  `startRooms` (the JetStream wire: stream per room on the ARC-era room
  root — moved to `agents.a2a.room.*` by the P6 rewrite, 2.5.0 above).
  Room frames ride protocol-core-compatible JSON with the class in the
  frame — no third envelope (§7 rejection honoured).
- The landing page's public verb table must mirror this harvest in lockstep
  (docs lane, next).
- Versions: sdk 2.2.0 → **2.3.0**, ext-synadia 0.4.0 → **0.5.0**.
- Tests: 14 group + 9 rate-limit + 8 tooling (ext-synadia 107 pass / 2
  skipped), 3 grammar-conformance (root). Full root suite 966/966; the two
  bun:test suites (31 tests) pass under `bun test` (dual-runner topology,
  pre-existing). `npm run build:extensions` re-run — bundle freshness gate
  green.

### 2.2.0 — tooling: dedup / ping / purge reports (UPGRADE.md §2 order #2) — 2026-11-17

P2 Wave 1, module 2 of 3 (tooling S — each tool S-sized):

- **dedup**: `DedupWindow` — inbound msgID duplicate suppression over a time
  window (default 2 min, pi-a2a's duplicate-window convention). Core-NATS
  messages carry no JetStream dedup; injectable clock; lazy age-out.
- **ping**: `probePeer(nc, subject, {timeoutMs})` — ACTIVE liveness with a
  hard deadline. A deadline miss is NOT alive; the probe never retries
  (retry policy is the caller's). Reply decoded when alive.
- **purge**: `presencePurgeReport(handle, {nowMs})` — the planner half:
  live/stale split + stale entries (oldest-stale LAST), computed with
  presence.ts's OWN `isStale` predicate (staleness semantics live in one
  place). The presence map's sweeper stays the executor — pi-a2a gc.ts's
  planner/execute split, honoured, not restated.
- Versions: sdk 2.1.0 → **2.2.0**, ext-synadia 0.3.0 → **0.4.0**.
- Tests: 8 new (`tooling.test.ts`). ext-synadia suite 93 pass / 2 skipped.

### 2.1.0 — rate-limit: the P2 volume contract lands (UPGRADE.md §5.1 req 4) — 2026-11-17

P2 Wave 1, module 1 of 3 (§2 port order #1: rate limiting S). The volume
backpressure contract lands in its designated layer, not as an ad-hoc patch:

- **Line 1 — per-sender token bucket**: `SenderRateLimiter` ported from
  pi-a2a `src/a2a/rate-limit.ts` (the proven algorithm, byte-faithful):
  FIFO deferral per sender, newest-only rejection at the buffer cap,
  injectable clock, drain-callback errors never kill the loop. Covers
  every inbound surface — rooms included, a room frame is a `submit()`.
- **Line 2 — room stream MaxMsgs + DiscardOld**: `ROOM_STREAM_MAX_MSGS`
  (10,000) + `roomStreamRetention(name, maxMsgs?)` — the retention bound
  every durable room stream is created with; a room is a bounded log.
  The group module (§2 order #3) consumes this one source.
- **Line 3 — notice-class frames never buffer to inbox**:
  `NON_TRIGGERING_FRAME_CLASSES` (`action`/`notice`/`hb`/`presence`),
  `isNonTriggeringFrameClass`, `inboxAdmissible` — display-plane only; a
  notice flood costs render, not queue depth.
- **The red-team gate predicate**: `triggersCompletion(frameType)` —
  DEFAULT-DENY, exact known triggering classes only (`msg` `cmd`
  `stream_chunk` `stream_end`). Case tricks (`"Notice"`), whitespace/
  null-suffixed spoofs, and unknown classes never complete. Pinned by
  adversarial tests (UPGRADE §5.1 req 2's red-team gate, predicate half).
- Deps: `@nats-io/jetstream@^3.4.0` added to ext-synadia (line 2's
  `StreamConfig` shape; the group module's stream creation uses it).
- Versions: sdk 2.0.0 → **2.1.0**, ext-synadia 0.2.2 → **0.3.0**.
- Tests: 9 (port fidelity + the three lines + the red-team adversarial
  set). ext-synadia 0.3.0.

### 2.0.0 — the subtraction (P1, UPGRADE.md v12 §4) — 2026-11-17

**BREAKING.** The On-ramp cut: subtraction before addition.

- **S1**: `src/daemon/` deleted (13 files, 2,657 LOC) with its six CLI verbs
  (`serve` `spawn` `steer` `kill` `panel` `eval`) and the pi-extension's
  worker-mode + `/vchat-family` lead surface. Dead-code proofs (family-wire
  import = transport.ts comment only; zero verb consumers; GZONE plan
  NOT-EXECUTED) recorded in [docs/P1_SUBTRACTION.md](docs/P1_SUBTRACTION.md).
  One-host family orchestration is pi-a2a's module; cross-host stays Tier P/W.
- **S2**: CLI table merged 24 → 10: `vclaw` (the verb table) + lifecycle
  top-levels `onboard` `retire` `uninstall` `start` `runtime` + infra
  `mcp` `update` `check-update` `pears`. Removed: `status` `health` `clear`
  `logout` `reset` `offline` `online` (→ the `vclaw` table) and `keygen`
  `export` `import` (consumer census: zero invocation sites in
  vclaw-desktop, the funnel, and hosts). The bundle codec stays a library
  export.
- **S3**: alias-release per the v11 pattern — the legacy `/vchat-*`
  extension commands carry deprecation pointers; `/vchat-family` is removed
  (a pointer-only stub). The remaining five delete in the next release.
- **S5 (E33)**: the MCP fabric tools dial the JWT path
  (`connectFabricOneShot`: static `credentials.jwt` or a vgate mint) — the
  measured `Authorization Violation` on bare-NKey CONNECT made every fabric
  verb dead against the operator-JWT server.
- Version 2.0.0; vclaw-desktop's vendored pin bumped in lockstep (C9).

#### Added / Fixed — the human sign-in plane works end to end (2026-11-16)

**The chain, proven live:** `vclaw signin` → IdP authorize (PKCE S256) → loopback callback →
token exchange → `iss` verified against the **discovery issuer** → `vgate /v1/session/resolve`
(audience accepted) → human store `0600` → silent remint before expiry. Signed in as
`chance@vchat.email` (segment `vcc`, 7 groups); `id_token exp` advanced unattended twice.

- **`iss` is verified against the IdP's discovery document, never the origin constant.** Autentico
  scopes its issuer to the OAuth surface (`https://auth.vclawhub.com/oauth2`); comparing against
  `https://auth.vclawhub.com` rejected **every** live id_token. `OIDC_ISSUER_FALLBACK` is the
  path-scoped value, used only when discovery is unavailable. Regression test: a token with the
  origin as `iss` is refused (`src/vclaw/human-auth.ts`, `test/unit/vclaw-human.test.ts`).
- **Endpoints come from discovery** (`/oauth2/*`), not the Authelia-era `/api/oidc/*` constants.
- **Fixed loopback redirect**: `http://localhost:41720/callback` (env `VCLAW_SIGNIN_PORT`), because
  the IdP matches redirect URIs byte-exactly — an ephemeral port can never match a registration.
- **Listener leak closed** (`src/vclaw/verbs/signin.ts`): one idempotent `finish()` is the only exit
  — `clearTimeout` → `srv.close()` → `closeAllConnections?.()` → settle — on all four paths
  (happy, `error=`, timeout, `EADDRINUSE`), with `Connection: close`. Live evidence before the fix:
  a `signin --wait 600000` process held :41720 for 52 minutes past its window. After: URL printed at
  t+0.000, exit at t+3.001, port free, no zombie.
- **The URL is printed before blocking** (`VerbContext.onProgress`, fd-level `writeSync` in the CLI,
  `ui.notify` in the TUI). Previously `--wait` produced no link at all — nothing was ever emitted.
- **Wait capped at the pending TTL** (10 min) so a long wait cannot end in `invalid_state`.
- **`reauthRequired` only on `ReauthRequiredError`** (signin + `who`): a DNS blip no longer brands a
  healthy session as re-auth-required.
- **`login --wait` unit bug fixed**: it read seconds against the ms contract (an 8.3-hour poll for
  `--wait 30000`), now ms with the same 15-minute cap.
- Tests: 31/31 across `vclaw-human` + `signin-listener`; `tsc` clean. The 4 failures in
  `vclaw-cli-contract.test.ts` are **pre-existing** (reproduced at the pre-change commit).

- **Fixed (KI-16): the pending flag no longer outlives an approval.** `up` cleared nothing, so
  `status`/`doctor`/`init` (all gated on `state.ts:111`'s `hasPendingFlag()`) reported
  `claim pending` after a successful claim. `clearPendingFlag()` is now called on every observed
  approval: both `up` branches (`claimed:true`, and `login`'s `claim:"approved"`) and `login`'s
  **409 `already_claimed`** end-state. Verified live: `status` went `claim: pending → approved`,
  `pending: true → false`; `login` now answers "already authenticated (server-confirmed)".
  Regression: `test/unit/login-claim-flag.test.ts` (vitest) — clears on 409, keeps on a 500 control.

## [Unreleased]

### Fixed — messaging is at-most-once without inventing success (2026-11-02)
- **`inbox` drains instead of unsubscribing.** `unsubscribe()` discards frames nats.js had already
  buffered, so messages arriving in the last milliseconds of the window were lost forever; the verb now
  awaits `sub.drain()` (bounded) so buffered frames reach the spool. Regression: a fake subscription that
  only yields when drained records both frames.
- **A broker-DENIED publish is exit 3, never `published`.** A `-ERR 'Permissions Violation for Publish'`
  arrives asynchronously as a `nc.status()` error and never rejects `flush()`; `send` now watches status
  across the publish window, fails closed, and claims no digest/delivery. Regression asserts exit 3 and
  the absence of any success claim.
- **`send --id <uuid>`** is validated (usage, exit 2) and used verbatim (normalised) so an operator retry
  can carry the same id and receiver dedupe can collapse it; `idSource` says whether it was caller-supplied.
- **The spool survives two writers.** `appendFor` takes an exclusive `<spool>.lock` (O_EXCL, bounded wait)
  around read-max-seq + dedupe + append, and dedupe is authoritative at read time; concurrent writers can
  no longer share a `seq` or duplicate a record.
- **`prune` merges instead of truncating.** It rewrites via temp + rename under the same lock, re-reads
  after its snapshot and keeps every line whose dedupe key was not in it; a torn tail or a shrinking file
  makes it refuse (return 0) rather than drop mail.
- **JWT scope never defaults.** `scopeFromJwt` now leaves `tenant`/`segment` undefined when the token grants
  neither; `who` uses the shared parser (its duplicate is gone) and refuses (3) rather than reading the
  literal `"default"` segment.
- **URLs and upstream bodies are redacted.** `scheme://user:pass@host` → `scheme://***@host`, and
  `Bearer`/`Basic` credentials are stripped from gateway response detail, on every fabric/who/sync surface.

### Fixed — the release artefact is now an allowlist with a gate that fails closed (2026-11-01)
- **`package.json#files` is an allowlist** (`bin`, `dist`, `skills`, + `README.md`, `UPGRADE.md`,
  `CHANGELOG.md`, `jsr.json`): the previous `.npmignore` was a *denylist* read from the **filesystem**,
  so a gitignored `package/.env` carrying an **npm token and a jsr token** shipped inside a published
  tarball. Two independent defences now: the allowlist, and `!**/.env` / `!.env` / `!**/*.env` beside it.
  `.github/`, `packages/`, `docs/`, `scripts/` and `E2E_tests.md` were dropped from the package; the shape
  went **433 → 353 files**.
- **`scripts/verify-pack.mjs` fails closed** on three classes: required files absent, forbidden paths
  (tests, `src/`, a stray root `*.tgz`, `.env*`/`.pem`/`.key`/`.creds`/`id_*`/`*secret*`), and any packed
  path outside the allowlist. Mutation-proved with a planted `.pem` (`should not ship: docs/zz-mutation.pem`).
  It also reads the verb table out of `src/vclaw/run.ts` and requires every verb in the shipped
  `dist/vclaw/run.js` — a stale `dist/` (skipped `tsc`, truncated build) is a gate failure, not a silent ship.
- **No baked self-pin.** The e2e harnesses carried `ARTIFACT_SHA` defaults that could only ever name the
  **previous** pack (`88a14d16`'s scripts pinned `ab038e06`; repacking yielded `6707af69` whose copy pinned
  `88a14d16`) — unsatisfiable by construction and a permanent false alarm. The default is gone; the digest
  comes from **outside** the artefact. The harness no longer ships inside it either.
- **`dist/agent.js` (+ `.sha256`) is packaging-excluded, not deleted**: it is the hosting surface for
  `vclawhub.com/agent.js`, regenerated by `build:cli-bundle`. Packing it would duplicate the CLI in the
  tarball (1.8 MB); deleting it from the checkout starves the install funnel while every gate stays green.

### Added — the alpha artefact and installer, staged and attested (2026-11-01)
- **`vclawhub-agent-1.5.0.tgz`** — 921,619 B, **353 files**, sha256
  `07ff87a52a88dd98c56ce79d126b16481794694886df58b121cbd5697635cc7f`.
  `node scripts/verify-pack.mjs` → `OK — 353 files, 14 verbs (status doctor init send inbox up login logout
  reauth signup who down peers provider) all present in dist/vclaw/run.js, both bundles present, no tests
  shipped, allowlist clean`.
- **Installer** `https://vclawhub.com/agent.js` — **1,858,301 B**, sha256
  `aca7cd785443ed26f20913ba213c3ea6939b7ade837c0b4f971df246815e3721`, produced by
  `bun run build:cli-bundle` (654 modules, 3 smoke gates in an empty dir with zero registry access) and
  **byte-identical** to a fresh local rebuild; the served `.sha256` sidecar agrees. Staged at
  `landing/public/agent.js`.
- **Alpha status: PREPARED, NOT PUBLISHED.** Nothing was pushed to npm or jsr and no network write was made.
  Blockers before alpha ships: credential rotation (npm token, jsr credential, Cloudflare token, two NATS
  user keys), the undeployed `/v1/agent/claim-link` route (404 on GET and POST), and the live-fabric leg
  of `send`/`inbox`/`peers`, which remains unproven. Full evidence: `docs/lanes/ALPHA_RELEASE_2026-11-01.md`.

### Added — the CLI proof surface is a full verb × state matrix (2026-11-01)
- **`scripts/e2e-vclaw-matrix.sh` (new):** 14 verbs × 5 states (identity-present · no-identity · pending ·
  usage · fabric-down), each row in its own HOME, asserting the exit code AND the envelope from that row's
  own output (`code === exit`, no `data.code`, exit ∈ `{0,2,3,4}`, a refusal's `error` is a REASON). The
  `pending` state is seeded offline (generated unclaimed key + `.pending` + a local 403 stub) and
  `fabric-down` is a closed loopback NATS port with the gateway reachable, so class 3 and its "names the
  fabric" requirement are deterministic. Unreachable states print **UNREACHABLE** with a reason and show
  as `U` in the table — never skipped.
- **`scripts/e2e-vclaw-usage.sh`:** extended past its 22 rows — the no-identity section is now a per-verb
  TABLE (the blanket "4 everywhere" was false for `logout`, `provider list`, `signup`, `up`), plus the new
  verbs: `logout` (default makes no HTTP call — asserted against a closed gateway port — and `--revoke`
  does), `reauth`, `down`, `provider list` against a `models.yml` fixture, and `init`'s 4-with-next-command.
- **Measured (this host, model-free, `env -i`):** 87/88 matrix rows pass; the single failure is
  `logout --revoke` with an unreachable gateway, which exits **3** correctly but whose `error` is the
  verb's banner `"logged out"` instead of the reason (the revoke failure is only in `data.revoked`) — the
  same D5 class the harness exists to catch. `down` and `up` also exit 3 against the deployed gateway
  (it answers `404` on the presence endpoint); `inbox --sync` exits 3 on `404 page not found`.

### Added — session mailbox: at-most-once becomes durable while a session runs (2026-10-31)
- The extension now subscribes the **IDP-fabric** mailbox subject (`tenant.<t>.a2a.<self>.>`) at
  `session_start` and drains it into the same spool the CLI reads — same builder (`vclaw/mailbox.ts`), same
  bytes. `subA2A` listened on the SDK taxonomy plane (`a2a.<nkey>.>`), which `send` never publishes to, so a
  DM sent while nobody ran `inbox` was lost.
- **Measured:** TUI open and idle, omp-1 sent `sent while idle`; the spool held it (`seq 1`) before any
  `inbox` ran, and the TUI rendered it. The same test previously lost the message.
- Still true and now stated in the spec: durable **while a session is open on that host**; with no session
  running there is no replay (that needs a broker-side durable consumer this fabric does not grant).

### Fixed — FS2 was missing from the TUI surface (2026-10-31, found by the desktop mirror)
- **`/vclaw send` and `/vclaw inbox` did not exist in the pi-extension bundle** (TUI answered
  `unknown verb`, exit 2) while the CLI had both: `npm run build` was `tsc` only, so the self-contained
  bundle kept the previous verb table *and* the pre-fix exit classification. Every CLI-side measurement
  passed against a stale shipped surface.
- **`npm run build` now rebuilds the extension bundles** (`tsc && npm run build:extensions`), so the CLI and
  the TUI cannot disagree without the build failing to produce one of them.

### Fixed — vclaw exit class + spool filename (2026-10-31, found by the desktop mirror)
- **`inbox` leaked exit `1`** in the no-identity state: `openFabric` threw a plain `Error`, so the generic
  catch produced a code outside the frozen set `{0,2,3,4}`. Fabric-backed verbs now classify by cause —
  no credentials / no granted mailbox → **4**, cannot reach the fabric → **3**. Measured with an empty HOME:
  `inbox`, `status`, `who` all exit **4** with `json.code 4`.
- **Spool filename is now `<tenant>__<self8>.jsonl`** (`self8` = first 8 chars of the own nkey, with the read
  set alongside as `<tenant>__<self8>.read.json`). Two identities on one host can no longer interleave into
  one `seq` space. Measured on the fleet: `vclaw__UBNBJ35N.jsonl`. Renamed now because zero external
  consumers exist; after the desktop ships this becomes a migration.

### Changed — the vclaw machine contract, frozen with the consumer (2026-10-31)
- **`code` is top-level on every verb result** and always equals the exit code (`who`/`status` no longer
  disagree); CI asserts one surface.
- **`to`/`from` are NKeys**, with an optional display `name`/`fromName` alongside — never a name alone.
- **`digest` is specified**: `sha256` hex over the exact frame bytes; `send` names the algorithm
  (`digestAlg`). Nonce-ish fields (`ts`/`id`/`conversationId`) are asserted structurally, not byte-equal.
- **Inbox spool is a consumer contract**: `~/.vclaw/inbox/<tenant>.jsonl`, 0600, append-only with
  `kind` first and a monotonic per-file `seq`; `conversationId` carried opaquely; `--prune` is opt-in
  (the only rewrite); the file is a mirror and the verb is the source of truth. One identity per host is
  assumed — a second would share the tenant file.

### Added — Feature Set 2: `send` + `inbox` (2026-10-31)
- **`vclaw send <peer> <text…>`** — one DM on the fabric: `a2a_request` envelope to
  `tenant.<tenant>.a2a.<peer>.req`, tenant derived from the identity's own JWT. The peer id must be ONE
  concrete subject token (dots, wildcards and spaces are refused, so a caller cannot retarget the subject).
- **`vclaw inbox [--wait ms] [--all]`** — a durable local spool at `~/.vclaw/inbox/<self>.jsonl` (0600),
  append-only, with read state in a separate atomically-written file; dedupe by envelope id with a content
  digest fallback; `prune()` caps at 2000 lines and never drops unread mail.
- **Measured cross-container**: omp-1 → omp-2 delivered and spooled; a second `inbox` reported `unread: 0`
  (read state persisted); `--all` showed `read: true`.
- **Stated limits**: no standing subscription yet (a DM sent with nobody subscribed is lost — the fix is a
  mailbox subscription inside the long-lived extension); threading carried but not surfaced; `from` is
  self-asserted and is labelled as such in the human view.

### Added — assertable TUI output (2026-10-31)
- **`/vclaw` appends every invocation to `~/.vclaw/vclaw-out.txt`** (`=== <iso> /vclaw <args> exit=<n>` + the
  rendered text, 0600). A pty only keeps the cursor region, so TUI output was unassertable in CI; this makes
  it a file. Verified in a container TUI on the shipped artefact: both invocations captured with verb, exit
  code and full text. Failures to write are swallowed — diagnostics must never break the command.

### Fixed — G14 reply correlation in the P2P session bridge (2026-10-31)
- **One prompt in flight.** `createBridge` pushed every inbound and immediately injected it, then replied to
  the OLDEST queued stream on every `turn_end` — so two inbound callers could swap answers, and a turn the
  local operator typed replied to a remote caller with text they never asked for. Prompts now queue and the
  next is injected only when the previous turn ends; a `turn_end` with nothing in flight answers nobody.
- **Known limit, stated and tested:** the host gives no correlation id, so while a remote prompt is in
  flight the operator's own next turn is attributed to it. `test/bridge-correlation.test.ts` pins both the
  fix and the limit. This unblocks the `inbox`/`send` half of Feature Set 2 (E31).

### Fixed — `/vclaw` in the real OMP TUI (2026-10-31)
- **`/vclaw` threw `result is not defined` in the TUI** — the handler read `result.data` while destructuring
  only `{ exit, text }`; a same-named binding elsewhere satisfied `tsc`, so the error was runtime-only and
  invisible to every non-TUI test. Surfaced by driving the real TUI in a container (tmux + `setupVersion: 2`
  preseeded). `/vclaw status` and `/vclaw who` now render their text there, measured on the final artefact.

### Fixed — fleet e2e loop (2026-10-31)
- **`who` derives its segment from the identity's own JWT** (`segmentFromJwt`). Hardcoding `default` failed
  with `Permissions Violation for Subscription to "$SRV.INFO.agents.default.>"`; the granted segment is
  `vclaw`, and a denial is now a clear answer rather than a stack trace.
- **`status --deep` reconciles with the server** and exposes an explicit `claim: none|pending|approved`.
  A claim approved elsewhere no longer reads PENDING forever, and `steward` is reported as "not disclosed"
  when the anonymous status call returns only `{claimed:true}`.
- **`scripts/e2e-vclaw-fleet.sh`** — install → signup → server-side approve → reconcile → `who`, per
  container. Measured on three containers: all claimed; cross-container discovery on segment `vclaw`.

### Security — Feature Set 1 audit, holes plugged (2026-10-31)
Nine findings from an adversarial review of `signup`/`who`; five fixed here, the rest documented:
- **`who` no longer trusts announcement JSON.** It previously parsed the payload directly, so any publisher
  could display itself under another agent's nkey and `who` would show the victim. It now ingests through
  `Directory` (`subject-pin + ed25519 sig + schema + TTL + replay`), and the verb reports
  `accepted`/`rejected` counts so a rejected record is visible instead of silently absent.
- **Backup files are `0600`.** `backupCredentials()` used `copyFile` at the umask default — a `--force`
  signup could leave a world-readable copy of the nkey **seed** beside the live one. Now `enforceSecretMode`.
- **A failed backup aborts the signup** instead of being swallowed and then overwriting the old identity.
- **The claim URL's proof is bounded** to 24 h (`expiresInSeconds`) instead of having no `exp` at all.
- **The proof stays out of structured output** unless the caller passes `--with-proof`: `--json` consumers
  are log pipelines far more often than browsers.
- **`openBrowser()` no longer builds a shell string.** It was `exec(\`open "${url}"\`)`, injectable through
  `CLAIM_BASE_URL`; it now spawns with argv and refuses any non-`https:` URL (`http:` only with `VCLAW_DEV=1`).
  The extension reuses this one implementation.
Still open and documented, not fixed: local `argv` exposure of the claim URL while an opener runs (mitigated
by the 24 h proof life), display-name squatting (inherent to self-asserted names), and `VCLAW_CREDS_DIR`
env-injection (absolute-path/world-writable checks not yet added).

### Added — Feature Set 1: signup + who (2026-10-31)
- **`vclaw signup` / `/vclaw signup`** — new-user signup over the classical vclaw auth link: mints or
  resumes an identity, calls `/v1/agent/introduce`, mints the ed25519-nkey **approve-proof**, prints the
  claim URL, and (TUI only) best-effort opens it. `--wait <s>` polls for approval and completes
  (`completeSignup`). Verified in the **installed state** on a fresh container.
- **Crash-safety fix in the signup ordering:** the identity seed is persisted **before** the `.pending`
  flag, so "a claim is pending" always means "the seed is recoverable" (the historical `onboard()` wrote
  the flag first and could strand a claim).
- **`vclaw who` / `/vclaw who`** — read-only "who is around" from **signed announcements**, because the
  minted agent JWT cannot use Micro discovery on this fabric (`$SRV.PING/INFO` → Permissions Violation).
  Verified end to end on the live fabric.
- **Packaging trap #2 (found via the desktop lane):** `dist/cli.js` is **gitignored** (`dist/*` with
  exceptions only for the two extension dirs), so a clean checkout ships no CLI and a `npm pack` without
  `tsc` ships a stale one — observed as `unknown command 'vclaw'`. Pinned artefact digests are recorded in
  `src/vclaw/README.md` §11a; a post-pack gate (five verbs + `command("vclaw"`) is specified.
- **Packaging trap fixed in the process:** `npm pack` shipped a **stale** `dist/` (tsc output predated the
  new verbs) — the CLI answered `unknown verb "signup"`. Always `npm run build` before `npm pack`; the
  tarball is now asserted to contain all five verbs.

### Added — `/vclaw`, the model-free operator surface (roadmap A, 2026-10-31)
- **`vclaw-agent vclaw <verb>`** and the **`/vclaw <verb>`** TUI command: `status`, `doctor`, `peers`.
  Built to run with **no LLM configured** — no prompt templates, no model calls, no interactive input.
- One **verb table** drives every surface (CLI, TUI text, completions); `--json` is the machine surface
  with a stable shape (`{ok, verb, state, data}`) and exit codes `0 · 2 usage · 3 dependency ·
  4 identity-not-ready`. `status` answers truthfully with nothing configured; `doctor` prints every
  check with the command that fixes it; `peers` reads local rosters only and labels rows `cached`.

### Fixed — v11 P0 (Synadia v0.3 conformance, 2026-10-31)
- **§9.2/§9.3 refusals are emitted on the prompt endpoint.** Bad input is no longer accepted or
  silently downgraded: empty payload, malformed JSON envelope, oversize (`max_payload`), and an
  attachment when `attachments_ok=false` each return `Nats-Service-Error-Code: 400` followed by the
  empty terminator. Verified live on the site fabric: four refusals with `code=400, bytes=0`, and a
  valid envelope answered normally.
- **§5.2 `attachments_ok` is truthful.** It defaulted to `"true"` while nothing consumed attachments;
  it now defaults to `"false"` and the endpoint **refuses** an attachment instead of dropping it.
- **§3.1 `version` is the harness semver.** `startSynadiaAgent({ harnessVersion })` wins over this
  bundle's version; the extension passes `VCLAW_HARNESS_VERSION`. Measured on the wire: `99.1.2` when
  the host supplies it.
- **§3.2 `session`** is set from `SYNADIA_SESSION` (verified on the wire as `p0-session`).
- **Publish set (G11/E40):** `jsr.json` `publish.include` gains **`dist/**`**, so the artefact now
  carries the two bundles `pi.extensions` declares (`jsr publish --dry-run`: 80 → **82 files**, both
  `dist/*/index.bundled.js` present). `packages/**` was tried and **removed** — jsr silently publishes
  nothing from it, and `@vclawhub/ext-synadia` ships that source on its own.

### Design
- **`/vclaw` — one model-free operator command**: `status · doctor · peers · inbox · send · ping · claim ·
  connect · family · watch`. Spec: [`src/vclaw/README.md`](src/vclaw/README.md). It works with **no LLM
  configured** — OMP runs local command handlers without a model (`agent-session.ts:7249-7278`) while
  non-interactive `omp -p` requires one, so automation belongs to `vclaw-agent`, never to `omp -p`.
- The ten legacy slash commands (`/vchat-*`, `/synadia-*`) become **aliases for one release**, then are
  removed; the plane becomes a `--tier` flag rather than a name prefix (operator ruling 2026-10-30).

## [1.5.0] — 2026-10-25

**Tier P becomes installable, and operators can see whether it works.** Before this release the P2P
stack was built and tested but reachable only from a repo checkout: the node helper was excluded from
`tsconfig`, `dist` and the npm tarball, so every installed agent answered `p2p_unavailable`.

### Added
- **`vclaw-agent pears status`** (`--json`, `--require`) — the read-only answer to "does Tier P work on
  this host?": helper build, node/version floor, dependency tree, helper socket, known delegations.
  `--require` exits 4 when unavailable so scripts and tests can assert it without parsing prose.
- **`scripts/build-pears-sidecar.mjs`** — packages the helper as its own artefact
  (`dist/pears-sidecar.tgz` + sha256, built tree staged in `dist/pears-sidecar/`). The dependency tree
  is deliberately NOT vendored: the installer runs `npm ci --omit=dev` so the native module matches
  that host's node ABI, not the packager's.
- **`npm run build:pears-sidecar`** and **`build:all`**.

### Changed
- **`resolveSidecarDir()` learns the install layout**: `~/.vclaw/pears/sidecar` is now the first
  candidate (the helper is a per-host singleton, so its home is user-level), ahead of the repo layout.
- Version 1.5.0 (jsr.json + package.json). Nothing had been published since 1.4.0 on 2026-10-03, so
  every M1–M3.5 change rides this release.

### Verified (POC, 3 incus containers + macOS arm64)
- 20 MiB artifact cross-host: put 199 ms, get 467 ms, sha256 identical; range read at 1 MiB: 65,536 B in 4 ms.
- Encrypted pub/sub cross-host: publisher `peers: 1`, receiver digest identical, payload byte-exact.
- Non-member (base key, no content key): connected, dialed, and received **nothing** — no error, 0 bytes.
- Degradation: with node off `PATH`, unavailable is reported explicitly (exit 4 with `--require`).

### Known gaps (tracked, not fixed here)
- `bindHost: "0.0.0.0"` is rejected by the sidecar (`E_OP: Invalid host`); a peer must pass its own
  interface address. *(Fixed in helper 0.3.1 the same sprint — E19: a wildcard/absent bind resolves
  to the first non-internal IPv4 and is advertised in the ready hello.)*
- `p2pTransport` still has zero production call sites — same-owner message routing (M4) is unimplemented.
- No delegation-row creator and no sealed-key distribution yet: the POC distributed the content key and
  base keys out of band.
- **Per-invocation private stdio helpers (root-caused 2026-10-29, BACKLOG E24):** `SidecarClient.start()` joins a
  live helper only when a **listen-mode socket** exists; otherwise it spawns a private stdio helper bound to that
  invocation's store, which dies with the process. Two standalone invocations (`pears put`, then `pears get`) are
  therefore two helpers and two stores — the reader's core is empty and there is no live writer to replicate from,
  which surfaces as *"artifact blocks not available"*. **The transport itself is sound:** a cross-container 1 MiB
  artifact (pears-1 → pears-2, both in listen mode, DHT bootstrap) completed in **42 ms with an identical sha256**.
  Earlier phrasings of this gap ("store-dir is silently ignored on connect", "hypercore replication does not sync")
  were both wrong; this one is measured. Fix: all CLI/POC surfaces go through `attachHelper`, and a store mismatch
  against the live helper is refused loudly.

## [1.4.0] — 2026-10-03

### Added
- **Conversation identity and ordering on H2A and A2A** (Phase 1 of the session-sync design, additive only):
  `messageId` (UUIDv7) and `conversationId` on `PromptMessage` — now **validated** on parse, where the frame
  was previously `JSON.parse`d unchecked; `Chunk.conversationId` set on every reply; A2A `inReplyTo` (the
  schema had zero writers) and `from.sessionId`; a per-conversation monotonic `seq` plus `parentMessageId`
  on both planes.
- Session entries carry `uid` + `seq`, and `head_id` is the entry's globally-unique UUIDv7 `uid`. The 8-hex
  file-local ids stay in the file: unique only within one file, they collide if exported to a global namespace.

### Changed
- A reply chunk with no `conversationId` is **rejected loudly** — `no conversationId … routing is impossible,
  frame discarded` — instead of vanishing silently. The outcome is unchanged for such frames (they were
  already discarded); the diagnostic is the fix. In a matched fleet the producers now set the field.

### Fixed
- The four stale subscription fixtures that failed at baseline (`ext-upgrade` ×2, `ext-retire` ×2): they
  invoked the callback with no `subject` while it correctly returns early without one. Fixed in the fixtures,
  not by relaxing the guard (byte-identical to before; 651 passed / 651).

