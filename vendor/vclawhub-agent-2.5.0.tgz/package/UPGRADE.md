# agent-sdk UPGRADE.md — The On-ramp Upgrade (v12)

> 🚀 **THIS IS THE ACTIVE PLAN (2026-11-16), OVERRIDING ALL PRIOR DESIGN AND IMPLEMENTATION
> PLANS IN THIS FILE.** Everything below the `── HISTORICAL ──` separator is a dated record —
> read it for context, never as a commitment. The supersession table in §0 states exactly what
> each prior plan contributed and what it ceded to this one.
>
> **Deep-research base (three read-only lanes, all findings measured with file:line evidence):**
> the pi-a2a absorption reality check (≈30–35% feature coverage, ≈15% wire-equivalent; canon
> Q3 rules against full absorption), the tailscale-way login reality check (agent-claim verb
> exists, human login absent, server half live, client gap M-sized), and the UPGRADE.md
> archaeology (supersession map + simplification inventory + invariants, 15.6KB at
> `.local/agent-sdk-overhaul-archaeology-2026-11-16.md`).
> **Cross-lane amendment (the absorption lane's closing deltas, folded in):** (1) the
> family/spawn row is PLAN-DEPENDENT — with §4's daemon deletion, pi-a2a coverage in
> agent-sdk falls to **~25–30%** and family orchestration moves onto the §2 port list (L);
> the honest baseline for this plan is the lower number. (2) The **LLM tool surface is the
> biggest single gap independent of the daemon**: pi-a2a exposes 8 in-session LLM tools,
> agent-sdk's pi-extension registers zero — §5's P2 therefore includes porting the
> a2a_* tool shape into the site-plane client's host integration, not only the wire features.

## 0. Supersession table — what each prior plan cedes to the On-ramp

| Prior plan | Status at cutover | What survives into v12 | What v12 retires |
|---|---|---|---|
| **v11** (conformance) | PARTIAL (P0 done) | ALL of P0's wins (G2 error emission, G3 truthful attachments_ok, G8 semver, G9 session, G11 publish-set), **G14** reply correlation, the consumer constraint, the model-free lint, C5 spec-pin. P1–P3's OPEN items are RE-SCOPED into v12's phases below | The ten-alias list (stale — seven real, zero synadia-*); P1's "retire one implementation" becomes §2's by-plane resolution |
| **v10** (Incus runtime) | LANDED-then-OBE | The **fabric-topology ruling** (Option A: containers ride host tailnet egress, per-link DNS, no SDK change) — canon, untouched | The one-container-one-agent deployment model, the baked image, profiles/volumes — zero live consumers; the image recipe moves to a dated appendix |
| **v9** (daemon orchestration) | LANDED-as-code, mostly UNWIRED | The envelope `family{}` fields (additive, stay in contracts) | **`src/daemon/` (2,657 LOC) + the 6 daemon CLI verbs + worker-mode** — the HIGHEST-VALUE deletion: family-wire's only import is transport.ts, the verbs have zero documented consumers, G1 live-run pending, GZONE pilot never executed |
| **v8** (JSR/bun) | LANDED | The bun pipe (THE funnel), `.npmrc` bootstrap, the CDN agent.js distribution of record | The npm-mirror transition window (never happened); JSR publish remains E20-blocked and is NOT a v12 gate |
| **v7.1 + v0.6** | DEAD | One principle: **verified-identity-only trust** (CLI labels carry zero server trust) | Everything else |

## 1. The one-paragraph design

**agent-sdk becomes the estate's single on-ramp: one install, three surfaces, two planes.**
The *install* is the existing bun pipe (unchanged). The *surfaces* are (a) `/vclaw` — the
model-free verb table, the operator and host contract; (b) the pi/omp extension — the session
integration; (c) the MCP server — the LLM tool surface. The *planes* are the tenant fabric
(`src/net`, NKey→JWT, vchat3 — unchanged wire) and the **site fabric** (the local
`127.0.0.1:14222` plane, where pi-a2a's feature set lands — see §2). The drastic
simplification is subtractive: delete the unwired daemon, merge the 24 CLI verbs into the
vclaw table + lifecycle verbs, resolve the dual implementations BY PLANE (never by deletion),
and add exactly one new capability — **the human login**, the tailscale-way verb that makes a
logged-in human the root of every agent they claim.

## 2. The pi-a2a question, resolved honestly

The research verdict: full absorption is ~30–35% true and **contradicted by canon** (V3.1 Q3
ruled pi-a2a a REF dependency; V3.2 moved same-owner A2A off the fabric). The On-ramp reframes
the goal instead of porting everything:

- **Site plane = pi-a2a's home, consumed not inlined.** `packages/ext-synadia` already speaks
  pi-a2a's fabric (its subjects are a hoist of pi-a2a's protocol builders). v12 GROWS this
  package into the site-plane client — porting the features the research marked absent
  (group messaging M, JetStream offline delivery L, rate limiting S, buddy-into-core M,
  chain/parallel L) **as site-plane modules**, not into `src/net`. pi-a2a itself remains the
  omp extension (its own release train, now 0.5.5); when a feature lands there first, the
  port to ext-synadia is a same-fabric port, not a redesign.
- **The identity convergence is already designed.** pi-a2a's 0.5.5 lineage stream carries
  `kind`/`seg` — the registry groundwork whose 0.7 phase (NKey signatures) makes a site-plane
  identity verifiable the way the tenant plane's announcements already are. v12 consumes that
  design; it does not fork it.
- **Same-owner A2A stays off the fabric** (V3.2): the daemon's replacement for family
  orchestration on one host is pi-a2a's family module (it exists, it works, it is the
  estate's actual multi-agent reality) — another reason the daemon deletes cleanly.

**Port order (site-plane modules, each independently shippable):** rate limiting (S) →
dedup/ping/purge tooling (S each) → group messaging (M) → buddy protocol into the site client
(M, ext-synadia's skeleton is the start) → JetStream offline delivery (L — needs the stream +
consumer grants on the local server, which the local plane's token trust makes trivial) →
chain/parallel workflows (L, ports pi-a2a's executeChain/executeParallel) → the lineage/
registry stream consumption (M — read pi-a2a's AGENTS_IDENTITY from the SDK side once 0.7
lands).

## 3. The human login — `/vclaw signin` (the tailscale way)

The research verdict: the verb-shaped surface exists, the human flow does not; the server
half (vgate `/v1/session/resolve` → 24h device JWT + `vchat_humans` registration) is live;
a working OIDC-PKCE client (vizshare/oidc.ts, 532 lines) sits in vclaw-desktop as the
template. The design:

```
/vclaw signin                          /vclaw signout                     /vclaw who
  │                                       │                                  │
  ▼                                       ▼                                  ▼
1. generate/persist a HUMAN           drop the human store;             report BOTH
   device NKey (~/.config/vclaw/      POST /v1/session/revoke           identities:
   human.json, 0600 — the             (server route exists; the         agent (claim
   tailscale "node key")              24h JWT TTL is the                state) and
 2. run OIDC auth-code+PKCE           backstop, documented               human (segment,
   against auth.vclawhub.com          arming gap)                       groups, JWT exp)
   (the vizshare pattern, moved
   into src/vclaw/ — print-URL
   + --wait, satisfying the
   no-browser-auto-open mandate)
 3. exchange id_token via
   POST /v1/session/resolve           SILENT RE-AUTH:
   → {human_uuid, email, segment,     a timer re-mints the device
      groups, nats_jwt (24h)}          JWT from the stored refresh
 4. persist the session in the         token before expiry (the
   human store                        agent reauth pattern,
                                       human-paced)
```

**The mandate reconciliation** (research gap #7): print-URL + `--wait` polling — the existing
`login` shape — satisfies both the no-browser-auto-open rule and the tailscale pattern; the
desktop (which CAN open a browser) consumes the same verb via `--json` and opens the URL
itself.

**The verb naming** (gap #1): `login` stays the agent-claim verb (shipped, consumed by the
desktop's vendored 1.5.0); the human verb is **`signin`** — distinct name, no flag ambiguity,
the table generates all three surfaces from one row.

**What the desktop gets** (gap #6): the human store lands in the agent-sdk layout it already
reads (`vclaw-sdk-root.ts`); its 80%-built consumption path (extension injection, spool,
credential paths) gains the last 20% — an IPC surface invoking `signin --json` and a
renderer-visible auth status. A human NATS connection in the desktop's main process is
**deferred**: the inbox spool the desktop already tails is the v1 path; the connection is
v2 (and is exactly the H2H×A2A conv-grammar's consumer once that canon amendment is ruled).

## 4. The simplification (subtractive, with proofs)

| # | action | size | dead-code proof required (v11 §8 standard) |
|---|---|---|---|
| S1 | **Delete `src/daemon/` + its 6 CLI verbs + worker-mode in pi-extension** | 2,657 LOC + 6 verbs | grep family-wire imports (transport.ts only), verb consumers (zero outside UPGRADE), GZONE plan status (NOT-EXECUTED) — re-run at deletion time |
| S2 | **Merge the CLI verb table**: 24 → the vclaw table + `onboard`/`retire`/`uninstall`/`start`/`runtime` as lifecycle top-levels; delete `keygen/export/import` if the consumer census clears them | ~2,700 LOC restructured | consumer census: vclaw-desktop's spawn contract (`--json`), the funnel, hosts |
| S3 | **Alias-release then delete the 7 live legacy aliases** (`vchat-*`) | 7 commands | v11's alias pattern, one release, deprecation pointers |
| S4 | **Resolve dual implementations BY PLANE** (never delete): presence/directory/heartbeat/identity exist twice because there are two fabrics — document each as site-vs-tenant in the package headers; E39's "one implementation" is answered: one per plane | 0 LOC deleted | the G16 table annotated |
| S5 | **The MCP E33 decision**: fix `connectViaNKey` → the JWT path for the fabric tools, or cut them to the working set — decided in P1 below | TBD | E33's measured Authorization Violation |
| S6 | **Absorb the unsealed CHANGELOG block + the five baseline discrepancies** (stale alias list, path-stale refs, funnel-of-record correction, the 146K false-size) into this plan's baseline section | doc-only | the archaeology's discrepancy list |

## 5. Phases (dispatch-ready, each gated)

| phase | content | gate |
|---|---|---|
| **P0 — the human login** | `/vclaw signin/signout` + the human store + the resolve client + silent re-mint; vizshare's OIDC client ported into `src/vclaw/` under the mandates | a fresh host: `signin` → browser → a persisted human session; `who` reports both identities; JWT re-mints silently; desktop consumes via `--json` |
| **P1 — the subtraction** | S1–S3 + S5 (the E33 decision) + the version cut to **2.0.0** | dead-code proofs green; `npm pack` set == jsr dry-run set; vclaw-desktop's vendored pin bumped in lockstep (C9); the funnel chain unchanged (join.ts → agent.js hash-verified) |
| **P2 — the site-plane growth** | the port order of §2 (rate-limit S → tooling S → group M → buddy M → JetStream L → chain/parallel L). **Absorbed 2026-11-17 (operator-approved, ARC convergence digest §3):** the `group` module becomes **durable rooms** — JetStream-persisted room state + the `/topic` pinned directive + `/list` (a strict upgrade of subscription-IS-membership; grammar harvested verb-by-verb under `/vclaw`). **Pre-P2 design requirement:** the anti-storm MUST-NOT-trigger invariant — `action`/`notice`/`hb`/`presence` frame classes NEVER trigger LLM completions (groups × auto-reply = the storm risk; codified before the group port lands) | per-module: the same feature works on `:14222` via ext-synadia that works in pi-a2a today; the group module additionally: rooms survive a server restart, and a red-team gate proves non-triggering frames cannot cause a completion |
| **P3 — the convergence** | consume pi-a2a 0.7's signature-backed registry from the SDK's site client; the desktop's human NATS connection (the conv-grammar consumer, gated on that canon amendment) | a site-plane identity verifies the way tenant announcements do |

### 5.1 P2 group-module pre-port design requirements (all codified BEFORE the port starts)

Sourced from the room-authority scout pass (`.local/arc-room-authority-scout-findings-2026-11-17.md`, parent repo) — every citation verified by the lead; rulings 1+3 are the operator's (2026-11-17):

1. **Topic-write authority (OPERATOR-RULED, role-mint):** member ≠ topic-writer. A pinned topic is context injected into every joining agent — it is a capability, not a status line. Rooms become **role-bearing at mint**: the invite already mints `{principal, rooms, role}` (`vgate/cmd/nats-init/main.go:222`) while the binding carries only `rooms` (`:194`, read every mint) — the ruling extends the already-minted role through to the binding, and `DeriveClaimedPermissions` (`token.go:438`, deny-by-default) scopes `topic.write` by it. VIZREG precedent governs the shape: the broker only delivers, the engine decides (`token.go:~455`).
2. **Anti-storm (absorbed earlier, unchanged):** `action`/`notice`/`hb`/`presence` frame classes NEVER trigger LLM completions; red-team gate required.
3. **Membership surface (OPERATOR-RULED, roster-KV):** rooms are **roster-KV keys** (identity truth, existing GC), NOT JetStream consumer state (transport truth). Enumeration ships as a read-only **`/vclaw names`** verb inside the approved grammar-harvest mandate (today `group.ts:82` lists only own subscriptions — an agent in a durable room cannot see its peers).
4. **Volume backpressure (design text, lands with the rate-limit port — first in §2's order):** per-sender token bucket; room stream `MaxMsgs` + `DiscardOld`; `notice`-class frames are never buffered to inbox. A decided answer in the designated layer — not an ad-hoc patch in the wrong one.

**Sequencing rationale:** P0 first because it is the only NEW capability and unblocks the
desktop's last 20%; P1 second because subtraction before addition keeps the 2.0.0 cut clean;
P2/P3 grow the site plane after the cut, each module independently shippable.

## 6. Invariants (inherited, non-negotiable)

1. Wire compat: `src/contracts` subjects + CLAIMED_AGENT grants + the protocol-core envelope — any change needs a vgate ruling, not an SDK release.
2. Publish set: jsr dry-run == npm pack; `pi.extensions` entries exist in every artefact.
3. Model-free `/vclaw`: the lint is a gate.
4. Import-side-effect-free: the consumer constraint, measured by vclaw-desktop.
5. The funnel: `curl …/join.ts | bun` + CDN agent.js, hash-verified — never broken by a release.
6. Verified-identity-only trust (v7.1's principle): CLI labels carry zero server trust; the human flow's identity comes from the IdP, the agent's from the claim.
7. Spec-pin: the v0.3 revision pinned in-tree, re-checked on bump.
8. Tier P optional-by-construction: no node → degrade to Tier W, never an error.

## 7. Compatibility gates to verify before P1's cut

- **C9 lockstep**: vclaw-desktop's ExpectedVersion pin must bump with 2.0.0 — enumerate its spawn contract first.
- **The consumer census**: every `vclaw-agent <verb>` invocation site in the estate (the desktop, the funnel, any host scripts) — the archaeology's starting list, re-run at cut time.
- **E33's fix-or-cut**: decided by measurement (a live JWT-path connect probe), not preference.

## 8. Non-goals

- **Not** porting pi-a2a's TUI panel into the SDK — panels are host surfaces; omp's panel stays pi-a2a's.
- **Not** re-enabling JSR publish as a gate — E20 (token) blocks it; npm + CDN are the distribution.
- **Not** a second orchestration story — the daemon's deletion is final; one-host family orchestration is pi-a2a's module, cross-host is Tier P/W per canon.
- **Not** the H2H×A2A conv grammar — that is the separate canon amendment (CONV_GRAMMAR doc, seven operator decisions pending); v12's P3 only consumes it if ruled.

---

*Plan of record: the operator's 2026-11-16 directive ("drastically simplify; the On-ramp
Upgrade; overriding any previous design"). Research base: three lanes, this session. Prior
plans: dated records below.*

── HISTORICAL ──
