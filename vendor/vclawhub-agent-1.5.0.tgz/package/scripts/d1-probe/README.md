# D1 Probe — SITE_MESH permission matrix (local-server harness)

Tests the V3.1 SITE principal grant set (`DeriveSiteMeshPermissions`,
`vgate/internal/agentidp/token.go:380-424`) at the wire: boots a scratch
local nats-server whose `site` user carries exactly those permissions, then
asserts each allow/deny cell of the D1 probe matrix
(`dash/docs/sprint-unified-a2a/03-v31-amendment-canon.md` §6) that is
testable on a single server (the `leaf→hub` column needs the live hub leaf —
D1's topology phase).

## Layout

| file | role |
|---|---|
| `site-mesh-perms.ts` | helper: emits the SITE_MESH permissions as nats-server config JSON — a faithful TS transcription of `token.go:380-424` (same grants, same order; `<agent>` placeholder kept literal, as in the landed Go) |
| `probe.ts` | connects as `site` (SITE_MESH) + `root` (control), runs the matrix, prints P/D per cell |
| `run.sh` | generates the server conf, boots nats-server on a scratch port, runs `probe.ts`, tears down |

## Run

```bash
cd agent-sdk
bun scripts/d1-probe/run.sh [site-id]     # default site-id: probe-site, port 45222
```

Prereqs: `nats-server` ≥2.10 on PATH, `bun`. No JetStream needed. The
scratch server writes nothing outside `/tmp`.

## Matrix implemented (site column of 03-v31 §6)

- ALLOWS: `$SRV.INFO.agents` / `$SRV.PING.agents` exact pub+sub; namespace
  verbs `agents.{prompt,hb,status,a2a,reply,buddy_*}.<agent>.<site>.>` pub;
  mesh-wide verb subs; `_INBOX.>` pub+sub.
- DENIES (negative probes): V3 announce `$SRV.INFO.agents.<seg>.<nkey>` pub +
  `$SRV.INFO.agents.<seg>.>` sub; other-site namespace pub AND sub;
  `tenant.<seg>.*` (a2a, audit.trade); `$KV.vchat_roster.>` pub;
  `$SRV.STOP.agents.<id>`; `$SYS.>` pub+sub.
- DIVERGENCE probes: doc-form kind subjects (`agents.prompt.pi.<site>.x`)
  vs landed literal `<agent>` form — records which actually passes.

Exit code 0 = all cells match expectations; 1 = any mismatch (CI-able).
