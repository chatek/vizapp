/**
 * probe.ts — D1 SITE_MESH wire probe (single-server column).
 *
 * Drives the nats CLI (per-probe fresh connection) against the scratch
 * server booted by run.sh:
 *   - pub probe:  nats pub <subject> — denial prints "Permissions Violation
 *     for Publish" and the CLI errors out.
 *   - sub probe:  nats sub <subject> --count 1 — denial prints "Permissions
 *     Violation for Subscription"; allowed-but-idle blocks and is killed by
 *     the timeout (counts as permitted).
 * The @nats-io JS client was tried first but does not surface server-side
 * permission violations synchronously (flush resolves, connection appears
 * healthy) — CLI wire behavior is the ground truth here.
 *
 * Exit 0 = every cell matches expectations; 1 = mismatches (printed).
 */

import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const PORT = process.env.D1_PROBE_PORT ?? "45222";
const SITE = process.env.D1_PROBE_SITE ?? "probe-site";
const OTHER = "other-site";
const SEG = "vchat";
const SITE_URL = `nats://site:d1-probe-site-pass@127.0.0.1:${PORT}`;
const ROOT_URL = `nats://root:d1-probe-root-pass@127.0.0.1:${PORT}`;

function resolveNatsBin(): string {
  const candidates = [process.env.NATS_BIN, "nats", join(homedir(), "go", "bin", "nats")].filter(Boolean) as string[];
  for (const c of candidates) {
    if (c.includes("/")) return existsSync(c) ? c : "";
    // PATH lookup
    const r = spawnSync("sh", ["-c", `command -v ${c}`], { encoding: "utf8" });
    if (r.status === 0 && r.stdout.trim()) return r.stdout.trim();
  }
  return "";
}

const NATS = resolveNatsBin();
if (!NATS) {
  console.error("nats CLI not found (set NATS_BIN)");
  process.exit(2);
}

/** Run a CLI probe with a hard timeout. Returns true = PERMITTED. */
function permitted(kind: "pub" | "sub", url: string, subject: string, ms = 2000): boolean {
  const args = ["-s", url, kind === "pub" ? "pub" : "sub", subject, ...(kind === "pub" ? ["d1-probe"] : ["--count", "1"])];
  const r = spawnSync(NATS, args, { encoding: "utf8", timeout: ms });
  const out = `${r.stdout ?? ""}${r.stderr ?? ""}${r.error?.message ?? ""}`;
  if (/violation|authorization/i.test(out)) return false;
  if (r.status === 0) return true;
  // Timed out (allowed-but-idle sub) → permitted; other failures → treat as denied harness error.
  return r.error?.message?.includes("ETIMEDOUT") || (r.signal === "SIGTERM" && kind === "sub");
}

interface Result { name: string; expect: "P" | "D"; got: "P" | "D"; note?: string }
const results: Result[] = [];
function cell(name: string, expect: "P" | "D", kind: "pub" | "sub", url: string, subject: string) {
  const ok = permitted(kind, url, subject);
  results.push({ name, expect, got: ok ? "P" : "D" });
}

async function main() {
  // ── Control sanity: root principal can do everything probed below ──
  const rootOk = permitted("pub", ROOT_URL, "agents.a2a.pi.control.sanity") && permitted("sub", ROOT_URL, "agents.a2a.pi.control.sanity");
  if (!rootOk) {
    console.error("CONTROL FAILED — root principal denied; server or harness broken, results invalid.");
    process.exit(2);
  }

  // ── ALLOWS (expected P under the landed grant set) ──
  cell("pub $SRV.INFO.agents (exact Micro)", "P", "pub", SITE_URL, "$SRV.INFO.agents");
  cell("sub $SRV.INFO.agents (exact Micro)", "P", "sub", SITE_URL, "$SRV.INFO.agents");
  cell("pub $SRV.PING.agents (exact Micro)", "P", "pub", SITE_URL, "$SRV.PING.agents");
  cell("sub $SRV.PING.agents (exact Micro)", "P", "sub", SITE_URL, "$SRV.PING.agents");
  cell(`pub agents.hb.<agent>.${SITE}.n1 (literal token via `*` wildcard)`, "P", "pub", SITE_URL, `agents.hb.<agent>.${SITE}.n1`);
  cell(`pub agents.prompt.<agent>.${SITE}.n1 (literal token via `*` wildcard)`, "P", "pub", SITE_URL, `agents.prompt.<agent>.${SITE}.n1`);
  cell(`pub agents.a2a.<agent>.${SITE}.n1 (literal token via `*` wildcard)`, "P", "pub", SITE_URL, `agents.a2a.<agent>.${SITE}.n1`);
  cell(`pub agents.buddy_request.<agent>.${SITE}.n1`, "P", "pub", SITE_URL, `agents.buddy_request.<agent>.${SITE}.n1`);
  cell("sub agents.hb.> (mesh-wide presence — protocol-fixed verb)", "P", "sub", SITE_URL, "agents.hb.>");
  cell(`sub agents.prompt.> (mesh-wide verb sub)`, "D", "sub", SITE_URL, "agents.prompt.>");
  cell(`sub agents.a2a.> (mesh-wide verb sub)`, "D", "sub", SITE_URL, "agents.a2a.>");
  cell("pub _INBOX.d1probe.1", "P", "pub", SITE_URL, "_INBOX.d1probe.1");
  cell("sub _INBOX.d1probe.>", "P", "sub", SITE_URL, "_INBOX.d1probe.>");

  // ── DENIES (negative probes — expected D) ──
  cell("pub $SRV.INFO.agents.<seg>.<nkey> (V3 announce — sites must NOT)", "D", "pub", SITE_URL, `$SRV.INFO.agents.${SEG}.ABCD123`);
  cell("sub $SRV.INFO.agents.<seg>.> (V3 discovery read)", "D", "sub", SITE_URL, `$SRV.INFO.agents.${SEG}.>`);
  cell("pub tenant.<seg>.a2a.x (IDP plane)", "D", "pub", SITE_URL, `tenant.${SEG}.a2a.x`);
  cell("pub tenant.<seg>.audit.trade.x (audit plane)", "D", "pub", SITE_URL, `tenant.${SEG}.audit.trade.x`);
  cell("pub $KV.vchat_roster.k (J4b KV-write retirement)", "D", "pub", SITE_URL, "$KV.vchat_roster.k");
  cell("pub $SRV.STOP.agents.svc1 (03-v31 §3 edge probe)", "D", "pub", SITE_URL, "$SRV.STOP.agents.svc1");
  cell("pub $SYS.REQ.SERVER.PING", "D", "pub", SITE_URL, "$SYS.REQ.SERVER.PING");
  cell("sub $SYS.>", "D", "sub", SITE_URL, "$SYS.>");

  // ── DIVERGENCE probes (doc-form vs landed form — recorded, not judged) ──
  const kindPub = permitted("pub", SITE_URL, `agents.prompt.pi.${SITE}.n1`);
  results.push({ name: `pub agents.prompt.pi.${SITE}.n1 (03-v31 doc kind-form)`, expect: "P", got: kindPub ? "P" : "D", note: "doc §2 table expects P; landed grants substitute only <site-id>, <agent> stays literal" });
  const otherKindPub = permitted("pub", SITE_URL, `agents.prompt.pi.${OTHER}.n1`);
  results.push({ name: `pub agents.prompt.pi.${OTHER}.n1 (cross-site send, doc form)`, expect: "P", got: otherKindPub ? "P" : "D", note: "03-v31 §6 expects P ([OPEN Q1])" });
  const otherSub = permitted("sub", SITE_URL, `agents.a2a.pi.${OTHER}.n1`);
  results.push({ name: `sub agents.a2a.pi.${OTHER}.n1 (identity-steal probe)`, expect: "D", got: otherSub ? "P" : "D", note: "03-v31 §6 expects D (namespace pin) — landed SubAllow is mesh-wide" });

  // ── Report ──
  console.log(`\nD1 SITE_MESH probe — site=${SITE} server=nats://127.0.0.1:${PORT} (nats CLI: ${NATS})\n`);
  let mismatches = 0;
  for (const r of results) {
    const ok = r.got === r.expect;
    if (!ok) mismatches++;
    const mark = ok ? "✓" : "✗";
    console.log(` ${mark} ${r.expect}→${r.got}  ${r.name}${r.note ? `  (${r.note})` : ""}`);
  }
  console.log(`\n ${results.length} cells, ${mismatches} mismatch(es) vs expectations.`);
  process.exit(mismatches > 0 ? 1 : 0);
}

main().catch((e) => { console.error("probe crashed:", e); process.exit(2); });
