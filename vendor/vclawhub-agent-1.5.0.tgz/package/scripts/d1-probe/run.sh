#!/usr/bin/env bash
# D1 probe runner — boots a scratch nats-server with the SITE_MESH grant set
# (transcribed from vgate/internal/agentidp/token.go DeriveSiteMeshPermissions)
# and runs probe.ts against it. See README.md.
#
# Usage: bun scripts/d1-probe/run.sh [site-id]
set -euo pipefail

SITE_ID="${1:-probe-site}"
PORT="${D1_PROBE_PORT:-45222}"
WORK="$(mktemp -d /tmp/d1-probe.XXXXXX)"
SERVER_PID=""

cleanup() {
  [ -n "$SERVER_PID" ] && kill "$SERVER_PID" 2>/dev/null || true
  rm -rf "$WORK"
}
trap cleanup EXIT

command -v nats-server >/dev/null || { echo "nats-server not on PATH"; exit 2; }
command -v bun >/dev/null || { echo "bun not on PATH"; exit 2; }

# 1. Generate the server conf (site user = SITE_MESH, root = control)
bun "$(dirname "$0")/site-mesh-perms.ts" "$SITE_ID" --conf > "$WORK/nats.conf"

# 2. Boot the scratch server
nats-server -c "$WORK/nats.conf" -l "$WORK/server.log" &
SERVER_PID=$!

for i in $(seq 1 50); do
  if nc -z 127.0.0.1 "$PORT" 2>/dev/null; then break; fi
  sleep 0.1
done
if ! nc -z 127.0.0.1 "$PORT" 2>/dev/null; then
  echo "server failed to boot — log:"; cat "$WORK/server.log"; exit 2
fi

# 3. Run the matrix
D1_PROBE_PORT="$PORT" D1_PROBE_SITE="$SITE_ID" bun "$(dirname "$0")/probe.ts"
