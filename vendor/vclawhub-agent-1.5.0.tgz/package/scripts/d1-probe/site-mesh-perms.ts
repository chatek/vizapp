/**
 * site-mesh-perms.ts — D1 probe helper.
 *
 * Emits the V3.1 SITE_MESH permission set as nats-server config JSON.
 * This is a faithful TS transcription of the CORRECTED Go implementation:
 *   vgate/internal/agentidp/token.go:380-424  DeriveSiteMeshPermissions(siteID)
 * — same grants, same order. Post-F1-fix shape: send verbs mesh-wide (Q8),
 * identity verbs site-pinned via `*` agent-kind token, sub side hb-only
 * mesh-wide (F3). The original F1-F3 findings live in 02 doc §g.
 *
 * Usage (bun):
 *   bun scripts/d1-probe/site-mesh-perms.ts <site-id>            # perms JSON
 *   bun scripts/d1-probe/site-mesh-perms.ts <site-id> --conf     # full server block
 */

export interface NatsPermissions {
  publish: { allow: string[]; deny: string[] };
  subscribe: { allow: string[]; deny: string[] };
}

/** Mirror of token.go:380-424. Keep in lockstep (conformance discipline). */
export function deriveSiteMeshPermissions(siteID: string): NatsPermissions {
  return {
    publish: {
      allow: [
        // SEND verbs (Q8): mesh-wide — bounded by admission/policy, not subjects.
        "agents.prompt.*.>",
        "agents.a2a.*.>",
        // IDENTITY verbs — pinned to THIS site's namespace (`*` = agent-kind; F1 fix).
        `agents.hb.*.${siteID}.>`,
        `agents.status.*.${siteID}.>`,
        `agents.reply.*.${siteID}.>`,
        `agents.events.*.${siteID}.>`,
        // Buddy protocol verbs (pi-a2a extension verbs, site-scoped).
        `agents.buddy_request.*.${siteID}.>`,
        `agents.buddy_accept.*.${siteID}.>`,
        `agents.buddy_reject.*.${siteID}.>`,
        // Micro discovery — EXACT literals, never `>` (non-collision proof).
        "$SRV.INFO.agents",
        "$SRV.PING.agents",
        // Request-reply routing.
        "_INBOX.>",
      ],
      deny: ["$SYS.>"],
    },
    subscribe: {
      allow: [
        // Mesh-wide PRESENCE only (hb = protocol-fixed visibility verb; F3 fix).
        "agents.hb.>",
        // Everything else: own-namespace inbound only.
        `agents.prompt.*.${siteID}.>`,
        `agents.a2a.*.${siteID}.>`,
        `agents.status.*.${siteID}.>`,
        `agents.reply.*.${siteID}.>`,
        `agents.events.*.${siteID}.>`,
        `agents.buddy_request.*.${siteID}.>`,
        `agents.buddy_accept.*.${siteID}.>`,
        `agents.buddy_reject.*.${siteID}.>`,
        // Micro discovery — EXACT literals, never `>`.
        "$SRV.INFO.agents",
        "$SRV.PING.agents",
        "_INBOX.>",
      ],
      deny: ["$SYS.>"],
    },
  };
}

// ── CLI ────────────────────────────────────────────────────────
const siteID = process.argv[2] ?? "probe-site";
if (process.argv.includes("--conf")) {
  const perms = deriveSiteMeshPermissions(siteID);
  console.log(JSON.stringify({
    port: Number(process.env.D1_PROBE_PORT ?? 45222),
    jetstream: { enabled: false },
    authorization: {
      timeout: 2,
      users: [
        {
          user: "site",
          pass: "d1-probe-site-pass",
          permissions: perms,
        },
        {
          // Control principal: unrestricted. Proves a denial is due to the
          // site's grant set, not server/state issues.
          user: "root",
          pass: "d1-probe-root-pass",
          permissions: { publish: ">", subscribe: ">" },
        },
      ],
    },
  }, null, 2));
} else {
  console.log(JSON.stringify(deriveSiteMeshPermissions(siteID), null, 2));
}
