#!/usr/bin/env node
/**
 * build-ext-synadia.mjs — bundle packages/ext-synadia/src/index.ts →
 * agent-sdk/dist/ext-synadia/index.bundled.js (BUILD lane G).
 *
 * Pattern: mirrors src/pi-extension/index.bundled.js (built with
 * `bun build --format=esm --target=node`; test/unit/extension-variants.test.ts
 * :6 documents the pattern and the runtime-entry decision). This script uses
 * esbuild (same semantics, no bun dependency):
 *   - platform: node, format: esm
 *   - fully SELF-CONTAINED like the pi-extension bundle: @nats-io/* and the
 *     workspace sibling @vchatemail/protocol-core are INLINED (the original
 *     bundle inlines all of @nats-io — its only @nats-io mentions are source
 *     path comments; verified against src/pi-extension/index.bundled.js:35+).
 *     Externalized: only pi-host-shimmed deps (@earendil-works/*, typebox —
 *     pi.dev provides them) and node builtins. Self-containment avoids the
 *     dist/→node_modules resolution problem (dist/ is what npm ships;
 *     packages/ext-synadia's deps don't travel with the meta-package root).
 */
import { build } from "esbuild";
import { mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, "..");
const ENTRY = join(ROOT, "packages/ext-synadia/src/index.ts");
const OUTDIR = join(ROOT, "dist/ext-synadia");

mkdirSync(OUTDIR, { recursive: true });

await build({
  entryPoints: [ENTRY],
  outfile: join(OUTDIR, "index.bundled.js"),
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node18",
  external: [
    // pi.dev shims these host-side (same set the pi-extension bundle
    // externalizes — extension-variants.test.ts:93):
    "@earendil-works/*",
    "@sinclair/typebox",
    "typebox",
    // node builtins:
    "node:*",
    "fsevents",
  ],
  // NOTE: @nats-io/* (nats-core, services, transport-node, nkeys, jetstream,
  // kv) and @vchatemail/protocol-core are NOT external — the bundle is fully
  // self-contained (mirrors src/pi-extension/index.bundled.js, which inlines
  // the entire @nats-io surface; only pi-shims stay external). protocol-core
  // resolves through the pnpm workspace symlink automatically.
  sourcemap: false,
  minify: false,
  logLevel: "info",
  banner: {
    // ESM-output CJS interop (tweetnacl require("crypto")) + role marker.
    js: [
      "import { createRequire } from 'node:module';",
      "const require = createRequire(import.meta.url);",
      "/**",
      " * ext-synadia bundled runtime entry (esbuild, BUILD lane G).",
      " * Source: packages/ext-synadia/src/index.ts — edit there, re-bundle:",
      " *   node scripts/build-ext-synadia.mjs   (or: pnpm build:extensions)",
      " * External: @earendil-works/*, typebox (pi shims), node builtins.",
      " * Inlined: @nats-io/* + @vchatemail/protocol-core (self-contained).",
      " */",
    ].join("\n"),
  },
});

console.error(`[build-ext-synadia] wrote ${join(OUTDIR, "index.bundled.js")}`);
