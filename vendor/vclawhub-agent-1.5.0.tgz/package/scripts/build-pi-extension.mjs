#!/usr/bin/env node
/**
 * build-pi-extension.mjs — (re)build src/pi-extension/index.bundled.js.
 *
 * HISTORICAL NOTE (BUILD lane G): the bundle was originally generated with
 * `bun build --format=esm --target=node` (documented in
 * test/unit/extension-variants.test.ts:6 — no build script existed; this file
 * IS that documentation made executable). The semantics are reproduced with
 * esbuild (no bun dependency at build time), plus the VERIFIED post-build
 * patch from extension-variants.test.ts:37-40:
 *
 *   tweetnacl's PRNG detection (`typeof self !== "undefined" ? self.crypto :
 *   null`) never finds crypto under node/pi.dev (no `self`) and falls into a
 *   createRequire(import.meta.url) branch that fails under pi.dev's
 *   virtualModules. The patch extends the detection to `|| globalThis.crypto`
 *   (Web Crypto, node ≥19 + pi.dev) — 2 sites (sign + curve copies).
 *
 * Bundle contract (locked by test/unit/extension-variants.test.ts):
 *   - INLINES nkeys + tweetnacl (the jiti getter-export seam — fromSeed/sign
 *     must work; createUser via the patched Web-Crypto PRNG).
 *   - EXTERNALIZES only node builtins; @sinclair/typebox is INLINED (see below).
 */
import { build } from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, "..");
const ENTRY = join(ROOT, "src/pi-extension/index.ts");
const OUT = join(ROOT, "dist/pi-extension/index.bundled.js");

// VERSION INJECTION — mirrors scripts/build-cli-bundle.mjs for the CLI bundle;
// a build-time define so the bundled extension reports its true version rather
// than the "0.0.0" sentinel src/version.ts falls back to when package.json is
// not resolvable inside a single-file bundle.
const PKG_VERSION = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf-8")).version;
if (!PKG_VERSION) throw new Error("package.json carries no version — cannot stamp the bundle");

mkdirSync(dirname(OUT), { recursive: true });

await build({
  entryPoints: [ENTRY],
  outfile: OUT,
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node18",
  // The pi-extension bundle contract: node builtins external; everything else
  // (nkeys/tweetnacl AND @sinclair/typebox) INLINED — omp has no real typebox
  // (it shims onto packages/omptype), so the bundle must carry its own copy or
  // the schema validator rejects `Unknown type` at runtime (OMP §3 row 4).
  external: ["node:*", "fsevents"],
  // NOTE: nkeys + tweetnacl are NOT external — inlining them is the runtime
  // decision (extension-variants.test.ts:10-22: the un-bundled source can
  // never connect under pi.dev's jiti/virtualModules).
  sourcemap: false,
  minify: false,
  define: { "process.env.AGENT_SDK_VERSION": JSON.stringify(PKG_VERSION) },
  logLevel: "info",
  banner: {
    js: [
      "/**",
      " * pi-extension bundled runtime entry (esbuild; originally bun build",
      " * --format=esm --target=node — see test/unit/extension-variants.test.ts",
      " * for the J3c/J1c runtime decision + the tweetnacl PRNG patch below).",
      " * Source: src/pi-extension/index.ts — edit there, re-bundle:",
      " *   node scripts/build-pi-extension.mjs   (or: pnpm build:extensions)",
      " */",
      // CJS-in-bundle require shim (B4): inlined CJS deps (transport-node)
      // require node builtins; esbuild's ESM stub throws "Dynamic require of
      // \"node:net\" is not supported". A real createRequire-backed `require`
      // resolves them at runtime (builtins are external by config). Exposed
      // the PRE-EXISTING dev-mode-on-bundle break (dynamic import of
      // transport-node existed since J1c; only ever exercised via vitest
      // mocks or CLI dist before the B4 gate-5 smoke).
      "import { createRequire as __b4CreateRequire } from 'node:module';",
      "const require = __b4CreateRequire(import.meta.url);",
    ].join("\n"),
  },
});

// ── VERIFIED post-build patch (extension-variants.test.ts:37-40) ────────────
// tweetnacl PRNG: `self.crypto || self.msCrypto` → also try globalThis.crypto.
// 2 sites (sign + curve tweetnacl copies inlined by esbuild).
const BEFORE = "var crypto2 = typeof self !== \"undefined\" ? self.crypto || self.msCrypto : null;";
const AFTER = "var crypto2 = (typeof self !== \"undefined\" ? self.crypto || self.msCrypto : null) || globalThis.crypto;";
let code = readFileSync(OUT, "utf-8");
const hits = code.split(BEFORE).length - 1;
if (hits === 0) {
  // esbuild's variable renaming may differ from bun's — locate the pattern
  // structurally instead (any var X = typeof self ... self.crypto ... : null).
  const re = /var (\w+) = typeof self !== "undefined" \? self\.crypto \|\| self\.msCrypto : null;/g;
  let patched = 0;
  code = code.replace(re, (_m, name) => {
    patched++;
    return `var ${name} = (typeof self !== "undefined" ? self.crypto || self.msCrypto : null) || globalThis.crypto;`;
  });
  if (patched === 0) {
    console.error("[build-pi-extension] WARNING: tweetnacl PRNG pattern not found — the esbuild bundle may use a different minified shape. Inspect manually (createUser path).");
  } else {
    writeFileSync(OUT, code);
    console.error(`[build-pi-extension] patched ${patched} tweetnacl PRNG site(s) (globalThis.crypto fallback).`);
  }
} else {
  code = code.split(BEFORE).join(AFTER);
  writeFileSync(OUT, code);
  console.error(`[build-pi-extension] patched ${hits} tweetnacl PRNG site(s) (globalThis.crypto fallback).`);
}

console.error(`[build-pi-extension] wrote ${OUT}`);
