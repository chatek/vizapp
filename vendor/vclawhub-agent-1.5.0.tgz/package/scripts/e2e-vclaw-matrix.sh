#!/usr/bin/env bash
# e2e-vclaw-matrix.sh — every `/vclaw` verb × every reachable STATE, proven from
# its own output (plan: docs/lanes/VCLAW_E2E_MVP_2026-11-01.md, obligation E1).
#
# The table is the 13 MVP verbs plus `up` (the E6 gap the mockup promises, now
# built): 14 verbs in this binary. `up` is listed first in the usage block, so a
# build without it shows up as a missing column entry rather than a silent skip.
#
# States (each row runs in a throwaway HOME, so a mutating verb cannot leak into
# the next row — `logout` really does delete credentials, measured):
#
#   identity     credentials on disk, claimed, real fabric/gateway config
#   no-identity  empty HOME
#   pending      a seeded identity that is introduced but NOT claimed, with a
#                local stub at the gateway URL answering 403 agent_not_claimed
#                (so the pending class is proven offline, not by a live 403)
#   usage        a bad flag / missing value / bad value — identity present
#   fabric-down  credentials present, gateway reachable, NATS server pointed at a
#                closed loopback port, so the ONLY failure is the fabric
#
# What every row asserts:
#   * the exit code is in the documented set for THAT state (pasted below);
#   * `code === exit` in the JSON envelope, and no `data.code`;
#   * exit ∉ {0,2,3,4} fails the row;
#   * a refusal carries a non-empty `error` that is a REASON — not the verb's
#     banner and not the verb's own name (D5 defect class);
#   * fabric-down errors NAME the fabric (plan rule 4);
#   * the environment is model-free: the child runs under `env -i` with no
#     provider key in scope (asserted, not assumed — see the guard row);
#   * per-row timing is recorded, so a hidden network/model call is visible.
#
# Usage:
#   ./scripts/e2e-vclaw-matrix.sh
#   VCLAW_BIN="vclaw-agent" ./scripts/e2e-vclaw-matrix.sh
#   E2E_IDENTITY_DIR=~/.config/vclaw ./scripts/e2e-vclaw-matrix.sh
#   MATRIX_NO_FABRIC=1 ./scripts/e2e-vclaw-matrix.sh   # skip rows that dial NATS
#
# Exit: 0 when every reachable row passes; 1 when any row failed. UNREACHABLE
# states are REPORTED with their reason (never skipped silently) and do not
# fail the run.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BIN_STR="${VCLAW_BIN:-node $ROOT_DIR/dist/cli.js}"
read -r -a BIN <<<"$BIN_STR"
IDENTITY_DIR="${E2E_IDENTITY_DIR:-$HOME/.config/vclaw}"
NO_FABRIC="${MATRIX_NO_FABRIC:-0}"

WORK="$(mktemp -d "${TMPDIR:-/tmp}/vclaw-matrix.XXXXXX")"
TPL="$WORK/tpl"
HOME_ROOT="$WORK/home"
MATRIX_TSV="$WORK/matrix.tsv"
mkdir -p "$TPL" "$HOME_ROOT" && : >"$MATRIX_TSV"

PASS=0 FAIL=0 ROWN=0 STUB_PID=""

cleanup() {
  [ -n "$STUB_PID" ] && kill "$STUB_PID" 2>/dev/null
  wait "$STUB_PID" 2>/dev/null
  rm -rf "$WORK"
}
trap cleanup EXIT INT TERM

ok()  { PASS=$((PASS + 1)); printf '  PASS  %-44s rc=%-2s %5sms  %s\n' "$LABEL" "${RC:-?}" "${MS:-?}" "${NOTE:-}"; }
bad() {
  FAIL=$((FAIL + 1))
  printf '  FAIL  %-44s rc=%-2s %5sms\n' "$LABEL" "${RC:-?}" "${MS:-?}"
  printf '        why: %s\n' "$*"
  printf '        args: vclaw %s\n' "${ARGS:-}"
  printf '        HOME: %s\n' "${ROW_HOME:-}"
  printf '        ---- output ----\n'
  printf '%s\n' "${OUT:-<empty>}" | sed 's/^/        /'
  printf '        ----------------\n'
}

command -v node >/dev/null 2>&1 || { echo "e2e-vclaw-matrix: node is required (JSON envelope + fixtures)"; exit 1; }

# The child runs with a CLEAN environment (`env -i`): that is what makes the
# model-free claim falsifiable. Only these four paths exist inside it.
CHILD_PATH="/usr/bin:/bin:/usr/sbin:/sbin:$(dirname "$(command -v node)")"
for extra in "$HOME/.bun/bin" "$HOME/.local/bin" /opt/homebrew/bin /usr/local/bin; do
  case ":$CHILD_PATH:" in *":$extra:"*) ;; *) CHILD_PATH="$CHILD_PATH:$extra" ;; esac
done

now_ms() { python3 -c 'import time;print(int(time.time()*1000))' 2>/dev/null || date +%s000; }

cat >"$WORK/analyze.cjs" <<'JS'
// One process computes every field a row asserts: exit-code equality, the
// presence of data.code, and the specific data fields that PROVE which state
// the verb actually saw (pendingClaim, providers[], stoppedAt.id, …).
let s = "";
process.stdin.on("data", (d) => (s += d)).on("end", () => {
  const U = "\x1f";
  const abs = "<absent>";
  let o;
  try { o = JSON.parse(s); } catch {
    process.stdout.write(["<not-json>", "", "", "", "", "", "", "", "", "", "", "", "", "", ""].join(U));
    return;
  }
  const d = o && typeof o.data === "object" && o.data !== null ? o.data : {};
  const g = (p) => {
    let c = d;
    for (const k of p.split(".")) {
      if (c === null || typeof c !== "object") return "";
      c = c[k];
    }
    return c === undefined || c === null ? "" : String(c);
  };
  const prov = Array.isArray(d.providers) ? String(d.providers.length) : "";
  const failing = Array.isArray(d.checks) ? String(d.checks.filter((c) => !c.ok).length) : "";
  const stop = d.stoppedAt && typeof d.stoppedAt === "object" ? String(d.stoppedAt.id ?? "") : "";
  process.stdout.write([
    String(o.code),
    Object.prototype.hasOwnProperty.call(d, "code") ? String(d.code) : abs,
    o.error === undefined ? abs : String(o.error),
    String(o.verb ?? ""),
    String(o.state ?? ""),
    g("identity.present"),
    g("identity.pendingClaim"),
    prov,
    String(d.next ?? ""),
    String(d.jti ?? ""),
    String(d.logout ?? ""),
    d.revoked == null ? "" : JSON.stringify(d.revoked),
    failing,
    stop,
    Array.isArray(d.steps) ? String(d.steps.length) : "",
  ].join(U));
});
JS

analyze() {
  local line
  line="$(printf '%s' "$OUT" | node "$WORK/analyze.cjs")"
  IFS=$'\x1f' read -r J_CODE J_DATACODE J_ERR J_VERB J_STATE J_IDENT J_PEND J_PROV J_NEXT J_JTI J_LOGOUT J_REVOKED J_FAILING J_STOP J_STEPS <<<"$line"
}

# ── row plumbing ──────────────────────────────────────────────────────────

BEGIN_VERB="" BEGIN_STATE=""
begin() {
  BEGIN_VERB="$1" BEGIN_STATE="$2" LABEL="$1 · $2"
  PROBLEMS="" ARGS="" RC="" MS="" OUT="" NOTE="" RETRY_NOTE=""
  EXPECTED=""
  J_CODE="" J_DATACODE="" J_ERR="" J_VERB="" J_STATE="" J_IDENT="" J_PEND="" J_PROV=""
  J_NEXT="" J_JTI="" J_LOGOUT="" J_REVOKED="" J_FAILING="" J_STOP="" J_STEPS=""
}

# run <template> <vclaw args...>
run() {
  local tpl="$1"; shift
  ARGS="$*"
  ROWN=$((ROWN + 1))
  ROW_HOME="$HOME_ROOT/r$ROWN"
  rm -rf "$ROW_HOME"; mkdir -p "$ROW_HOME"
  if [ -d "$TPL/$tpl" ]; then cp -R "$TPL/$tpl/." "$ROW_HOME/"; fi
  local t0 t1 attempt
  attempt=1
  while :; do
    t0="$(now_ms)"
    OUT="$(env -i HOME="$ROW_HOME" PATH="$CHILD_PATH" TERM=dumb ${BIN[@]+"${BIN[@]}"} vclaw "$@" 2>&1)"
    RC=$?
    t1="$(now_ms)"
    MS=$((t1 - t0))
    # A child that died with NO bytes is a host/infra hiccup (a spawn failure
    # under load), not a verb result: nothing was observed, so nothing is proven.
    # Retry exactly once and SAY SO in the row — never silently re-run a failure
    # that produced output.
    if [ "$RC" = "1" ] && [ -z "${OUT//[[:space:]]/}" ] && [ "$attempt" = "1" ]; then
      attempt=2; RETRY_NOTE="child died with no output — retried once"
      sleep 0.3
      continue
    fi
    break
  done
  analyze
}

complain() { PROBLEMS="${PROBLEMS}${PROBLEMS:+; }$*"; }

# The documented set for THIS row. An exit outside {0,2,3,4} always fails.
expect_exit() {
  local w
  for w in "$@"; do [ "$RC" = "$w" ] && return 0; done
  complain "exit $RC not in documented set {$*}"
}

expect_code_matches_exit() {
  [ "$J_CODE" = "$RC" ] || complain "code=$J_CODE !== exit=$RC"
}

expect_no_data_code() {
  case "$J_DATACODE" in
    ""|"<absent>") return 0 ;;
  esac
  complain "data.code present ($J_DATACODE) — the envelope carries two codes"
}

# D5: a refusal's `error` is the reason, never the banner and never the verb.
expect_reason() {
  case "$J_ERR" in
    ""|"<absent>"|"null") complain "refusal carries no error"; return 0 ;;
  esac
  case "$J_ERR" in
    "vclaw "*) complain "error is the banner, not a reason: $J_ERR" ;;
  esac
  [ "${#J_ERR}" -ge 8 ] || complain "error too short to be a reason: $J_ERR"
  if [ -n "$BEGIN_VERB" ] && [ "$J_ERR" = "$BEGIN_VERB" ]; then
    complain "error is the verb name: $J_ERR"
  fi
}

expect_err_matches() { # <extended-regex>
  printf '%s' "$J_ERR" | grep -Eq "$1" || complain "error does not match /$1/: $J_ERR"
}

expect_fabric_named() {
  printf '%s' "$J_ERR" | grep -Eqi 'fabric|nats://' || complain "class-3 error does not name the fabric: $J_ERR"
}

expect_field() { # <name> <want> <actual>
  [ "$2" = "$3" ] || complain "$1 expected \"$2\", got \"$3\""
}

finish() {
  local status="PASS"
  [ -n "$RETRY_NOTE" ] && NOTE="${NOTE:+$NOTE; }$RETRY_NOTE"
  [ -n "$PROBLEMS" ] && status="FAIL"
  # Envelope invariants apply to EVERY JSON row.
  expect_code_matches_exit
  expect_no_data_code
  case "$RC" in
    0|2|3|4) ;;
    *) complain "exit $RC outside the contract {0,2,3,4}" ;;
  esac
  [ "$RC" != "0" ] && expect_reason
  # Re-evaluate after the invariants added their complaints.
  status="PASS"; [ -n "$PROBLEMS" ] && status="FAIL"
  if [ "$status" = "PASS" ]; then ok; else bad "$PROBLEMS"; fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$BEGIN_VERB" "$BEGIN_STATE" "${EXPECTED:-$RC}" "$RC" "$status" "${MS:-0}" >>"$MATRIX_TSV"
  EXPECTED=""
}

unreachable() { # <verb> <state> <reason>
  printf '  UNREACHABLE  %-26s %s\n' "$1 · $2" "$3"
  printf '%s\t%s\tU\tU\tUNREACHABLE\t0\n' "$1" "$2" >>"$MATRIX_TSV"
}

# ── fixtures ──────────────────────────────────────────────────────────────

seed_identity() { # <dir>  — copy of the host's own identity, never mutated in place
  mkdir -p "$1/.config/vclaw"
  cp "$IDENTITY_DIR/credentials.json" "$1/.config/vclaw/credentials.json" 2>/dev/null || return 1
  cp "$IDENTITY_DIR/config.json" "$1/.config/vclaw/config.json" 2>/dev/null || :
  chmod 600 "$1/.config/vclaw/credentials.json" 2>/dev/null
  [ -s "$1/.config/vclaw/credentials.json" ]
}

config_patch() { # <dir> <jq-ish js mutator>
  node -e '
    const fs = require("fs"), f = process.argv[1];
    let c = {};
    try { c = JSON.parse(fs.readFileSync(f, "utf8")); } catch {}
    new Function("c", process.argv[2])(c);
    fs.writeFileSync(f, JSON.stringify(c, null, 2));
  ' "$1/.config/vclaw/config.json" "$2"
}

models_fixture() { # <dir> — two providers, keys that resolve to NOTHING (no secret)
  mkdir -p "$1/.omp/agent"
  cat >"$1/.omp/agent/models.yml" <<'YML'
# e2e fixture — no secret: apiKey is an env NAME that is never set.
providers:
  deepseek:
    baseUrl: http://127.0.0.1:1/v1
    api: openai
    apiKey: E2E_UNSET_DEEPSEEK_KEY
    models:
      - deepseek-chat
  glm:
    baseUrl: http://127.0.0.1:2/v1
    api: openai
    apiKey: ""
    models:
      - glm-4.6
YML
}

MATRIX_STARTED=$(now_ms)

echo "== fixtures =="
mkdir -p "$TPL/no"
IDENTITY_OK=0
if seed_identity "$TPL/id"; then
  IDENTITY_OK=1
  mkdir -p "$TPL/id-off" "$TPL/fd" "$TPL/id-prov"
  cp -R "$TPL/id/." "$TPL/id-off/"
  cp -R "$TPL/id/." "$TPL/fd/"
  cp -R "$TPL/id/." "$TPL/id-prov/"
  config_patch "$TPL/id-off" 'c.vgateUrl = "http://127.0.0.1:1";'
  config_patch "$TPL/fd" 'c.server = "nats://127.0.0.1:1";'
  models_fixture "$TPL/id-prov"
  echo "  identity seed: $IDENTITY_DIR (copied per row; the host file is never written)"
else
  echo "  identity seed: ABSENT at $IDENTITY_DIR — every identity-present row will be UNREACHABLE"
fi
models_fixture "$TPL/prov"

# A synthetic identity makes the `pending` state reachable with no network and
# no real key: generate offline, never claimed, and mark it pending.
SYNTH_OK=0
if [ -f "$ROOT_DIR/dist/lib/keygen.js" ]; then
  if SYNTH_NKEY="$(node -e '
    const { generateNkeyPair } = require(process.argv[1]);
    (async () => {
      const k = await generateNkeyPair();
      const creds = {
        seed: k.seed,
        public_key: k.publicKey,
        agent_nkey: Buffer.from(k.rawPublicKey).toString("base64url"),
        name: "e2e-matrix-pending",
        steward: "unknown",
        created_at: new Date().toISOString(),
      };
      const fs = require("fs"), d = process.argv[2] + "/.config/vclaw";
      fs.mkdirSync(d, { recursive: true });
      fs.writeFileSync(d + "/credentials.json", JSON.stringify(creds, null, 2));
      fs.writeFileSync(d + "/.pending", k.publicKey);
      console.log(k.publicKey);
    })().catch((e) => { console.error(String(e)); process.exit(1); });
  ' "$ROOT_DIR/dist/lib/keygen.js" "$TPL/pend")"; then
    SYNTH_OK=1
    echo "  pending fixture: $SYNTH_NKEY (unclaimed, offline)"
  else
    echo "  pending fixture: FAILED to generate (dist/lib/keygen.js)"
  fi
fi

# Gateway stub: 403 agent_not_claimed. Used ONLY by the pending state, so the
# class-4 rows are deterministic and need no live vgate.
STUB_PORT=""
if [ "$SYNTH_OK" = "1" ]; then
  STUB_PORT="$(node -e 'const s=require("net").createServer().listen(0,"127.0.0.1",()=>{console.log(s.address().port);s.close()})')"
  cat >"$WORK/stub.cjs" <<'JS'
const http = require("node:http");
http.createServer((_q, r) => {
  r.writeHead(403, { "content-type": "application/json" });
  r.end(JSON.stringify({ error: "agent_not_claimed", message: "agent not claimed or already issued" }));
}).listen(Number(process.argv[2]), "127.0.0.1");
JS
  node "$WORK/stub.cjs" "$STUB_PORT" & STUB_PID=$!
  for _ in $(seq 1 50); do
    node -e 'require("net").connect(Number(process.argv[1]),"127.0.0.1").on("connect",function(){this.end();process.exit(0)}).on("error",()=>process.exit(1))' "$STUB_PORT" && break
    sleep 0.1
  done
  config_patch "$TPL/pend" "c.server = \"nats://127.0.0.1:1\"; c.vgateUrl = \"http://127.0.0.1:$STUB_PORT\";"
  echo "  gateway stub: http://127.0.0.1:$STUB_PORT (403 agent_not_claimed)"
fi

# ── environment pre-flight (recorded, never assumed) ──────────────────────

echo
echo "== pre-flight =="
printf '  binary: %s\n' "$BIN_STR"
printf '  child env: env -i HOME=<row> PATH=%s\n' "$CHILD_PATH"
if [ "$IDENTITY_OK" = "1" ]; then
  # The gateway is what turns a dead NATS port into a FABRIC error instead of a
  # "fetch failed". Probe it once so a gateway outage is reported, not guessed.
  run id reauth --json
  GATEWAY="down"; [ "$RC" = "0" ] && GATEWAY="up"
  printf '  gateway (reauth): %s  rc=%s  %sms\n' "$GATEWAY" "$RC" "$MS"
  run id who --wait 300 --json
  if [ "$RC" = "0" ]; then FABRIC="up"; else FABRIC="down"; NAMED="not-named"; fi
  printf '  fabric  (who):    %s  rc=%s  %sms  %s\n' "$FABRIC" "$RC" "$MS" "$([ "$RC" = "0" ] || printf '%s' "$J_ERR")"
  printf '  fabric config:    %s\n' "$(node -e 'try{console.log(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).server||"(none)")}catch{console.log("(none)")}' "$IDENTITY_DIR/config.json" 2>/dev/null)"
else
  GATEWAY="unknown"; FABRIC="unknown"
fi
# Model-free guard: the child must see NO provider key, checked, not promised.
CHILD_ENV="$(env -i HOME="$HOME_ROOT/envprobe" PATH="$CHILD_PATH" node -e 'console.log(Object.keys(process.env).sort().join(","))')"
if printf '%s' "$CHILD_ENV" | grep -Eqi 'API_KEY|_KEY=|TOKEN|SECRET|OPENAI|ANTHROPIC|DEEPSEEK|ZHIPU'; then
  echo "  MODEL-FREE GUARD: FAIL — a provider key survives into the child: $CHILD_ENV"
  MODEL_FREE=0
else
  echo "  model-free guard:  PASS — child env keys: $CHILD_ENV"
  MODEL_FREE=1
fi
printf '  no-fabric rows:    %s\n' "$NO_FABRIC"

# ── identity-present rows ─────────────────────────────────────────────────

echo
echo "== identity-present =="
if [ "$IDENTITY_OK" != "1" ]; then
  for v in status doctor who peers send inbox up signup login logout reauth down provider init; do
    unreachable "$v" identity "no credentials at $IDENTITY_DIR (set E2E_IDENTITY_DIR to a seeded HOME)"
  done
else
  begin status identity
  EXPECTED="0"
  run id status --json
  expect_exit 0
  expect_field identity.present true "$J_IDENT"
  expect_field verb status "$J_VERB"
  finish

  begin doctor identity
  EXPECTED="0 3"
  run id doctor --json
  expect_exit 0 3
  NOTE="$J_FAILING failing check(s)"
  finish

  if [ "$NO_FABRIC" != "1" ]; then
    begin who identity
    EXPECTED="$([ "$FABRIC" = up ] && echo 0 || echo 3)"
    run id who --wait 300 --json
    expect_exit 0 3
    [ "$RC" = "3" ] && expect_fabric_named
    NOTE="fabric $FABRIC"
    finish
  fi

  begin peers identity
  EXPECTED="0"
  run id peers --json
  expect_exit 0
  finish

  begin send identity
  EXPECTED="$([ "$FABRIC" = up ] && echo 0 || echo 3)"
  run id send UBAN43BJNBGXOCUKIHJDMXUJRFB42G47ZDWFCFSTF6P2KFBNJMZZSJSP matrix-probe --json
  expect_exit 0 3
  [ "$RC" = "3" ] && expect_fabric_named
  finish

  begin inbox identity
  EXPECTED="$([ "$FABRIC" = up ] && echo 0 || echo 3)"
  run id inbox --json
  expect_exit 0 3
  [ "$RC" = "3" ] && expect_fabric_named
  finish

  begin login identity
  EXPECTED="0"
  run id login --wait 1 --json
  expect_exit 0
  expect_field verb login "$J_VERB"
  finish

  begin logout identity
  EXPECTED="0"
  run id logout --json
  expect_exit 0
  expect_field logout done "$J_LOGOUT"
  [ -f "$ROW_HOME/.config/vclaw/credentials.json" ] && complain "credentials survived a logout"
  NOTE="credentials removed; revoked=$J_REVOKED"
  finish

  begin reauth identity
  EXPECTED="0 3"
  run id reauth --json
  expect_exit 0 3
  if [ "$RC" = "0" ]; then [ -n "$J_JTI" ] || complain "reauth returned 0 with no jti"; else expect_err_matches 'gateway|unreachable|refused|fabric'; fi
  NOTE="gateway $GATEWAY jti=${J_JTI:0:8}"
  finish

  # `down` is an HTTP presence write on the deployed gateway; the class is 0 when
  # accepted, 3 when the endpoint refuses the write. Both are proven from output.
  begin down identity
  EXPECTED="0 3"
  run id down --json
  expect_exit 0 3
  [ "$RC" = "3" ] && expect_err_matches 'presence|refused|unreachable|fabric'
  NOTE="$J_ERR"
  finish

  begin provider-list identity
  EXPECTED="0"
  run id provider list --json
  expect_exit 0
  NOTE="models.yml absent -> $J_PROV provider(s)"
  finish

  begin provider-list-fixture identity
  EXPECTED="0"
  run id-prov provider list --json
  expect_exit 0
  expect_field providers 2 "$J_PROV"
  NOTE="models.yml fixture -> $J_PROV providers"
  finish

  begin init identity
  EXPECTED="0 3"
  run id-prov init --json
  expect_exit 0 3
  NOTE="stoppedAt=${J_STOP:-none} next=$J_NEXT"
  finish

  begin signup identity
  EXPECTED="0"
  run id signup --json
  expect_exit 0
  finish

  # `up` = token + presence. Class 0 when accepted, 3 when the presence
  # endpoint refuses (measured: the deployed gateway answers 404), 4 when the
  # claim is not approved.
  begin up identity
  EXPECTED="0 3"
  run id up --json
  expect_exit 0 3
  [ "$RC" = "3" ] && expect_fabric_named
  NOTE="$J_ERR"
  finish
fi

# ── identity-present, gateway down (proves which verbs need it) ───────────

echo
echo "== identity-present · gateway down (config.vgateUrl -> closed port) =="
if [ "$IDENTITY_OK" != "1" ]; then
  unreachable logout id-off "no credentials at $IDENTITY_DIR"
  unreachable logout id-off "no credentials at $IDENTITY_DIR"
  unreachable reauth id-off "no credentials at $IDENTITY_DIR"
  unreachable down id-off "no credentials at $IDENTITY_DIR"
else
  # The headline assertion for logout: the DEFAULT path makes no HTTP call, so a
  # gateway that cannot be reached changes nothing — it still exits 0 and drops
  # the credential. If it dialled, this row would be class 3.
  begin logout-gateway-down id-off
  EXPECTED="0"
  run id-off logout --json
  expect_exit 0
  expect_field logout done "$J_LOGOUT"
  [ -f "$ROW_HOME/.config/vclaw/credentials.json" ] && complain "credentials survived a logout"
  NOTE="no HTTP: exit 0 with the gateway unreachable"
  finish

  # --revoke DOES need it, and must say WHY it failed — "logged out" is the
  # verb's banner, not a reason (this row is expected to catch that defect).
  begin logout-revoke-gateway-down id-off
  EXPECTED="3"
  run id-off logout --revoke --json
  expect_exit 3
  expect_err_matches 'revoke|unreachable|refused|gateway'
  NOTE="revoked=$J_REVOKED"
  finish

  begin reauth-gateway-down id-off
  EXPECTED="3"
  run id-off reauth --json
  expect_exit 3
  expect_err_matches 'gateway|unreachable|refused'
  finish

  begin down-gateway-down id-off
  EXPECTED="3"
  run id-off down --json
  expect_exit 3
  expect_err_matches 'presence|refused|unreachable'
  finish

  begin up-gateway-down id-off
  EXPECTED="3"
  run id-off up --json
  expect_exit 3
  expect_fabric_named
  finish
fi

# ── no-identity rows ──────────────────────────────────────────────────────

echo
echo "== no-identity (empty HOME) =="
begin status no-identity
EXPECTED="4"; run no status --json; expect_exit 4
expect_err_matches 'credential|identity|login|signup'; finish

begin doctor no-identity
EXPECTED="4"; run no doctor --json; expect_exit 4
expect_field "failing checks (>0)" true "$([ "${J_FAILING:-0}" -gt 0 ] && echo true || echo false)"; finish

begin who no-identity
EXPECTED="4"; run no who --wait 200 --json; expect_exit 4; finish

begin peers no-identity
EXPECTED="4"; run no peers --json; expect_exit 4; finish

begin send no-identity
EXPECTED="4"; run no send UBAN43BJNBGXOCUKIHJDMXUJRFB42G47ZDWFCFSTF6P2KFBNJMZZSJSP hi --json; expect_exit 4; finish

begin inbox no-identity
EXPECTED="4"; run no inbox --json; expect_exit 4; finish

begin login no-identity
EXPECTED="4"; run no login --wait 1 --json; expect_exit 4; finish

# Logout with nothing to drop is IDEMPOTENT (0), not an identity failure.
begin logout no-identity
EXPECTED="0"; run no logout --json; expect_exit 0
expect_field logout already "$J_LOGOUT"; NOTE="idempotent"; finish

begin logout-revoke no-identity
EXPECTED="0"; run no logout --revoke --json; expect_exit 0
expect_field logout already "$J_LOGOUT"; finish

begin reauth no-identity
EXPECTED="4"; run no reauth --json; expect_exit 4; finish

begin down no-identity
EXPECTED="4"; run no down --json; expect_exit 4; finish

# `up` with no identity starts signup itself and stops at approval: class 4 with
# the link, not a dependency error.
begin up no-identity
EXPECTED="4"; run no up --json; expect_exit 4
expect_err_matches 'approval|claim|signup'
NOTE="$J_ERR"; finish

# The provider inventory is deliberately identity-free.
begin provider-list no-identity
EXPECTED="0"; run no provider list --json; expect_exit 0; finish

begin provider-list-fixture no-identity
EXPECTED="0"; run prov provider list --json; expect_exit 0
expect_field providers 2 "$J_PROV"; NOTE="no identity needed"; finish

begin init no-identity
EXPECTED="4"; run no init --json; expect_exit 4
expect_field stoppedAt identity "$J_STOP"
case "$J_NEXT" in *signup*) ;; *) complain "init's next command does not advance the identity step: $J_NEXT" ;; esac
NOTE="next: $J_NEXT"; finish

begin signup no-identity
EXPECTED="0 3"; run no signup --json; expect_exit 0 3
if [ "$RC" = "0" ]; then
  [ -f "$ROW_HOME/.config/vclaw/credentials.json" ] || complain "signup exited 0 without writing credentials"
  NOTE="minted local identity (network introduce)"
else
  expect_err_matches 'introduce|unreachable|gateway|fetch'
fi
finish

# ── pending rows (seeded identity, gateway stub answers 403) ──────────────

echo
echo "== pending (seeded unclaimed identity, stub 403 agent_not_claimed) =="
if [ "$SYNTH_OK" != "1" ]; then
  for v in status doctor who peers send inbox up signup login logout reauth down provider init; do
    unreachable "$v" pending "dist/lib/keygen.js missing — cannot generate the offline fixture"
  done
else
  begin status pending
  EXPECTED="0"; run pend status --json; expect_exit 0
  expect_field identity.pendingClaim true "$J_PEND"
  NOTE="pendingClaim=$J_PEND"; finish

  begin doctor pending
  EXPECTED="4"; run pend doctor --json; expect_exit 4
  expect_err_matches 'claim'; finish

  begin who pending
  EXPECTED="4"; run pend who --wait 200 --json; expect_exit 4
  expect_err_matches 'claim|not approved|not_claimed'; finish

  begin peers pending
  EXPECTED="0"; run pend peers --json; expect_exit 0; finish

  begin send pending
  EXPECTED="4"; run pend send UBAN43BJNBGXOCUKIHJDMXUJRFB42G47ZDWFCFSTF6P2KFBNJMZZSJSP hi --json
  expect_exit 4; expect_err_matches 'claim|not approved'; finish

  begin inbox pending
  EXPECTED="4"; run pend inbox --json; expect_exit 4
  expect_err_matches 'claim|not approved'; finish

  begin login pending
  EXPECTED="4"; run pend login --wait 1 --json; expect_exit 4
  expect_err_matches 'claim|not_claimed|approved'; finish

  begin signup pending
  EXPECTED="0"; run pend signup --json; expect_exit 0
  expect_field state degraded "$J_STATE"; NOTE="resumes the pending claim, no new key"; finish

  begin logout pending
  EXPECTED="0"; run pend logout --json; expect_exit 0
  expect_field logout done "$J_LOGOUT"; finish

  begin reauth pending
  EXPECTED="4"; run pend reauth --json; expect_exit 4
  expect_err_matches 'claim|not_approved|not_claimed'; finish

  begin down pending
  EXPECTED="4"; run pend down --json; expect_exit 4
  expect_err_matches 'claim|not_claimed|refused'; finish

  begin up pending
  EXPECTED="4"; run pend up --json; expect_exit 4
  expect_err_matches 'claim|not_claimed|approval'; finish

  begin provider-list pending
  EXPECTED="0"; run pend provider list --json; expect_exit 0; finish

  begin init pending
  EXPECTED="4"; run pend init --json; expect_exit 4
  expect_field stoppedAt approval "$J_STOP"
  case "$J_NEXT" in *login*) ;; *) complain "init's next command does not advance the approval step: $J_NEXT" ;; esac
  NOTE="next: $J_NEXT"; finish
fi

# ── usage rows (bad flag / missing value / bad value) ─────────────────────

echo
echo "== usage (refused, verb never runs) =="
USAGE_TPL=id; [ "$IDENTITY_OK" != "1" ] && USAGE_TPL=no
for v in status doctor init send inbox login logout reauth signup who down peers provider up; do
  begin "usage-$v" usage
  EXPECTED="2"; run "$USAGE_TPL" "$v" --bogusflag --json
  expect_exit 2
  expect_err_matches 'unknown flag'
  finish
done

begin usage-wait-no-value usage
EXPECTED="2"; run "$USAGE_TPL" inbox --wait --json; expect_exit 2
expect_err_matches 'no value'; finish

begin usage-wait-not-numeric usage
EXPECTED="2"; run "$USAGE_TPL" inbox --wait abc --json; expect_exit 2
expect_err_matches 'milliseconds'; finish

begin usage-tier-bad usage
EXPECTED="2"; run "$USAGE_TPL" peers --tier bogus --json; expect_exit 2
expect_err_matches 'tier'; finish

begin usage-init-skip usage
EXPECTED="2"; run "$USAGE_TPL" init --skip nope --json; expect_exit 2
expect_err_matches 'skip'; finish

begin usage-send-bad-peer usage
EXPECTED="2"; run "$USAGE_TPL" send bad.peer hi --json; expect_exit 2
expect_err_matches 'invalid peer'; finish

begin usage-send-no-args usage
EXPECTED="2"; run "$USAGE_TPL" send --json; expect_exit 2
expect_err_matches 'usage'; finish

begin usage-provider-unknown-sub usage
EXPECTED="2"; run "$USAGE_TPL" provider bogus --json; expect_exit 2
expect_err_matches 'unknown subcommand'; finish

begin usage-provider-add-no-id usage
EXPECTED="2"; run "$USAGE_TPL" provider add --json; expect_exit 2
expect_err_matches 'id is required'; finish

begin usage-provider-test-unknown usage
EXPECTED="2"; run "$USAGE_TPL" provider test nosuch --json; expect_exit 2
expect_err_matches 'unknown provider'; finish

# ── fabric-down rows (gateway up, NATS dead) ──────────────────────────────

echo
echo "== fabric-down (config.server -> closed loopback port) =="
if [ "$IDENTITY_OK" != "1" ]; then
  for v in status doctor who peers send inbox up signup login logout reauth down provider init; do
    unreachable "$v" fabric-down "needs a claimed identity to mint a JWT; no credentials at $IDENTITY_DIR"
  done
else
  begin status fabric-down
  EXPECTED="0"; run fd status --json; expect_exit 0
  expect_field identity.present true "$J_IDENT"; NOTE="the dashboard still answers"; finish

  begin doctor fabric-down
  EXPECTED="0 3"; run fd doctor --json; expect_exit 0 3
  NOTE="$J_FAILING failing check(s)"; finish

  begin who fabric-down
  EXPECTED="3"; run fd who --wait 300 --json; expect_exit 3
  expect_fabric_named; finish

  begin peers fabric-down
  EXPECTED="0"; run fd peers --json; expect_exit 0
  NOTE="local rosters only"; finish

  begin send fabric-down
  EXPECTED="3"; run fd send UBAN43BJNBGXOCUKIHJDMXUJRFB42G47ZDWFCFSTF6P2KFBNJMZZSJSP hi --json
  expect_exit 3; expect_fabric_named; finish

  begin inbox fabric-down
  EXPECTED="3"; run fd inbox --json; expect_exit 3
  expect_fabric_named; finish

  begin inbox-sync fabric-down
  EXPECTED="3"; run fd inbox --sync --json; expect_exit 3
  expect_err_matches 'inbox|endpoint|fabric|nats|fetch'
  NOTE="$J_ERR"; finish

  begin login fabric-down
  EXPECTED="0"; run fd login --wait 1 --json; expect_exit 0
  NOTE="login needs the gateway, not the fabric"; finish

  begin logout fabric-down
  EXPECTED="0"; run fd logout --json; expect_exit 0
  expect_field logout done "$J_LOGOUT"; finish

  begin reauth fabric-down
  EXPECTED="0"; run fd reauth --json; expect_exit 0
  NOTE="reauth mints over HTTP; the fabric is not consulted"; finish

  begin down fabric-down
  EXPECTED="0 3"; run fd down --json; expect_exit 0 3
  [ "$RC" = "3" ] && expect_err_matches 'presence|refused|unreachable'
  NOTE="$J_ERR"; finish

  begin provider-list fabric-down
  EXPECTED="0"; run fd provider list --json; expect_exit 0; finish

  begin init fabric-down
  EXPECTED="0 3"; run fd init --json; expect_exit 0 3
  NOTE="stoppedAt=${J_STOP:-none}"; finish

  begin signup fabric-down
  EXPECTED="0"; run fd signup --json; expect_exit 0; finish

  begin up fabric-down
  EXPECTED="3"; run fd up --json; expect_exit 3
  expect_fabric_named; NOTE="$J_ERR"; finish
fi

# ── report ────────────────────────────────────────────────────────────────

TOTAL_MS=$(( $(now_ms) - MATRIX_STARTED ))
echo
echo "== matrix (verb × state → exit) =="
node - "$MATRIX_TSV" <<'JS'
const fs = require("fs");
const rows = fs.readFileSync(process.argv[2], "utf8").trim().split("\n").filter(Boolean).map((l) => l.split("\t"));
const STATES = ["identity", "no-identity", "pending", "usage", "fabric-down"];
const EXTRA = ["id-off", "identity", "no-identity", "pending", "usage", "fabric-down"]; // id-off folded below
const VERBS = ["status", "doctor", "who", "peers", "send", "inbox", "up", "signup", "login", "logout", "reauth", "down", "provider", "init"];
// Fold the flag variants onto their verb: "provider-list" -> provider, "usage-provider" -> provider …
const verbOf = (v) => {
  const base = v.replace(/^usage-/, "").replace(/-.*$/, "");
  return VERBS.includes(base) ? base : v.replace(/^usage-/, "");
};
const cell = new Map();
let failed = 0, unreach = 0;
for (const [verb, state, expect, rc, status] of rows) {
  if (status === "FAIL") failed++;
  if (status === "UNREACHABLE") { unreach++; }
  const v = verbOf(verb);
  const k = v + "|" + state;
  const prev = cell.get(k) || { codes: new Set(), bad: false, unreach: 0 };
  if (status === "UNREACHABLE") prev.unreach++;
  else prev.codes.add(rc);
  if (status === "FAIL") prev.bad = true;
  cell.set(k, prev);
}
const width = Math.max(...VERBS.map((v) => v.length), 4) + 2;
const pad = (s, n) => s + " ".repeat(Math.max(0, n - s.length));
let head = pad("verb", width);
for (const s of STATES) head += pad(s, 14);
console.log(head);
console.log("-".repeat(head.length));
for (const v of VERBS) {
  let line = pad(v, width);
  for (const s of STATES) {
    const c = cell.get(v + "|" + s);
    let txt = "·";
    if (c) {
      if (c.codes.size > 0) txt = [...c.codes].join(",") + (c.bad ? " !" : "");
      else if (c.unreach > 0) txt = "U";
      else txt = "·";
    }
    line += pad(txt, 14);
  }
  console.log(line);
}
console.log("\nlegend: exit codes observed for that cell · '·' = no row (verb/state not applicable) · 'U' = UNREACHABLE in this environment (reason listed per row) · '!' = a row failed");
console.log(`rows: ${rows.length}  failed: ${failed}  unreachable: ${unreach}`);

// Rows that are not one of the five columns (identity-present with the gateway
// dead) — reported rather than folded away, because they are what proves which
// verbs need the gateway and which do not.
const extra = rows.filter(([, state]) => !STATES.includes(state));
if (extra.length > 0) {
  console.log("\n== rows outside the five columns ==");
  for (const [verb, state, expect, rc, status] of extra) {
    console.log(`  ${status === "UNREACHABLE" ? "UNREACHABLE" : status}  ${verb} · ${state}  expected {${expect}}  got ${rc}`);
  }
}
JS

if grep -q 'UNREACHABLE' "$MATRIX_TSV" 2>/dev/null; then
  echo
  echo "== states UNREACHABLE in this environment (reported, never skipped) =="
  awk -F'\t' '$5=="UNREACHABLE"{n[$2]++} END{for (s in n) printf "  %-14s %d row(s)\n", s, n[s]}' "$MATRIX_TSV"
fi

echo
echo "== slowest rows (a hidden network or model call shows here) =="
sort -t$'\t' -k6 -nr "$MATRIX_TSV" | head -6 | awk -F'\t' '{printf "  %6sms  %s · %s  (rc=%s, %s)\n", $6, $1, $2, $4, $5}'

echo
echo "RESULT: ${PASS} passed, ${FAIL} failed, ${TOTAL_MS}ms total"
[ "$MODEL_FREE" = "1" ] || { echo "MODEL-FREE GUARD FAILED"; exit 1; }
[ "$FAIL" -eq 0 ]
