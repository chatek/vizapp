#!/usr/bin/env bash
# e2e-vclaw-tui.sh — the /vclaw TUI acceptance loop, scripted: ALL 13 VERBS, BOTH IDENTITY MODES.
#
# What it proves (docs/lanes/VCLAW_E2E_MVP_2026-11-01.md, row E2):
#   * every verb of the MVP (`status doctor who peers send inbox signup login logout reauth down
#     provider init`, spec §2) DISPATCHES inside a real `omp` TUI — not just on the CLI;
#   * each dispatch returns one of §5's classes {0,2,3,4} — an exit of 1 is a FAIL, not a note;
#   * the verb's OWN text was rendered (its first line is asserted, and a `<verb> — …` banner that
#     the model could not have produced must be present);
#   * the run is MODEL-FREE: `omp` is started under `env -i` (no provider keys, no API tokens), and
#     every row records its wall time so a hidden network/model call is visible as a timing anomaly.
#
# …and it runs twice, `identity` and `no-identity`, because the identity gate (class 4) is a
# different code path from the fabric (class 3) and a harness that only ever saw one of them would
# never notice the two swapping.
#
# Why this harness exists:
#   * OMP print mode does NOT dispatch extension commands, so `/vclaw` is TUI-only; the CLI
#     (`vclaw-agent vclaw …`) is a different surface (the E1 harness owns that one).
#   * A pty keeps only the cursor region, so a screen scrape cannot be asserted. The extension
#     appends `=== <iso> /vclaw <args> exit=<n>` + rendered text to ~/.vclaw/vclaw-out.txt; that
#     file is the assertion surface.
#   * MODEL FALL-THROUGH DETECTION: only the extension's command handler writes that file. A verb
#     that OMP handed to the model renders an answer on screen and appends NOTHING. So the
#     discriminator is exact, not heuristic — "the pane changed but no `===` line appeared" is
#     reported as MODEL FALL-THROUGH (distinct from "the keystroke never arrived", where the pane
#     is unchanged). A plugin dir whose package.json omits `"type": "module"` is loaded as CJS, the
#     import fails silently, `/vclaw` is never registered, and the model answers instead. This
#     script writes an ESM package.json AND fails loudly on the fall-through.
#   * A fresh $HOME opens OMP's first-run wizard, which eats keystrokes; we pre-seed
#     `setupVersion: 2` in config.yml.
#
# Class expectations are DERIVED, never guessed (each row prints `exp`):
#   * FABRIC (host probe, `who --json` before any run — the verb, not the TCP port: 127.0.0.1:4223
#     accepted a connection on 2026-11-01 while the NATS handshake failed upstream). down ⇒ who /
#     inbox / send MUST be 3 AND their text MUST name the fabric (`cannot reach the fabric`).
#   * GATEWAY (presence of api.vclawhub.com) decides `reauth`: minted ⇒ 0, unreachable ⇒ 3.
#   * PRESENCE ROUTE (the deployed vgate's answer to POST /v1/agent/<nkey>/presence) decides `down`:
#     404 (route absent, measured 2026-11-01) or transport failure ⇒ 3; a live route ⇒ 0.
#   * `status`/`peers`/`provider`/`logout`/help are local: their class is fixed by the mode.
#   * `doctor`/`init` aggregate environment checks, so their class is `0 3` (identity) / `4`
#     (no identity) — and a `3` must show at least one failing check / an unreached step in its own
#     text, so the row is a proof that the failure is environmental, not a stub that always says 3.
#
# Wait times (measured on omp-1, shipped pin):
#   * TUI ready: banner ~0.5–1.3 s under `env -i`, but extension session_start is still settling.
#     We require the status marker (`AUTO ·`) for 4 consecutive 250 ms samples, then settle
#     WAIT_SETTLE_S=2 s.
#   * Per verb, identity + fabric down: status 0.6 s · doctor 0.4 s · who 6.5 s (4 s presence
#     window + connect failure) · peers 0.5 s · send 1.1 s · inbox 9.7 s (3 s drain + connect) ·
#     provider 0.2 s · init 0.2 s · reauth 9.3 s (token mint) · login 0.3 s · down 2.0 s ·
#     logout 0.2 s · help 0.3 s. Without identity every gated verb answers in ~0.15 s.
#     We poll the capture file (0.1 s cadence) until a new `=== ` header appears, up to
#     WAIT_RESULT_S=90 s — a fixed sleep would read a spinner or race the slow path.
#
# Env:
#   CONTAINER=omp-1          incus container
#   KUAI=debian@kuai         tailscale ssh host running incus
#   TARBALL=<repo>/vclawhub-agent-1.5.0.tgz
#   ARTIFACT_SHA=<sha256>    pinned tarball (empty string disables the check)
#   BUNDLE_SHA=<sha256>      pinned dist/pi-extension/index.bundled.js
#   SKIP_INSTALL=1           use the package already installed in the container
#   SKIP_PIN=1               skip artifact/bundle sha verification
#   MODES="identity no-identity"   the modes to run (default: both)
#   NO_IDENTITY=1            with MODES unset, run only the no-identity mode
#   WAIT_READY_S=60          TUI startup budget
#   WAIT_RESULT_S=90         per-command capture budget
set -uo pipefail

CONTAINER="${CONTAINER:-omp-1}"
KUAI="${KUAI:-debian@kuai}"
HERE="$(cd "$(dirname "$0")" && pwd)"
TARBALL="${TARBALL:-$HERE/../vclawhub-agent-1.5.0.tgz}"
ARTIFACT_SHA="${ARTIFACT_SHA-e428d795ade3cfeeab519d74df951b44008b62e801f954ba5f6d84d158ef09f1}"
BUNDLE_SHA="${BUNDLE_SHA-be6ea19d1571ff8c981e0d6d60f1b0e838d707b152dad9d03a1a1db4f1f922e1}"
SKIP_INSTALL="${SKIP_INSTALL:-0}"
SKIP_PIN="${SKIP_PIN:-0}"
WAIT_READY_S="${WAIT_READY_S:-60}"
WAIT_RESULT_S="${WAIT_RESULT_S:-90}"

# Both modes by default: the identity gate and the fabric are different classes and E2 owes proof
# of both. NO_IDENTITY=1 stays honoured for a single no-identity pass.
if [ -z "${MODES:-}" ]; then
  if [ "${NO_IDENTITY:-0}" = 1 ]; then MODES="no-identity"; else MODES="identity no-identity"; fi
fi

die() { printf 'e2e-vclaw-tui: %s\n' "$*" >&2; exit 1; }

k() { tailscale ssh "$KUAI" "$@"; }

# ── 1. artefact ------------------------------------------------------------
if [ "$SKIP_INSTALL" != 1 ]; then
  [ -f "$TARBALL" ] || die "tarball not found: $TARBALL"
  if [ "$SKIP_PIN" != 1 ] && [ -n "$ARTIFACT_SHA" ]; then
    got=$(shasum -a 256 "$TARBALL" | cut -d' ' -f1)
    [ "$got" = "$ARTIFACT_SHA" ] || die "tarball sha256 mismatch: $got (pinned $ARTIFACT_SHA)"
  fi
  echo "   installing $(basename "$TARBALL") — sha256 $(shasum -a 256 "$TARBALL" | cut -c1-12)…"
  cat "$TARBALL" | k 'cat > /tmp/agent.tgz' || die "push to $KUAI failed"
  k "sudo -n incus file push /tmp/agent.tgz $CONTAINER/root/agent.tgz" >/dev/null || die "incus file push failed"
  k "sudo -n incus exec $CONTAINER -- env PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin npm i -g /root/agent.tgz --no-audit --no-fund" >/tmp/vclaw-tui-install.log 2>&1 \
    || { cat /tmp/vclaw-tui-install.log >&2; die "npm install failed"; }
else
  echo "   SKIP_INSTALL=1: using the package already installed in $CONTAINER"
fi

# ── 2. dependency probes (HOST side — the container script cannot call incus) ──
# 2a. the FABRIC. Ask the fabric, not the TCP port: measured 2026-11-01, 127.0.0.1:4223 accepted
# a connection while the NATS handshake failed upstream ("node provided an undefined error"), so
# `who` still answered 3. The only honest probe is the verb itself, with the real identity,
# before the no-identity variant moves it aside.
_fab_code=$(k "sudo -n incus exec $CONTAINER -- env PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin vclaw-agent vclaw who --wait 300 --json" 2>/dev/null | grep -o '"code": *[0-9]*' | head -1 | grep -o '[0-9]*$')
FABRIC=up
[ "${_fab_code:-3}" = "3" ] && FABRIC=down
echo "   fabric probe: who -> code ${_fab_code:-unknown}"
echo "   fabric: $FABRIC"
if [ "$FABRIC" = down ]; then
  echo "   NOTE: who/inbox/send are asserted at exit=3 (dependency, class 3) AND their text must name"
  echo "         the fabric. Start the relay with:"
  echo "         ssh -f -N -R 127.0.0.1:4223:100.106.248.70:4223 $KUAI"
fi

# 2b. the GATEWAY and the PRESENCE ROUTE — the two dependencies `reauth` and `down` talk to.
# Probe them directly (HTTP), not through the verbs: a verb that is broken must fail its row, not
# define its own expectation. Reads the container's configured vgateUrl, never prints the seed.
cat > /tmp/vclaw-env-probe.js <<'EOJ'
const fs = require("fs");
const d = "/root/.config/vclaw";
let base = "https://api.vclawhub.com", nkey = null;
try { const c = JSON.parse(fs.readFileSync(d + "/config.json", "utf8")); if (c.vgateUrl) base = c.vgateUrl; } catch {}
try { const c = JSON.parse(fs.readFileSync(d + "/credentials.json", "utf8")); nkey = c.public_key || null; } catch {}
const hit = async (u, o) => { try { const r = await fetch(u, o); return r.status; } catch { return 0; } };
(async () => {
  const gw = await hit(base + "/health");
  const pr = await hit(base + "/v1/agent/" + encodeURIComponent(nkey || "x") + "/presence",
    { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
  console.log(`gw=${gw} presence=${pr} base=${base}`);
})();
EOJ
cat /tmp/vclaw-env-probe.js | k "cat > /tmp/vclaw-env-probe.js && sudo -n incus file push /tmp/vclaw-env-probe.js $CONTAINER/root/vclaw-env-probe.js" >/dev/null \
  || die "could not stage the gateway probe"
_probe=$(k "sudo -n incus exec $CONTAINER -- env HOME=/root PATH=/usr/local/bin:/usr/bin:/bin node /root/vclaw-env-probe.js" 2>/dev/null | tail -1)
GW=$(printf '%s' "$_probe" | sed -n 's/.*gw=\([0-9]*\).*/\1/p'); GW="${GW:-0}"
PRESENCE=$(printf '%s' "$_probe" | sed -n 's/.*presence=\([0-9]*\).*/\1/p'); PRESENCE="${PRESENCE:-0}"
echo "   gateway probe: ${_probe:-<no answer>}"
echo "     gw=$GW (0 = unreachable) · presence route=$PRESENCE (404 = route absent on the deployed vgate)"

# ── 3. container-side harness ----------------------------------------------
# Everything below runs INSIDE the container as root.
cat > /tmp/vclaw-tui-harness.sh <<'EOS'
#!/usr/bin/env bash
set -uo pipefail
export HOME=/root
export PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin
export TERM=xterm-256color

NO_IDENTITY="${NO_IDENTITY:-0}"
MODE="${MODE:-identity}"
FABRIC="${FABRIC:-down}"
GW="${GW:-0}"
PRESENCE="${PRESENCE:-0}"
BUNDLE_SHA="${BUNDLE_SHA:-}"
SKIP_PIN="${SKIP_PIN:-0}"
WAIT_READY_S="${WAIT_READY_S:-60}"
WAIT_RESULT_S="${WAIT_RESULT_S:-90}"
WAIT_SETTLE_S=2

OUT=/root/.vclaw/vclaw-out.txt
SESS=vclaw-tui-e2e
PLUGDIR=/root/.omp/agent/extensions/vclaw-e2e
CFG=/root/.omp/agent/config.yml
ASIDE=/root/.config/vclaw/credentials.json.e2e-aside
SNAP=/root/.vclaw/e2e-identity-snap
CREDS=/root/.config/vclaw/credentials.json
fails=0
declare -a rows=()

fail() { printf '   FAIL  %s\n' "$*"; fails=$((fails+1)); }

# The files `logout` deletes and `signup`/`login` rewrite. Snapshot before, restore after: the row
# still proves the REAL drop (we assert the file is gone), and the container's identity survives
# for the next mode and for every other lane using this box.
tracked_paths() {
  printf '%s\n' \
    /root/.config/vclaw/credentials.json /root/.config/vchat/credentials.json /root/.vchat/credentials.json \
    /root/.config/vclaw/.pending /root/.config/vchat/.pending /root/.vchat/.pending
}
snapshot_identity() {
  rm -rf "$SNAP"; mkdir -p "$SNAP"; : > "$SNAP/manifest"
  local i=0 p
  while IFS= read -r p; do
    i=$((i+1)); printf '%s\t%s\n' "$i" "$p" >> "$SNAP/manifest"
    [ -f "$p" ] && cp -p "$p" "$SNAP/$i"
  done < <(tracked_paths)
  return 0
}
restore_snapshot() {
  [ -f "$SNAP/manifest" ] || return 0
  local i p
  while IFS=$'\t' read -r i p; do
    if [ -f "$SNAP/$i" ]; then cp -p "$SNAP/$i" "$p"; else rm -f "$p"; fi
  done < "$SNAP/manifest"
}
restore_quarantine() {
  if [ -e "$ASIDE" ]; then mv -f "$ASIDE" "$CREDS"; fi
}
cleanup() {
  tmux kill-session -t "$SESS" 2>/dev/null || true
  restore_quarantine
  restore_snapshot
}
trap cleanup EXIT INT TERM

echo "  mode=$MODE fabric=$FABRIC gw=$GW presence-route=$PRESENCE"

# 3a. tmux
command -v tmux >/dev/null 2>&1 || {
  apt-get install -y -qq tmux >/tmp/vclaw-tui-apt.log 2>&1 || { echo "FAIL: tmux unavailable"; exit 1; }
}

# 3b. installed package → ESM extension package (plugin dir)
GLOBAL_ROOT=$(npm root -g) || { echo "FAIL: npm root -g"; exit 1; }
BUNDLE="$GLOBAL_ROOT/@vclawhub/agent/dist/pi-extension/index.bundled.js"
[ -f "$BUNDLE" ] || { echo "FAIL: installed bundle missing: $BUNDLE (build/pack the tarball with dist/)"; exit 1; }
bundle_got=$(sha256sum "$BUNDLE" | cut -d' ' -f1)
if [ "$SKIP_PIN" != 1 ] && [ -n "$BUNDLE_SHA" ]; then
  if [ "$bundle_got" != "$BUNDLE_SHA" ]; then
    echo "FAIL: installed bundle sha256 $bundle_got != pinned $BUNDLE_SHA"
    exit 1
  fi
  echo "   bundle ${bundle_got:0:12}… (pinned)"
else
  echo "   bundle ${bundle_got:0:12}… (unpinned)"
fi

mkdir -p "$PLUGDIR"
cat > "$PLUGDIR/package.json" <<JSON
{"name":"vclaw-e2e","version":"1.0.0","type":"module","main":"index.js"}
JSON
# ESM re-export of the installed factory. The file:// URL is absolute on purpose:
# OMP loads this module by realpath, independent of cwd.
printf 'export { default } from "file://%s";\n' "$BUNDLE" > "$PLUGDIR/index.js"

# 3c. pre-seed the first-run wizard (a fresh HOME silently eats keystrokes)
mkdir -p "$(dirname "$CFG")"
if [ -f "$CFG" ] && ! grep -q '^setupVersion:' "$CFG"; then
  cp "$CFG" "$CFG.e2e-bak"
  printf 'setupVersion: 2\n' >> "$CFG"
elif [ ! -f "$CFG" ]; then
  printf 'setupVersion: 2\n' > "$CFG"
fi

# 3d. no-identity variant: credentials out of the way for the WHOLE run
if [ "$NO_IDENTITY" = 1 ]; then
  [ -f "$CREDS" ] || { echo "FAIL: NO_IDENTITY=1 but no $CREDS to move aside"; exit 1; }
  [ -e "$ASIDE" ] && { echo "FAIL: stale $ASIDE exists"; exit 1; }
  mv "$CREDS" "$ASIDE"
fi
snapshot_identity

# pending claim flag: `login` re-issues a link instead of answering "already authenticated" when
# one is on disk, which is a different (gateway-dependent) class. Detect it instead of guessing.
PENDING=0
for p in /root/.config/vclaw/.pending /root/.config/vchat/.pending /root/.vchat/.pending; do
  [ -e "$p" ] && PENDING=1
done

# 3e. start the TUI — MODEL-FREE: `env -i` means no provider keys, no API tokens, no inherited
# credentials of any kind. If a verb needed the model it could not reach one.
tmux kill-session -t "$SESS" 2>/dev/null || true
rm -f "$OUT"
tmux new-session -d -s "$SESS" -x 200 -y 60 -c /root || { echo "FAIL: tmux new-session"; exit 1; }
tmux send-keys -t "$SESS" "exec env -i HOME=/root PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin TERM=xterm-256color omp" Enter

ready_start=$(date +%s%N)
stable=0
ready=0
for _ in $(seq 1 $((WAIT_READY_S * 4))); do
  sleep 0.25
  pane=$(tmux capture-pane -t "$SESS" -p 2>/dev/null || true)
  if printf '%s' "$pane" | grep -q 'AUTO ·'; then stable=$((stable+1)); else stable=0; fi
  [ "$stable" -ge 4 ] && { ready=1; break; }
done
ready_ms=$(( ($(date +%s%N) - ready_start) / 1000000 ))
if [ "$ready" != 1 ]; then
  echo "FAIL: TUI did not reach the prompt in ${WAIT_READY_S}s; pane tail:"
  tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -15
  exit 1
fi
# Let extension session_start (fabric/mailbox subscribe) finish before typing.
sleep "$WAIT_SETTLE_S"

# 3f. drive one command and assert its appended exit code AND its own rendered text
drive() { # $1 args · $2 expected codes · $3 body regex · $4 why · $5 optional "code:regex" condition
  local args="$1" expected=" $2 " re="$3" why="${4:-}" cond="${5:-}"
  local base c start_ns elapsed line code body first pane_before pane_after hdr_line
  base=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); base=${base:-0}
  pane_before=$(tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^[[:space:]]*$' || true)
  # A previous command that has not been submitted yet gets CONCATENATED with this one
  # (measured 2026-11-01: "status --bogusflag/vclaw inbox" arrived as a single usage error).
  # Clear the composer first, then verify the appended line is the command we meant.
  tmux send-keys -t "$SESS" C-u
  sleep 0.2
  tmux send-keys -t "$SESS" "/vclaw${args:+ $args}" Enter
  start_ns=$(date +%s%N)
  c=$base
  for _ in $(seq 1 $((WAIT_RESULT_S * 10))); do
    sleep 0.1
    c=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); c=${c:-0}
    [ "$c" -gt "$base" ] && break
  done
  elapsed=$(( ($(date +%s%N) - start_ns) / 1000000 ))
  if [ "$c" -le "$base" ]; then
    pane_after=$(tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^[[:space:]]*$' || true)
    if [ "$pane_after" != "$pane_before" ]; then
      echo "   FAIL  /vclaw ${args} — MODEL FALL-THROUGH (distinct from a crash):"
      echo "         the pane rendered an answer, but $OUT gained no '=== ' line in ${WAIT_RESULT_S}s."
      echo "         Only the extension's command handler appends that line; a model reply cannot."
      echo "         (/vclaw is not registered — check the plugin's ESM package.json and its import.)"
    else
      echo "   FAIL  /vclaw ${args} — command never submitted: the pane did not change at all."
      echo "         (composer/keystroke problem, NOT a model fall-through)"
    fi
    printf '%s\n' "$pane_after" | tail -12 | sed 's/^/         /'
    fails=$((fails+1)); return 1
  fi
  line=$(grep '^=== ' "$OUT" | tail -1)
  # the header the extension writes is `=== <iso> /vclaw <argv.join(" ")> exit=<n>`
  if ! printf '%s\n' "$line" | grep -qF "/vclaw ${args} exit="; then
    echo "   FAIL  harness: appended line is not the command sent"
    echo "         sent: /vclaw ${args}"
    echo "         line: $line"
    fails=$((fails+1)); return 1
  fi
  hdr_line=$(grep -n '^=== ' "$OUT" | tail -1 | cut -d: -f1)
  code=${line##*exit=}
  body=$(tail -n +$(( hdr_line + 1 )) "$OUT")
  first=$(printf '%s\n' "$body" | grep -v '^[[:space:]]*$' | head -1)
  # 1. the class set is CLOSED: §5 defines 0/2/3/4 and nothing else. Exit 1 means a throw with no
  #    class of its own reached the catch — a bug, never a state a caller may expect.
  case "$code" in
    0|2|3|4) ;;
    *) fail "/vclaw ${args} — exit=$code is outside the §5 class set {0,2,3,4}"; return 1 ;;
  esac
  # 2. empty text is a refusal with no reason: not a proof of anything
  if [ -z "$first" ]; then fail "/vclaw ${args} — exit=$code with EMPTY text (a verb must say why)"; return 1; fi
  # 3. the class this state implies
  case "$expected" in
    *" $code "*) ;;
    *) fail "/vclaw ${args} — exit=$code, expected one of: $2  (first line: $first)"; return 1 ;;
  esac
  # 4. the VERB's own text — a string only its renderer produces
  if ! printf '%s\n' "$body" | grep -qE "$re"; then
    fail "/vclaw ${args} — exit=$code but the text does not match /$re/: $first"
    return 1
  fi
  # 5. a class-conditioned claim (e.g. exit=3 must name the check that failed)
  if [ -n "$cond" ]; then
    local cc="${cond%%:*}" cr="${cond#*:}"
    if [ "$code" = "$cc" ] && ! printf '%s\n' "$body" | grep -qE "$cr"; then
      fail "/vclaw ${args} — exit=$code requires /$cr/ in the text, it is not there: $first"
      return 1
    fi
  fi
  rows+=("$(printf '%-28s exit=%-2s exp %-4s %6sms  PASS  %-24s| %s' \
    "/vclaw ${args}" "$code" "$2" "$elapsed" "$why" "$(printf '%s' "$first" | cut -c1-72)")")
  return 0
}

# ── 4. the 13 verbs ───────────────────────────────────────────────────────
# Expectations per mode. Every non-zero class is justified in `why`.
if [ "$NO_IDENTITY" = 1 ]; then
  e_status=4;   r_status='identity[[:space:]]+not onboarded'
  e_doctor=4;   r_doctor='✗ identity[[:space:]]+no credentials'
  e_who=4;      r_who='no identity on this host'
  e_peers=4;    r_peers='no identity and no cached roster'
  e_send=4;     r_send='no identity on this host'
  e_inbox=4;    r_inbox='no identity on this host'
  e_provider=0; r_provider='vclaw provider — endpoints'
  e_init=4;     r_init='vclaw init — resumable'
  e_reauth=4;   r_reauth='vclaw reauth — no identity on this host'
  e_login=4;    r_login='vclaw login — no identity on this host'
  e_down=4;     r_down='no identity on this host, so there is no presence to withdraw'
  e_logout=0;   r_logout='already logged out'
else
  e_status=0;   r_status='identity[[:space:]]+agent-'
  # doctor never dials the fabric/cloud API; its 3 comes from ENVIRONMENT checks that are missing in
  # this container (site-fabric: no nats-ipc.conf; tier-p: no pears helper). A bare 3 is not
  # accepted — the text must show the failing check, so "always says 3" fails the row.
  e_doctor="0 3"; r_doctor='✓ identity[[:space:]]+credentials at'; c_doctor='3:✗ '
  if [ "$FABRIC" = up ]; then
    e_who=0;    r_who='vclaw who'
    e_inbox=0;  r_inbox='vclaw inbox'
    e_send=0;   r_send='published'
  else
    # class 3 is the CORRECT answer for both: the dependency is unreachable, and the text must say
    # which dependency (`cannot reach the fabric`), so an unrelated 3 still fails the row.
    e_who=3;    r_who='cannot reach the fabric'
    e_inbox=3;  r_inbox='cannot reach the fabric'
    e_send=3;   r_send='cannot reach the fabric'
  fi
  e_peers=0;    r_peers='vclaw peers'
  e_provider=0; r_provider='vclaw provider — endpoints'
  # init is read-only and stops at the first unmet step: identity/approval ⇒ 4, providers/doctor ⇒ 3,
  # everything passes ⇒ 0. A 3 must show the unreached steps in its own text.
  e_init="0 3"; r_init='vclaw init — resumable'; c_init='3:not reached'
  if [ "$GW" = 0 ]; then e_reauth=3; r_reauth='could not mint'; else e_reauth=0; r_reauth='token minted'; fi
  if [ "$PENDING" = 1 ]; then e_login="0 3 4"; r_login='vclaw login — '; else e_login=0; r_login='already authenticated'; fi
  case "$PRESENCE" in
    0|404) e_down=3; r_down='presence write was refused' ;;
    *)     e_down=0; r_down='presence withdrawn|already down' ;;
  esac
  e_logout=0;   r_logout='vclaw logout — logged out'
fi
e_help=0; r_help='one command, no model required'

# 4a. GATE: is /vclaw registered at all? A model fall-through here would otherwise produce 13
# confusable failures; one gate row names the real cause. Not counted among the 13.
drive "" "0" "$r_help" "gate" || {
  echo "  RESULT FAIL — /vclaw never dispatched; the 13 rows would all fail the same way."
  exit 1
}
rows=()   # the gate row is evidence, not a row

c_send=''
c_status=''; c_doctor=${c_doctor:-}; c_who=''; c_peers=''; c_inbox=''; c_provider=''
c_init=${c_init:-}; c_reauth=''; c_login=''; c_down=''; c_logout=''

drive "status --deep"   "$e_status"   "$r_status"   "local: identity" "$c_status"
drive "doctor"          "$e_doctor"   "$r_doctor"   "env checks"     "$c_doctor"
drive "who"             "$e_who"      "$r_who"      "fabric"         "$c_who"
drive "peers"           "$e_peers"    "$r_peers"    "local roster"   "$c_peers"
# `send <unknown peer> hi`: the token is a syntactically valid NKey no peer answers to. `send` is a
# PUBLISH, not a lookup — it never resolves the peer, so an unknown-but-valid token is not a usage
# error; the class tracks the fabric instead (3 while it is unreachable, 0 = published at-most-once
# when it is up). A malformed token (`bad.peer`) would be 2, and the E1 CLI harness asserts that.
drive "send UE2EUNKNOWNPEER hi" "$e_send" "$r_send" "fabric"     "$c_send"
drive "inbox"           "$e_inbox"    "$r_inbox"    "fabric"         "$c_inbox"
drive "provider list"   "$e_provider" "$r_provider" "local: models.yml" "$c_provider"
drive "init"            "$e_init"     "$r_init"     "aggregate"      "$c_init"
drive "reauth"          "$e_reauth"   "$r_reauth"   "gateway"        "$c_reauth"
drive "login"           "$e_login"    "$r_login"    "local/gateway"  "$c_login"
drive "down"            "$e_down"     "$r_down"     "gateway route"  "$c_down"

# logout is the one destructive verb: it DELETES this host's credentials (bare form; the identity
# stays on the fabric). Drive it, prove the file is actually gone, then restore the snapshot so the
# container keeps its identity for the next mode and for other lanes.
if drive "logout" "$e_logout" "$r_logout" "local drop" "$c_logout"; then
  if [ "$NO_IDENTITY" = 1 ]; then
    [ -e "$CREDS" ] && fail "logout (no-identity) — it created $CREDS out of nothing"
  else
    if [ -e "$CREDS" ]; then
      fail "logout — exit=0 but $CREDS is still on disk (the 'drop' did not happen)"
    else
      echo "   note  logout removed $CREDS — verified on disk, restoring the snapshot for the next mode"
    fi
  fi
  restore_snapshot
fi

drive ""                "$e_help"     "$r_help"     "usage"          ""

tmux kill-session -t "$SESS" 2>/dev/null || true

echo
echo "  ready in ${ready_ms}ms (marker stable 1s + ${WAIT_SETTLE_S}s settle) · omp started under env -i (no provider keys)"
printf '  %s\n' "${rows[@]+"${rows[@]}"}"
echo "  captured: $OUT"
echo "  per-row: exit · exp = class this state implies · ms = wall time (a hidden call shows here)"
echo "  class derivations: fabric=$FABRIC · gw=$GW (0=unreachable · reauth) · presence-route=$PRESENCE (404=absent · down) · pending=$PENDING (login)"
if [ "${#rows[@]}" -ne 13 ]; then
  echo "  FAIL: expected 13 rows, asserted ${#rows[@]}"
  fails=$((fails+1))
fi
if [ "$fails" -ne 0 ]; then
  echo "  RESULT FAIL ($fails mismatch(es))"
  exit 1
fi
echo "  RESULT PASS (13/13)"
EOS

# ── 4. run each identity mode ----------------------------------------------
overall=0
for mode in $MODES; do
  case "$mode" in
    identity)    NI=0 ;;
    no-identity) NI=1 ;;
    *) die "unknown mode \"$mode\" (identity|no-identity)" ;;
  esac
  echo
  echo "== /vclaw TUI e2e — container $CONTAINER ($mode) — 13 verbs"

  cat /tmp/vclaw-tui-harness.sh | k "cat > /tmp/vclaw-tui-harness.sh && sudo -n incus file push /tmp/vclaw-tui-harness.sh $CONTAINER/root/vclaw-tui-harness.sh" >/dev/null \
    || die "could not stage container harness"

  k "sudo -n incus exec $CONTAINER -- bash -c 'exec env MODE=$mode NO_IDENTITY=$NI FABRIC=$FABRIC GW=$GW PRESENCE=$PRESENCE BUNDLE_SHA=$BUNDLE_SHA SKIP_PIN=$SKIP_PIN WAIT_READY_S=$WAIT_READY_S WAIT_RESULT_S=$WAIT_RESULT_S bash /root/vclaw-tui-harness.sh'" \
    2>&1 | tee "/tmp/vclaw-tui-e2e-$mode.log"
  rc=${PIPESTATUS[0]}
  [ "$rc" -eq 0 ] && echo "== $mode PASS" || { echo "== $mode FAIL (rc=$rc)"; overall=1; }
done

echo
[ "$overall" -eq 0 ] && echo "== PASS (both modes)" || echo "== FAIL (see the mode summary above)"
exit "$overall"
