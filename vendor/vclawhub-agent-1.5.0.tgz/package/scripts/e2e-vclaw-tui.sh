#!/usr/bin/env bash
# e2e-vclaw-tui.sh — the /vclaw TUI acceptance loop, scripted.
#
# Turns the manual tmux recipe into a check: install the pinned artefact into an
# incus container (or accept SKIP_INSTALL=1), build an ESM extension package from
# the installed bundle, start `omp` under tmux, drive the TUI commands, and assert
# the exit codes the extension appended to ~/.vclaw/vclaw-out.txt. Fails non-zero
# on any mismatch.
#
# Why this harness exists:
#   * OMP print mode does NOT dispatch extension commands, so `/vclaw` is
#     TUI-only; the CLI (`vclaw-agent vclaw …`) is a different surface.
#   * A pty keeps only the cursor region, so a screen scrape cannot be asserted.
#     The extension appends `=== <iso> /vclaw <args> exit=<n>` + rendered text to
#     ~/.vclaw/vclaw-out.txt; that file is the assertion surface.
#   * A plugin dir whose package.json omits `"type": "module"` is loaded as CJS,
#     the import silently fails, `/vclaw` is not registered, and OMP hands the
#     text to the MODEL — which can look like a successful run. This script
#     therefore writes an ESM package.json AND fails when the capture file never
#     grows (it prints the pane tail so a model fall-through is visible).
#   * A fresh $HOME opens OMP's first-run wizard, which eats keystrokes before
#     any command runs; we pre-seed `setupVersion: 2` in config.yml.
#
# Wait times (measured on omp-1, shipped pin):
#   * TUI ready: banner/prompt appears ~1.3 s, but extension session_start is
#     still settling. We require the status line marker (`AUTO ·`) to be present
#     for 4 consecutive 250 ms samples, then settle WAIT_SETTLE_S=2 s.
#   * Result: `/vclaw status --bogusflag` ~0.1 s; `/vclaw inbox` ~4.3 s
#     (3 s default drain window + fabric connect/sync); `/vclaw who` ~5.2 s
#     (4 s default presence window + JWT fetch). With no identity, inbox/who
#     return exit=4 in ~0.1 s. We poll the capture file (0.1 s cadence) until a
#     new `=== ` header appears, up to WAIT_RESULT_S=90 s — a fixed sleep would
#     either read a spinner or race the slow path. The file is written once per
#     invocation (header + text), so a header implies the text is complete.
#
# Env:
#   CONTAINER=omp-1          incus container
#   KUAI=debian@kuai         tailscale ssh host running incus
#   TARBALL=<repo>/vclawhub-agent-1.5.0.tgz
#   ARTIFACT_SHA=<sha256>    pinned tarball (empty string disables the check)
#   BUNDLE_SHA=<sha256>      pinned dist/pi-extension/index.bundled.js
#   SKIP_INSTALL=1           use the package already installed in the container
#   SKIP_PIN=1               skip artifact/bundle sha verification
#   NO_IDENTITY=1            move ~/.config/vclaw/credentials.json aside for the
#                            whole run, restore on exit; expects exit=4 for
#                            inbox/who instead of 0-or-4
#   WAIT_READY_S=60          TUI startup budget
#   WAIT_RESULT_S=90         per-command capture budget
set -uo pipefail

CONTAINER="${CONTAINER:-omp-1}"
KUAI="${KUAI:-debian@kuai}"
HERE="$(cd "$(dirname "$0")" && pwd)"
TARBALL="${TARBALL:-$HERE/../vclawhub-agent-1.5.0.tgz}"
ARTIFACT_SHA="${ARTIFACT_SHA-ce81ba34da3e1700fe7ddfd81540b5b1a56a97550ecc563d682c5975b5b99ed8}"
BUNDLE_SHA="${BUNDLE_SHA-45c7430175c2cc86a021daf098f01678189c1a7c7f1dc07a59ff5d496a18bb4d}"
SKIP_INSTALL="${SKIP_INSTALL:-0}"
SKIP_PIN="${SKIP_PIN:-0}"
NO_IDENTITY="${NO_IDENTITY:-0}"
WAIT_READY_S="${WAIT_READY_S:-60}"
WAIT_RESULT_S="${WAIT_RESULT_S:-90}"

die() { printf 'e2e-vclaw-tui: %s\n' "$*" >&2; exit 1; }

[ "$NO_IDENTITY" = 1 ] && variant="no-identity" || variant="identity"
echo "== /vclaw TUI e2e — container $CONTAINER ($variant)"

k() { tailscale ssh "$KUAI" "$@"; }

# ── 1. artefact ------------------------------------------------------------
if [ "$SKIP_INSTALL" != 1 ]; then
  [ -f "$TARBALL" ] || die "tarball not found: $TARBALL"
  if [ "$SKIP_PIN" != 1 ] && [ -n "$ARTIFACT_SHA" ]; then
    got=$(shasum -a 256 "$TARBALL" | cut -d' ' -f1)
    [ "$got" = "$ARTIFACT_SHA" ] || die "tarball sha256 mismatch: $got (pinned $ARTIFACT_SHA)"
  fi
  echo "   installing $(basename "$TARBALL") — sha256 $(shasum -a 256 "$TARBALL" | cut -c1-12)…"
  cat "$TARBALL" | k 'cat > /tmp/agent.tgz' || die "push to $KUAI failed"
  k "sudo -n incus file push /tmp/agent.tgz $CONTAINER/root/agent.tgz" >/dev/null || die "incus file push failed"
  k "sudo -n incus exec $CONTAINER -- env PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin npm i -g /root/agent.tgz --no-audit --no-fund" >/tmp/vclaw-tui-install.log 2>&1 \
    || { cat /tmp/vclaw-tui-install.log >&2; die "npm install failed"; }
else
  echo "   SKIP_INSTALL=1: using the package already installed in $CONTAINER"
fi

# ── 2. container-side harness ----------------------------------------------
# Everything below runs INSIDE the container as root.
cat > /tmp/vclaw-tui-harness.sh <<'EOS'
#!/usr/bin/env bash
set -uo pipefail
export HOME=/root
export PATH=/usr/local/bin:/root/.bun/bin:/usr/bin:/bin
export TERM=xterm-256color

NO_IDENTITY="${NO_IDENTITY:-0}"
BUNDLE_SHA="${BUNDLE_SHA:-}"
SKIP_PIN="${SKIP_PIN:-0}"
WAIT_READY_S="${WAIT_READY_S:-60}"
WAIT_RESULT_S="${WAIT_RESULT_S:-90}"
WAIT_SETTLE_S=2

OUT=/root/.vclaw/vclaw-out.txt
SESS=vclaw-tui-e2e
PLUGDIR=/root/.omp/agent/extensions/vclaw-e2e
CFG=/root/.omp/agent/config.yml
ASIDE=/root/.config/vclaw/credentials.json.e2e-aside
fails=0
declare -a rows=()

fail() { printf '   FAIL  %s\n' "$*"; fails=$((fails+1)); }

restore_identity() {
  if [ -e "$ASIDE" ]; then
    mv -f "$ASIDE" /root/.config/vclaw/credentials.json
  fi
}
cleanup() {
  restore_identity
  tmux kill-session -t "$SESS" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# 2a. tmux
command -v tmux >/dev/null 2>&1 || {
  apt-get install -y -qq tmux >/tmp/vclaw-tui-apt.log 2>&1 || { echo "FAIL: tmux unavailable"; exit 1; }
}

# 2b. installed package → ESM extension package (plugin dir)
GLOBAL_ROOT=$(npm root -g) || { echo "FAIL: npm root -g"; exit 1; }
BUNDLE="$GLOBAL_ROOT/@vclawhub/agent/dist/pi-extension/index.bundled.js"
[ -f "$BUNDLE" ] || { echo "FAIL: installed bundle missing: $BUNDLE (build/pack the tarball with dist/)"; exit 1; }
bundle_got=$(sha256sum "$BUNDLE" | cut -d' ' -f1)
if [ "$SKIP_PIN" != 1 ] && [ -n "$BUNDLE_SHA" ]; then
  if [ "$bundle_got" != "$BUNDLE_SHA" ]; then
    echo "FAIL: installed bundle sha256 $bundle_got != pinned $BUNDLE_SHA"
    exit 1
  fi
  echo "   bundle ${bundle_got:0:12}… (pinned)"
else
  echo "   bundle ${bundle_got:0:12}… (unpinned)"
fi

mkdir -p "$PLUGDIR"
cat > "$PLUGDIR/package.json" <<JSON
{"name":"vclaw-e2e","version":"1.0.0","type":"module","main":"index.js"}
JSON
# ESM re-export of the installed factory. The file:// URL is absolute on purpose:
# OMP loads this module by realpath, independent of cwd.
printf 'export { default } from "file://%s";\n' "$BUNDLE" > "$PLUGDIR/index.js"

# 2c. pre-seed the first-run wizard (a fresh HOME silently eats keystrokes)
mkdir -p "$(dirname "$CFG")"
if [ -f "$CFG" ] && ! grep -q '^setupVersion:' "$CFG"; then
  cp "$CFG" "$CFG.e2e-bak"
  printf 'setupVersion: 2\n' >> "$CFG"
elif [ ! -f "$CFG" ]; then
  printf 'setupVersion: 2\n' > "$CFG"
fi

# 2d. no-identity variant: credentials out of the way for the WHOLE run
if [ "$NO_IDENTITY" = 1 ]; then
  [ -f /root/.config/vclaw/credentials.json ] || { echo "FAIL: NO_IDENTITY=1 but no credentials.json to move aside"; exit 1; }
  [ -e "$ASIDE" ] && { echo "FAIL: stale $ASIDE exists"; exit 1; }
  mv /root/.config/vclaw/credentials.json "$ASIDE"
fi

# 2e. start the TUI
tmux kill-session -t "$SESS" 2>/dev/null || true
rm -f "$OUT"
tmux new-session -d -s "$SESS" -x 200 -y 60 -c /root || { echo "FAIL: tmux new-session"; exit 1; }
tmux send-keys -t "$SESS" "omp" Enter

ready_start=$(date +%s%N)
stable=0
ready=0
for _ in $(seq 1 $((WAIT_READY_S * 4))); do
  sleep 0.25
  pane=$(tmux capture-pane -t "$SESS" -p 2>/dev/null || true)
  if printf '%s' "$pane" | grep -q 'AUTO ·'; then stable=$((stable+1)); else stable=0; fi
  [ "$stable" -ge 4 ] && { ready=1; break; }
done
ready_ms=$(( ($(date +%s%N) - ready_start) / 1000000 ))
if [ "$ready" != 1 ]; then
  echo "FAIL: TUI did not reach the prompt in ${WAIT_READY_S}s; pane tail:"
  tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -15
  exit 1
fi
# Let extension session_start (fabric/mailbox subscribe) finish before typing.
sleep "$WAIT_SETTLE_S"

# 2f. drive one command and assert its appended exit code
drive() { # $1 args, $2 expected codes (space-separated)
  local args="$1" expected=" $2 "
  local base c start_ns elapsed line code
  base=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); base=${base:-0}
  tmux send-keys -t "$SESS" "/vclaw $args" Enter
  start_ns=$(date +%s%N)
  c=$base
  for _ in $(seq 1 $((WAIT_RESULT_S * 10))); do
    sleep 0.1
    c=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); c=${c:-0}
    [ "$c" -gt "$base" ] && break
  done
  elapsed=$(( ($(date +%s%N) - start_ns) / 1000000 ))
  if [ "$c" -le "$base" ]; then
    echo "   FAIL  /vclaw $args — no line appended to $OUT in ${WAIT_RESULT_S}s"
    echo "         (extension not loaded, or /vclaw fell through to the model)"
    tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -12
    fails=$((fails+1)); return 1
  fi
  line=$(grep '^=== ' "$OUT" | tail -1)
  case "$line" in
    *"/vclaw $args exit="*) ;;
    *) echo "   FAIL  /vclaw $args — appended line is for a different command: $line"; fails=$((fails+1)); return 1 ;;
  esac
  code=${line##*exit=}
  case "$expected" in
    *" $code "*) rows+=("$(printf '%-30s exit=%-2s expected %-6s %6sms  PASS' "/vclaw $args" "$code" "$2" "$elapsed")") ;;
    *) rows+=("$(printf '%-30s exit=%-2s expected %-6s %6sms  FAIL' "/vclaw $args" "$code" "$2" "$elapsed")")
       echo "   FAIL  /vclaw $args — exit=$code, expected one of: $2"; fails=$((fails+1)); return 1 ;;
  esac
  return 0
}

# ── 3. assertions ----------------------------------------------------------
if [ "$NO_IDENTITY" = 1 ]; then
  inbox_codes="4"; who_codes="4"
else
  inbox_codes="0 4"; who_codes="0 4"
fi
drive "status --bogusflag" "2"
drive "inbox" "$inbox_codes"
drive "who" "$who_codes"

tmux kill-session -t "$SESS" 2>/dev/null || true
restore_identity

echo
echo "  ready in $((ready_ms))ms (marker stable 1s + ${WAIT_SETTLE_S}s settle)"
printf '  %s\n' "${rows[@]+"${rows[@]}"}"
echo "  captured: $OUT"
if [ "$fails" -ne 0 ]; then
  echo "  RESULT FAIL ($fails mismatch(es))"
  exit 1
fi
echo "  RESULT PASS (3/3)"
EOS

cat /tmp/vclaw-tui-harness.sh | k "cat > /tmp/vclaw-tui-harness.sh && sudo -n incus file push /tmp/vclaw-tui-harness.sh $CONTAINER/root/vclaw-tui-harness.sh" >/dev/null \
  || die "could not stage container harness"

k "sudo -n incus exec $CONTAINER -- bash -c 'exec env NO_IDENTITY=$NO_IDENTITY BUNDLE_SHA=$BUNDLE_SHA SKIP_PIN=$SKIP_PIN WAIT_READY_S=$WAIT_READY_S WAIT_RESULT_S=$WAIT_RESULT_S bash /root/vclaw-tui-harness.sh'"
rc=$?
[ "$rc" -eq 0 ] && echo "== PASS" || echo "== FAIL (rc=$rc)"
exit "$rc"
