#!/usr/bin/env bash
# e2e-vclaw-local-omp.sh — prove `/vclaw` works on THIS workstation's own `omp`
# (plan row E3: "usable on this OMP host, not a container").
#
# What this asserts, and why each assertion is the one that matters:
#
#   * The extension is loaded the way OMP actually loads plugins —
#     `omp plugin link <installed package>`. A hand-made directory is NOT a
#     plugin: `omp plugin doctor` reports it as "No omp/pi manifest (not an omp
#     plugin)" and the runtime loader skips it, so `/vclaw` is never registered
#     and OMP hands the text to the MODEL. That failure mode looks like success
#     from an exit status alone, which is why this script refuses to accept a row
#     on status: every row needs its own appended `=== … exit=<n>` line.
#   * The witness is `~/.vclaw/vclaw-out.txt` (the extension appends
#     `=== <iso> /vclaw <args> exit=<n>` + the rendered frame, 0600). A pty keeps
#     only the cursor region, so a screen scrape cannot be asserted; this file is.
#   * MODEL-FREE is proven twice, in two separate TUI processes:
#       RUN A: `env -i` — every provider env var of the caller is stripped;
#       RUN B: `env -i` + `--model zzz-nope` — a model that provably does not
#              exist (the TUI prints `Warning: Model "zzz-nope" not found` and its
#              status line reads `⬢ no-model`). A verb that needed a model could
#              not answer at all here.
#     The environment each TUI really ran under is dumped to run-<label>-env.txt
#     and asserted to contain NO provider/agent variable. Wall-clock per verb is
#     printed so a hidden network/model call shows up as a number.
#   * The whole run happens under a throwaway $HOME (temp dir), so the real
#     `~/.omp` and `~/.config/vclaw` are never touched: the script records their
#     state before and after and fails if either changed.
#
# Fallback: if `omp plugin link` fails on this host, the script retries the same
# two verbs with `omp -e <installed bundle>` (the explicit-extension path) and
# records which loading method worked. It does NOT silently downgrade the rows.
#
# Prereqs: `omp` (with bun on PATH — omp's entry point is `#!/usr/bin/env bun`),
# `tmux`, `npm`, `shasum`. Exits non-zero on any failed row.
#
# Env:
#   TARBALL=<repo>/vclawhub-agent-1.5.0.tgz
#   ARTIFACT_SHA=<sha256>   pinned tarball (empty disables the check)
#   BUNDLE_SHA=<sha256>     pinned dist/pi-extension/index.bundled.js inside it
#   WAIT_READY_S=60         TUI startup budget
#   WAIT_RESULT_S=60        per-command capture budget
#   WAIT_SETTLE_S=2         settle after the prompt marker is stable
#   KEEP=1                  keep the temp HOME/tree for inspection
#   FORCE_FALLBACK=1        skip `omp plugin link` and use `omp -e <bundle>`
#                           (exercises the fallback path the script takes when
#                            link fails on a host; the script prints which one ran)
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
TARBALL="${TARBALL:-$HERE/../vclawhub-agent-1.5.0.tgz}"
ARTIFACT_SHA="${ARTIFACT_SHA-87ab679e5982cb8d30f73181b62d463d435571b30f1a6134fdc37ac3cacbb2ac}"
BUNDLE_SHA="${BUNDLE_SHA-32a6a94fc0eddcbe826478014a6b66a4accf42f46e6a6070f4479dc5ba9cb483}"
WAIT_READY_S="${WAIT_READY_S:-60}"
WAIT_RESULT_S="${WAIT_RESULT_S:-60}"
WAIT_SETTLE_S="${WAIT_SETTLE_S:-2}"
KEEP="${KEEP:-0}"
FORCE_FALLBACK="${FORCE_FALLBACK:-0}"
BOGUS_MODEL="${BOGUS_MODEL:-zzz-nope}"

die() { printf 'e2e-vclaw-local-omp: %s\n' "$*" >&2; exit 1; }

fails=0
declare -a rows=()
fail() { printf '   FAIL  %s\n' "$*"; fails=$((fails + 1)); }

# provider/agent variables that must NOT reach the TUI (names only, never values)
PROVIDER_ENV_RE='^(ANTHROPIC|OPENAI|AZURE_OPENAI|GEMINI|GOOGLE|DEEPSEEK|DASHSCOPE|GROQ|MISTRAL|XAI|OPENROUTER|TOGETHER|FIREWORKS|CEREBRAS|HF_|HUGGINGFACE|PERPLEXITY|MOONSHOT|ZAI|QWEN|OLLAMA|LM_STUDIO|LLAMACPP|PI_|VCLAW_|OMP_)'

echo "== /vclaw on THIS host's omp"

# ── 0. preflight ───────────────────────────────────────────────────────────
OMP_BIN=$(command -v omp || true)
[ -n "$OMP_BIN" ] || die "omp not found on PATH — this row is about the real OMP host"
OMP_VERSION=$("$OMP_BIN" --version 2>&1 | head -1)
command -v tmux >/dev/null 2>&1 || die "tmux not found (brew install tmux) — a pty driver is required"
TMUX_VERSION=$(tmux -V 2>&1 | head -1)
command -v npm >/dev/null 2>&1 || die "npm not found"
BUN_BIN=$(command -v bun 2>/dev/null || true)
[ -n "$BUN_BIN" ] || [ -x "$HOME/.bun/bin/bun" ] || die "bun not found — omp's entry point is '#!/usr/bin/env bun'"
echo "   omp    $OMP_VERSION  ($OMP_BIN)"
echo "   tmux   $TMUX_VERSION"
echo "   host   $(uname -s) $(uname -m)"

# host provider-variable census: proves the caller HAD them, so stripping is meaningful
# Canaries: this process exports a synthetic key for each major provider BEFORE the
# census, so the "no provider env var reached the TUI" assertion is self-contained
# even on a host that carries no real keys. They are obvious dummies — never a real key.
export OPENAI_API_KEY=canary-openai ANTHROPIC_API_KEY=canary-anthropic \
  GEMINI_API_KEY=canary-gemini DEEPSEEK_API_KEY=canary-deepseek PI_API_KEY=canary-pi
host_env_hits=$(env | cut -d= -f1 | grep -E "$PROVIDER_ENV_RE" | sort | tr '\n' ' ')
echo "   caller provider/agent env vars (values never read): ${host_env_hits:-none}"
printf '%s' "$host_env_hits" | grep -q 'OPENAI_API_KEY' || die "canary provider vars did not land in this process env"

# ── 1. staging: install the pinned artefact into a temp tree ───────────────
[ -f "$TARBALL" ] || die "tarball not found: $TARBALL"
if [ -n "$ARTIFACT_SHA" ]; then
  got=$(shasum -a 256 "$TARBALL" | cut -d' ' -f1)
  [ "$got" = "$ARTIFACT_SHA" ] || die "tarball sha256 mismatch: $got (pinned $ARTIFACT_SHA)"
  echo "   tarball $(basename "$TARBALL") sha256 ${got:0:12}… (pinned)"
fi

WORK=$(mktemp -d "${TMPDIR:-/tmp}/vclaw-local-omp.XXXXXX") || die "mktemp failed"
HOME_T="$WORK/home"
PKG="$WORK/pkg"
mkdir -p "$HOME_T/.omp/agent"
SESS="vclaw-local-e2e"

cleanup() {
  tmux kill-session -t "$SESS" 2>/dev/null || true
  # the pane pid is the launcher (exec'd into omp): kill it if tmux left it behind
  [ -n "${PANE_PID:-}" ] && kill -TERM "$PANE_PID" 2>/dev/null || true
  pkill -f "$WORK/launch-" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# real-HOME fingerprint: the whole run must leave it untouched
real_state() {
  printf 'vclaw-out:%s\n' "$(ls -la "$HOME/.vclaw/vclaw-out.txt" 2>/dev/null | awk '{print $5"-"$6"-"$7"-"$8}' || echo absent)"
  printf 'plugins-lock:%s\n' "$(shasum -a 256 "$HOME/.omp/plugins/omp-plugins.lock.json" 2>/dev/null | cut -d' ' -f1 || echo absent)"
  printf 'omp-plugin-list:%s\n' "$("$OMP_BIN" plugin list 2>&1 | tr '\n' '|')"
}
real_before=$(real_state)

echo "   installing $(basename "$TARBALL") into $PKG (temp prefix, real ~/.config untouched)"
npm i --prefix "$PKG" --no-audit --no-fund "$TARBALL" >"$WORK/npm-install.log" 2>&1 \
  || { tail -20 "$WORK/npm-install.log" >&2; die "npm install failed"; }

INSTALLED="$PKG/node_modules/@vclawhub/agent"
BUNDLE="$INSTALLED/dist/pi-extension/index.bundled.js"
[ -f "$BUNDLE" ] || die "installed bundle missing: $BUNDLE"
bundle_got=$(shasum -a 256 "$BUNDLE" | cut -d' ' -f1)
if [ -n "$BUNDLE_SHA" ]; then
  [ "$bundle_got" = "$BUNDLE_SHA" ] || die "installed bundle sha256 $bundle_got != pinned $BUNDLE_SHA"
  echo "   bundle ${bundle_got:0:12}… (pinned)"
else
  echo "   bundle ${bundle_got:0:12}… (unpinned)"
fi

# ── 2. load the extension: `omp plugin link <installed package>` ───────────
# The installed package carries the `pi` manifest (pi.extensions →
# dist/pi-extension/index.bundled.js + dist/ext-synadia/index.bundled.js), which
# is exactly what the runtime loader needs; a hand-made dir has no manifest.
mkdir -p "$HOME_T/.omp/agent"
printf 'setupVersion: 2\n' >"$HOME_T/.omp/agent/config.yml"   # skip the first-run wizard

LINK_CMD="omp plugin link $INSTALLED"
LOAD_MODE="plugin-link"
OMP_ARGS=()
link_rc=0
link_out=""
if [ "$FORCE_FALLBACK" = 1 ]; then
  echo "   FORCE_FALLBACK=1: skipping plugin link, using omp -e <installed bundle>"
  load_forced=1
else
  link_out=$(HOME="$HOME_T" "$OMP_BIN" plugin link "$INSTALLED" 2>&1)
  link_rc=$?
  printf '%s\n' "$link_out" | sed 's/^/   /'
  load_forced=0
fi
if [ "$load_forced" = 1 ] || [ "$link_rc" -ne 0 ]; then
  [ "$load_forced" = 1 ] || fail "omp plugin link failed (rc=$link_rc): $link_out"
  echo "   falling back to the explicit-extension path: omp -e <installed bundle>"
  LOAD_MODE="extension-flag"
  OMP_ARGS+=(-e "$BUNDLE")
else
  list_out=$(HOME="$HOME_T" "$OMP_BIN" plugin list 2>&1)
  printf '%s\n' "$list_out" | sed 's/^/   /'
  printf '%s\n' "$list_out" | grep -q '@vclawhub/agent' \
    || fail "plugin list does not show @vclawhub/agent after link"
fi
echo "   load mode: $LOAD_MODE"

# ── 3. TUI driver ──────────────────────────────────────────────────────────
PATH_TUI="$(dirname "$OMP_BIN"):/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

write_launcher() { # $1 label, $2.. extra omp args
  local label="$1"; shift
  local envfile="$WORK/run-$label-env.txt"
  {
    printf '#!/usr/bin/env bash\n'
    printf 'env -i HOME=%s PATH=%s TERM=xterm-256color ' "$HOME_T" "$PATH_TUI"
    printf "bash -c 'env | sort > %s; exec omp" "$envfile"
    for a in "$@"; do printf ' %s' "$a"; done
    printf "'\n"
  } >"$WORK/launch-$label.sh"
  chmod +x "$WORK/launch-$label.sh"
  printf '%s' "$envfile"
}

start_tui() { # $1 label, $2.. omp args → prints env-file path
  local label="$1"; shift
  local envfile
  envfile=$(write_launcher "$label" "$@")
  tmux kill-session -t "$SESS" 2>/dev/null || true
  tmux new-session -d -s "$SESS" -x 200 -y 50 -c "$WORK" "bash $WORK/launch-$label.sh" \
    || die "tmux new-session failed"
  PANE_PID=$(tmux list-panes -t "$SESS" -F '#{pane_pid}' 2>/dev/null | head -1)
  printf '%s' "$envfile"
}

wait_ready() {
  local start_ns stable=0 pane
  start_ns=$(date +%s%N)
  for _ in $(seq 1 $((WAIT_READY_S * 4))); do
    sleep 0.25
    pane=$(tmux capture-pane -t "$SESS" -p 2>/dev/null || true)
    if printf '%s' "$pane" | grep -Eq 'π >|AUTO ·'; then stable=$((stable + 1)); else stable=0; fi
    [ "$stable" -ge 4 ] && { echo $((($(date +%s%N) - start_ns) / 1000000)); return 0; }
    tmux has-session -t "$SESS" 2>/dev/null || break
  done
  echo "FAIL: TUI did not reach the prompt in ${WAIT_READY_S}s; pane tail:" >&2
  tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -15 >&2
  return 1
}

# wait for the extension's own session_start notify — proof `/vclaw` is REGISTERED,
# not that the text fell through to the model
wait_extension() {
  local pane
  for _ in $(seq 1 120); do
    pane=$(tmux capture-pane -t "$SESS" -p 2>/dev/null || true)
    printf '%s' "$pane" | grep -q 'vchat:' && return 0
    sleep 0.25
  done
  return 1
}

drive() { # $1 args, $2 expected codes, $3 frame substring, $4 label
  local args="$1" expected=" $2 " frame="$3" label="$4"
  local base c start_ns elapsed line code pane ok
  base=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); base=${base:-0}
  # a command typed before the previous one submitted gets CONCATENATED — clear first
  tmux send-keys -t "$SESS" C-u
  sleep 0.2
  tmux send-keys -t "$SESS" "/vclaw $args" Enter
  start_ns=$(date +%s%N)
  c=$base
  for _ in $(seq 1 $((WAIT_RESULT_S * 10))); do
    sleep 0.1
    c=$(grep -c '^=== ' "$OUT" 2>/dev/null || true); c=${c:-0}
    [ "$c" -gt "$base" ] && break
  done
  elapsed=$((($(date +%s%N) - start_ns) / 1000000))
  if [ "$c" -le "$base" ]; then
    echo "   FAIL  [$label] /vclaw $args — nothing appended to $OUT in ${WAIT_RESULT_S}s"
    echo "         (extension not registered, or /vclaw fell through to the model)"
    tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -12
    fail "[$label] /vclaw $args — no capture line (model fall-through)"
    return 1
  fi
  line=$(grep '^=== ' "$OUT" | tail -1)
  if ! printf '%s\n' "$line" | grep -qF "/vclaw $args exit="; then
    fail "[$label] appended line is not the command sent"
    echo "         sent: /vclaw $args"
    echo "         line: $line"
    return 1
  fi
  code=${line##*exit=}
  case " 0 2 3 4 " in
    *" $code "*) ;;
    *) fail "[$label] /vclaw $args — exit=$code outside {0,2,3,4}"; return 1 ;;
  esac
  # the frame: the pty keeps only the cursor region, so read scrollback too
  ok=0
  for _ in $(seq 1 50); do
    pane=$(tmux capture-pane -t "$SESS" -p -S -300 2>/dev/null || true)
    printf '%s' "$pane" | grep -qF "$frame" && { ok=1; break; }
    sleep 0.1
  done
  [ "$ok" = 1 ] || fail "[$label] /vclaw $args — frame did not render (missing: $frame)"
  case "$expected" in
    *" $code "*)
      rows+=("$(printf '%-34s %-10s exit=%-2s expected %-6s %6sms  %s' "/vclaw $args" "$label" "$code" "$2" "$elapsed" "$([ "$ok" = 1 ] && echo PASS || echo 'FAIL(frame)')")") ;;
    *)
      rows+=("$(printf '%-34s %-10s exit=%-2s expected %-6s %6sms  FAIL' "/vclaw $args" "$label" "$code" "$2" "$elapsed")")
      fail "[$label] /vclaw $args — exit=$code, expected one of: $2"
      return 1 ;;
  esac
  return 0
}

run_tui() { # $1 label, $2.. omp args
  local label="$1"; shift
  local envfile ready_ms argstr="$*"
  echo
  echo "-- RUN $label: env -i + omp ${argstr:-<no model flag>}"
  OUT="$HOME_T/.vclaw/vclaw-out.txt"
  rm -f "$OUT"
  envfile=$(start_tui "$label" "$@")
  ready_ms=$(wait_ready) || { fail "[$label] TUI never became ready"; return 1; }
  if ! wait_extension; then
    fail "[$label] extension session_start notify ('vchat: …') never appeared — /vclaw is not registered"
    tmux capture-pane -t "$SESS" -p 2>/dev/null | grep -v '^$' | tail -12
  fi
  sleep "$WAIT_SETTLE_S"
  rows+=("$(printf '%-34s %-10s %s' "(tui ready)" "$label" "$(printf '%6sms' "$ready_ms")")")

  # model-free evidence, per process: the environment the TUI actually got
  [ -f "$envfile" ] || fail "[$label] env dump missing: $envfile"
  env_hits=$(cut -d= -f1 "$envfile" 2>/dev/null | grep -E "$PROVIDER_ENV_RE" | sort | tr '\n' ' ')
  if [ -n "$env_hits" ]; then
    fail "[$label] provider/agent env vars leaked into the TUI: $env_hits"
  else
    echo "   env: $(wc -l <"$envfile" | tr -d ' ') vars, no provider/agent var present"
  fi
  pane=$(tmux capture-pane -t "$SESS" -p -S -300 2>/dev/null || true)
  printf '%s' "$pane" | grep -q 'vchat:' && echo "   extension: $(printf '%s' "$pane" | grep -o 'vchat: .*' | head -1)"

  # EVERY verb that can run without creating state on the real IDP. `signup` and `login` are
  # deliberately absent: in a temp HOME they would mint a pending identity against production, so
  # they are covered by the container harness and the fixture server instead.
  drive "" "0" "vclaw" "$label"                      # help
  drive "status --bogusflag" "2" "exit codes: 0 ok" "$label"
  drive "status --deep" "4" "vclaw status" "$label"  # temp HOME: no identity
  drive "doctor" "3 4" "vclaw doctor" "$label"       # 4 identity, 3 if a provider check fails first
  drive "who" "4" "vclaw who" "$label"
  drive "peers" "4" "vclaw peers" "$label"
  drive "send UBN5HKOLCW6YQMANDMR54XFLYJLH2ITE5HBRGI6KXHGOOGJQYP4VC32R hi" "4" "vclaw send" "$label"
  drive "inbox" "4" "vclaw inbox" "$label"
  drive "logout" "0" "vclaw logout" "$label"          # idempotent: nothing local to drop
  drive "reauth" "4" "vclaw reauth" "$label"
  drive "down" "4" "vclaw down" "$label"
  drive "provider list" "0" "vclaw provider" "$label"
  drive "init" "4" "vclaw init" "$label"
  # `up` IS NOT DRIVEN HERE, and the reason is a real finding: with no identity it runs `signup`, which
  # MINTS A PENDING IDENTITY AGAINST THE PRODUCTION IDP (measured 2026-11-01 — a local e2e must never
  # create production rows). Same for `signup`/`login`. Those three are covered by the container harness
  # and by the fixture server (real handlers, loopback, throwaway identities).
  echo "   SKIP  /vclaw up, /vclaw signup, /vclaw login — they MINT against production; covered by the container + fixture rows"

  echo
  echo "   capture file ($OUT):"
  sed 's/^/   | /' "$OUT" 2>/dev/null

  if printf '%s' "$*" | grep -q -- "--model"; then
    if printf '%s' "$pane" | grep -qF "Warning: Model \"$BOGUS_MODEL\" not found"; then
      echo "   model-free: TUI warns 'Model \"$BOGUS_MODEL\" not found' AND still answered both verbs"
    else
      fail "[$label] the bogus-model warning did not render — cannot claim the model was unusable"
    fi
  fi

  tmux kill-session -t "$SESS" 2>/dev/null || true
  return 0
}

# ── 4. the two runs ────────────────────────────────────────────────────────
run_tui "A-no-keys" "${OMP_ARGS[@]+"${OMP_ARGS[@]}"}"
run_tui "B-bogus-model" "${OMP_ARGS[@]+"${OMP_ARGS[@]}"}" --model "$BOGUS_MODEL"

# ── 5. cleanup + verification ──────────────────────────────────────────────
echo
echo "-- cleanup"
tmux kill-session -t "$SESS" 2>/dev/null || true
sleep 0.5
if tmux has-session -t "$SESS" 2>/dev/null; then fail "tmux session $SESS still alive"; else echo "   tmux: session $SESS gone"; fi
if pgrep -f "$WORK" >/dev/null 2>&1; then fail "a process still references $WORK"; else echo "   processes: none referencing $WORK"; fi

real_after=$(real_state)
if [ "$real_before" = "$real_after" ]; then
  echo "   real HOME untouched (no ~/.vclaw write, ~/.omp plugin state and 'omp plugin list' unchanged)"
else
  fail "real HOME changed during the run:"
  diff <(printf '%s\n' "$real_before") <(printf '%s\n' "$real_after") | sed 's/^/         /'
fi

if [ "$KEEP" = 1 ]; then
  echo "   KEEP=1: leaving $WORK"
else
  rm -rf "$WORK"
  [ -e "$WORK" ] && fail "temp tree survived rm -rf: $WORK" || echo "   temp tree removed: $WORK"
fi

# ── 6. verdict ─────────────────────────────────────────────────────────────
echo
printf '  %s\n' "${rows[@]+"${rows[@]}"}"
echo "  load mode: $LOAD_MODE   ($LINK_CMD)"
if [ "$fails" -ne 0 ]; then
  echo "  RESULT FAIL ($fails mismatch(es))"
  exit 1
fi
echo "  RESULT PASS — /vclaw dispatched via $LOAD_MODE: 13 verbs x 2 model modes (env -i and --model $BOGUS_MODEL), model-free; up/signup/login skipped by design (they mint against production)"
