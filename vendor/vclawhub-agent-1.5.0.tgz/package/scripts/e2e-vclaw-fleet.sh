#!/usr/bin/env bash
# e2e-vclaw-fleet.sh — the /vclaw Feature-Set-1 loop on the incus testbed.
#
# Per container: install the tarball → signup (mint proof) → approve SERVER-SIDE
# (vgate service token + approve_proof) → status --deep reconciles → who.
#
# Prereqs (documented in src/vclaw/README.md §11b):
#   * the fabric relay: `ssh -f -N -R 127.0.0.1:4223:100.106.248.70:4223 debian@<kuai>`
#     (kuai cannot reach vchat3:4223 directly), plus the incus proxy device
#     `nats4223` per container (listen 127.0.0.1:4223 -> host loopback).
#   * vgate must have `service_token` configured; the asserted email must pass the
#     segment-membership / vchat.admin gate.
set -uo pipefail
KUAI="${KUAI:-debian@kuai}"
V3="${V3:-debian@vchat3}"
CONTAINERS="${CONTAINERS:-omp-1 omp-2 omp-3}"
TARBALL="${TARBALL:-vclawhub-agent-1.5.0.tgz}"
EMAIL="${EMAIL:-chance@vchat.email}"
V3IP="${V3IP:-100.106.248.70}"
PATH_PREFIX='export PATH=/usr/local/bin:/root/.bun/bin:$PATH'

k() { tailscale ssh "$KUAI" "$@"; }
v() { tailscale ssh "$V3" "$@"; }
inc() { k "sudo -n incus exec $1 -- bash -c '$PATH_PREFIX; $2'"; }
row() { printf '  %-7s %-24s %s\n' "$1" "$2" "$3"; }

cat "$TARBALL" | k 'cat > /tmp/agent.tgz'
for c in $CONTAINERS; do
  echo "== $c"
  k "sudo -n incus config device remove $c nats4223 >/dev/null 2>&1; sudo -n incus config device add $c nats4223 proxy listen=tcp:127.0.0.1:4223 connect=tcp:127.0.0.1:4223 bind=container >/dev/null 2>&1"
  k "sudo -n incus file push /tmp/agent.tgz $c/root/agent.tgz >/dev/null"
  inc "$c" "npm i -g /root/agent.tgz --no-audit --no-fund >/tmp/n.log 2>&1" || { row "$c" install FAIL; continue; }
  k "sudo -n incus exec $c -- bash -c \"mkdir -p /root/.config/vclaw && printf '{\\\"server\\\":\\\"nats://127.0.0.1:4223\\\",\\\"runtime\\\":\\\"omp\\\"}' > /root/.config/vclaw/config.json && chmod 600 /root/.config/vclaw/config.json\""

  J=$(inc "$c" "vclaw-agent vclaw signup --force --json --with-proof 2>/dev/null")
  NK=$(printf '%s' "$J" | grep -o '"nkey": *"[^"]*"' | cut -d'"' -f4)
  PF=$(printf '%s' "$J" | grep -o 'proof=[^"]*' | head -1 | cut -d= -f2)
  if [ -z "$PF" ] || [ -z "$NK" ]; then row "$c" signup "FAIL (no proof/nkey)"; continue; fi
  row "$c" signup "ok nkey=${NK:0:12}…"

  AP=$(printf '%s' "$PF" | v 'read -r P; T=$(sudo -n grep -E "^\s*service_token:" /etc/vgate/config.yaml | sed -E "s/.*service_token:[[:space:]]*//; s/[\"'"'"']//g"); curl -sS -m 20 -X POST -H "X-VChat-Service-Token: $T" -H "X-VChat-User-Email: '"$EMAIL"'" -H "Content-Type: application/json" -d "{\"approve_proof\":\"$P\"}" https://api.vclawhub.com/v1/agent/claim/'"$NK"'/approve -w " HTTP=%{http_code}"')
  row "$c" approve "$(printf '%s' "$AP" | tail -1)"

  ST=$(inc "$c" "vclaw-agent vclaw status --deep 2>&1 | grep -E 'claim|identity' | tr '\n' ' '")
  row "$c" claim "$ST"
  WH=$(inc "$c" "vclaw-agent vclaw who --wait 3000 2>&1 | grep -E 'segment|agent\\(s\\) around|no verified' | tr '\n' ' '")
  row "$c" who "$WH"
done
