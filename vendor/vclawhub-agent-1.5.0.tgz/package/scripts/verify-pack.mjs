#!/usr/bin/env node
/**
 * verify-pack.mjs — the post-pack gate promised in the vclaw spec (§11a).
 *
 * `npm pack` ships whatever `dist/` is on disk, and `dist/*` is gitignored, so a
 * build that skipped `tsc` produces a tarball whose CLI answers "unknown command
 * vclaw", and one that skipped the extension build ships a bundle without /vclaw.
 * Both happened on 2026-10-31 — to two different people. Assert the artefact.
 */
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const need = [
  "bin/agent.js",
  "dist/cli.js",
  "dist/pi-extension/index.bundled.js",
  "dist/ext-synadia/index.bundled.js",
  "dist/vclaw/run.js",
];
const verbs = ["status", "doctor", "peers", "who", "signup"];
const forbidden = [/^test\//, /^src\//, /^[^/]+\.tgz$/]; // a ROOT tarball is a stray pack artefact; dist/pears-sidecar.tgz ships on purpose

const out = execFileSync("npm", ["pack", "--json", "--dry-run"], { encoding: "utf8" });
const info = JSON.parse(out)[0];
const files = info.files.map((f) => f.path);

const problems = [];
for (const f of need) if (!files.includes(f)) problems.push(`missing from the pack: ${f}`);
for (const re of forbidden) {
  const hit = files.find((f) => re.test(f));
  if (hit) problems.push(`should not ship: ${hit}`);
}

const runJs = readFileSync("dist/vclaw/run.js", "utf8");
for (const v of verbs) if (!runJs.includes(`name: "${v}"`)) problems.push(`verb missing from dist/vclaw/run.js: ${v}`);
const cliJs = readFileSync("dist/cli.js", "utf8");
if (!/command\(\s*["']vclaw/.test(cliJs)) problems.push('dist/cli.js has no command("vclaw") — stale tsc output?');

if (problems.length) {
  console.error("verify-pack: FAILED\n  " + problems.join("\n  "));
  process.exit(1);
}
console.log(`verify-pack: OK — ${files.length} files, ${verbs.length} verbs, both bundles present, no tests shipped`);
