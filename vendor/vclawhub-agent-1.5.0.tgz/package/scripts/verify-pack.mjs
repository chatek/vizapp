#!/usr/bin/env node
/**
 * verify-pack.mjs — the post-pack gate promised in the vclaw spec (§11a).
 *
 * `npm pack` ships whatever `dist/` is on disk, and `dist/*` is gitignored, so a
 * build that skipped `tsc` produces a tarball whose CLI answers "unknown command
 * vclaw", and one that skipped the extension build ships a bundle without /vclaw.
 * Both happened on 2026-10-31 — to two different people. Assert the artefact.
 */
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const need = [
  "bin/agent.js",
  "dist/cli.js",
  "dist/pi-extension/index.bundled.js",
  "dist/ext-synadia/index.bundled.js",
  "dist/vclaw/run.js",
];
const forbidden = [
  /^test\//,
  /^src\//,
  /^[^/]+\.tgz$/, // a ROOT tarball is a stray pack artefact; dist/pears-sidecar.tgz ships on purpose
  // ── CREDENTIALS. MEASURED 2026-11-01: a published tarball carried `package/.env` with an npm and a jsr
  // token, because `npm pack` reads the FILESYSTEM and .gitignore hides such files from git, not from the pack.
  /(^|\/)\.env(\..*)?$/,
  /\.env$/,
  /\.pem$/,
  /\.key$/,
  /\.creds$/,
  /(^|\/)id_(rsa|ed25519|ecdsa)(\.|$)/,
  /(^|\/)[^/]*secret[^/]*$/i,
  // ── STALE BUILD LEFTOVERS that a clean build never produces (they made "408 files" look plausible).
  /^dist\/agent\.js$/,
  /^dist\/agent\.js\.sha256$/,
  /^dist\/autonomous\//,
];

const out = execFileSync("npm", ["pack", "--json", "--dry-run"], { encoding: "utf8" });
const info = JSON.parse(out)[0];
const files = info.files.map((f) => f.path);

// ── ALLOWLIST. package.json#files is an allowlist (2026-11-01). Anything packed from outside it is a file
// that reached the tarball by sitting on disk — which is exactly how .env shipped.
const pkg = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8"));
const allowTops = new Set(
  (pkg.files ?? []).filter((f) => !f.startsWith("!")).map((f) => f.split("/")[0]),
);
// npm always includes these regardless of `files`.
for (const always of ["package.json", "README.md", "LICENSE", "LICENCE", "bin"]) allowTops.add(always);

const problems = [];
for (const f of need) if (!files.includes(f)) problems.push(`missing from the pack: ${f}`);
for (const f of files) {
  const top = f.split("/")[0];
  if (!allowTops.has(top)) problems.push(`outside the package.json#files allowlist: ${f}`);
}

for (const re of forbidden) {
  const hit = files.find((f) => re.test(f));
  if (hit) problems.push(`should not ship: ${hit}`);
}

// The verb table in `src/vclaw/run.ts` is the source of truth; the BUILT file is
// what ships. Read the names out of the table and require every one of them in
// `dist/vclaw/run.js` — a verb added to the table but not to `dist/` (a skipped
// `tsc`, or a truncated build) is exactly the stale-artefact class this gate
// exists for. The reverse check catches the other direction: a `dist/` from
// another branch carrying a verb the table no longer has.
const verbs = [...readFileSync("src/vclaw/run.ts", "utf8").matchAll(/^ {2}([a-z][a-z0-9]*): \{\n {4}name: "([a-z][a-z0-9]*)"/gm)].map(
  (m) => m[2],
);
if (verbs.length === 0) problems.push("could not read the verb table out of src/vclaw/run.ts");

const runJs = readFileSync("dist/vclaw/run.js", "utf8");
for (const v of verbs) if (!runJs.includes(`name: "${v}"`)) problems.push(`verb missing from dist/vclaw/run.js: ${v}`);
for (const m of runJs.matchAll(/\bname: "([a-z][a-z0-9]*)"/g)) {
  if (!verbs.includes(m[1])) problems.push(`dist/vclaw/run.js carries verb "${m[1]}" that the table has no entry for — stale build?`);
}
const cliJs = readFileSync("dist/cli.js", "utf8");
if (!/command\(\s*["']vclaw/.test(cliJs)) problems.push('dist/cli.js has no command("vclaw") — stale tsc output?');

if (problems.length) {
  console.error("verify-pack: FAILED\n  " + problems.join("\n  "));
  process.exit(1);
}
console.log(
  `verify-pack: OK — ${files.length} files, ${verbs.length} verbs (${verbs.join(" ")}) all present in dist/vclaw/run.js, both bundles present, no tests shipped, allowlist clean`,
);
