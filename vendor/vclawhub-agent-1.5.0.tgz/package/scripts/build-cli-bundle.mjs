#!/usr/bin/env node
/**
 * build-cli-bundle.mjs — the npm-free bundled CLI (sprint-jsr-migration W-J7a).
 *
 * Builds the single-file CLI with ALL deps inlined:
 *   bun build src/cli.ts --target=bun --outfile dist/agent.js \
 *     --define process.env.AGENT_SDK_VERSION='"<version>"'
 *
 * The define stamps the version (src/version.ts sdkVersion() reads it) — the
 * audit's B1 blocker fix: in a bundle the import.meta.url-relative
 * package.json reads degrade to sentinels, so the true version is injected at
 * build time. Version source = jsr.json (the published identity).
 *
 * Emits alongside the bundle:
 *   dist/agent.js         — the single-file CLI (~0.9 MB; run: bun agent.js …)
 *   dist/agent.js.sha256  — integrity digest for the landing/hosting surface
 *
 * Smoke gates (run automatically after build): --version must print the
 * stamped version; --help must exit 0; keygen (pure-local) must exit 0 —
 * each executed with `bun <bundle>` from an EMPTY temp dir (no node_modules
 * anywhere in sight — proving zero-registry).
 *
 * MANUAL GATE (documented, CI-optional): after hosting, in a fresh shell:
 *   curl -fsSL https://vclawhub.com/agent.js -o ~/.vchat/agent.js
 *   bun ~/.vchat/agent.js --version      # → the jsr.json version
 *   bun ~/.vchat/agent.js keygen         # → prints a fresh Nkey pair
 *
 * Usage: bun scripts/build-cli-bundle.mjs [--outdir dist]
 */

import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outdirArg = process.argv.indexOf("--outdir");
const outdir = outdirArg !== -1 ? resolve(process.argv[outdirArg + 1]) : join(root, "dist");

const jsr = JSON.parse(readFileSync(join(root, "jsr.json"), "utf-8"));
const version = jsr.version;
if (!version) throw new Error("jsr.json carries no version — cannot stamp the bundle");

const outfile = join(outdir, "agent.js");

console.log(`── building bundled CLI (version ${version}) …`);
const build = spawnSync(
  "bun",
  [
    "build", join(root, "src/cli.ts"),
    "--target=bun",
    "--outfile", outfile,
    "--define", `process.env.AGENT_SDK_VERSION=${JSON.stringify(version)}`,
  ],
  { stdio: "inherit", cwd: root },
);
if (build.status !== 0) throw new Error(`bun build failed (exit ${build.status})`);

const size = statSync(outfile).size;
const sha = createHash("sha256").update(readFileSync(outfile)).digest("hex");
writeFileSync(`${outfile}.sha256`, `${sha}  agent.js\n`);
console.log(`── agent.js: ${(size / 1024 / 1024).toFixed(2)} MB (${size} bytes)`);
console.log(`── agent.js.sha256: ${sha}`);

// ── Smoke gates: empty dir, zero registry ────────────────────────
const empty = mkdtempSync(join(tmpdir(), "agent-bundle-smoke-"));
let failures = 0;
try {
  const run = (args) =>
    spawnSync("bun", [outfile, ...args], { cwd: empty, encoding: "utf-8", timeout: 30_000 });

  const v = run(["--version"]);
  const vOut = (v.stdout ?? "").trim();
  if (v.status === 0 && vOut === version) {
    console.log(`── smoke --version: OK (${vOut})`);
  } else {
    failures++;
    console.error(`✗ smoke --version: status=${v.status} out="${vOut}" (expected ${version})`);
  }

  const h = run(["--help"]);
  if (h.status === 0 && (h.stdout ?? "").includes("Usage:")) {
    console.log("── smoke --help: OK");
  } else {
    failures++;
    console.error(`✗ smoke --help: status=${h.status}`);
  }

  const k = run(["keygen"]);
  if (k.status === 0 && (k.stdout ?? "").includes("Seed:")) {
    console.log("── smoke keygen: OK (pure-local, no network)");
  } else {
    failures++;
    console.error(`✗ smoke keygen: status=${k.status}`);
  }
} finally {
  rmSync(empty, { recursive: true, force: true });
}

if (failures > 0) {
  throw new Error(`${failures} smoke gate(s) failed`);
}
console.log("── all smoke gates green (empty-dir, zero-registry) ✓");
