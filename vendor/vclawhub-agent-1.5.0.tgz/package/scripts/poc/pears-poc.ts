#!/usr/bin/env node
/**
 * pears-poc.ts — the Tier P proof-of-concept harness (NOT part of the published CLI).
 *
 * Why it exists: the SDK's P2P stack is a library plus a node helper. To prove the
 * transport across real hosts (docs/lanes/PEARS_POC_PLAN_2026-10-25.md TC-06..TC-12)
 * we need a driver that uses the SAME client code the daemon uses, on hosts that only
 * have the join-pipe install. It never ships; `bun build --target=node` produces one
 * file that runs under the node runtime the helper already requires.
 *
 * Identity: --seed-file points at ~/.vclaw/identity.json (the join pipe writes
 * {name, public_key, seed(hex), ...}, mode 0600). The ROOT seed never crosses IPC —
 * only per-fabric HKDF subkeys are passed to the helper (PROTOCOL §6).
 *
 * Output contract: every result is one `POC <json>` line on stdout so an orchestrator
 * can parse it; human-readable notes go to stderr. Exit code 0 = the op succeeded.
 *
 * Commands
 *   status  --delegation <id>                     what this host can do (sidecar? node? keys? topic?)
 *   keys    --delegation <id>                     root/peer/writer/artifacts-writer keys (b64 + hex)
 *   attach  --delegation <id> --role writer|reader [--enc-key b64] [--base-key b64]
 *           [--artifacts-base b64] [--seed-port N | --bootstrap host:port] [--peer b64,...]
 *           [--bind 0.0.0.0] [--hold-ms N]        join the delegation; prints base keys
 *   send    ...same flags... --subject S --data TEXT|@FILE
 *   recv    ...same flags... --pattern P --timeout-ms N
 *   put     ...same flags... --file PATH          blobPut; prints {blobId, sha256, size}
 *   get     ...same flags... --blob JSON --out PATH [--offset N --length N]
 */
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { createHash } from "node:crypto";
import { homedir } from "node:os";
import { join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";

import {
  SidecarClient,
  SidecarUnavailableError,
  attachHelper,
  putArtifact,
  getArtifact,
  derivePeerKeyPair,
  deriveWriterKeyPair,
  deriveArtifactsWriterKeyPair,
  delegationTopic,
  resolveSidecarDir,
  resolveNodeBinary,
  type NetworkConfig,
} from "../../src/net/p2p/index.js";

const argv = process.argv.slice(2);
const cmd = argv[0];
const flag = (name: string): string | undefined => {
  const i = argv.indexOf("--" + name);
  return i === -1 ? undefined : argv[i + 1];
};
const flagAll = (name: string): string[] => {
  const out: string[] = [];
  argv.forEach((a, i) => {
    if (a === "--" + name && argv[i + 1]) out.push(argv[i + 1]);
  });
  return out;
};
const need = (name: string): string => {
  const v = flag(name);
  if (v === undefined) {
    console.error(`missing --${name}`);
    process.exit(2);
  }
  return v;
};

function emit(obj: Record<string, unknown>): void {
  console.log("POC " + JSON.stringify(obj));
}

function readSeed(): Uint8Array {
  const path = flag("seed-file") ?? join(homedir(), ".vclaw", "identity.json");
  if (!existsSync(path)) throw new Error(`no identity file at ${path}`);
  const j = JSON.parse(readFileSync(path, "utf8")) as { seed?: string; public_key?: string };
  if (!j.seed) throw new Error(`identity file ${path} carries no seed`);
  const raw = j.seed.startsWith("S") ? Buffer.from(j.seed, "utf8") : Buffer.from(j.seed, "hex");
  if (raw.length !== 32) throw new Error(`seed must be 32 bytes (got ${raw.length})`);
  return new Uint8Array(raw);
}

const b64 = (u: Uint8Array): string => Buffer.from(u).toString("base64");

function networkFlags(): NetworkConfig | undefined {
  const network: NetworkConfig = {};
  const bind = flag("bind");
  if (bind) network.bindHost = bind;
  const seedPort = flag("seed-port");
  if (seedPort) network.seedPort = Number(seedPort);
  const boot = flagAll("bootstrap");
  if (boot.length) {
    network.bootstrap = boot.map((s) => {
      const idx = s.lastIndexOf(":");
      return { host: s.slice(0, idx), port: Number(s.slice(idx + 1)) };
    });
  }
  return Object.keys(network).length ? network : undefined;
}

async function connect(delegation: string) {
  const seed = readSeed();
  const peerKeyPair = await derivePeerKeyPair(seed);
  const writerKeyPair = await deriveWriterKeyPair(seed, delegation);
  const artifactsWriter = await deriveArtifactsWriterKeyPair(seed, delegation);
  const storeDir = flag("store-dir") ?? join(homedir(), ".vclaw", "pears", "poc-" + delegation);
  mkdirSync(storeDir, { recursive: true, mode: 0o700 });

  const client = new SidecarClient();
  const network = networkFlags();
  const hello = await client.start({
    storeDir,
    peerKeyPair,
    network,
    sidecarDir: flag("sidecar-dir"),
    nodeBin: flag("node-bin"),
    bootTimeoutMs: Number(flag("boot-timeout-ms") ?? 20000),
  });
  return { client, hello, peerKeyPair, writerKeyPair, artifactsWriter, storeDir, network };
}

function attachOpts(delegation: string, role: "writer" | "reader", k: {
  writerKeyPair: { publicKey: Uint8Array; secretKey: Uint8Array };
  artifactsWriter: { publicKey: Uint8Array; secretKey: Uint8Array };
}) {
  const peers = flagAll("peer").map((p) => ({ publicKey: p }));
  const base = {
    delegationId: delegation,
    topic: b64(delegationTopic(delegation)),
    role,
    peers: peers.length ? peers : undefined,
    encryptionKey: flag("enc-key"),
  };
  if (role === "writer") {
    return {
      ...base,
      writerKeyPair: { publicKey: b64(k.writerKeyPair.publicKey), secretKey: b64(k.writerKeyPair.secretKey) },
      artifacts: {
        writerKeyPair: { publicKey: b64(k.artifactsWriter.publicKey), secretKey: b64(k.artifactsWriter.secretKey) },
      },
    };
  }
  return {
    ...base,
    baseKey: flag("base-key"),
    artifacts: flag("artifacts-base") ? { baseKey: flag("artifacts-base") } : undefined,
  };
}

async function main() {
  const delegation = flag("delegation") ?? "poc-delegation-1";

  if (cmd === "status") {
    const sidecarDir = resolveSidecarDir();
    const nodeBin = resolveNodeBinary();
    const seed = readSeed();
    const peer = await derivePeerKeyPair(seed);
    emit({
      op: "status",
      sidecarDir,
      sidecarPresent: sidecarDir !== null,
      nodeBin,
      nodePresent: nodeBin !== null,
      peerPublicB64: b64(peer.publicKey),
      peerPublicHex: Buffer.from(peer.publicKey).toString("hex"),
      topicHex: Buffer.from(delegationTopic(delegation)).toString("hex"),
      delegation,
      tierPAvailable: sidecarDir !== null && nodeBin !== null,
    });
    return;
  }

  if (cmd === "keys") {
    const seed = readSeed();
    const peer = await derivePeerKeyPair(seed);
    const writer = await deriveWriterKeyPair(seed, delegation);
    const artifacts = await deriveArtifactsWriterKeyPair(seed, delegation);
    emit({
      op: "keys",
      delegation,
      peerPublicB64: b64(peer.publicKey),
      peerPublicHex: Buffer.from(peer.publicKey).toString("hex"),
      writerPublicB64: b64(writer.publicKey),
      artifactsWriterPublicB64: b64(artifacts.publicKey),
      topicB64: b64(delegationTopic(delegation)),
    });
    return;
  }

  if (cmd === "attach") {
    const role = (flag("role") ?? "writer") as "writer" | "reader";
    const k = await connect(delegation);
    try {
      const res = await k.client.attach(attachOpts(delegation, role, k));
      emit({
        op: "attach",
        delegation,
        role,
        peerPublicB64: b64(k.peerKeyPair.publicKey),
        peerPublicHex: Buffer.from(k.peerKeyPair.publicKey).toString("hex"),
        dht: k.hello.dht,
        topicB64: res.topic,
        baseKey: res.baseKey,
        artifactsBaseKey: res.artifactsBaseKey,
        storeDir: k.storeDir,
      });
      const holdMs = Number(flag("hold-ms") ?? 0);
      if (holdMs > 0) {
        console.error(`holding ${holdMs} ms (peers can dial now)`);
        await delay(holdMs);
      }
    } finally {
      await k.client.stop();
    }
    return;
  }

  if (cmd === "send") {
    const k = await connect(delegation);
    try {
      await k.client.attach(attachOpts(delegation, "writer", k));
      const subject = need("subject");
      const raw = flag("data") ?? "";
      const data = raw.startsWith("@") ? readFileSync(raw.slice(1)) : Buffer.from(raw, "utf8");
      const res = await k.client.publish(delegation, subject, "", new Uint8Array(data));
      emit({ op: "send", subject, bytes: data.length, peers: res.peers, digest: res.digest });
    } finally {
      await k.client.stop();
    }
    return;
  }

  if (cmd === "recv") {
    const k = await connect(delegation);
    try {
      await k.client.attach(attachOpts(delegation, "reader", k));
      const pattern = flag("pattern") ?? ">";
      const timeoutMs = Number(flag("timeout-ms") ?? 60000);
      const subId = await k.client.subscribe(delegation, pattern);
      console.error(`subscribed ${pattern} (subId ${subId}); waiting ${timeoutMs} ms`);
      const waiter = Promise.withResolvers<{ subject: string; data: string; digest: string; from: string } | null>();
      const timer = setTimeout(() => waiter.resolve(null), timeoutMs);
      k.client.onMessage((ev) => {
        if (ev.delegation !== delegation || ev.subId !== subId) return;
        clearTimeout(timer);
        waiter.resolve({ subject: ev.subject, data: ev.data, digest: ev.digest, from: ev.from });
      });
      const got = await waiter.promise;
      if (!got) {
        emit({ op: "recv", received: false, pattern, timeoutMs });
        process.exitCode = 3;
        return;
      }
      const plain = Buffer.from(got.data, "base64");
      emit({
        op: "recv",
        received: true,
        subject: got.subject,
        from: got.from,
        digest: got.digest,
        bytes: plain.length,
        sha256: createHash("sha256").update(plain).digest("hex"),
        text: plain.toString("utf8").slice(0, 200),
      });
    } finally {
      await k.client.stop();
    }
    return;
  }

  if (cmd === "multi") {
    // The §9 production shape: ONE live helper, a SECOND client attaching the SAME
    // delegation while the first still holds it. Both connections go through
    // attachHelper (listen mode) — a stdio client would spawn its own helper and the
    // store lock would (correctly) refuse, which is the confusion this command ends.
    const seed = readSeed();
    const storeDir = flag("store-dir") ?? join(homedir(), ".vclaw", "pears", "poc-" + delegation);
    const writer = await deriveWriterKeyPair(seed, delegation);
    const artifactsWriter = await deriveArtifactsWriterKeyPair(seed, delegation);
    const opts = attachOpts(delegation, "writer", { writerKeyPair: writer, artifactsWriter });
    const first = await attachHelper({ seed, storeDir, sidecarDir: flag("sidecar-dir"), nodeBin: flag("node-bin") });
    const a = await first.client.attach(opts);
    await delay(Number(flag("hold-ms") ?? 5000));
    let second: Record<string, unknown>;
    try {
      const b = await attachHelper({ seed, storeDir, sidecarDir: flag("sidecar-dir"), nodeBin: flag("node-bin") });
      const r = await b.client.attach(opts);
      second = { ok: true, spawned: b.spawned, helperPid: b.helperPid, baseKey: r.baseKey, artifactsBaseKey: r.artifactsBaseKey };
      await b.close().catch(() => undefined);
    } catch (e) {
      second = { ok: false, error: (e as Error).message };
    }
    emit({ op: "multi", delegation, first: { spawned: first.spawned, helperPid: first.helperPid, baseKey: a.baseKey }, second });
    await first.close().catch(() => undefined);
    if (second.ok !== true) process.exitCode = 6;
    return;
  }

  if (cmd === "storm") {
    // TC-10c: the LISTEN-MODE path, which the rest of this POC never touches —
    // one helper per host over a unix socket, killed under a caller and
    // reconnected. It is the shape production uses and the only place the
    // stale-socket + store-lock race (sidecar main.ts boot) can bite.
    const rounds = Number(flag("rounds") ?? 5);
    const seed = readSeed();
    const storeDir = flag("store-dir") ?? join(homedir(), ".vclaw", "pears", "poc-" + delegation);
    const results: Record<string, unknown>[] = [];
    for (let round = 1; round <= rounds; round += 1) {
      const began = Date.now();
      try {
        const session = await attachHelper({
          seed,
          storeDir,
          sidecarDir: flag("sidecar-dir"),
          nodeBin: flag("node-bin"),
          socketPath: flag("socket"),
          lingerMs: 1000,
        });
        const writer = await deriveWriterKeyPair(seed, delegation);
        const artifactsWriter = await deriveArtifactsWriterKeyPair(seed, delegation);
        const res = session.client.attach
          ? await session.client.attach(attachOpts(delegation, "writer", { writerKeyPair: writer, artifactsWriter }))
          : null;
        const killable = session.helperPid !== null;
        if (killable) process.kill(session.helperPid as number, "SIGKILL");
        await session.close().catch(() => undefined);
        results.push({ round, ok: true, spawned: session.spawned, killed: killable, baseKey: res?.baseKey, ms: Date.now() - began });
      } catch (e) {
        results.push({ round, ok: false, error: (e as Error).message, ms: Date.now() - began });
      }
      await delay(300);
    }
    emit({ op: "storm", rounds, results, failures: results.filter((r) => r.ok !== true).length });
    if (results.some((r) => r.ok !== true)) process.exitCode = 5;
    return;
  }

  if (cmd === "stats") {
    // Wire-level evidence. The sidecar DROPS undecryptable frames silently
    // (frame.ts openFrame never throws), so "the app received nothing" cannot by
    // itself distinguish "ciphertext flowed and the crypto held" from "nothing
    // reached us". The room counters can: received>0 with delivered==0 and
    // undecryptable>0 is the Q5 shape, and it is the only honest PASS evidence.
    const k = await connect(delegation);
    try {
      if (flag("role")) await k.client.attach(attachOpts(delegation, flag("role") as "writer" | "reader", k));
      // A subscription is what makes the counters admissible as evidence: the
      // non-member must be LISTENING when the publish happens, or "0 delivered"
      // cannot be told apart from "was not subscribed". Assert it took effect
      // (subscribe resolves with an id) before the window opens.
      const pattern = flag("pattern");
      const subId = pattern ? await k.client.subscribe(delegation, pattern) : null;
      const holdMs = Number(flag("hold-ms") ?? 0);
      if (holdMs > 0) await delay(holdMs);
      const s = await k.client.stats();
      emit({
        op: "stats",
        delegation,
        subscribed: subId,
        rooms: s.rooms.filter((r) => r.delegationId === delegation),
        connections: s.connections,
      });
    } finally {
      await k.client.stop();
    }
    return;
  }

  if (cmd === "serve") {
    const role = (flag("role") ?? "writer") as "writer" | "reader";
    const k = await connect(delegation);
    const pattern = flag("pattern");
    const subject = flag("subject");
    let subId: number | null = null;
    try {
      const res = await k.client.attach(attachOpts(delegation, role, k));
      emit({
        op: "serve.ready",
        role,
        delegation,
        peerPublicB64: b64(k.peerKeyPair.publicKey),
        dht: k.hello.dht,
        baseKey: res.baseKey,
        artifactsBaseKey: res.artifactsBaseKey,
      });
      if (pattern) {
        subId = await k.client.subscribe(delegation, pattern);
        console.error(`subscribed ${pattern} (subId ${subId})`);
      }
      if (subject && flag("data") !== undefined) {
        const publishAfter = Number(flag("publish-after-ms") ?? 5000);
        const raw = flag("data") ?? "";
        const data = raw.startsWith("@") ? readFileSync(raw.slice(1)) : Buffer.from(raw, "utf8");
        const timer = setTimeout(() => {
          void k.client
            .publish(delegation, subject, "", new Uint8Array(data))
            .then((r) => emit({ op: "serve.published", subject, bytes: data.length, peers: r.peers, digest: r.digest }))
            .catch((e: Error) => emit({ op: "serve.publish.error", subject, error: e.message }));
        }, publishAfter);
        timer.unref();
      }
      k.client.onMessage((ev) => {
        if (ev.delegation !== delegation) return;
        const plain = Buffer.from(ev.data, "base64");
        emit({
          op: "serve.message",
          subject: ev.subject,
          from: ev.from,
          digest: ev.digest,
          bytes: plain.length,
          sha256: createHash("sha256").update(plain).digest("hex"),
          text: plain.toString("utf8").slice(0, 200),
        });
      });
      await delay(Number(flag("hold-ms") ?? 20000));
    } finally {
      if (subId !== null) await k.client.unsubscribe(subId).catch(() => undefined);
      await k.client.stop();
    }
    return;
  }

  if (cmd === "put") {
    const k = await connect(delegation);
    try {
      await k.client.attach(attachOpts(delegation, "writer", k));
      const file = need("file");
      const bytes = readFileSync(file);
      const began = Date.now();
      const res = await putArtifact(k.client, delegation, new Uint8Array(bytes), { name: flag("name") });
      emit({ op: "put", file, bytes: bytes.length, sha256: res.sha256, blobRef: res.blobRef, size: res.size, ms: Date.now() - began });
    } finally {
      await k.client.stop();
    }
    return;
  }

  if (cmd === "get") {
    const k = await connect(delegation);
    try {
      await k.client.attach(attachOpts(delegation, "reader", k));
      const blobRef = need("blob-ref");
      const offset = flag("offset") ? Number(flag("offset")) : undefined;
      const length = flag("length") ? Number(flag("length")) : undefined;
      const began = Date.now();
      const bytes = await getArtifact(k.client, delegation, blobRef, {
        range: offset === undefined && length === undefined ? undefined : { offset: offset ?? 0, length: length ?? 0 },
        timeoutMs: Number(flag("timeout-ms") ?? 300000),
      });
      const out = flag("out");
      if (out) writeFileSync(out, bytes);
      emit({
        op: "get",
        bytes: bytes.length,
        sha256: createHash("sha256").update(bytes).digest("hex"),
        out,
        ms: Date.now() - began,
      });
    } finally {
      await k.client.stop();
    }
    return;
  }

  console.error("usage: pears-poc.mjs status|keys|attach|send|recv|put|get [flags]");
  process.exit(2);
}

main().catch((err: unknown) => {
  const e = err as Error;
  const unavailable = e instanceof SidecarUnavailableError;
  emit({ op: String(cmd), ok: false, unavailable, error: e.message });
  console.error(e.stack ?? e.message);
  process.exit(unavailable ? 4 : 1);
});
