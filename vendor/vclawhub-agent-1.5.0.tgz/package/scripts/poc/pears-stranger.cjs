#!/usr/bin/env node
// pears-stranger.cjs — TC-09c: a peer with NO delegation keys that joins a
// Tier P room's swarm via the PUBLIC topic and publishes frames into it.
// Proves: topic knowledge is not authorisation. Uses the helper's own
// node_modules (hyperswarm/hyperdht/protomux) — no SDK, no identity.
const args = {}
for (let i = 2; i < process.argv.length; i += 2) args[process.argv[i].replace('--','')] = process.argv[i+1]
const { createHash } = require('node:crypto')
const topicHex = createHash('sha256').update('vclaw/pears/topic/v1').update(Buffer.from([0])).update(args.delegation,'utf8').digest('hex')
const nm = require.resolve('hyperswarm', { paths: [__dirname + '/node_modules'] })
const Hyperswarm = require(nm)
const {execSync} = require('node:child_process')
const sodium = require(require.resolve('sodium-native', { paths: [__dirname + '/node_modules'] }))
const kp = sodium.crypto_sign_keypair()
const pub = Buffer.from(kp.publicKey)
console.log('STRANGER peer=' + pub.toString('hex').slice(0,16) + ' topic=' + topicHex.slice(0,16) + ' delegation=' + args.delegation)
const nm_path = require.resolve('hyperswarm', { paths: [__dirname + '/node_modules'] }).replace(/hyperswarm.*/, '')
const HyperDHT = require(nm_path + 'hyperdht')
const dht = new HyperDHT({ bootstrap: args.bootstrap ? [{host: args.bootstrap.split(':')[0], port: Number(args.bootstrap.split(':')[1])}] : [], host: args.bind || '0.0.0.0' })
const swarm = new Hyperswarm({ dht, keyPair: kp })
const protomux = require(require.resolve('protomux', { paths: [__dirname + '/node_modules'] }))
swarm.join(Buffer.from(topicHex, 'hex'), { server: true, client: true })
swarm.on('connection', (conn, peer) => {
  console.log('STRANGER connected to ' + peer.publicKey.toString('hex').slice(0,16))
  const mux = protomux.from(conn)
  const ch = mux.createChannel({ protocol: 'pears/a2a/v1' })
  const msg = ch.addMessage({ encoding: require('compact-encoding').json })
  ch.open()
  msg.send({ t: topicHex, s: 'stranger.inject', r: '', d: Buffer.from('injected-frames').toString('base64'), digest: 'forged-digest', from: pub.toString('hex') })
  console.log('STRANGER frame sent')
})
console.log('STRANGER joining topic ' + topicHex.slice(0,16) + ' bind=' + (args.bind || '0.0.0.0'))
const hold = Number(args['hold-ms'] || 30000)
setTimeout(() => { console.log('STRANGER done'); process.exit(0) }, hold)
