#!/usr/bin/env bash
# e2e-vclaw-usage.sh — the USAGE surface of `/vclaw`, on an installed binary.
#
# Codifies the assertions round-3 e2e measured by hand (docs/lanes/VCLAW_E2E_ROUND3_2026-10-31.md):
#   * an undeclared flag is refused (exit 2) and the verb NEVER runs — the defect
#     that mattered was `inbox --bogusflag` marking unread mail read;
#   * `--wait` with no value / a non-numeric value is refused (exit 2);
#   * a flag may precede the verb (`--json status`);
#   * `--help` lists every built verb, and `--help --json` is one envelope;
#   * every non-zero result carries `error` in the machine envelope, and that
#     error is a REASON (not a banner, not the verb's own name);
#   * the no-identity class is a TABLE, one documented code per verb — `logout`
#     is 0 (idempotent), `provider list` is 0 (identity-free), `signup` mints
#     the identity. A blanket "4 everywhere" hid those branches;
#   * an unreachable broker is 3, and the error NAMES the fabric.
#
# Usage:
#   ./scripts/e2e-vclaw-usage.sh                        # `node dist/cli.js` when a build exists
#   VCLAW_BIN="vclaw-agent" ./scripts/e2e-vclaw-usage.sh  # an INSTALLED binary instead
#   E2E_IDENTITY_DIR=~/.config/vclaw ./scripts/e2e-vclaw-usage.sh
#   BROKER=1 ./scripts/e2e-vclaw-usage.sh               # also the exit-3 case (edits config, restores)
#
# The full verb × state matrix lives in e2e-vclaw-matrix.sh; this file stays the
# usage-surface harness (flags, help, envelope, refusals).
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# Default to THIS checkout's build. The installed shim under ~/.local/bin is a
# different artefact with its own release cadence — pointing at it by default
# made every row measure the install, not the code under review. VCLAW_BIN is
# still the way to assert an installed binary (that is E7's job, not this file's).
if [ -n "${VCLAW_BIN:-}" ]; then
  BIN_STR="$VCLAW_BIN"
elif [ -f "$ROOT_DIR/dist/cli.js" ]; then
  BIN_STR="node $ROOT_DIR/dist/cli.js"
else
  BIN_STR="vclaw-agent"
fi
read -r -a BIN <<<"$BIN_STR"
echo "binary: $BIN_STR"
PASS=0 FAIL=0
ok()   { PASS=$((PASS + 1)); printf '  PASS  %-46s %s\n' "$1" "${2:-}"; }
bad()  { FAIL=$((FAIL + 1)); printf '  FAIL  %-46s %s\n' "$1" "${2:-}"; }

# run <json?> <args...> -> sets RC and OUT (stdout)
run() {
  OUT="$("${BIN[@]}" vclaw "$@" 2>&1)"; RC=$?
}
# jget <field> — read one top-level field from $OUT with node (no jq dependency)
jget() {
  printf '%s' "$OUT" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const o=JSON.parse(s);const v=o[process.argv[1]];console.log(v===undefined?"<absent>":JSON.stringify(v))}catch{console.log("<not-json>")}})' "$1"
}

echo "== usage refused (exit 2, verb does not run) =="
run status --bogusflag --json
[ "$RC" -eq 2 ] && ok "status --bogusflag -> 2" || bad "status --bogusflag -> 2" "got $RC"

run inbox --wait --json
[ "$RC" -eq 2 ] && ok "inbox --wait (no value) -> 2" || bad "inbox --wait (no value) -> 2" "got $RC"

run inbox --wait abc --json
[ "$RC" -eq 2 ] && ok "inbox --wait abc -> 2" || bad "inbox --wait abc -> 2" "got $RC"

echo "== wrapper-level usage errors are class 2 (not 1) =="
"${BIN[@]}" --json status >/dev/null 2>&1; RC=$?
[ "$RC" -eq 2 ] && ok "vclaw-agent --json status -> 2" || bad "vclaw-agent --json status -> 2" "got $RC"
"${BIN[@]}" --nonsense >/dev/null 2>&1; RC=$?
[ "$RC" -eq 2 ] && ok "unknown top-level option -> 2" || bad "unknown top-level option -> 2" "got $RC"
"${BIN[@]}" --help >/dev/null 2>&1; RC=$?
[ "$RC" -eq 0 ] && ok "--help still exits 0" || bad "--help still exits 0" "got $RC"

echo "== flags may precede the verb =="
run --json status --json
VERB="$(jget verb)"
[ "$VERB" = '"status"' ] && ok "--json status parses the status verb" || bad "--json status parses the status verb" "verb=$VERB"

echo "== help =="
run --help
HELP_OK=1
for v in status doctor init send inbox login logout reauth signup who down peers provider up; do
  grep -q "/vclaw $v" <<<"$OUT" || HELP_OK=0
done
[ "$HELP_OK" -eq 1 ] && ok "--help lists every built verb" || bad "--help lists every built verb"

run --help --json
[ "$RC" -eq 0 ] && [ "$(jget verb)" = '"help"' ] && ok "--help --json is one envelope" || bad "--help --json is one envelope" "rc=$RC"

echo "== refusals carry a reason =="
run send --json
ERR="$(jget error)"
[ "$RC" -eq 2 ] && [ "$ERR" != "<absent>" ] && ok "send refusal carries error" || bad "send refusal carries error" "rc=$RC error=$ERR"

# B4 (2026-11-01): the peer-token check threw a plain Error, so this exited 1 — a
# code §5 does not define. It is a usage error, and `error` names the token.
echo "== a bad argument is class 2, never exit 1 =="
run send "bad.peer" hello --json
[ "$RC" -eq 2 ] && ok "send bad.peer -> exit 2" || bad "send bad.peer -> exit 2" "got $RC"
[ "$(jget code)" = "2" ] && ok "send bad.peer -> code 2 (=== exit)" || bad "send bad.peer -> code 2" "code=$(jget code)"
case "$(jget error)" in *"invalid peer"*) ok "send bad.peer -> error names the token" ;; *) bad "send bad.peer -> error names the token" "error=$(jget error)" ;; esac

# D5b: `status`/`doctor` open their text with a banner, so the first line alone
# reported "vclaw status" as the reason. `error` must carry the real reason.
echo "== a refusal's error is the reason, not the banner =="
TMPREASON="$(mktemp -d)"
for v in status doctor; do
  OUT="$(HOME="$TMPREASON" "${BIN[@]}" vclaw "$v" --json 2>&1)"; RC=$?
  ERR="$(jget error)"
  if [ "$RC" -eq 4 ] && [ "$ERR" != "\"vclaw $v\"" ] && [ "$ERR" != "<absent>" ] && [ "$ERR" != "null" ]; then
    ok "$v refusal -> error is a reason"
  else
    bad "$v refusal -> error is a reason" "rc=$RC error=$ERR"
  fi
done
rm -rf "$TMPREASON"

echo "== identity class (empty HOME): a documented code per verb, not one code for all =="
# The old row here asserted "no-identity is 4 everywhere". That was wrong for
# four verbs — the matrix proved it: `logout` (nothing to drop is idempotent),
# `provider list` (the inventory is deliberately identity-free), `signup` (it
# CREATES the identity) and `up` (it starts the signup it needs). One code per
# verb, each with a reason, is the contract; a blanket 4 hid those branches.
# Every row gets its own HOME: `logout` and `signup` write.
NOID() { # <verb+args…> -> RC/OUT in a throwaway HOME
  local h; h="$(mktemp -d)"
  OUT="$(HOME="$h" "${BIN[@]}" vclaw "$@" 2>&1)"; RC=$?
  rm -rf "$h"
}
NOID status;            [ "$RC" -eq 4 ] && ok "status x no-identity -> 4" || bad "status x no-identity -> 4" "got $RC"
NOID doctor;            [ "$RC" -eq 4 ] && ok "doctor x no-identity -> 4" || bad "doctor x no-identity -> 4" "got $RC"
NOID who --wait 200;    [ "$RC" -eq 4 ] && ok "who x no-identity -> 4" || bad "who x no-identity -> 4" "got $RC"
NOID peers;             [ "$RC" -eq 4 ] && ok "peers x no-identity -> 4" || bad "peers x no-identity -> 4" "got $RC"
NOID send UBAN43BJNBGXOCUKIHJDMXUJRFB42G47ZDWFCFSTF6P2KFBNJMZZSJSP hi
[ "$RC" -eq 4 ] && ok "send x no-identity -> 4" || bad "send x no-identity -> 4" "got $RC"
NOID inbox;             [ "$RC" -eq 4 ] && ok "inbox x no-identity -> 4" || bad "inbox x no-identity -> 4" "got $RC"
NOID login --wait 1;    [ "$RC" -eq 4 ] && ok "login x no-identity -> 4" || bad "login x no-identity -> 4" "got $RC"
NOID reauth;            [ "$RC" -eq 4 ] && ok "reauth x no-identity -> 4" || bad "reauth x no-identity -> 4" "got $RC"
NOID down;              [ "$RC" -eq 4 ] && ok "down x no-identity -> 4" || bad "down x no-identity -> 4" "got $RC"
NOID up;                [ "$RC" -eq 4 ] && ok "up x no-identity -> 4 (starts signup itself)" || bad "up x no-identity -> 4" "got $RC"

NOID logout --json
LOGOUT_STATE="$(jget data | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{console.log(JSON.parse(s).logout||"-")}catch{console.log("-")}})')"
[ "$RC" -eq 0 ] && [ "$LOGOUT_STATE" = "already" ] \
  && ok "logout x no-identity -> 0 (idempotent)" || bad "logout x no-identity -> 0 (idempotent)" "rc=$RC data.logout=$LOGOUT_STATE"
NOID logout --revoke --json
[ "$RC" -eq 0 ] && ok "logout --revoke x no-identity -> 0 (nothing to revoke)" \
  || bad "logout --revoke x no-identity -> 0 (nothing to revoke)" "got $RC"

NOID provider list --json
[ "$RC" -eq 0 ] && [ "$(jget code)" = "0" ] && ok "provider list x no-identity -> 0 (identity-free)" \
  || bad "provider list x no-identity -> 0 (identity-free)" "rc=$RC"

NOID signup --json
case "$RC" in
  0) ok "signup x no-identity -> 0 (minted the local identity)" ;;
  3) ok "signup x no-identity -> 3 (gateway unreachable, documented)" ;;
  *) bad "signup x no-identity -> 0|3" "got $RC" ;;
esac

NOID init --json
INIT_NEXT="$(jget data | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const d=JSON.parse(s);console.log((d.stoppedAt&&d.stoppedAt.id)||"",d.next||"")}catch{console.log("-")}})')"
[ "$RC" -eq 4 ] && case "$INIT_NEXT" in identity*"vclaw signup"*) ok "init x no-identity -> 4 with the next command" ;; *) bad "init x no-identity -> 4 with the next command" "got: $INIT_NEXT" ;; esac \
  || bad "init x no-identity -> 4 with the next command" "rc=$RC $INIT_NEXT"

echo "== provider list against a models.yml fixture (temp HOME) =="
PROVHOME="$(mktemp -d)"
mkdir -p "$PROVHOME/.omp/agent"
cat >"$PROVHOME/.omp/agent/models.yml" <<'YML'
providers:
  deepseek:
    baseUrl: http://127.0.0.1:1/v1
    api: openai
    apiKey: E2E_UNSET_DEEPSEEK_KEY
    models:
      - deepseek-chat
  glm:
    baseUrl: http://127.0.0.1:2/v1
    api: openai
    apiKey: ""
    models:
      - glm-4.6
YML
OUT="$(HOME="$PROVHOME" "${BIN[@]}" vclaw provider list --json 2>&1)"; RC=$?
NPROV="$(jget data | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{console.log((JSON.parse(s).providers||[]).length)}catch{console.log("-")}})')"
[ "$RC" -eq 0 ] && [ "$NPROV" = "2" ] && ok "provider list reads the fixture -> 2 providers" \
  || bad "provider list reads the fixture -> 2 providers" "rc=$RC providers=$NPROV"
OUT="$(HOME="$PROVHOME" "${BIN[@]}" vclaw provider test deepseek --json 2>&1)"; RC=$?
[ "$RC" -eq 3 ] && ok "provider test (dead endpoint) -> 3, never 1" || bad "provider test (dead endpoint) -> 3" "got $RC"
rm -rf "$PROVHOME"

echo "== the new verbs: what each one actually needs =="
# An identity-present HOME, built FRESH per row: `logout` really deletes the
# credential, so sharing a HOME between rows would turn the second row's class
# into an artefact of the first.
SEED="${E2E_IDENTITY_DIR:-$HOME/.config/vclaw}"
mkid() { # mkid <dir> [<vclaw-config-js-mutation>]
  mkdir -p "$1/.config/vclaw"
  cp "$SEED/credentials.json" "$1/.config/vclaw/credentials.json" 2>/dev/null || return 1
  cp "$SEED/config.json" "$1/.config/vclaw/config.json" 2>/dev/null || :
  chmod 600 "$1/.config/vclaw/credentials.json" 2>/dev/null
  if [ -n "${2:-}" ]; then
    node -e 'const fs=require("fs"),f=process.argv[1];let c={};try{c=JSON.parse(fs.readFileSync(f,"utf8"))}catch{};new Function("c",process.argv[2])(c);fs.writeFileSync(f,JSON.stringify(c,null,2))' \
      "$1/.config/vclaw/config.json" "$2"
  fi
}
SEED_OK=0; mkid "$(mktemp -d)" >/dev/null 2>&1 && SEED_OK=1
freshid() { # freshid [<config mutation>] -> prints a new seeded HOME
  local d; d="$(mktemp -d)"
  mkid "$d" "${1:-}" || { rm -rf "$d"; echo ""; return 1; }
  echo "$d"
}
if [ "$SEED_OK" = "1" ]; then
  # logout DEFAULT must not dial: the gateway here is a closed port, and the row
  # still exits 0 and drops the credential. A dial would make this class 3.
  H="$(freshid 'c.vgateUrl="http://127.0.0.1:1";')"
  OUT="$(HOME="$H" "${BIN[@]}" vclaw logout --json 2>&1)"; RC=$?
  LOGOUT="$(jget data | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const d=JSON.parse(s);console.log(d.logout||"-",(d.revoked===null?"null":"revoked"),(d.removed||[]).length)}catch{console.log("-")}})')"
  [ "$RC" -eq 0 ] && [ "$LOGOUT" = "done null 1" ] && [ ! -f "$H/.config/vclaw/credentials.json" ] \
    && ok "logout default -> 0, no HTTP, credential dropped" \
    || bad "logout default -> 0, no HTTP, credential dropped" "rc=$RC data=$LOGOUT"
  rm -rf "$H"

  # --revoke DOES need the gateway, and its refusal must carry a REASON.
  H="$(freshid 'c.vgateUrl="http://127.0.0.1:1";')"
  OUT="$(HOME="$H" "${BIN[@]}" vclaw logout --revoke --json 2>&1)"; RC=$?
  [ "$RC" -eq 3 ] && ok "logout --revoke x unreachable gateway -> 3" || bad "logout --revoke x unreachable gateway -> 3" "got $RC"
  case "$(jget error)" in
    *revoke*|*unreachable*|*refused*|*gateway*) ok "logout --revoke -> error names the failed revoke" ;;
    *) bad "logout --revoke -> error names the failed revoke" "error=$(jget error)  (D5: a refusal must carry a reason, not the banner)" ;;
  esac
  rm -rf "$H"

  # reauth mints over HTTP: unreachable gateway is class 3, not 1.
  H="$(freshid 'c.vgateUrl="http://127.0.0.1:1";')"
  OUT="$(HOME="$H" "${BIN[@]}" vclaw reauth --json 2>&1)"; RC=$?
  [ "$RC" -eq 3 ] && ok "reauth x unreachable gateway -> 3" || bad "reauth x unreachable gateway -> 3" "got $RC"
  rm -rf "$H"

  # down is an HTTP presence write on the deployed gateway.
  H="$(freshid 'c.vgateUrl="http://127.0.0.1:1";')"
  OUT="$(HOME="$H" "${BIN[@]}" vclaw down --json 2>&1)"; RC=$?
  case "$RC" in
    0|3) ok "down -> $RC (0 accepted, 3 refused, both documented)" ;;
    *) bad "down -> 0|3" "got $RC" ;;
  esac
  rm -rf "$H"

  # A dead NATS server is class 3 and the error must NAME the fabric.
  for v in "who --wait 300" "inbox" "up"; do
    H="$(freshid 'c.server="nats://127.0.0.1:1";')"
    OUT="$(HOME="$H" "${BIN[@]}" vclaw $v --json 2>&1)"; RC=$?
    ERR="$(jget error)"
    if [ "$RC" -eq 3 ] && printf '%s' "$ERR" | grep -Eqi 'fabric|nats://'; then
      ok "$v x fabric-down -> 3, error names the fabric"
    else
      bad "$v x fabric-down -> 3, error names the fabric" "rc=$RC error=$ERR"
    fi
    rm -rf "$H"
  done
else
  echo "  UNREACHABLE  the new-verb rows: no credentials at $SEED (set E2E_IDENTITY_DIR to a seeded HOME)"
fi

echo "== envelope uniformity on a green verb =="
run peers --json
[ "$RC" -eq "$(jget code)" 2>/dev/null ] && [ "$(jget data.code)" = "<not-json>" -o "$(jget data.code)" = "<absent>" ] \
  && ok "peers: json.code == exit, no data.code" || bad "peers: json.code == exit, no data.code" "rc=$RC code=$(jget code)"

if [ "${BROKER:-0}" = "1" ]; then
  echo "== dependency class (broker unreachable) =="
  CFG="${HOME}/.config/vclaw/config.json"
  if [ -f "$CFG" ]; then
    BACKUP="$(mktemp)"; cp "$CFG" "$BACKUP"
    node -e 'const f=process.argv[1],fs=require("fs");const c=JSON.parse(fs.readFileSync(f,"utf8"));c.server="nats://127.0.0.1:1";fs.writeFileSync(f,JSON.stringify(c))' "$CFG"
    run inbox --json
    [ "$RC" -eq 3 ] && ok "inbox x unreachable broker -> 3" || bad "inbox x unreachable broker -> 3" "got $RC"
    cp "$BACKUP" "$CFG"; rm -f "$BACKUP"
  else
    echo "  SKIP  broker case (no config.json in this HOME)"
  fi
fi

if [ "${PENDING:-0}" = "1" ] && command -v node >/dev/null 2>&1; then
  echo "== pending claim (403 agent_not_claimed) is class 4 in EVERY verb =="
  CFG="${HOME}/.config/vclaw/config.json"
  if [ -f "$CFG" ]; then
    BACKUP="$(mktemp)"; cp "$CFG" "$BACKUP"
    STUB="$(mktemp).mjs"
    cat >"$STUB" <<'JS'
import http from "node:http";
http.createServer((_q, r) => {
  r.writeHead(403, { "content-type": "application/json" });
  r.end(JSON.stringify({ error: "agent_not_claimed", message: "agent not claimed or already issued" }));
}).listen(18080, "127.0.0.1");
JS
    node "$STUB" & STUB_PID=$!
    sleep 1
    node -e 'const f=process.argv[1],fs=require("fs");const c=JSON.parse(fs.readFileSync(f,"utf8"));c.vgateUrl="http://127.0.0.1:18080";fs.writeFileSync(f,JSON.stringify(c))' "$CFG"
    for v in who inbox; do
      OUT="$("${BIN[@]}" vclaw "$v" --wait 300 --json 2>&1)"; RC=$?
      [ "$RC" -eq 4 ] && [ "$(jget code)" = "4" ] && ok "$v x 403 not-claimed -> 4" || bad "$v x 403 not-claimed -> 4" "rc=$RC code=$(jget code)"
    done
    OUT="$("${BIN[@]}" vclaw send NYYxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx hi --json 2>&1)"; RC=$?
    [ "$RC" -eq 4 ] && ok "send x 403 not-claimed -> 4" || bad "send x 403 not-claimed -> 4" "rc=$RC"
    kill "$STUB_PID" 2>/dev/null; wait "$STUB_PID" 2>/dev/null
    cp "$BACKUP" "$CFG"; rm -f "$BACKUP" "$STUB"
  else
    echo "  SKIP  pending-claim case (no config.json in this HOME)"
  fi
fi

echo
echo "RESULT: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ]
