#!/usr/bin/env bash
# e2e-vclaw-usage.sh — the USAGE surface of `/vclaw`, on an installed binary.
#
# Codifies the assertions round-3 e2e measured by hand (docs/lanes/VCLAW_E2E_ROUND3_2026-10-31.md):
#   * an undeclared flag is refused (exit 2) and the verb NEVER runs — the defect
#     that mattered was `inbox --bogusflag` marking unread mail read;
#   * `--wait` with no value / a non-numeric value is refused (exit 2);
#   * a flag may precede the verb (`--json status`);
#   * `--help` lists every built verb, and `--help --json` is one envelope;
#   * every non-zero result carries `error` in the machine envelope;
#   * no-identity is 4 everywhere, and an unreachable broker is 3.
#
# Usage:
#   ./scripts/e2e-vclaw-usage.sh                        # `vclaw-agent` on PATH
#   VCLAW_BIN="node dist/cli.js" ./scripts/e2e-vclaw-usage.sh
#   BROKER=1 ./scripts/e2e-vclaw-usage.sh               # also the exit-3 case (edits config, restores)
set -uo pipefail

BIN_STR="${VCLAW_BIN:-vclaw-agent}"
read -r -a BIN <<<"$BIN_STR"
PASS=0 FAIL=0
ok()   { PASS=$((PASS + 1)); printf '  PASS  %-46s %s\n' "$1" "${2:-}"; }
bad()  { FAIL=$((FAIL + 1)); printf '  FAIL  %-46s %s\n' "$1" "${2:-}"; }

# run <json?> <args...> -> sets RC and OUT (stdout)
run() {
  OUT="$("${BIN[@]}" vclaw "$@" 2>&1)"; RC=$?
}
# jget <field> — read one top-level field from $OUT with node (no jq dependency)
jget() {
  printf '%s' "$OUT" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const o=JSON.parse(s);const v=o[process.argv[1]];console.log(v===undefined?"<absent>":JSON.stringify(v))}catch{console.log("<not-json>")}})' "$1"
}

echo "== usage refused (exit 2, verb does not run) =="
run status --bogusflag --json
[ "$RC" -eq 2 ] && ok "status --bogusflag -> 2" || bad "status --bogusflag -> 2" "got $RC"

run inbox --wait --json
[ "$RC" -eq 2 ] && ok "inbox --wait (no value) -> 2" || bad "inbox --wait (no value) -> 2" "got $RC"

run inbox --wait abc --json
[ "$RC" -eq 2 ] && ok "inbox --wait abc -> 2" || bad "inbox --wait abc -> 2" "got $RC"

echo "== wrapper-level usage errors are class 2 (not 1) =="
"${BIN[@]}" --json status >/dev/null 2>&1; RC=$?
[ "$RC" -eq 2 ] && ok "vclaw-agent --json status -> 2" || bad "vclaw-agent --json status -> 2" "got $RC"
"${BIN[@]}" --nonsense >/dev/null 2>&1; RC=$?
[ "$RC" -eq 2 ] && ok "unknown top-level option -> 2" || bad "unknown top-level option -> 2" "got $RC"
"${BIN[@]}" --help >/dev/null 2>&1; RC=$?
[ "$RC" -eq 0 ] && ok "--help still exits 0" || bad "--help still exits 0" "got $RC"

echo "== flags may precede the verb =="
run --json status --json
VERB="$(jget verb)"
[ "$VERB" = '"status"' ] && ok "--json status parses the status verb" || bad "--json status parses the status verb" "verb=$VERB"

echo "== help =="
run --help
HELP_OK=1
for v in status doctor who peers send inbox signup; do
  grep -q "/vclaw $v" <<<"$OUT" || HELP_OK=0
done
[ "$HELP_OK" -eq 1 ] && ok "--help lists every built verb" || bad "--help lists every built verb"

run --help --json
[ "$RC" -eq 0 ] && [ "$(jget verb)" = '"help"' ] && ok "--help --json is one envelope" || bad "--help --json is one envelope" "rc=$RC"

echo "== refusals carry a reason =="
run send --json
ERR="$(jget error)"
[ "$RC" -eq 2 ] && [ "$ERR" != "<absent>" ] && ok "send refusal carries error" || bad "send refusal carries error" "rc=$RC error=$ERR"

echo "== identity class (empty HOME) =="
TMPHOME="$(mktemp -d)"
for v in status who inbox; do
  OUT="$(HOME="$TMPHOME" "${BIN[@]}" vclaw "$v" --json 2>&1)"; RC=$?
  if [ "$RC" -eq 4 ] && [ "$(jget code)" = "4" ] && [ "$(jget data.code)" = "<not-json>" -o "$(jget data.code)" = "<absent>" ]; then
    ok "$v x no-identity -> 4/4/no data.code"
  else
    bad "$v x no-identity -> 4/4/no data.code" "rc=$RC code=$(jget code)"
  fi
done
rm -rf "$TMPHOME"

echo "== envelope uniformity on a green verb =="
run peers --json
[ "$RC" -eq "$(jget code)" 2>/dev/null ] && [ "$(jget data.code)" = "<not-json>" -o "$(jget data.code)" = "<absent>" ] \
  && ok "peers: json.code == exit, no data.code" || bad "peers: json.code == exit, no data.code" "rc=$RC code=$(jget code)"

if [ "${BROKER:-0}" = "1" ]; then
  echo "== dependency class (broker unreachable) =="
  CFG="${HOME}/.config/vclaw/config.json"
  if [ -f "$CFG" ]; then
    BACKUP="$(mktemp)"; cp "$CFG" "$BACKUP"
    node -e 'const f=process.argv[1],fs=require("fs");const c=JSON.parse(fs.readFileSync(f,"utf8"));c.server="nats://127.0.0.1:1";fs.writeFileSync(f,JSON.stringify(c))' "$CFG"
    run inbox --json
    [ "$RC" -eq 3 ] && ok "inbox x unreachable broker -> 3" || bad "inbox x unreachable broker -> 3" "got $RC"
    cp "$BACKUP" "$CFG"; rm -f "$BACKUP"
  else
    echo "  SKIP  broker case (no config.json in this HOME)"
  fi
fi

if [ "${PENDING:-0}" = "1" ] && command -v node >/dev/null 2>&1; then
  echo "== pending claim (403 agent_not_claimed) is class 4 in EVERY verb =="
  CFG="${HOME}/.config/vclaw/config.json"
  if [ -f "$CFG" ]; then
    BACKUP="$(mktemp)"; cp "$CFG" "$BACKUP"
    STUB="$(mktemp).mjs"
    cat >"$STUB" <<'JS'
import http from "node:http";
http.createServer((_q, r) => {
  r.writeHead(403, { "content-type": "application/json" });
  r.end(JSON.stringify({ error: "agent_not_claimed", message: "agent not claimed or already issued" }));
}).listen(18080, "127.0.0.1");
JS
    node "$STUB" & STUB_PID=$!
    sleep 1
    node -e 'const f=process.argv[1],fs=require("fs");const c=JSON.parse(fs.readFileSync(f,"utf8"));c.vgateUrl="http://127.0.0.1:18080";fs.writeFileSync(f,JSON.stringify(c))' "$CFG"
    for v in who inbox; do
      OUT="$("${BIN[@]}" vclaw "$v" --wait 300 --json 2>&1)"; RC=$?
      [ "$RC" -eq 4 ] && [ "$(jget code)" = "4" ] && ok "$v x 403 not-claimed -> 4" || bad "$v x 403 not-claimed -> 4" "rc=$RC code=$(jget code)"
    done
    OUT="$("${BIN[@]}" vclaw send NYYxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx hi --json 2>&1)"; RC=$?
    [ "$RC" -eq 4 ] && ok "send x 403 not-claimed -> 4" || bad "send x 403 not-claimed -> 4" "rc=$RC"
    kill "$STUB_PID" 2>/dev/null; wait "$STUB_PID" 2>/dev/null
    cp "$BACKUP" "$CFG"; rm -f "$BACKUP" "$STUB"
  else
    echo "  SKIP  pending-claim case (no config.json in this HOME)"
  fi
fi

echo
echo "RESULT: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ]
