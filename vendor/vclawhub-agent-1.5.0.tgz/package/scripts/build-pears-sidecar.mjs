#!/usr/bin/env node
/**
 * build-pears-sidecar.mjs — package the Tier P node helper for distribution.
 *
 * Why this exists (docs/VCLAW_CORE_MODULES.md §E9, grant G-6): the helper is a
 * separate runtime (node >= 22.18 — bun cannot host the dep set, bun #18546) with
 * its own pinned dependency tree, so it CANNOT be inlined into the single-file CLI
 * bundle. It therefore ships as its own artefact: a tarball the join pipe fetches,
 * verifies and extracts to ~/.vclaw/pears/sidecar, where resolveSidecarDir() looks.
 *
 * Emits:
 *   dist/pears-sidecar/            staged tree (package.json + lockfile + built dist/)
 *   dist/pears-sidecar.tgz         the distributable
 *   dist/pears-sidecar.tgz.sha256  integrity digest (the join pipe refuses a mismatch)
 *
 * The dependency tree is NOT vendored into the tarball — the installer runs
 * `npm ci --omit=dev` so the native module (sodium-native) matches THAT host's node
 * ABI. A tarball with a prebuilt .node would be arch- AND abi-locked.
 *
 * Usage: node scripts/build-pears-sidecar.mjs [--skip-install] [--skip-build]
 */
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sidecar = join(root, "src", "net", "p2p", "sidecar");
const outdir = join(root, "dist");
const stage = join(outdir, "pears-sidecar");
const tarball = join(outdir, "pears-sidecar.tgz");
const skipInstall = process.argv.includes("--skip-install");
const skipBuild = process.argv.includes("--skip-build");

const run = (cmd, args, cwd) => {
  const res = spawnSync(cmd, args, { cwd, stdio: "inherit" });
  if (res.status !== 0) throw new Error(`${cmd} ${args.join(" ")} failed (exit ${res.status})`);
};

if (!skipInstall && !existsSync(join(sidecar, "node_modules", "hyperswarm"))) {
  console.log("── installing the helper's pinned deps (npm ci) …");
  run("npm", ["ci"], sidecar);
}
if (!skipBuild) {
  // ALWAYS from clean: measured 2026-10-25 — after reverting a source experiment the
  // packager copied a STALE dist/main.js into the tarball (the reverted call was still
  // in the artefact, and three hosts installed it before anyone noticed). An
  // incremental tsc cannot be trusted here, so the build directory is removed first.
  rmSync(join(sidecar, "dist"), { recursive: true, force: true });
  console.log("── building the helper (tsc, clean) …");
  run("npm", ["run", "build"], sidecar);
}
if (!existsSync(join(sidecar, "dist", "main.js"))) {
  throw new Error("helper build produced no dist/main.js — refusing to package an empty helper");
}

rmSync(stage, { recursive: true, force: true });
mkdirSync(join(stage, ".."), { recursive: true });
cpSync(sidecar, stage, {
  recursive: true,
  filter: (src) => !src.includes("node_modules") && !src.includes(`${join(sidecar, "src")}`),
});
cpSync(join(root, "src", "net", "p2p", "PROTOCOL.md"), join(stage, "PROTOCOL.md"));
rmSync(tarball, { force: true });
run("tar", ["-czf", tarball, "-C", stage, "."]);

const digest = createHash("sha256").update(readFileSync(tarball)).digest("hex");
writeFileSync(tarball + ".sha256", `${digest}  pears-sidecar.tgz\n`);

const pkg = JSON.parse(readFileSync(join(sidecar, "package.json"), "utf8"));
console.log(`\n✅ helper ${pkg.version} packaged`);
console.log(`   ${tarball}  (${(statSync(tarball).size / 1024).toFixed(0)} KiB)`);
console.log(`   sha256 ${digest}`);
console.log(`   install: extract to ~/.vclaw/pears/sidecar and run npm ci --omit=dev there`);
