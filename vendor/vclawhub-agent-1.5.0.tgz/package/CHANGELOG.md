## [Unreleased]

### Added — Feature Set 1: signup + who (2026-10-31)
- **`vclaw signup` / `/vclaw signup`** — new-user signup over the classical vclaw auth link: mints or
  resumes an identity, calls `/v1/agent/introduce`, mints the ed25519-nkey **approve-proof**, prints the
  claim URL, and (TUI only) best-effort opens it. `--wait <s>` polls for approval and completes
  (`completeSignup`). Verified in the **installed state** on a fresh container.
- **Crash-safety fix in the signup ordering:** the identity seed is persisted **before** the `.pending`
  flag, so "a claim is pending" always means "the seed is recoverable" (the historical `onboard()` wrote
  the flag first and could strand a claim).
- **`vclaw who` / `/vclaw who`** — read-only "who is around" from **signed announcements**, because the
  minted agent JWT cannot use Micro discovery on this fabric (`$SRV.PING/INFO` → Permissions Violation).
  Verified end to end on the live fabric.
- **Packaging trap #2 (found via the desktop lane):** `dist/cli.js` is **gitignored** (`dist/*` with
  exceptions only for the two extension dirs), so a clean checkout ships no CLI and a `npm pack` without
  `tsc` ships a stale one — observed as `unknown command 'vclaw'`. Pinned artefact digests are recorded in
  `src/vclaw/README.md` §11a; a post-pack gate (five verbs + `command("vclaw"`) is specified.
- **Packaging trap fixed in the process:** `npm pack` shipped a **stale** `dist/` (tsc output predated the
  new verbs) — the CLI answered `unknown verb "signup"`. Always `npm run build` before `npm pack`; the
  tarball is now asserted to contain all five verbs.

### Added — `/vclaw`, the model-free operator surface (roadmap A, 2026-10-31)
- **`vclaw-agent vclaw <verb>`** and the **`/vclaw <verb>`** TUI command: `status`, `doctor`, `peers`.
  Built to run with **no LLM configured** — no prompt templates, no model calls, no interactive input.
- One **verb table** drives every surface (CLI, TUI text, completions); `--json` is the machine surface
  with a stable shape (`{ok, verb, state, data}`) and exit codes `0 · 2 usage · 3 dependency ·
  4 identity-not-ready`. `status` answers truthfully with nothing configured; `doctor` prints every
  check with the command that fixes it; `peers` reads local rosters only and labels rows `cached`.

### Fixed — v11 P0 (Synadia v0.3 conformance, 2026-10-31)
- **§9.2/§9.3 refusals are emitted on the prompt endpoint.** Bad input is no longer accepted or
  silently downgraded: empty payload, malformed JSON envelope, oversize (`max_payload`), and an
  attachment when `attachments_ok=false` each return `Nats-Service-Error-Code: 400` followed by the
  empty terminator. Verified live on the site fabric: four refusals with `code=400, bytes=0`, and a
  valid envelope answered normally.
- **§5.2 `attachments_ok` is truthful.** It defaulted to `"true"` while nothing consumed attachments;
  it now defaults to `"false"` and the endpoint **refuses** an attachment instead of dropping it.
- **§3.1 `version` is the harness semver.** `startSynadiaAgent({ harnessVersion })` wins over this
  bundle's version; the extension passes `VCLAW_HARNESS_VERSION`. Measured on the wire: `99.1.2` when
  the host supplies it.
- **§3.2 `session`** is set from `SYNADIA_SESSION` (verified on the wire as `p0-session`).
- **Publish set (G11/E40):** `jsr.json` `publish.include` gains **`dist/**`**, so the artefact now
  carries the two bundles `pi.extensions` declares (`jsr publish --dry-run`: 80 → **82 files**, both
  `dist/*/index.bundled.js` present). `packages/**` was tried and **removed** — jsr silently publishes
  nothing from it, and `@vclawhub/ext-synadia` ships that source on its own.

### Design
- **`/vclaw` — one model-free operator command**: `status · doctor · peers · inbox · send · ping · claim ·
  connect · family · watch`. Spec: [`src/vclaw/README.md`](src/vclaw/README.md). It works with **no LLM
  configured** — OMP runs local command handlers without a model (`agent-session.ts:7249-7278`) while
  non-interactive `omp -p` requires one, so automation belongs to `vclaw-agent`, never to `omp -p`.
- The ten legacy slash commands (`/vchat-*`, `/synadia-*`) become **aliases for one release**, then are
  removed; the plane becomes a `--tier` flag rather than a name prefix (operator ruling 2026-10-30).

## [1.5.0] — 2026-10-25

**Tier P becomes installable, and operators can see whether it works.** Before this release the P2P
stack was built and tested but reachable only from a repo checkout: the node helper was excluded from
`tsconfig`, `dist` and the npm tarball, so every installed agent answered `p2p_unavailable`.

### Added
- **`vclaw-agent pears status`** (`--json`, `--require`) — the read-only answer to "does Tier P work on
  this host?": helper build, node/version floor, dependency tree, helper socket, known delegations.
  `--require` exits 4 when unavailable so scripts and tests can assert it without parsing prose.
- **`scripts/build-pears-sidecar.mjs`** — packages the helper as its own artefact
  (`dist/pears-sidecar.tgz` + sha256, built tree staged in `dist/pears-sidecar/`). The dependency tree
  is deliberately NOT vendored: the installer runs `npm ci --omit=dev` so the native module matches
  that host's node ABI, not the packager's.
- **`npm run build:pears-sidecar`** and **`build:all`**.

### Changed
- **`resolveSidecarDir()` learns the install layout**: `~/.vclaw/pears/sidecar` is now the first
  candidate (the helper is a per-host singleton, so its home is user-level), ahead of the repo layout.
- Version 1.5.0 (jsr.json + package.json). Nothing had been published since 1.4.0 on 2026-10-03, so
  every M1–M3.5 change rides this release.

### Verified (POC, 3 incus containers + macOS arm64)
- 20 MiB artifact cross-host: put 199 ms, get 467 ms, sha256 identical; range read at 1 MiB: 65,536 B in 4 ms.
- Encrypted pub/sub cross-host: publisher `peers: 1`, receiver digest identical, payload byte-exact.
- Non-member (base key, no content key): connected, dialed, and received **nothing** — no error, 0 bytes.
- Degradation: with node off `PATH`, unavailable is reported explicitly (exit 4 with `--require`).

### Known gaps (tracked, not fixed here)
- `bindHost: "0.0.0.0"` is rejected by the sidecar (`E_OP: Invalid host`); a peer must pass its own
  interface address. *(Fixed in helper 0.3.1 the same sprint — E19: a wildcard/absent bind resolves
  to the first non-internal IPv4 and is advertised in the ready hello.)*
- `p2pTransport` still has zero production call sites — same-owner message routing (M4) is unimplemented.
- No delegation-row creator and no sealed-key distribution yet: the POC distributed the content key and
  base keys out of band.
- **Per-invocation private stdio helpers (root-caused 2026-10-29, BACKLOG E24):** `SidecarClient.start()` joins a
  live helper only when a **listen-mode socket** exists; otherwise it spawns a private stdio helper bound to that
  invocation's store, which dies with the process. Two standalone invocations (`pears put`, then `pears get`) are
  therefore two helpers and two stores — the reader's core is empty and there is no live writer to replicate from,
  which surfaces as *"artifact blocks not available"*. **The transport itself is sound:** a cross-container 1 MiB
  artifact (pears-1 → pears-2, both in listen mode, DHT bootstrap) completed in **42 ms with an identical sha256**.
  Earlier phrasings of this gap ("store-dir is silently ignored on connect", "hypercore replication does not sync")
  were both wrong; this one is measured. Fix: all CLI/POC surfaces go through `attachHelper`, and a store mismatch
  against the live helper is refused loudly.

## [1.4.0] — 2026-10-03

### Added
- **Conversation identity and ordering on H2A and A2A** (Phase 1 of the session-sync design, additive only):
  `messageId` (UUIDv7) and `conversationId` on `PromptMessage` — now **validated** on parse, where the frame
  was previously `JSON.parse`d unchecked; `Chunk.conversationId` set on every reply; A2A `inReplyTo` (the
  schema had zero writers) and `from.sessionId`; a per-conversation monotonic `seq` plus `parentMessageId`
  on both planes.
- Session entries carry `uid` + `seq`, and `head_id` is the entry's globally-unique UUIDv7 `uid`. The 8-hex
  file-local ids stay in the file: unique only within one file, they collide if exported to a global namespace.

### Changed
- A reply chunk with no `conversationId` is **rejected loudly** — `no conversationId … routing is impossible,
  frame discarded` — instead of vanishing silently. The outcome is unchanged for such frames (they were
  already discarded); the diagnostic is the fix. In a matched fleet the producers now set the field.

### Fixed
- The four stale subscription fixtures that failed at baseline (`ext-upgrade` ×2, `ext-retire` ×2): they
  invoked the callback with no `subject` while it correctly returns early without one. Fixed in the fixtures,
  not by relaxing the guard (byte-identical to before; 651 passed / 651).

