## [Unreleased]

### Added — session mailbox: at-most-once becomes durable while a session runs (2026-10-31)
- The extension now subscribes the **IDP-fabric** mailbox subject (`tenant.<t>.a2a.<self>.>`) at
  `session_start` and drains it into the same spool the CLI reads — same builder (`vclaw/mailbox.ts`), same
  bytes. `subA2A` listened on the SDK taxonomy plane (`a2a.<nkey>.>`), which `send` never publishes to, so a
  DM sent while nobody ran `inbox` was lost.
- **Measured:** TUI open and idle, omp-1 sent `sent while idle`; the spool held it (`seq 1`) before any
  `inbox` ran, and the TUI rendered it. The same test previously lost the message.
- Still true and now stated in the spec: durable **while a session is open on that host**; with no session
  running there is no replay (that needs a broker-side durable consumer this fabric does not grant).

### Fixed — FS2 was missing from the TUI surface (2026-10-31, found by the desktop mirror)
- **`/vclaw send` and `/vclaw inbox` did not exist in the pi-extension bundle** (TUI answered
  `unknown verb`, exit 2) while the CLI had both: `npm run build` was `tsc` only, so the self-contained
  bundle kept the previous verb table *and* the pre-fix exit classification. Every CLI-side measurement
  passed against a stale shipped surface.
- **`npm run build` now rebuilds the extension bundles** (`tsc && npm run build:extensions`), so the CLI and
  the TUI cannot disagree without the build failing to produce one of them.

### Fixed — vclaw exit class + spool filename (2026-10-31, found by the desktop mirror)
- **`inbox` leaked exit `1`** in the no-identity state: `openFabric` threw a plain `Error`, so the generic
  catch produced a code outside the frozen set `{0,2,3,4}`. Fabric-backed verbs now classify by cause —
  no credentials / no granted mailbox → **4**, cannot reach the fabric → **3**. Measured with an empty HOME:
  `inbox`, `status`, `who` all exit **4** with `json.code 4`.
- **Spool filename is now `<tenant>__<self8>.jsonl`** (`self8` = first 8 chars of the own nkey, with the read
  set alongside as `<tenant>__<self8>.read.json`). Two identities on one host can no longer interleave into
  one `seq` space. Measured on the fleet: `vclaw__UBNBJ35N.jsonl`. Renamed now because zero external
  consumers exist; after the desktop ships this becomes a migration.

### Changed — the vclaw machine contract, frozen with the consumer (2026-10-31)
- **`code` is top-level on every verb result** and always equals the exit code (`who`/`status` no longer
  disagree); CI asserts one surface.
- **`to`/`from` are NKeys**, with an optional display `name`/`fromName` alongside — never a name alone.
- **`digest` is specified**: `sha256` hex over the exact frame bytes; `send` names the algorithm
  (`digestAlg`). Nonce-ish fields (`ts`/`id`/`conversationId`) are asserted structurally, not byte-equal.
- **Inbox spool is a consumer contract**: `~/.vclaw/inbox/<tenant>.jsonl`, 0600, append-only with
  `kind` first and a monotonic per-file `seq`; `conversationId` carried opaquely; `--prune` is opt-in
  (the only rewrite); the file is a mirror and the verb is the source of truth. One identity per host is
  assumed — a second would share the tenant file.

### Added — Feature Set 2: `send` + `inbox` (2026-10-31)
- **`vclaw send <peer> <text…>`** — one DM on the fabric: `a2a_request` envelope to
  `tenant.<tenant>.a2a.<peer>.req`, tenant derived from the identity's own JWT. The peer id must be ONE
  concrete subject token (dots, wildcards and spaces are refused, so a caller cannot retarget the subject).
- **`vclaw inbox [--wait ms] [--all]`** — a durable local spool at `~/.vclaw/inbox/<self>.jsonl` (0600),
  append-only, with read state in a separate atomically-written file; dedupe by envelope id with a content
  digest fallback; `prune()` caps at 2000 lines and never drops unread mail.
- **Measured cross-container**: omp-1 → omp-2 delivered and spooled; a second `inbox` reported `unread: 0`
  (read state persisted); `--all` showed `read: true`.
- **Stated limits**: no standing subscription yet (a DM sent with nobody subscribed is lost — the fix is a
  mailbox subscription inside the long-lived extension); threading carried but not surfaced; `from` is
  self-asserted and is labelled as such in the human view.

### Added — assertable TUI output (2026-10-31)
- **`/vclaw` appends every invocation to `~/.vclaw/vclaw-out.txt`** (`=== <iso> /vclaw <args> exit=<n>` + the
  rendered text, 0600). A pty only keeps the cursor region, so TUI output was unassertable in CI; this makes
  it a file. Verified in a container TUI on the shipped artefact: both invocations captured with verb, exit
  code and full text. Failures to write are swallowed — diagnostics must never break the command.

### Fixed — G14 reply correlation in the P2P session bridge (2026-10-31)
- **One prompt in flight.** `createBridge` pushed every inbound and immediately injected it, then replied to
  the OLDEST queued stream on every `turn_end` — so two inbound callers could swap answers, and a turn the
  local operator typed replied to a remote caller with text they never asked for. Prompts now queue and the
  next is injected only when the previous turn ends; a `turn_end` with nothing in flight answers nobody.
- **Known limit, stated and tested:** the host gives no correlation id, so while a remote prompt is in
  flight the operator's own next turn is attributed to it. `test/bridge-correlation.test.ts` pins both the
  fix and the limit. This unblocks the `inbox`/`send` half of Feature Set 2 (E31).

### Fixed — `/vclaw` in the real OMP TUI (2026-10-31)
- **`/vclaw` threw `result is not defined` in the TUI** — the handler read `result.data` while destructuring
  only `{ exit, text }`; a same-named binding elsewhere satisfied `tsc`, so the error was runtime-only and
  invisible to every non-TUI test. Surfaced by driving the real TUI in a container (tmux + `setupVersion: 2`
  preseeded). `/vclaw status` and `/vclaw who` now render their text there, measured on the final artefact.

### Fixed — fleet e2e loop (2026-10-31)
- **`who` derives its segment from the identity's own JWT** (`segmentFromJwt`). Hardcoding `default` failed
  with `Permissions Violation for Subscription to "$SRV.INFO.agents.default.>"`; the granted segment is
  `vclaw`, and a denial is now a clear answer rather than a stack trace.
- **`status --deep` reconciles with the server** and exposes an explicit `claim: none|pending|approved`.
  A claim approved elsewhere no longer reads PENDING forever, and `steward` is reported as "not disclosed"
  when the anonymous status call returns only `{claimed:true}`.
- **`scripts/e2e-vclaw-fleet.sh`** — install → signup → server-side approve → reconcile → `who`, per
  container. Measured on three containers: all claimed; cross-container discovery on segment `vclaw`.

### Security — Feature Set 1 audit, holes plugged (2026-10-31)
Nine findings from an adversarial review of `signup`/`who`; five fixed here, the rest documented:
- **`who` no longer trusts announcement JSON.** It previously parsed the payload directly, so any publisher
  could display itself under another agent's nkey and `who` would show the victim. It now ingests through
  `Directory` (`subject-pin + ed25519 sig + schema + TTL + replay`), and the verb reports
  `accepted`/`rejected` counts so a rejected record is visible instead of silently absent.
- **Backup files are `0600`.** `backupCredentials()` used `copyFile` at the umask default — a `--force`
  signup could leave a world-readable copy of the nkey **seed** beside the live one. Now `enforceSecretMode`.
- **A failed backup aborts the signup** instead of being swallowed and then overwriting the old identity.
- **The claim URL's proof is bounded** to 24 h (`expiresInSeconds`) instead of having no `exp` at all.
- **The proof stays out of structured output** unless the caller passes `--with-proof`: `--json` consumers
  are log pipelines far more often than browsers.
- **`openBrowser()` no longer builds a shell string.** It was `exec(\`open "${url}"\`)`, injectable through
  `CLAIM_BASE_URL`; it now spawns with argv and refuses any non-`https:` URL (`http:` only with `VCLAW_DEV=1`).
  The extension reuses this one implementation.
Still open and documented, not fixed: local `argv` exposure of the claim URL while an opener runs (mitigated
by the 24 h proof life), display-name squatting (inherent to self-asserted names), and `VCLAW_CREDS_DIR`
env-injection (absolute-path/world-writable checks not yet added).

### Added — Feature Set 1: signup + who (2026-10-31)
- **`vclaw signup` / `/vclaw signup`** — new-user signup over the classical vclaw auth link: mints or
  resumes an identity, calls `/v1/agent/introduce`, mints the ed25519-nkey **approve-proof**, prints the
  claim URL, and (TUI only) best-effort opens it. `--wait <s>` polls for approval and completes
  (`completeSignup`). Verified in the **installed state** on a fresh container.
- **Crash-safety fix in the signup ordering:** the identity seed is persisted **before** the `.pending`
  flag, so "a claim is pending" always means "the seed is recoverable" (the historical `onboard()` wrote
  the flag first and could strand a claim).
- **`vclaw who` / `/vclaw who`** — read-only "who is around" from **signed announcements**, because the
  minted agent JWT cannot use Micro discovery on this fabric (`$SRV.PING/INFO` → Permissions Violation).
  Verified end to end on the live fabric.
- **Packaging trap #2 (found via the desktop lane):** `dist/cli.js` is **gitignored** (`dist/*` with
  exceptions only for the two extension dirs), so a clean checkout ships no CLI and a `npm pack` without
  `tsc` ships a stale one — observed as `unknown command 'vclaw'`. Pinned artefact digests are recorded in
  `src/vclaw/README.md` §11a; a post-pack gate (five verbs + `command("vclaw"`) is specified.
- **Packaging trap fixed in the process:** `npm pack` shipped a **stale** `dist/` (tsc output predated the
  new verbs) — the CLI answered `unknown verb "signup"`. Always `npm run build` before `npm pack`; the
  tarball is now asserted to contain all five verbs.

### Added — `/vclaw`, the model-free operator surface (roadmap A, 2026-10-31)
- **`vclaw-agent vclaw <verb>`** and the **`/vclaw <verb>`** TUI command: `status`, `doctor`, `peers`.
  Built to run with **no LLM configured** — no prompt templates, no model calls, no interactive input.
- One **verb table** drives every surface (CLI, TUI text, completions); `--json` is the machine surface
  with a stable shape (`{ok, verb, state, data}`) and exit codes `0 · 2 usage · 3 dependency ·
  4 identity-not-ready`. `status` answers truthfully with nothing configured; `doctor` prints every
  check with the command that fixes it; `peers` reads local rosters only and labels rows `cached`.

### Fixed — v11 P0 (Synadia v0.3 conformance, 2026-10-31)
- **§9.2/§9.3 refusals are emitted on the prompt endpoint.** Bad input is no longer accepted or
  silently downgraded: empty payload, malformed JSON envelope, oversize (`max_payload`), and an
  attachment when `attachments_ok=false` each return `Nats-Service-Error-Code: 400` followed by the
  empty terminator. Verified live on the site fabric: four refusals with `code=400, bytes=0`, and a
  valid envelope answered normally.
- **§5.2 `attachments_ok` is truthful.** It defaulted to `"true"` while nothing consumed attachments;
  it now defaults to `"false"` and the endpoint **refuses** an attachment instead of dropping it.
- **§3.1 `version` is the harness semver.** `startSynadiaAgent({ harnessVersion })` wins over this
  bundle's version; the extension passes `VCLAW_HARNESS_VERSION`. Measured on the wire: `99.1.2` when
  the host supplies it.
- **§3.2 `session`** is set from `SYNADIA_SESSION` (verified on the wire as `p0-session`).
- **Publish set (G11/E40):** `jsr.json` `publish.include` gains **`dist/**`**, so the artefact now
  carries the two bundles `pi.extensions` declares (`jsr publish --dry-run`: 80 → **82 files**, both
  `dist/*/index.bundled.js` present). `packages/**` was tried and **removed** — jsr silently publishes
  nothing from it, and `@vclawhub/ext-synadia` ships that source on its own.

### Design
- **`/vclaw` — one model-free operator command**: `status · doctor · peers · inbox · send · ping · claim ·
  connect · family · watch`. Spec: [`src/vclaw/README.md`](src/vclaw/README.md). It works with **no LLM
  configured** — OMP runs local command handlers without a model (`agent-session.ts:7249-7278`) while
  non-interactive `omp -p` requires one, so automation belongs to `vclaw-agent`, never to `omp -p`.
- The ten legacy slash commands (`/vchat-*`, `/synadia-*`) become **aliases for one release**, then are
  removed; the plane becomes a `--tier` flag rather than a name prefix (operator ruling 2026-10-30).

## [1.5.0] — 2026-10-25

**Tier P becomes installable, and operators can see whether it works.** Before this release the P2P
stack was built and tested but reachable only from a repo checkout: the node helper was excluded from
`tsconfig`, `dist` and the npm tarball, so every installed agent answered `p2p_unavailable`.

### Added
- **`vclaw-agent pears status`** (`--json`, `--require`) — the read-only answer to "does Tier P work on
  this host?": helper build, node/version floor, dependency tree, helper socket, known delegations.
  `--require` exits 4 when unavailable so scripts and tests can assert it without parsing prose.
- **`scripts/build-pears-sidecar.mjs`** — packages the helper as its own artefact
  (`dist/pears-sidecar.tgz` + sha256, built tree staged in `dist/pears-sidecar/`). The dependency tree
  is deliberately NOT vendored: the installer runs `npm ci --omit=dev` so the native module matches
  that host's node ABI, not the packager's.
- **`npm run build:pears-sidecar`** and **`build:all`**.

### Changed
- **`resolveSidecarDir()` learns the install layout**: `~/.vclaw/pears/sidecar` is now the first
  candidate (the helper is a per-host singleton, so its home is user-level), ahead of the repo layout.
- Version 1.5.0 (jsr.json + package.json). Nothing had been published since 1.4.0 on 2026-10-03, so
  every M1–M3.5 change rides this release.

### Verified (POC, 3 incus containers + macOS arm64)
- 20 MiB artifact cross-host: put 199 ms, get 467 ms, sha256 identical; range read at 1 MiB: 65,536 B in 4 ms.
- Encrypted pub/sub cross-host: publisher `peers: 1`, receiver digest identical, payload byte-exact.
- Non-member (base key, no content key): connected, dialed, and received **nothing** — no error, 0 bytes.
- Degradation: with node off `PATH`, unavailable is reported explicitly (exit 4 with `--require`).

### Known gaps (tracked, not fixed here)
- `bindHost: "0.0.0.0"` is rejected by the sidecar (`E_OP: Invalid host`); a peer must pass its own
  interface address. *(Fixed in helper 0.3.1 the same sprint — E19: a wildcard/absent bind resolves
  to the first non-internal IPv4 and is advertised in the ready hello.)*
- `p2pTransport` still has zero production call sites — same-owner message routing (M4) is unimplemented.
- No delegation-row creator and no sealed-key distribution yet: the POC distributed the content key and
  base keys out of band.
- **Per-invocation private stdio helpers (root-caused 2026-10-29, BACKLOG E24):** `SidecarClient.start()` joins a
  live helper only when a **listen-mode socket** exists; otherwise it spawns a private stdio helper bound to that
  invocation's store, which dies with the process. Two standalone invocations (`pears put`, then `pears get`) are
  therefore two helpers and two stores — the reader's core is empty and there is no live writer to replicate from,
  which surfaces as *"artifact blocks not available"*. **The transport itself is sound:** a cross-container 1 MiB
  artifact (pears-1 → pears-2, both in listen mode, DHT bootstrap) completed in **42 ms with an identical sha256**.
  Earlier phrasings of this gap ("store-dir is silently ignored on connect", "hypercore replication does not sync")
  were both wrong; this one is measured. Fix: all CLI/POC surfaces go through `attachHelper`, and a store mismatch
  against the live helper is refused loudly.

## [1.4.0] — 2026-10-03

### Added
- **Conversation identity and ordering on H2A and A2A** (Phase 1 of the session-sync design, additive only):
  `messageId` (UUIDv7) and `conversationId` on `PromptMessage` — now **validated** on parse, where the frame
  was previously `JSON.parse`d unchecked; `Chunk.conversationId` set on every reply; A2A `inReplyTo` (the
  schema had zero writers) and `from.sessionId`; a per-conversation monotonic `seq` plus `parentMessageId`
  on both planes.
- Session entries carry `uid` + `seq`, and `head_id` is the entry's globally-unique UUIDv7 `uid`. The 8-hex
  file-local ids stay in the file: unique only within one file, they collide if exported to a global namespace.

### Changed
- A reply chunk with no `conversationId` is **rejected loudly** — `no conversationId … routing is impossible,
  frame discarded` — instead of vanishing silently. The outcome is unchanged for such frames (they were
  already discarded); the diagnostic is the fix. In a matched fleet the producers now set the field.

### Fixed
- The four stale subscription fixtures that failed at baseline (`ext-upgrade` ×2, `ext-retire` ×2): they
  invoked the callback with no `subject` while it correctly returns early without one. Fixed in the fixtures,
  not by relaxing the guard (byte-identical to before; 651 passed / 651).

