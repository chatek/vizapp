# agent-sdk backlog — `/vclaw`

**Scope rule.** The estate register (`../docs/BACKLOG.md`) stays authoritative for anything that crosses lanes
(vgate, desktop, deploy). THIS file is the SDK-local register: what `/vclaw` plans, what is deferred and why, and
what must not be built yet. A row here that needs another lane says which estate row it depends on.

**Code lives at `agent-sdk/src/vclaw/`** — 7 core files (`run`, `fabric`, `inbox-store`, `mailbox`, `render`,
`state`, `sync`) plus `verbs/` (8 today). Tests in `test/unit/vclaw-*.test.ts`; e2e harnesses in
`scripts/e2e-vclaw-usage.sh` (usage surface), `scripts/e2e-vclaw-matrix.sh` (verb × state proofs) and
`scripts/e2e-vclaw-tui.sh`. Spec: `src/vclaw/README.md`.

## 1 · In the current sprint (for context, not a backlog)

| item | state |
|---|---|
| **B4** exit `1` reachable · **B5** dashboard reads `~/.vclaw/pears/inbox` | **B4 done** (2026-11-01): `send "bad.peer"` is `2`, `signup`/`login` map `lib/signup` throws through `classifyFabricError`, and run.ts's `1` is the documented internal-fault last resort no classified path can reach · **B5** open |
| surface trio: `signup` returns `data.claimUrl` · `who` full nkeys · refusal `error` is a reason · `verify-pack` 7/7 | **done** (2026-11-01): `claimUrl` always in `data` (`--with-proof` retired) · `who` full nkeys · `status`/`doctor` refusals carry `VerbResult.reason` · `verify-pack` derives every verb from the table (13 today) and fails on a stale `dist/` in both directions |
| **C23 client**: `logout`, `reauth`, `down`, `up` | **`logout --revoke`, `reauth`, `down` BUILT** (2026-11-01, 18 tests; the assertion helper mints the ed25519 `client_assertion` the vgate side verifies). **`up` still open** — it composes signup→login→connect and needs the deployed endpoints to be worth writing |
| **C22**: `provider list/add/test/use/rm` + `doctor` provider checks + `init` (≥2 providers) | **`provider` and `init` BUILT** (2026-11-01, 28 tests): keys are PRESENCE-only in output, `add` writes OMP's file only with `--write-omp` (append, mode preserved), `test` is one request. **Open: `doctor` provider checks** — `init` reports them, `doctor` does not yet |

## 2 · Planned but NOT in this sprint

| feature | state | why deferred | unblocked by |
|---|---|---|---|
| **`ping <peer> [--count]`** | PLANNED (spec §4) | none of the three sprint jobs needs it; needs a round-trip decision (NATS request/reply vs announcement echo) and a peer that answers | a design note + a reachable peer |
| **`connect [--reconnect] [--dry-run]`** | PLANNED (spec §4) | `up` will absorb the common case; `--reconnect` re-registration is **G17** | `up` landing first |
| **`family`** | PLANNED (spec §4) | orchestrates the v9 daemon (`serve`/`spawn`/`steer`) — an agent-ops surface, not `/vclaw`'s control-plane scope | the daemon contract |
| **`watch on\|off`** | PLANNED (spec §4) | contradicts *cheap by default* (rule 8) and needs a widget that a CLI does not have; the pane is the real consumer | a UI to render it |
| **`switch <profile>` / 2 agents on 1 host** | **not proposed** | credentials, JWT and the spool name `<tenant>__<self8>` are per-host singletons; this needs a spool-namespace design before a verb can exist | an identity-per-host decision (operator) |
| **`vclaw_<verb>` MCP tool surface** | deferred | the spec names a TOOL surface; the SDK's MCP server today exposes different tools (`roster`, `presence_status`, artifact/a2a tools), and no `vclaw_<verb>` bridge exists | a bridge design; not needed while the CLI+TUI cover the jobs |
| **Threads / surfacing `conversationId`** | deferred | the field is carried opaquely on every record and in `send`, so grouping can be added later with **no spool migration** | a consumer that wants it (pane UI) |
| **Unified same-owner + cross-owner inbox** | **never** (by canon) | V3.2 splits tiers by ownership: same-owner is Pears, the IDP must not read it. A merged view would be a lie about custody | — |
| **Durable consumer beyond C19** (JetStream consumer / queue) | deferred, **fabric-side** | the agent JWT is granted no consumer/ACK permission; C19's gateway-stored inbox is the granted path | a mint change + operator ruling |
| **`retire` / `export` / `import` inside `/vclaw`** | deferred | they exist as agent-CLI commands (`vclaw-agent retire|export|import`); moving them into the table is cosmetic until an operator script needs the `/vclaw` spelling | a script that needs it |
| **Legacy `/vchat-*` names as aliases** | **not built as claimed** | the spec says "aliases for one release"; they are separate implementations with their own handlers and the old `command_result` envelope — recorded as a doc-vs-code defect, decision pending | a migration decision |

### 2b · `/vclaw` support for `services/vclaw-idp-mcp` — planned, **excluded from this sprint**

**What the service is (measured 2026-11-01):** a **workstation-local, API-key-gated MCP broker for IDP
administration**, not a node service. `README.md` states the read tier is implemented — `initialize`, `tools/list`
and **seven read tools** (`idp_whoami`, `fleet_list`, `segment_list` / `segment_get` / `segment_agents`,
`budget_get`, `audit_events`, `isolation`); the socket broker, `relay`, `keys rotate`, step-up and **every write
tool are phase 2/3 and absent**. It talks outward to `vgate` over HTTPS; the only node-side change in its design is
an OIDC client registration for step-up.

**What `/vclaw` support would be** — a read-only namespace that maps those reads to the operator surface, so a
human can answer "who am I as an admin, what is in this segment, what is the spend, what happened" without a
second toolchain:

| planned verb | maps to | notes |
|---|---|---|
| `vclaw idp whoami` | `idp_whoami` | identity + scopes + segment + key id |
| `vclaw idp fleet` | `fleet_list` | the agents known to the IDP |
| `vclaw idp segments [<id>]` / `vclaw idp agents <segment>` | `segment_list` / `segment_get` / `segment_agents` | roster by segment |
| `vclaw idp budget` | `budget_get` | spend view (read-only) |
| `vclaw idp audit [--limit]` | `audit_events` | **redacted** by the service; a verb must not widen it |
| `vclaw idp isolation` | `isolation` | per-host isolation state |
| `vclaw status` line | — | `idp: reachable via MCP (read) / not configured` — never implies liveness it has not probed |

**The principal rule, stated because it decides the design:** the MCP broker authenticates a HUMAN with an
**operator API key**; `/vclaw` authenticates an **agent nkey**. These must not be conflated. `/vclaw idp …` may
exist only as an **operator-only, read-only** surface (explicit key, never the agent's credentials), or it becomes
an agent-side admin path — which would be a privilege escalation dressed as a feature. Every row above is read;
the write tier stays behind the service's own step-up, and `/vclaw` must not offer a way around it.

**Why it is excluded this sprint (operator instruction, 2026-11-01):** this build does not interface with
`services/vclaw-idp-mcp` yet. Beyond that: the service is workstation-local over a unix socket (a headless agent
host cannot reach it), its write half does not exist, and no consumer has asked for the reads.

**Unblocked by:** (a) the MCP read tier and its socket protocol frozen; (b) an operator decision that exposing
those reads through an agent-facing CLI is acceptable with an operator-only key; (c) a redaction review of every
field the verbs would print (the service already masks secrets — a verb must not re-expand them); (d) a design for
"what does a status line mean when the socket is on another machine".

## 3 · Do-not-build-without (features gated by a blocker)

- **Any model-bearing inbound path** (A2A injection, auto-reply) — blocked by **B1**: any same-tenant peer can write
  into the live model's turn today. Presence in the inbox is fine; execution is not.
- **The lifecycle UX** — blocked by **B4/B5**: a login series that ends on a dashboard which cannot count unread mail
  is worse than no series.
- **`/vclaw idp …` at all** — blocked by an operator decision and the principal rule in §2b: an agent-facing CLI must never gain the MCP broker's admin reads through the agent's own credentials. Read-only, operator key, and only after the write tier has its own step-up path.
- **`inbox --sync` as "durable"** — blocked by the **C19 deployment**: until `nats-init` creates the buckets and
  vgate ships, the endpoint answers **503** by design.

## 4 · How a row closes

Same rule as the estate: with a commit sha, a measured acceptance line, and the spec's `state` column updated in the
same commit. A PLANNED row is not a verb — invoking it returns exit `2`, which is a contract, not an accident.
