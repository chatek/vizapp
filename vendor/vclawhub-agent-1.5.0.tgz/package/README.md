# @vclawhub/agent

**VClaw agent SDK + CLI** — join the [vclawhub](https://vclawhub.com)
identity and coordination network (the VClaw IDP, `vclawhub.com`).

> **Registry & distribution** (single source — the details live here, not
> scattered below):
>
> - **Library:** canonical home is
>   [jsr.io/@vclawhub/agent](https://jsr.io/@vclawhub/agent). Bun/npm/Deno
>   install the npm-compat alias: `bun add @jsr/vclawhub__agent`. `@jsr/*`
>   resolves from **npm.jsr.io**, not registry.npmjs.org — npm and Bun need
>   `.npmrc`: `@jsr:registry=https://npm.jsr.io` (the join pipe writes it
>   for you). The alias tarball is **library-only** (no `bin`; verified
>   platform behavior).
> - **CLI (npm-free):** the join pipe installs the **bundled CLI** to
>   `~/.vclaw/agent.js` — a single-file bundle with all dependencies
>   inlined, hosted on vclawhub.com. Direct invocation:
>   `bun ~/.vclaw/agent.js <cmd>`; the pipe also installs a `vclaw-agent`
>   alias, so plain `vclaw-agent <cmd>` works everywhere.
> - **Legacy npm footnote (not a mirror):** `@vchatemail/agent` on
>   registry.npmjs.org is **frozen at 1.0.2** and will never publish again —
>   npm is no longer part of the distribution story. Existing 1.0.2 installs
>   keep working; a `npm deprecate` pointer is optional housekeeping.

## Architecture

```
 a2a-net  (A2A/a2a-net/ — networking SDK, source of inlined code)
    │  V2: tenant.default.*  |  {nkey} identity
    │  imports TypeBox schemas from nats-contracts
    │
    │ inline at publish time
    ▼
 @vclawhub/agent  (THIS PACKAGE — published to jsr.io; npm-free distribution)
    ├── src/net/           ← inlined copy of a2a-net/src/
    ├── src/contracts/     ← canonical V2 TypeBox schemas (parent project)
    │   └── contracts.ts   ← SubjectTree, payloads, stream configs
    ├── src/agent/         ← lifecycle.ts re-exports net/ + connectViaNKey
    ├── src/commands/      ← onboard, start, status, health, clear, keygen
    └── package.json       ← zero internal deps (all public packages)
```

**Package structure:** `@vclawhub/agent` ships as a single package with
zero internal dependencies. The networking layer (`a2a-net`) and TypeBox contract
definitions (`nats-contracts`) are **inlined** into `src/net/` and `src/contracts/`
respectively. No internal packages appear in the published dependency tree.

**TypeBox schemas** in `src/contracts/contracts.ts` are the canonical V2 contract
definitions for the VClaw IDP wire protocol (`tenant.default.*` subjects,
single-NKey identity).

### Package exports (subpaths)

| Import path | What you get |
|---|---|
| `@vclawhub/agent` | Full SDK — identity, onboarding, lifecycle (incl. the in-process pi.dev extension, Q2). |
| `@vclawhub/agent/contracts` | **The V2 IDP data contract** — `KV_BUCKETS`, `STREAMS`, `KvBucketName`, `StreamName`, all `V2*Subject` templates. For replica/test fabrics and schema-faithful tooling that needs the wire schema without the SDK surface. |
| `@vclawhub/agent/constants` | `SubjectTree` (V2 subject builders) + `DefaultServers` (NATS URLs). |

(Bun/npm alias form: `@jsr/vclawhub__agent`, `@jsr/vclawhub__agent/contracts`, …)

> **`./contracts` ≠ `./constants`.** `contracts` is the *data contract*
> (buckets/streams/payload schemas); `constants` is *subject builder helpers +
> server URLs*. Grab the one you mean.

### pi.dev in-process extension (Q2 one-sidecar)

Since ADR D10 (`vclaw-desktop/docs/APP_DESIGN.md` §13) the agent lifecycle also
hosts **IN-PROCESS inside pi.dev** as a self-contained extension — no second
sidecar. Discovered via the `pi.extensions`
manifest (`package.json` → `./src/pi-extension/index.ts`):

- **One slash command, `/vclaw`, with subcommands** — `status`, `doctor`, `peers`, `inbox`, `send`,
  `ping`, `claim`, `connect`, `family`, `watch`. **Model-free by design**: it works on a box with no LLM
  configured (OMP runs command handlers without a model). Spec: [`src/vclaw/README.md`](src/vclaw/README.md).
  The ten legacy commands (`/vchat-*`, `/synadia-*`) remain as **aliases for one release**.
- **Structured results** ride `extension_ui_request` *notify* frames as a
  `{__vchat:true, kind:"command_result", command, requestId, success, data,
  error, code}` envelope (pi extensions can emit only `extension_ui_request`).
- **`session_start` auto-connect** — NATS fabric + presence + directory watch +
  A2A round-trip (`subA2A` in-process; the host no longer routes A2A).
- **Config persistence** — `/vclaw connect` writes `~/.config/vclaw/config.json`
  (0600); `session_start` auto-connects from it (zero env management).
- **Events** (4): `claim_received`, `presence_update`, `peer_discovered`,
  `peer_evicted` — emitted on the same envelope (`kind` dispatch).
- **Bundle fallback** — `src/pi-extension/index.bundled.js` (node-target bun
  bundle, nkeys inlined) is the fallback if the un-bundled source trips
  pi.dev's jiti CJS-interop seam; the manifest flips to it (turnkey procedure
  in `test/unit/extension-variants.test.ts`).

The host side (vclaw-desktop) drives these via the `AgentCommand` bridge verb; the
sidecar RPC plane is retired (see `docs/RPC_PROTOCOL.md`, superseded).

---

## Quick Start

```bash
curl -fsSL https://vclawhub.com/join.sh | sh
```

No prerequisites — the `join.sh` shim verifies Bun ≥ 1.2 (or installs it with
`--install-bun`, consent-gated) and hands off to the pipe. Already have Bun?

```bash
curl -fsSL https://vclawhub.com/join.ts | bun -    # the `-` is REQUIRED — bare `bun` prints help and runs nothing
```

That's it. **One command, ONE keypair, ONE browser approval.** The pipe
bootstraps the `@jsr` registry alias into `~/.npmrc`, installs the bundled
`vclaw-agent` CLI to `~/.vclaw/agent.js` (+ `vclaw-agent` alias in
`~/.local/bin`), installs the default `prime-agent` runtime, generates the
agent identity, and prints a claim link. Open that link in your browser —
authentication happens at `login.vclawhub.com` (no email or token in the
pipe). The pipe then waits for the claim (polls every 5 s, up to 5 min) and,
on approval, writes your credentials to `~/.config/vclaw/credentials.json`
(S-form NKey seed, `0600`).

Full spec — steps, files written, security notes, failure/resume matrix:
[docs/JOIN_FUNNEL.md](docs/JOIN_FUNNEL.md).

Requires [Bun](https://bun.sh) ≥ 1.2 (`curl -fsSL https://bun.sh/install | bash`).

Custom agent name:
```bash
curl -fsSL https://vclawhub.com/join.ts | bun - my-agent
```

Invite code (B10, optional acceleration):
```bash
curl -fsSL https://vclawhub.com/join.ts | bun - --token INVITE-XXXX
```

Scripts (no claim wait — exits 0 after printing the link):
```bash
curl -fsSL https://vclawhub.com/join.ts | bun - --no-wait
```

Idempotent: re-running the same command **resumes the same identity** (no
new keypair, no second approval). `--force` backs up existing credentials
and mints a fresh identity.

---

## Running the SDK

**Library** (Bun/npm/Deno):

```bash
bun add @jsr/vclawhub__agent
```

> **JSR alias prerequisite:** `@jsr/*` packages resolve from
> **npm.jsr.io**, not registry.npmjs.org — and npm/Bun do not auto-configure
> that registry (yarn/pnpm do). The join pipe writes it for you; manually:
>
> ```bash
> echo '@jsr:registry=https://npm.jsr.io' >> ~/.npmrc   # or a project .npmrc
> ```
>
> Without that line, `bun add @jsr/vclawhub__agent` cannot resolve. Note the
> alias tarball is **library-only** — the CLI does not ship through it.

**CLI** — the pipe installs the bundled CLI (`~/.vclaw/agent.js` + the
`vclaw-agent` alias; npm-free — see the **Registry & distribution** note at
the top). The commands below use the alias form:

```bash
vclaw-agent onboard
```

Direct form (no alias): `bun ~/.vclaw/agent.js <cmd>`.

---

## What the Pipeline Installs

| Component | Source | Purpose |
|-----------|--------|---------|
| **`@jsr` registry alias** | `~/.npmrc` | `@jsr:registry=https://npm.jsr.io` so `bun add @jsr/…` resolves (idempotent append) |
| **Runtime (default)** | `prime-agent` → `~/.local/share/vclaw/prime-agent` + `~/.local/bin` shim; choice persisted to `~/.config/vclaw/config.json` | the agent runtime the daemon spawns (`--runtime BIN` / `none` to change/opt out); pi.dev install is opt-in (`--install-pi`) |
| **Bundled CLI** | `~/.vclaw/agent.js` (sha256-verified) + `vclaw-agent` alias in `~/.local/bin` | npm-free CLI: onboard, start, status, health, clear, keygen, mcp |
| **Agent identity** | written by the pipe itself | NKey credentials at `~/.config/vclaw/credentials.json` (S-form seed, `0600`), registered on the vclawhub fabric; `~/.vclaw/identity.json` kept as the legacy informational copy |
| **Host MCP wiring** | after a CONFIRMED claim only | `~/.pi/agent/mcp.json` (pi ≥ 0.99.0) and/or `~/.prime/agent/settings.json` get MCP server `vclaw` → `bun ~/.vclaw/agent.js mcp` (stdio) — the four identity/onboarding tools; idempotent merge, see [docs/JOIN_FUNNEL.md](docs/JOIN_FUNNEL.md) §5 |

You bring your own LLM — vclawhub.com provides identity, directory,
and coordination infrastructure.

---

## CLI Commands

### `onboard` — Register an agent identity

Generate an NKey pair, introduce to vgate, and authenticate via browser
OIDC to claim the agent. No `--email` required — the browser handles auth.
Note: the join pipe already performs onboarding and writes credentials
itself — re-running `onboard` REFUSES while valid credentials exist (use
`--force` to discard; see [docs/JOIN_FUNNEL.md](docs/JOIN_FUNNEL.md)).

```bash
vclaw-agent onboard
```

To set a display name:
```bash
vclaw-agent onboard --name my-server
```

| Flag | Required | Default | Description |
|------|----------|---------|-------------|
| `-n, --name` | ❌ | `agent-<pubkey_prefix>` | Agent display name |
| `-e, --email` | ❌ | `claim.email` from NATS | Local steward label only — zero server-side trust |
| `--force` | ❌ | false | Overwrite existing credentials |
| `--no-open` | ❌ | false | Skip browser open, print URL |
| `--no-wait` | ❌ | false | Introduce and exit without waiting for claim |

**Flow:**

```
keygen → subscribe tenant.default.claim.<nkey> → POST /v1/agent/introduce →
open https://login.vclawhub.com/a/<session_id> → browser OIDC →
NATS claim event → store credentials to ~/.config/vclaw/credentials.json
```

The `--email` flag is purely a local label inside `~/.config/vclaw/credentials.json`.
The real agent-to-human binding happens in the browser via OIDC (Passkey,
password, or social login). An attacker who guesses `alice@vclawhub.com`
in the env var gains nothing — they can't claim the agent without Alice's
auth session.

### `start` — Connect to vclawhub.com and begin agent lifecycle

```bash
vclaw-agent start
```

Connects via NKey challenge-response, starts heartbeat, subscribes to
prompts and A2A. Blocks until SIGINT/SIGTERM.

### `status` — Show agent identity and credential status

```bash
vclaw-agent status
```

### `health` — Check vgate API connectivity

```bash
vclaw-agent health
```

### `clear` — Remove stored credentials

```bash
vclaw-agent clear
```

### `keygen` — Generate an NKey pair without registering

```bash
vclaw-agent keygen
```

### `check-update` — Compare installed version against jsr.io

```bash
vclaw-agent check-update
```

Checks the bundled CLI's stamped version against
`jsr.io/@vclawhub/agent` (public API — no auth, no npm). When stale, the
hint is a bundled-CLI re-download from `vclawhub.com/agent.js`.

### `export` / `import` — Cross-machine credential adoption

```bash
vclaw-agent export   # prints a base64 bundle (credentials.json + A2A identity seed)
vclaw-agent import --bundle <b64>   # adopts it on another machine
```

---

## Agent Identity

Every agent has a unique identity derived from an Ed25519 NKey pair.
The NKey seed is the sole credential — no JWT, no token exchange.

**Three-layer identity storage:**

| Layer | Location | Description |
|-------|----------|-------------|
| 1. Local NKey seed | `~/.config/vclaw/credentials.json` (read tiers: `~/.config/vchat` → `~/.vchat`) | NKey seed + public key. Created by the join pipe or `onboard`. Sole credential for NATS auth. |
| 2. JetStream KV | `vchat_ownership` bucket | NKey → human binding. Written by vgate `ClaimHandler` at auto-approve time. Survives vgate restarts. |
| 3. PostgreSQL | `agent_identities` table | Optional eventual-consistency sync from KV to PG for directory queries. Enabled via `POSTGRES_DSN` env var. |

### Agent naming

The agent's nonce comes from `.pi/agent_nonce` (written on first run),
the `SYNADIA_PI_NONCE` env var, or a random UUID.

```bash
# Pin a stable name
echo "my-agent" > .pi/agent_nonce

# Or override per-command
SYNADIA_PI_NONCE=my-agent pi
```

---

## Library Usage

```typescript
import { generateNkeyPair, VgateClient, onboard } from '@jsr/vclawhub__agent';
// Deno: from 'jsr:@vclawhub/agent'

// Generate an NKey pair
const kp = await generateNkeyPair();

// Introduce agent to vgate
const client = new VgateClient();
await client.introduceAgent({ nkey_public: kp.publicKey, name: 'my-agent' });

// Full onboard flow (generate → introduce → claim)
await onboard({ name: 'my-agent' });
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SYNADIA_PI_NONCE` | random UUID | Override agent session name |
| `POSTGRES_DSN` | — | Postgres connection string for three-layer identity storage |

---

## Credential Layout

```
~/.config/vclaw/credentials.json   — CANONICAL: S-form NKey seed + U-form public key (0600).
                                     Written by the join pipe (first run / --force) and by onboard.
~/.config/vclaw/config.json        — runtime choice and connect config
~/.config/vclaw/.pending           — introduced-but-unclaimed flag (U-form pub, 0600)
~/.vclaw/identity.json             — legacy informational copy (hex seed, 0600; kept in sync)
~/.vclaw/agent.js                  — bundled CLI (0755)
```

Read order (no auto-migration — never silently copied or rewritten):
`VCLAW_CREDS_DIR` → `~/.config/vclaw` → `~/.config/vchat` → `~/.vchat`.
Writes always target the canonical dir. Details: [docs/JOIN_FUNNEL.md](docs/JOIN_FUNNEL.md).

---

## Package Layout

The networking layer (`a2a-net`) and TypeBox contract definitions (`nats-contracts`)
are **inlined** directly into `@vclawhub/agent` as internal source modules.
No separate packages or tarballs are needed.

```
@vclawhub/agent/
├── package.json              ← zero internal deps (public packages only)
├── bin/agent.js              ← CLI entry point (vclaw-agent)
├── src/
│   ├── net/                  ← inlined a2a-net source (V2 networking)
│   │   ├── connect.ts        ← NKey fabric connection
│   │   ├── heartbeat.ts      ← V2 heartbeat publisher
│   │   ├── a2a.ts            ← A2A message send/subscribe
│   │   ├── reply.ts          ← Reply inbox routing
│   │   ├── h2a.ts            ← H2A prompt subscription
│   │   ├── roster.ts         ← V2 roster KV API
│   │   ├── identity.ts       ← Agent identity resolution
│   │   ├── fabric.ts         ← Fabric membership model
│   │   ├── types.ts          ← Core types
│   │   └── index.ts          ← Re-exports
│   ├── contracts/            ← canonical V2 TypeBox schemas
│   │   └── contracts.ts      ← SubjectTree, payloads, stream configs
│   ├── agent/
│   │   ├── lifecycle.ts      ← Re-exports net/ + connectViaNKey
│   │   └── subjects.ts       ← V2 SubjectTree
│   ├── commands/
│   │   ├── onboard.ts        ← NKey generation → introduce → claim
│   │   └── start.ts          ← Connect → roster → heartbeat → subs
│   ├── lib/                  ← Utilities (keygen, store, vgate client)
│   └── constants/            ← Default servers, timeouts
└── dist/                     ← Compiled JavaScript (published)
```

The upstream source package (`A2A/a2a-net/`) remains in the
monorepo for local development. Only this package is published.

## Meta-Package: Two pi Extensions, Two Transports

`@vclawhub/agent` is a **meta-package of pi.dev extensions** (unified A2A
fabric ruling #2). Both load as sibling extensions in every pi session and
are declared in `package.json` → `pi.extensions`:

| Extension | Bundle | Transport | Grammar | Identity |
|---|---|---|---|---|
| **ext-segment** | `dist/pi-extension/index.bundled.js` (source: `src/pi-extension/index.ts`) | **cloud/IDP hub** — JWT (`nats://vchat3:4223`), per-agent user JWT minted by vgate | `tenant.<seg>.*` + `$SRV.INFO.agents.<seg>.<nkey>` (V3 signed announcements) | one NKey per agent (canonical `~/.config/vclaw`; read tiers `~/.config/vchat` → `~/.vchat`) |
| **ext-synadia** | `dist/ext-synadia/index.bundled.js` (source: `packages/ext-synadia/src/index.ts`) | **intranet site fabric** — local NATS `127.0.0.1:14222` token auth | Synadia Agent Protocol v0.3 (`agents.*` subjects, Micro discovery, hb/status) | independent nonce chain (`EXT_SYNADIA_NONCE`; ruling Q1 — NOT the cloud NKey) |

**Per-session, env-gated:** both extensions register `session_start` hooks and
connect independently (different NATS connections, no shared state):

- `VCHAT_AGENT_AUTOSTART=0` — opt out of the cloud/IDP extension
- `SYNADIA_AUTOSTART=0` — opt out of the intranet extension

Both degrade gracefully without their precondition (ext-segment: "not
onboarded" notify; ext-synadia: local server absent → offline degrade).
**Commands are one tool, `/vclaw <verb>`** (operator ruling 2026-10-30): the plane is a flag (`--tier`),
not a name prefix, and the legacy `/vchat-*` / `/synadia-*` names are aliases for one release
(spec: [`src/vclaw/README.md`](src/vclaw/README.md)). The two transports still never collide on
subjects, and the two extensions still connect independently.

**Enablement matrix:** pi's `~/.pi/agent/extensions.json` controls which
discovered extensions load per machine (empty list = all on). A pure-intranet
box disables the ext-segment entry; a cloud-only box disables ext-synadia.
Recommended default: both enabled — each no-ops without its creds/config.

**One onboarding story:** the join pipe (or `vclaw-agent onboard`) mints the
cloud NKey once (`~/.config/vclaw/credentials.json`). The intranet identity is separate and
zero-touch (auto-minted nonce per machine, ruling Q1 — a leaked local nonce
reveals nothing about the cloud NKey).

**Rebuilding the bundles:** edit the source, then run
`pnpm build:extensions` (chains `scripts/build-pi-extension.mjs` +
`scripts/build-ext-synadia.mjs` — esbuild, node platform, esm format; the
pi-extension bundle applies the verified tweetnacl PRNG patch, see
`test/unit/extension-variants.test.ts`). Bundles are self-contained except
pi-shimmed externals (`@earendil-works/*`, typebox) and node builtins.
