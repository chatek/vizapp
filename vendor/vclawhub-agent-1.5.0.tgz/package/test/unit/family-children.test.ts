/**
 * family-children.test.ts — v9 W3 children[] mirror reader.
 *
 * Covers UPGRADE.md §6 W3's data path: worker state on disk (daemon family
 * dir, single-writer) → FamilyChildEntry[] for the lead announcement. Verify:
 * deterministic sorted output · role→caps mapping · lowercase state tokens ·
 * crash-safe (corrupt files skipped, missing dirs/roles → []/empty caps).
 */
import { describe, it, expect, afterEach } from "vitest";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  familyChildrenFromDir,
  familyStateToken,
  writeJsonAtomic,
  RUNNING,
  IDLE,
  INACTIVE,
} from "../../src/daemon/index.js";

const dirs: string[] = [];
async function tmpFamily(): Promise<string> {
  const d = await mkdtemp(join(tmpdir(), "family-children-"));
  dirs.push(d);
  return d;
}
afterEach(async () => {
  await Promise.all(dirs.splice(0).map((d) => rm(d, { recursive: true, force: true })));
});

function workerJson(name: string, state: string, role?: string): Record<string, unknown> {
  return {
    name,
    state,
    ...(role ? { role } : {}),
    sessionFile: `sessions/${name}.jsonl`,
  };
}

describe("familyChildrenFromDir (W3 children mirror)", () => {
  it("maps workers + role specs → sorted FamilyChildEntry[] with lowercase state tokens", async () => {
    const dir = await tmpFamily();
    await writeJsonAtomic(join(dir, "workers", "researcher-a.json"), workerJson("researcher-a", RUNNING, "researcher"));
    await writeJsonAtomic(join(dir, "workers", "reviewer-b.json"), workerJson("reviewer-b", IDLE, "reviewer"));
    await writeJsonAtomic(join(dir, "workers", "anon.json"), workerJson("anon", INACTIVE));
    await writeJsonAtomic(join(dir, "roles", "researcher.json"), { role: "researcher", capabilities: ["code", "search"] });
    await writeJsonAtomic(join(dir, "roles", "reviewer.json"), { role: "reviewer" });

    const kids = await familyChildrenFromDir(dir);
    expect(kids.map((k) => k.name)).toEqual(["anon", "researcher-a", "reviewer-b"]);
    expect(kids[0]).toEqual({ name: "anon", role: "", caps: [], state: "inactive" });
    expect(kids[1]).toEqual({ name: "researcher-a", role: "researcher", caps: ["code", "search"], state: "running" });
    // role spec without capabilities → empty caps (never undefined on the wire)
    expect(kids[2]).toEqual({ name: "reviewer-b", role: "reviewer", caps: [], state: "idle" });
  });

  it("skips corrupt worker files and yields [] for a missing family dir", async () => {
    const dir = await tmpFamily();
    await writeJsonAtomic(join(dir, "workers", "ok.json"), workerJson("ok", IDLE, "code"));
    // corrupt file written raw (writeJsonAtomic would never emit this)
    const { writeFile } = await import("node:fs/promises");
    await writeFile(join(dir, "workers", "corrupt.json"), "{not json{{{", "utf8");
    await writeJsonAtomic(join(dir, "roles", "code.json"), { role: "code", capabilities: ["code"] });

    const kids = await familyChildrenFromDir(dir);
    expect(kids.map((k) => k.name)).toEqual(["ok"]);
    expect(kids[0]!.caps).toEqual(["code"]);

    const empty = await tmpFamily();
    expect(await familyChildrenFromDir(empty)).toEqual([]);
  });

  it("falls back to the file name when a worker record is missing its name", async () => {
    const dir = await tmpFamily();
    await writeJsonAtomic(join(dir, "workers", "nameless.json"), { state: RUNNING, sessionFile: "sessions/nameless.jsonl" });
    const kids = await familyChildrenFromDir(dir);
    expect(kids).toEqual([{ name: "nameless", role: "", caps: [], state: "running" }]);
  });
});

describe("familyStateToken (WorkerState → announcement vocabulary)", () => {
  it("maps all three lifecycle states to the fixture-lockstep lowercase tokens", () => {
    expect(familyStateToken(RUNNING)).toBe("running");
    expect(familyStateToken(IDLE)).toBe("idle");
    expect(familyStateToken(INACTIVE)).toBe("inactive");
  });
});
