/**
 * BUILD lane B — ext-segment upgrade tests (additive).
 *
 * Covers the three deliverables (mock fs / mock pi — same discipline as
 * extension-commands.test.ts):
 *   B1: H2A wiring — inbound prompt on SubjectTree.PROMPT subject → ack chunk
 *       published immediately to reply_to + sendUserMessage injection; the
 *       reply subject is served by turn_end (response chunk + EOF terminator).
 *   B2: JWT refresh timer — provider closure returns the LATEST token after
 *       a refresh cycle (fake timers); failure path forces reconnect events.
 *   B3: config read-order (Q4) — new dir first, old dir fallback; writes to
 *       the NEW dir only; pending-flag checks both dirs.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { mkdtemp, writeFile, mkdir, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { existsSync } from "node:fs";

// ── B3: real fs (temp dirs), no mocks — the store is plain fs code ──────────
// VCHAT_CREDS_DIR single-dir override keeps legacy semantics; the two-dir
// read-order needs BOTH dirs pointed at temp roots, so we monkey-patch
// homedir via process.env before importing the module fresh.

// ── B1/B2 mocks (pi-extension harness) ──────────────────────────────────────
const mocks = vi.hoisted(() => ({
  loadCredentials: vi.fn(),
  hasPendingFlag: vi.fn(),
  readConfig: vi.fn(),
  saveConfig: vi.fn(),
  fetchNatsUserJWT: vi.fn(),
  connectViaJWT: vi.fn(),
  startPresence: vi.fn(),
  subA2A: vi.fn(),
  watchDirectory: vi.fn(),
  setTenantSegment: vi.fn(),
}));

vi.mock("../../src/lib/store.js", () => ({
  loadCredentials: mocks.loadCredentials,
  hasPendingFlag: mocks.hasPendingFlag,
  readConfig: mocks.readConfig,
  saveConfig: mocks.saveConfig,
}));
vi.mock("../../src/agent/lifecycle.js", () => ({
  fetchNatsUserJWT: mocks.fetchNatsUserJWT,
  connectViaJWT: mocks.connectViaJWT,
  startPresence: mocks.startPresence,
  subA2A: mocks.subA2A,
}));
vi.mock("../../src/net/directory.js", () => ({
  watchDirectory: mocks.watchDirectory,
}));
// Phase 1 (conversation identity): the extension now also uses the H2A prompt
// schema, so the partial mock must carry it — the REAL schema (via
// importOriginal), never a hand-copied stub, so the validator under test is the
// shipped one. Everything else stays mocked exactly as before.
vi.mock("../../src/contracts/contracts.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../src/contracts/contracts.js")>();
  return {
    H2aPromptPayload: actual.H2aPromptPayload,
    setTenantSegment: mocks.setTenantSegment,
  };
});
vi.mock("../../src/agent/subjects.js", () => ({
  SubjectTree: {
    CLAIM: () => "tenant.vchat.claim.FAKE_NKEY",
    PROMPT: (nkey: string) => `tenant.vchat.user.${nkey}.agent.${nkey}.prompt.>`,
  },
}));

const CREDS = {
  seed: "SUATESTSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEED",
  public_key: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  agent_nkey: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  name: "test-agent",
  steward: "tester@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
} as const;

interface FakeSub {
  subject: string;
  queue?: string;
  callback: ((err: unknown, msg: unknown) => void) | null;
  unsubscribe: () => void;
}

/** Fake NatsConnection capturing subscriptions with callback wiring. */
function fakeNc() {
  const subs: FakeSub[] = [];
  const published: Array<{ subject: string; data: string | null }> = [];
  const nc = {
    subscribe: vi.fn((subject: string, opts?: { queue?: string; callback?: (e: unknown, m: unknown) => void }) => {
      const sub: FakeSub = { subject, queue: opts?.queue, callback: opts?.callback ?? null, unsubscribe() {} };
      subs.push(sub);
      // Minimal async-iterator shape for claim loop (unused here).
      return Object.assign(sub, {
        [Symbol.asyncIterator]() {
          return { next: async () => ({ done: true as const, value: undefined }) };
        },
      });
    }),
    publish: vi.fn((subject: string, data?: Uint8Array) => {
      published.push({
        subject,
        data: data && data.length > 0 ? new TextDecoder().decode(data) : null,
      });
    }),
    drain: vi.fn(async () => {}),
    close: vi.fn(() => {}),
  };
  return { nc, subs, published };
}

let factory: (pi: unknown) => void;

async function freshFactory() {
  vi.resetModules();
  factory = (await import("../../src/pi-extension/index.ts")).default;
}

function harness() {
  const commands = new Map<string, (args: string, ctx: unknown) => Promise<void>>();
  const handlers = new Map<string, (...a: unknown[]) => unknown>();
  const pi = {
    on: vi.fn((name: string, fn: (...a: unknown[]) => unknown) => handlers.set(name, fn)),
    registerCommand: vi.fn((name: string, spec: { handler: (a: string, c: unknown) => Promise<void> }) =>
      commands.set(name, spec.handler),
    ),
    sendUserMessage: vi.fn(),
  };
  factory(pi);
  return { commands, handlers, pi };
}

function stubRuntimeSuccess() {
  mocks.fetchNatsUserJWT.mockResolvedValue("JWT-xxx");
  mocks.startPresence.mockReturnValue({ stop: async () => {} });
  mocks.subA2A.mockReturnValue(undefined);
  mocks.watchDirectory.mockReturnValue({ directory: { snapshot: () => [] }, stop: () => {} });
}

beforeEach(async () => {
  vi.clearAllMocks();
  await freshFactory();
});

afterEach(() => {
  vi.useRealTimers();
});

// ── B1: H2A wiring ───────────────────────────────────────────────────────────
describe("B1: H2A prompt injection + turn_end reply (§6 chunks)", () => {
  it("subscribes the prompt subject with queue group 'agents'", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { nc } = fakeNc();
    mocks.connectViaJWT.mockResolvedValue(nc as never);
    const { commands } = harness();

    const ctx = { hasUI: true, ui: { notify() {} } };
    await commands.get("vchat-connect")!("", ctx);

    const promptSub = nc.subscribe.mock.calls.find((c: unknown[]) =>
      String(c[0]).includes(".prompt.>")
    );
    expect(promptSub).toBeTruthy();
    expect((promptSub![1] as { queue?: string }).queue).toBe("agents");
  });

  it("inbound prompt → ack chunk + sendUserMessage injection; turn_end → response chunk + EOF", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { nc, published } = fakeNc();
    mocks.connectViaJWT.mockResolvedValue(nc as never);
    const { commands, handlers, pi } = harness();

    const ctx = { hasUI: true, ui: { notify() {} } };
    await commands.get("vchat-connect")!("", ctx);

    const promptSub = nc.subscribe.mock.calls.find((c: unknown[]) =>
      String(c[0]).includes(".prompt.>")
    ) as unknown as [string, { queue?: string; callback?: (e: unknown, m: unknown) => void }];
    expect(promptSub).toBeTruthy();

    const replyTo = "tenant.vchat.user.X.agent.X.prompt.replies.abc123";
    const payload = JSON.stringify({
      messages: [{ role: "user", content: "what is the answer?" }],
      reply_to: replyTo,
    });
    // The subscription is the WILDCARD `...prompt.>`; a real frame therefore
    // arrives on the CONCRETE endpoint the producer publishes to — `.req`
    // (promptRequestSubject, src/net/h2a.ts:41; a bare `...prompt` publish does
    // not match `>`). A frame with no subject cannot be routed, so the
    // extension refuses it early (src/pi-extension/index.ts:442) — the fixture
    // must carry the delivered subject, not just a payload.
    expect(promptSub[0]).toBe(
      `tenant.vchat.user.${CREDS.agent_nkey}.agent.${CREDS.agent_nkey}.prompt.>`,
    );
    const inboundSubject = promptSub[0].replace(/\.>$/, ".req");
    // Simulate the inbound NATS message (callback form).
    promptSub[1].callback!(null, {
      subject: inboundSubject,
      data: new TextEncoder().encode(payload),
      reply: "",
    });

    // Injection happened with the extracted user text.
    expect(pi.sendUserMessage).toHaveBeenCalledTimes(1);
    expect(String((pi.sendUserMessage as ReturnType<typeof vi.fn>).mock.calls[0][0])).toContain("what is the answer?");
    // Ack chunk published to reply_to immediately.
    expect(published.some((p) => p.subject === replyTo && p.data?.includes('"status"') && p.data.includes("ack"))).toBe(true);

    // Fire turn_end — response chunk + EOF terminator.
    await handlers.get("turn_end")!({ message: { content: [{ type: "text", text: "42" }] } }, {});
    const replyChunks = published.filter((p) => p.subject === replyTo);
    const respChunk = replyChunks.find((p) => p.data?.includes('"response"'));
    const eof = replyChunks.find((p) => p.data === null);
    expect(respChunk).toBeTruthy();
    expect(respChunk!.data).toContain("42");
    expect(eof).toBeTruthy();
  });

  it("prompt without reply_to is dropped with a warning (no injection, no publish)", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { nc, published } = fakeNc();
    mocks.connectViaJWT.mockResolvedValue(nc as never);
    const { commands, pi } = harness();
    const ctx = { hasUI: true, ui: { notify() {} } };
    await commands.get("vchat-connect")!("", ctx);

    const promptSub = nc.subscribe.mock.calls.find((c: unknown[]) =>
      String(c[0]).includes(".prompt.>")
    ) as unknown as [string, { callback?: (e: unknown, m: unknown) => void }];
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    promptSub[1].callback!(null, {
      // Same real endpoint as the test above: without a subject the frame is
      // refused before the missing-reply_to warning is ever reached.
      subject: promptSub[0].replace(/\.>$/, ".req"),
      data: new TextEncoder().encode(JSON.stringify({ messages: [] })),
      reply: "",
    });
    expect(pi.sendUserMessage).not.toHaveBeenCalled();
    expect(published).toHaveLength(0);
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });
});

// ── B2: JWT refresh timer ────────────────────────────────────────────────────
describe("B2: JWT refresh (50min cycle, provider returns latest)", () => {
  it("connectViaJWT receives a provider closure; after a refresh the closure returns the NEW token", async () => {
    vi.useFakeTimers();
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { nc } = fakeNc();
    mocks.connectViaJWT.mockResolvedValue(nc as never);
    let tokenSeq = 0;
    mocks.fetchNatsUserJWT.mockImplementation(async () => `JWT-${++tokenSeq}`);

    const { commands } = harness();
    const ctx = { hasUI: true, ui: { notify() {} } };
    await commands.get("vchat-connect")!("", ctx);

    // Provider closure captured.
    const provider = (mocks.connectViaJWT as ReturnType<typeof vi.fn>).mock.calls[0][1] as () => string;
    expect(typeof provider).toBe("function");
    expect(provider()).toBe("JWT-1");

    // 50min pass → refresh cycle runs → closure now returns the new token.
    await vi.advanceTimersByTimeAsync(50 * 60 * 1000 + 1000);
    expect(mocks.fetchNatsUserJWT).toHaveBeenCalledTimes(2);
    expect(provider()).toBe("JWT-2");
  });

  it("refresh failure retries at +5min, then forces reconnect (drain+close) on second failure", async () => {
    vi.useFakeTimers();
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { nc } = fakeNc();
    mocks.connectViaJWT.mockResolvedValue(nc as never);
    let calls = 0;
    mocks.fetchNatsUserJWT
      .mockImplementationOnce(async () => "JWT-initial")
      .mockImplementation(async () => { calls++; throw new Error("vgate down"); });

    const { commands } = harness();
    const ctx = { hasUI: true, ui: { notify() {} } };
    await commands.get("vchat-connect")!("", ctx);

    await vi.advanceTimersByTimeAsync(50 * 60 * 1000 + 1000); // first tick fails
    expect(nc.drain).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(5 * 60 * 1000 + 1000); // retry fails → reconnect
    expect(nc.drain).toHaveBeenCalled();
    expect(nc.close).toHaveBeenCalled();
  });
});

// ── B3: config read-order (real fs, temp dirs) ───────────────────────────────
describe("B3: Q4 config read-order (old ~/.vchat → new ~/.config/vchat; write new)", () => {
  let homeDir: string;
  let oldDir: string;
  let newDir: string;
  // REAL seed (the real store validates via nkeys.fromSeed — the CREDS fake
  // from the B1/B2 harness would be rejected as invalid, returning null).
  let realCreds: { seed: string; public_key: string; name: string; steward: string };

  beforeEach(async () => {
    const { nkeys } = await import("@nats-io/nats-core");
    const kp = nkeys.createUser();
    realCreds = {
      seed: new TextDecoder().decode(kp.getSeed()),
      public_key: kp.getPublicKey(),
      name: "b3-agent",
      steward: "b3@vchat.email",
    };
    homeDir = await mkdtemp(join(tmpdir(), "vchat-b3-"));
    oldDir = join(homeDir, ".vchat");
    newDir = join(homeDir, ".config", "vclaw");
    await mkdir(oldDir, { recursive: true });
    process.env.VCHAT_CREDS_DIR = ""; // clear any inherited override
    // Point HOME at the temp root — store.ts uses homedir() at module load.
    process.env.HOME = homeDir;
    vi.resetModules();
  });

  afterEach(async () => {
    delete process.env.VCHAT_CREDS_DIR;
    await rm(homeDir, { recursive: true, force: true });
  });

  async function freshStore() {
    // importActual: bypass the file-global store mock (B1/B2 harness) so B3
    // exercises the REAL fs code against temp dirs.
    return await vi.importActual<typeof import("../../src/lib/store.js")>("../../src/lib/store.js");
  }

  it("reads NEW dir first when both exist", async () => {
    await mkdir(newDir, { recursive: true });
    await writeFile(join(newDir, "credentials.json"), JSON.stringify(realCreds));
    await writeFile(join(oldDir, "credentials.json"), JSON.stringify({ ...realCreds, name: "stale-old-agent" }));
    const store = await freshStore();
    const creds = await store.loadCredentials();
    expect(creds?.name).toBe("b3-agent"); // new dir wins
  });

  it("falls back to OLD dir when new dir has no creds", async () => {
    await writeFile(join(oldDir, "credentials.json"), JSON.stringify({ ...realCreds, name: "legacy-agent" }));
    const store = await freshStore();
    const creds = await store.loadCredentials();
    expect(creds?.name).toBe("legacy-agent");
  });

  it("reads config from old dir when new lacks it; saveConfig writes NEW", async () => {
    await writeFile(join(oldDir, "config.json"), JSON.stringify({ segment: "legacy-seg" }));
    const store = await freshStore();
    const cfg = await store.readConfig();
    expect(cfg?.segment).toBe("legacy-seg");

    await store.saveConfig({ segment: "fresh-seg" });
    expect(existsSync(join(newDir, "config.json"))).toBe(true);
    expect(existsSync(join(oldDir, "config.json"))).toBe(true); // old untouched
    const fresh = JSON.parse(await readFile(join(newDir, "config.json"), "utf-8"));
    expect(fresh.segment).toBe("fresh-seg");
  });

  it("saveCredentials writes to NEW dir only", async () => {
    const store = await freshStore();
    await store.saveCredentials(realCreds as never);
    expect(existsSync(join(newDir, "credentials.json"))).toBe(true);
    expect(existsSync(join(oldDir, "credentials.json"))).toBe(false);
  });

  it("hasPendingFlag sees the OLD dir flag too (migration window)", async () => {
    await writeFile(join(oldDir, ".pending"), "UAATESTPUBLICPUBLIC");
    const store = await freshStore();
    expect(store.hasPendingFlag()).toBe(true);
    // clearPendingFlag clears both.
    await store.clearPendingFlag();
    expect(store.hasPendingFlag()).toBe(false);
  });
});
