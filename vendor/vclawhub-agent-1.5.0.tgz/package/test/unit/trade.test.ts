/**
 * trade.test.ts — J6a commerce-contract surface verification.
 *
 * Covers the J6a commerce-contract surface that remains in the SDK after the
 * 2026-10-24 wallet-plane removal (agents are DENIED rpc.wallet — vgate
 * token.go; the human-plane server is kevproxy/vpay):
 *  (1) Trade offer/commit/settle request + response + error schemas (the
 *      payloads on V3TradeSubject subjects).
 *  (2) EscrowContract state machine: states, legal/illegal transitions
 *      (ESCROW_TRANSITIONS / canTransitionEscrow), CAS revision field, sig
 *      fields, additionalProperties:false.
 *  (3) canonicalTradeBytes cross-encoder parity lock (the 6 TRADE_FIELD_ORDER
 *      fields are the Go mirror's signedTerms — locks the schema seam).
 *  (4) schema validation: valid + invalid cases per op + state transition.
 */
import { describe, it, expect } from "vitest";
import { Value } from "@sinclair/typebox/value";
import {
  TradeOfferRequest,
  TradeCommitRequest,
  TradeSettleRequest,
  TradeRequest,
  TradeOfferResponse,
  TradeCommitResponse,
  TradeSettleResponse,
  TradeResponse,
  TradeError,
  EscrowState,
  EscrowContract,
  ESCROW_TRANSITIONS,
  canTransitionEscrow,
  escrowKey,
  canonicalTradeBytes,
  TRADE_FIELD_ORDER,
} from "../../src/contracts/contracts.js";

// ── (1) Trade request schemas (offer/commit/settle) ────────────
describe("TradeRequest (offer/commit/settle discriminated union)", () => {
  const validOffer = {
    verb: "offer", conversation_id: "c-1", offerer_nkey: "UA1",
    amount: "10.00", budget_cap_ref: "cap-100", offer_sig: "sigA", ts: "2026-08-06T00:00:00.000Z",
  };
  const validCommit = {
    verb: "commit", conversation_id: "c-1", offerer_nkey: "UA1", committer_nkey: "UA2",
    offer_sig: "sigA", commit_sig: "sigB", amount: "10.00", budget_cap_ref: "cap-100",
    escrow_id: "vchat_escrow.c-1", ts: "2026-08-06T00:00:00.000Z",
  };
  const validSettle = {
    verb: "settle", conversation_id: "c-1", offerer_nkey: "UA1", committer_nkey: "UA2",
    offer_sig: "sigA", commit_sig: "sigB", amount: "10.00", budget_cap_ref: "cap-100",
    escrow_id: "vchat_escrow.c-1", ts: "2026-08-06T00:00:00.000Z",
  };

  it("accepts valid offer/commit/settle (each + the union)", () => {
    expect(Value.Check(TradeOfferRequest, validOffer)).toBe(true);
    expect(Value.Check(TradeCommitRequest, validCommit)).toBe(true);
    expect(Value.Check(TradeSettleRequest, validSettle)).toBe(true);
    for (const v of [validOffer, validCommit, validSettle]) {
      expect(Value.Check(TradeRequest, v)).toBe(true);
    }
  });

  it("rejects an invalid verb", () => {
    expect(Value.Check(TradeRequest, { ...validOffer, verb: "refund" })).toBe(false);
  });

  it("commit REQUIRES committer_nkey + commit_sig + escrow_id (dual-sig + escrow intent)", () => {
    expect(Value.Check(TradeCommitRequest, { ...validCommit, committer_nkey: undefined })).toBe(false);
    expect(Value.Check(TradeCommitRequest, { ...validCommit, commit_sig: undefined })).toBe(false);
    expect(Value.Check(TradeCommitRequest, { ...validCommit, escrow_id: undefined })).toBe(false);
  });

  it("settle REQUIRES both sigs (Q-C dual-sig)", () => {
    expect(Value.Check(TradeSettleRequest, { ...validSettle, offer_sig: undefined })).toBe(false);
    expect(Value.Check(TradeSettleRequest, { ...validSettle, commit_sig: undefined })).toBe(false);
  });

  it("rejects a numeric amount (canonical DECIMAL STRING)", () => {
    expect(Value.Check(TradeOfferRequest, { ...validOffer, amount: 10 })).toBe(false);
  });

  it("rejects unknown fields (additionalProperties:false)", () => {
    expect(Value.Check(TradeOfferRequest, { ...validOffer, extra: 1 })).toBe(false);
    expect(Value.Check(TradeCommitRequest, { ...validCommit, extra: 1 })).toBe(false);
    expect(Value.Check(TradeSettleRequest, { ...validSettle, extra: 1 })).toBe(false);
  });

  it("offer carries optional terms + expires_at", () => {
    expect(Value.Check(TradeOfferRequest, { ...validOffer, terms: "1h support", expires_at: "2026-08-07T00:00:00.000Z" })).toBe(true);
  });
});

// ── (1) Trade response + error envelopes ───────────────────────
describe("TradeResponse + TradeError", () => {
  const ts = "2026-08-06T00:00:00.000Z";
  it("each verb response pins its escrow state literal", () => {
    expect(Value.Check(TradeOfferResponse, { verb: "offer", ok: true, escrow_id: "e1", state: "offered", receipt_id: "r1", ts })).toBe(true);
    expect(Value.Check(TradeOfferResponse, { verb: "offer", ok: true, escrow_id: "e1", state: "committed", receipt_id: "r1", ts })).toBe(false);
    expect(Value.Check(TradeCommitResponse, { verb: "commit", ok: true, escrow_id: "e1", state: "committed", receipt_id: "r1", ts })).toBe(true);
    expect(Value.Check(TradeSettleResponse, { verb: "settle", ok: true, escrow_id: "e1", state: "settled", tx_id: "tx1", receipt_id: "r1", ts })).toBe(true);
  });

  it("TradeResponse union accepts all three", () => {
    expect(Value.Check(TradeResponse, { verb: "settle", ok: true, escrow_id: "e1", state: "settled", tx_id: "tx1", receipt_id: "r1", ts })).toBe(true);
  });

  it("TradeError carries the J6 guard codes (bad_state / cap_exceeded / sig_invalid / already_committed)", () => {
    expect(Value.Check(TradeError, { verb: "settle", ok: false, error: "not committed", code: "bad_state", ts })).toBe(true);
    expect(Value.Check(TradeError, { verb: "commit", ok: false, error: "dup", code: "already_committed", escrow_id: "e1", state: "committed", ts })).toBe(true);
    expect(Value.Check(TradeError, { verb: "settle", ok: false, error: "cap", code: "cap_exceeded", ts })).toBe(true);
    expect(Value.Check(TradeError, { verb: "settle", ok: false, error: "x", code: "sig_invalid", ts })).toBe(true);
    // ok must be false
    expect(Value.Check(TradeError, { verb: "offer", ok: true, error: "x", ts })).toBe(false);
  });
});

// ── (2) Escrow state machine ───────────────────────────────────
describe("EscrowContract state machine (Q-C)", () => {
  it("EscrowState accepts the Q-C states (incl. frozen arbitration)", () => {
    for (const s of ["offered", "committed", "settled", "released", "disputed", "frozen"] as const) {
      expect(Value.Check(EscrowState, s)).toBe(true);
    }
    expect(Value.Check(EscrowState, "cancelled")).toBe(false);
  });

  it("ESCROW_TRANSITIONS: terminal states have no outgoing edges", () => {
    expect(ESCROW_TRANSITIONS.settled).toEqual([]);
    expect(ESCROW_TRANSITIONS.released).toEqual([]);
  });

  it("canTransitionEscrow allows the legal happy path + cancel + dispute paths", () => {
    // happy path
    expect(canTransitionEscrow("offered", "committed")).toBe(true);
    expect(canTransitionEscrow("committed", "settled")).toBe(true);
    // cancel / release
    expect(canTransitionEscrow("offered", "released")).toBe(true);
    expect(canTransitionEscrow("committed", "released")).toBe(true);
    // dispute → arbitration → release
    expect(canTransitionEscrow("committed", "disputed")).toBe(true);
    expect(canTransitionEscrow("disputed", "frozen")).toBe(true);
    expect(canTransitionEscrow("frozen", "released")).toBe(true);
  });

  it("canTransitionEscrow REJECTS illegal transitions (CAS guard)", () => {
    // cannot settle an offer that was never committed (the J6 acceptance guard)
    expect(canTransitionEscrow("offered", "settled")).toBe(false);
    // cannot skip committed
    expect(canTransitionEscrow("offered", "disputed")).toBe(false);
    // cannot leave a terminal state
    expect(canTransitionEscrow("settled", "released")).toBe(false);
    expect(canTransitionEscrow("released", "disputed")).toBe(false);
    // frozen is ONLY reachable from disputed
    expect(canTransitionEscrow("committed", "frozen")).toBe(false);
    // no self-transitions
    expect(canTransitionEscrow("committed", "committed")).toBe(false);
  });

  it("frozen resolves ONLY to released (arbitration funnel)", () => {
    expect(ESCROW_TRANSITIONS.frozen).toEqual(["released"]);
  });

  const baseOffered = {
    escrow_id: "vchat_escrow.c-1", conversation_id: "c-1", state: "offered",
    offerer_nkey: "UA1", amount: "10.00", budget_cap_ref: "cap-100",
    offer_sig: "sigA", revision: 0,
    created_at: "2026-08-06T00:00:00.000Z", updated_at: "2026-08-06T00:00:00.000Z",
  };

  it("accepts a valid offered escrow (committer/commit_sig absent — join at commit)", () => {
    expect(Value.Check(EscrowContract, baseOffered)).toBe(true);
    // committer + commit_sig land at committed
    expect(Value.Check(EscrowContract, {
      ...baseOffered, state: "committed", committer_nkey: "UA2", commit_sig: "sigB", revision: 1,
    })).toBe(true);
  });

  it("requires the CAS revision field (single-writer guard)", () => {
    const { revision, ...noRev } = baseOffered;
    expect(Value.Check(EscrowContract, noRev)).toBe(false);
  });

  it("rejects a negative revision", () => {
    expect(Value.Check(EscrowContract, { ...baseOffered, revision: -1 })).toBe(false);
  });

  it("rejects a numeric amount (canonical DECIMAL STRING)", () => {
    expect(Value.Check(EscrowContract, { ...baseOffered, amount: 10 })).toBe(false);
  });

  it("rejects an unknown state", () => {
    expect(Value.Check(EscrowContract, { ...baseOffered, state: "cancelled" })).toBe(false);
  });

  it("rejects unknown fields (additionalProperties:false)", () => {
    expect(Value.Check(EscrowContract, { ...baseOffered, extra: 1 })).toBe(false);
  });

  it("settled carries the wallet tx_id", () => {
    expect(Value.Check(EscrowContract, {
      ...baseOffered, state: "settled", committer_nkey: "UA2", commit_sig: "sigB",
      revision: 2, settled_tx_id: "tx-9",
    })).toBe(true);
  });

  it("escrowKey builds vchat_escrow.<conversation_id>", () => {
    expect(escrowKey("c-1")).toBe("vchat_escrow.c-1");
  });
});

// ── (3) canonicalTradeBytes cross-encoder parity lock ──────────
describe("canonicalTradeBytes cross-encoder parity (J6 schema seam)", () => {
  // The Go mirror (dash/sidecar/internal/tradeaudit/tradeaudit.go) `signedTerms`
  // struct emits EXACTLY these 6 fields in this order. Lock the field set +
  // order so a TS/Go drift is caught here, not at sig-verify time on the wire.
  it("TRADE_FIELD_ORDER is exactly the 6 Go signedTerms fields in order", () => {
    expect([...TRADE_FIELD_ORDER]).toEqual([
      "receipt_id", "conversation_id", "kind", "offerer_nkey", "amount", "budget_cap_ref",
    ]);
    expect(TRADE_FIELD_ORDER.length).toBe(6);
  });

  it("canonicalTradeBytes emits ONLY the 6 TERM keys (sigs excluded)", () => {
    const receipt = {
      receipt_id: "r-1", conversation_id: "c-1", kind: "commit",
      offerer_nkey: "UA1", amount: "10.00", budget_cap_ref: "cap-100",
      offer_sig: "sigA", fleet_sig: "sigF",
    };
    const json = JSON.parse(new TextDecoder().decode(canonicalTradeBytes(receipt)));
    expect(Object.keys(json)).toEqual([...TRADE_FIELD_ORDER]);
    const decoded = new TextDecoder().decode(canonicalTradeBytes(receipt));
    expect(decoded).not.toContain("offer_sig");
    expect(decoded).not.toContain("fleet_sig");
  });

  // BYTE-FOR-BYTE parity with dash/sidecar/internal/tradeaudit/tradeaudit.go
  // CanonicalTradeBytes (Go TestCanonicalTradeBytes_Golden pins the same string).
  // Hardcoding the literal bytes catches serialization drift (spacing / HTML
  // escaping / trailing newline) the key-set assertion above would miss — this
  // is the actual byte-for-byte lock the J6 criterion demands.
  it("canonicalTradeBytes is byte-for-byte the Go golden (compact, no whitespace, no trailing newline)", () => {
    const receipt = {
      receipt_id: "r-1", conversation_id: "c-1", kind: "commit",
      offerer_nkey: "UA1", amount: "10.00", budget_cap_ref: "cap-100",
      offer_sig: "sigA", fleet_sig: "sigF",
    };
    const decoded = new TextDecoder().decode(canonicalTradeBytes(receipt));
    expect(decoded).toBe(
      '{"receipt_id":"r-1","conversation_id":"c-1","kind":"commit","offerer_nkey":"UA1","amount":"10.00","budget_cap_ref":"cap-100"}'
    );
    // Go json.Encoder appends a newline that tradeaudit.go trims; TS must not
    // add one (JSON.stringify doesn't) — a trailing newline would break sig parity.
    expect(decoded.endsWith("\n")).toBe(false);
  });
});
