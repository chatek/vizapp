/**
 * J15 — every assert must be able to FAIL (the inert-gate kill switch).
 *
 * Iterates the FULL assert registry and proves, for every builder variant:
 * predicate(goodFixture) === true AND predicate(badFixture) === false for
 * EVERY bad fixture. A gate that cannot go red cannot be registered — the
 * type requires a bad fixture, and this test requires it to actually bite.
 */
import { describe, it, expect } from "vitest";
import { buildAssert, type AssertSpec, type AssertId } from "../../skills/incus-repackager/src/asserts.js";

const SPECS: Record<AssertId, AssertSpec> = {
  exactVersion: { assertId: "exactVersion", expected: "1.3.14", label: "bun", howItFails: "mismatch" },
  substringVersion: { assertId: "substringVersion", expected: "0.12.14", label: "uv", howItFails: "missing" },
  scanEmpty: { assertId: "scanEmpty", expected: "(none)", label: "nats scan", howItFails: "leftovers" },
  cloudInitDone: { assertId: "cloudInitDone", expected: "status: done", label: "ci", howItFails: "not done" },
  modeIs: { assertId: "modeIs", expected: "600", label: "auth.json", howItFails: "wrong mode" },
  rc0: { assertId: "rc0", expected: "rc=0", label: "gate", howItFails: "nonzero rc" },
  shaMatch: { assertId: "shaMatch", expected: "a".repeat(64), label: "tgz sha", howItFails: "digest mismatch" },
  includesNot: { assertId: "includesNot", expected: "claimed", not: "pending", label: "claim", howItFails: "not claimed" },
};

describe("assert registry — failable-gate proof", () => {
  for (const [id, spec] of Object.entries(SPECS)) {
    it(`${id}: good passes, EVERY bad fixture goes RED`, () => {
      const def = buildAssert(spec);
      expect(def.predicate(def.fixtures.good), `${id} good fixture must pass`).toBe(true);
      expect(def.fixtures.bad.length).toBeGreaterThan(0);
      for (const bad of def.fixtures.bad) {
        expect(def.predicate(bad), `${id} bad fixture must FAIL: ${JSON.stringify(bad)}`).toBe(false);
      }
    });
  }

  it("T1 exactly: AVX2 SIGILL (rc=132, EMPTY stdout) is RED, not silent-pass", () => {
    const def = buildAssert(SPECS.exactVersion);
    const sigill = { rc: 132, stdout: "", stderr: "Illegal instruction (core dumped)" };
    expect(def.predicate(sigill)).toBe(false);
  });

  it("T6 exactly: 'extended_status: degraded done' is RED despite 'status: done' present", () => {
    const def = buildAssert(SPECS.cloudInitDone);
    expect(def.predicate({ rc: 0, stdout: "status: done\nextended_status: degraded done\n", stderr: "" })).toBe(false);
  });

  it("O44 exactly: credential mode 644 is RED", () => {
    const def = buildAssert(SPECS.modeIs);
    expect(def.predicate({ rc: 0, stdout: "644\n", stderr: "" })).toBe(false);
  });
});
