/**
 * p2p-identity.test.ts — HKDF per-fabric subkey derivation (Pears Tier P, M2).
 *
 * Pins the M2 derivation gate: deterministic; distinct per fabric; distinct
 * per root seed; NO key reuse between the peer identity and any delegation's
 * writer identity; the 64B secret key is exactly seed||pub (the layout
 * sodium/hyperswarm/hypercore expect — M0 Q7's foreign-key import shape).
 */
import { describe, it, expect } from "vitest";
import * as ed from "@noble/ed25519";
import { createHash } from "node:crypto";
import {
  deriveFabricSeed,
  derivePeerKeyPair,
  derivePeerKeyPairFromNkey,
  deriveWriterKeyPair,
  keyPairFromSeed,
  PEER_FABRIC,
  coreWriterFabric,
  PEARS_HKDF_SALT,
} from "../../src/net/p2p/identity.js";

(ed.hashes as unknown as { sha512?: (m: Uint8Array) => Uint8Array }).sha512 = (m: Uint8Array): Uint8Array => {
  const h = createHash("sha512");
  h.update(m);
  return new Uint8Array(h.digest());
};

// Golden vectors: fixed root seed 0xab*32 (computed against this
// implementation at M2 time; they pin the algorithm, not the test).
const GOLDEN = {
  fabricSeedHex: "3b2d05ae065c8647c8b31756db03cbc7674ef178c0a015c366ad7f12bf1aedff",
  peerPubHex: "94545db78978decb9cc5b708414eb055ee8dcf6be4d9d0414fd5404473fbd40f",
  peerSkHex: "3b2d05ae065c8647c8b31756db03cbc7674ef178c0a015c366ad7f12bf1aedff94545db78978decb9cc5b708414eb055ee8dcf6be4d9d0414fd5404473fbd40f",
  writerPubHex: "ed4d363f2aba688bfbd37cc1562c0ba3e815a64be560854c6f5cf78ae67da156",
};

const ROOT = new Uint8Array(32).fill(0xab);
const hex = (u: Uint8Array): string => Buffer.from(u).toString("hex");

describe("deriveFabricSeed", () => {
  it("matches the golden HKDF vector", () => {
    expect(hex(deriveFabricSeed(ROOT, PEER_FABRIC))).toBe(GOLDEN.fabricSeedHex);
  });

  it("is deterministic", () => {
    expect(hex(deriveFabricSeed(ROOT, PEER_FABRIC))).toBe(hex(deriveFabricSeed(ROOT, PEER_FABRIC)));
  });

  it("is distinct per fabric", () => {
    const a = deriveFabricSeed(ROOT, PEER_FABRIC);
    const b = deriveFabricSeed(ROOT, coreWriterFabric("dlg-1"));
    const c = deriveFabricSeed(ROOT, coreWriterFabric("dlg-2"));
    expect(hex(a)).not.toBe(hex(b));
    expect(hex(b)).not.toBe(hex(c));
  });

  it("is distinct per root seed", () => {
    const other = new Uint8Array(32).fill(0xcd);
    expect(hex(deriveFabricSeed(ROOT, PEER_FABRIC))).not.toBe(hex(deriveFabricSeed(other, PEER_FABRIC)));
  });

  it("rejects a non-32B root seed", () => {
    expect(() => deriveFabricSeed(new Uint8Array(31), PEER_FABRIC)).toThrow(/32 bytes/);
  });
});

describe("derivePeerKeyPair / deriveWriterKeyPair", () => {
  it("peer keypair matches the golden vector (pub + 64B secret layout)", async () => {
    const kp = await derivePeerKeyPair(ROOT);
    expect(hex(kp.publicKey)).toBe(GOLDEN.peerPubHex);
    expect(hex(kp.secretKey)).toBe(GOLDEN.peerSkHex);
    expect(kp.secretKey.length).toBe(64);
    // secretKey is exactly seed||pub
    expect(hex(kp.secretKey.subarray(0, 32))).toBe(GOLDEN.fabricSeedHex);
    expect(hex(kp.secretKey.subarray(32, 64))).toBe(GOLDEN.peerPubHex);
  });

  it("is deterministic across calls", async () => {
    const [a, b] = await Promise.all([derivePeerKeyPair(ROOT), derivePeerKeyPair(ROOT)]);
    expect(hex(a.publicKey)).toBe(hex(b.publicKey));
    expect(hex(a.secretKey)).toBe(hex(b.secretKey));
  });

  it("peer identity and writer identities NEVER share key material (no reuse)", async () => {
    const peer = await derivePeerKeyPair(ROOT);
    const w1 = await deriveWriterKeyPair(ROOT, "dlg-1");
    const w2 = await deriveWriterKeyPair(ROOT, "dlg-1");
    const wOther = await deriveWriterKeyPair(new Uint8Array(32).fill(0xcd), "dlg-1");
    expect(hex(w1.publicKey)).toBe(hex(w2.publicKey)); // deterministic per (seed, delegation)
    expect(hex(peer.publicKey)).not.toBe(hex(w1.publicKey));
    expect(hex(peer.secretKey)).not.toBe(hex(w1.secretKey));
    expect(hex(w1.publicKey)).not.toBe(hex(wOther.publicKey)); // seed matters
    // golden is for delegation "dlg-golden" (the fixed vector's scope)
    const wGolden = await deriveWriterKeyPair(ROOT, "dlg-golden");
    expect(hex(wGolden.publicKey)).toBe(GOLDEN.writerPubHex);
  });

  it("the derived public key verifies signatures from the derived secret (ed25519 sanity)", async () => {
    const kp = await derivePeerKeyPair(ROOT);
    const message = new TextEncoder().encode("pears-m2-identity-check");
    const signature = await ed.sign(message, kp.secretKey.subarray(0, 32));
    expect(await ed.verify(signature, message, kp.publicKey)).toBe(true);
  });

  it("derives the same peer identity from an NKey seed string", async () => {
    // Build a real NKey seed, then derive from it twice (string + raw path).
    const { createUser } = await import("@nats-io/nkeys");
    const kp = createUser();
    const seedString = Buffer.from(kp.getSeed()).toString("utf8");
    const fromString = await derivePeerKeyPairFromNkey(seedString);
    const { decodeNkeySeed } = await import("../../src/lib/keygen.js");
    const fromRaw = await derivePeerKeyPair(decodeNkeySeed(seedString));
    expect(hex(fromString.publicKey)).toBe(hex(fromRaw.publicKey));
  });

  it("HKDF salt is the documented constant", () => {
    expect(PEARS_HKDF_SALT).toBe("vclaw-pears-v1");
    expect(PEER_FABRIC).toBe("pears/peer/v1");
    expect(coreWriterFabric("d")).toBe("pears/core-writer/v1/d");
  });

  it("keyPairFromSeed rejects mismatches between seed and layout", async () => {
    const seed = deriveFabricSeed(ROOT, PEER_FABRIC);
    const kp = await keyPairFromSeed(seed);
    expect(kp.publicKey.length).toBe(32);
    expect(kp.secretKey.length).toBe(64);
  });
});
