/**
 * Unit tests for the credential storage module (src/lib/store.ts).
 *
 * All filesystem calls (readFile, writeFile, mkdir, unlink, existsSync)
 * and os.homedir are mocked so no real I/O ever occurs.
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import { readFile, writeFile, mkdir, unlink, copyFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir } from "node:os";

// ---------------------------------------------------------------------------
// Mocks — hoisted by vitest before any import
// ---------------------------------------------------------------------------

vi.mock("node:fs/promises");
vi.mock("node:fs");
vi.mock("node:os", () => ({
  homedir: vi.fn(() => "/home/testuser"),
}));

// ---------------------------------------------------------------------------
// Module under test (imported after mocks are hoisted)
// ---------------------------------------------------------------------------

import {
  loadCredentials,
  saveCredentials,
  clearCredentials,
  credentialsPath,
  backupCredentials,
  hasPendingFlag,
} from "../../src/lib/store.js";

// ---------------------------------------------------------------------------
// Type-safe mock accessors
// ---------------------------------------------------------------------------

const mockedReadFile = vi.mocked(readFile);
const mockedWriteFile = vi.mocked(writeFile);
const mockedMkdir = vi.mocked(mkdir);
const mockedUnlink = vi.mocked(unlink);
const mockedCopyFile = vi.mocked(copyFile);
const mockedExistsSync = vi.mocked(existsSync);
const mockedHomedir = vi.mocked(homedir);

// ---------------------------------------------------------------------------
// Test data
// ---------------------------------------------------------------------------

const SAMPLE_CREDENTIALS = {
  seed: "SUAFRB6GC2O2XQTRQQUVMR4272SQH6QFG4U3XGAYHUE27GRALTB42MYVSU",
  public_key: "UCFA332X42SXC2XYRWP3AKP5QKOBM6RFXZCIDL6CVW274TNATVR5YXF5",
  agent_nkey: "AAGENT1234567890",
  name: "test-agent",
  template: "researcher",
  steward: "test@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
} as const;

// ---------------------------------------------------------------------------
// Setup / teardown
// ---------------------------------------------------------------------------

beforeEach(() => {
  vi.resetAllMocks();

  // Re-establish the homedir mock after reset, so credentialsPath() etc.
  // always see a deterministic path.
  mockedHomedir.mockReturnValue("/home/testuser");
});

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("loadCredentials()", () => {
  it("returns null when the credentials file does not exist (ENOENT)", async () => {
    const enoent = new Error("ENOENT");
    (enoent as NodeJS.ErrnoException).code = "ENOENT";
    mockedReadFile.mockRejectedValue(enoent);

    const result = await loadCredentials();

    expect(result).toBeNull();
    // Wave-1 read-order: all three tiers attempted (canonical, then both
    // legacy dirs) before null.
    expect(mockedReadFile).toHaveBeenCalledTimes(3);
  });

  it("returns null when the file contains malformed JSON", async () => {
    mockedReadFile.mockResolvedValue("this is not valid json");

    const result = await loadCredentials();

    expect(result).toBeNull();
    // Malformed in ALL tiers (mock applies to every readFile call).
    expect(mockedReadFile).toHaveBeenCalledTimes(3);
  });

  it("returns null when the stored seed is not a valid nkeys seed (stale pre-fix format)", async () => {
    // The pre-keygen-fix era wrote non-standard 'ST...' seeds that
    // nkeys.fromSeed rejects ('invalid encoded key'). Treat as no creds.
    mockedReadFile.mockResolvedValue(
      JSON.stringify({ ...SAMPLE_CREDENTIALS, seed: "ST" + "A".repeat(55) })
    );

    const result = await loadCredentials();

    expect(result).toBeNull();
  });

  it("returns parsed credentials when the file contains valid JSON", async () => {
    mockedReadFile.mockResolvedValue(JSON.stringify(SAMPLE_CREDENTIALS));

    const result = await loadCredentials();

    expect(result).toEqual(SAMPLE_CREDENTIALS);
    // Q4: first hit (new dir) short-circuits — no legacy read.
    expect(mockedReadFile).toHaveBeenCalledOnce();
  });
});

describe("saveCredentials()", () => {
  it("creates the new config directory (~/.config/vchat, Q4) when it does not exist", async () => {
    mockedExistsSync.mockReturnValue(false);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveCredentials(SAMPLE_CREDENTIALS);

    expect(mockedExistsSync).toHaveBeenCalledWith(
      "/home/testuser/.config/vclaw",
    );
    expect(mockedMkdir).toHaveBeenCalledWith("/home/testuser/.config/vclaw", {
      recursive: true,
    });
  });

  it("skips creating the directory when it already exists", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveCredentials(SAMPLE_CREDENTIALS);

    expect(mockedExistsSync).toHaveBeenCalledWith(
      "/home/testuser/.config/vclaw",
    );
    expect(mockedMkdir).not.toHaveBeenCalled();
  });

  it("writes the credentials file (NEW dir, Q4) with owner-read/write (0o600) mode", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveCredentials(SAMPLE_CREDENTIALS);

    expect(mockedWriteFile).toHaveBeenCalledWith(
      "/home/testuser/.config/vclaw/credentials.json",
      JSON.stringify(SAMPLE_CREDENTIALS, null, 2),
      { encoding: "utf-8", mode: 0o600 },
    );
  });

  it("correctly serialises the credentials object to JSON", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveCredentials(SAMPLE_CREDENTIALS);

    const callArgs = mockedWriteFile.mock.calls[0];
    const writtenJson = callArgs[1] as string;
    const parsed = JSON.parse(writtenJson);

    expect(parsed).toEqual(SAMPLE_CREDENTIALS);
  });
});

describe("clearCredentials()", () => {
  it("calls unlink on the credentials file (both dirs — full logout, Q4)", async () => {
    mockedUnlink.mockResolvedValue(undefined);

    await clearCredentials();

    expect(mockedUnlink).toHaveBeenCalledWith(
      "/home/testuser/.config/vclaw/credentials.json",
    );
    expect(mockedUnlink).toHaveBeenCalledWith(
      "/home/testuser/.vchat/credentials.json",
    );
  });

  it("is a no-op when the credentials file does not exist (unlink throws)", async () => {
    mockedUnlink.mockRejectedValue(new Error("ENOENT"));

    // Should not throw, despite the underlying rejection.
    await expect(clearCredentials()).resolves.toBeUndefined();

    expect(mockedUnlink).toHaveBeenCalledWith(
      "/home/testuser/.config/vclaw/credentials.json",
    );
  });
});

describe("credentialsPath()", () => {
  it("returns the NEW-dir path (Q4: ~/.config/vchat/credentials.json)", () => {
    const path = credentialsPath();

    expect(path).toBe("/home/testuser/.config/vclaw/credentials.json");
  });
});

describe("hasPendingFlag()", () => {
  it("checks the flag in BOTH dirs (Q4 migration window)", () => {
    mockedExistsSync.mockReturnValue(true);
    expect(hasPendingFlag()).toBe(true);
    expect(mockedExistsSync).toHaveBeenCalledWith("/home/testuser/.config/vclaw/.pending");

    mockedExistsSync.mockReturnValue(false);
    expect(hasPendingFlag()).toBe(false);
    expect(mockedExistsSync).toHaveBeenCalledWith("/home/testuser/.vchat/.pending");
  });
});

describe("backupCredentials()", () => {
  it("returns null when no credentials file exists", async () => {
    mockedExistsSync.mockReturnValue(false);

    const result = await backupCredentials();

    expect(result).toBeNull();
    expect(mockedCopyFile).not.toHaveBeenCalled();
  });

  it("copies credentials.json to credentials.json.bak-<ts> and returns the path", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedCopyFile.mockResolvedValue(undefined);

    const result = await backupCredentials();

    expect(result).toMatch(/credentials\.json\.bak-/);
    const [src, dest] = mockedCopyFile.mock.calls[0] as [string, string];
    expect(src).toBe("/home/testuser/.config/vclaw/credentials.json");
    expect(dest).toMatch(/credentials\.json\.bak-\d{4}-\d{2}-\d{2}T/);
  });
});
