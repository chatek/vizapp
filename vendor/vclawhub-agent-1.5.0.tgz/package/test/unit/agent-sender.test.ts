/**
 * agent-sender.test.ts — Synadia Agent Protocol §13 conformance, against the SPEC'S OWN published vector.
 *
 * The vector is `operator-account-signed` from Appendix B.13 of
 * vendors/synadia-agent-sdk-docs/core-protocol.md (mirrored from the SDKs' shared fixtures
 * test-fixtures/identity/sender-vectors.json). The seed is the spec's throwaway test key,
 * published precisely so the signature can be reproduced — it is TEST-ONLY.
 *
 * PORTED, NOT RE-DERIVED: every literal below is copied from the spec. If a test fails, re-read the spec
 * before touching a fixture.
 *
 * NOT covered here (deliberately, and named so it is not mistaken for covered): §13.3 agent-id parsing and
 * its §13.3.3 parse-fixture table. That is a separate function and a separate build item.
 */
import { describe, it, expect } from "vitest";
import {
  agentSenderSignedInput,
  signAgentSender,
  verifyAgentSender,
  sha256Hex,
  SHA256_EMPTY_HEX,
} from "../../packages/protocol-core/src/agent-sender.js";

// ── B.13 `operator-account-signed` — verbatim from the spec ──────────────────
const SEED = "SUAEJ6GDK6FSSB54LD45Q7W25AW7NUT7MVLBABIR5MIPFUTBW7ZNPK2KYE"; // TEST-ONLY (published)
const ACCOUNT = "AABYLMBR6Q2CDXTLGRQCFA2GP76BGCDF7NZF2OVHH4RQ7L3Y3TZWJDRL";
const USER = "UCDUW5V44EBDBIK2FL4CTNDBQFNGBEZVJHSZGQVKRHASN4AV4IWPB5NT";
const SUBJECT = "agents.prompt.demo-agent.alice.example";
const TS = "2026-08-28T12:00:00Z";
const NONCE = "nonce-operator-account-signed";
const PAYLOAD = new TextEncoder().encode('{"prompt":"hello"}'); // 18 bytes
const EXPECTED_SHA256_HEX = "8a44725210b9dcd4fefd9f0eca07b70ae45e69274a3105fb25eb426a2cf8bbf4";
const EXPECTED_SIG_B64URL = "EPGc0tNF0ZQeBqXUduwUp3zdi33k1AKIXOX-PUPSeY9QtS4V3d2EZLq-fHuPuYkw6Cc3HdVn_jVI58Y_3YBZBw";

const FIELDS = { account: ACCOUNT, user: USER, subject: SUBJECT, ts: TS, nonce: NONCE, payload: PAYLOAD };

describe("Synadia §13 sender identity — spec vectors", () => {
  it("payload digest matches the spec (and the payload really is 18 bytes)", async () => {
    expect(PAYLOAD.byteLength).toBe(18);
    expect(await sha256Hex(PAYLOAD)).toBe(EXPECTED_SHA256_HEX);
  });

  it("the signed input is the spec's seven lines, LF-terminated, tag first", async () => {
    const bytes = await agentSenderSignedInput(FIELDS);
    const expected = [
      "AGENT-SENDER-V1",
      ACCOUNT,
      USER,
      SUBJECT,
      TS,
      NONCE,
      EXPECTED_SHA256_HEX,
    ].join("\n") + "\n";
    expect(new TextDecoder().decode(bytes)).toBe(expected);
    // exactly seven LFs: six separators + the trailing one
    expect(Array.from(bytes).filter((b) => b === 0x0a).length).toBe(7);
    expect(bytes[bytes.length - 1]).toBe(0x0a);
  });

  it("SIGNATURE reproduces the published vector, base64url without padding (86 chars)", async () => {
    const sig = await signAgentSender(FIELDS, SEED);
    expect(sig).toBe(EXPECTED_SIG_B64URL);
    expect(sig.length).toBe(86);
    expect(sig).not.toContain("=");
  });

  it("verifies against the user public key, and REJECTS a tampered payload", async () => {
    const sig = await signAgentSender(FIELDS, SEED);
    expect(await verifyAgentSender(FIELDS, sig, USER)).toBe(true);
    const tampered = { ...FIELDS, payload: new TextEncoder().encode('{"prompt":"evil!"}') };
    expect(await verifyAgentSender(tampered, sig, USER)).toBe(false);
  });

  it("empty payload hashes to SHA-256 of zero bytes (§13.6.1's named case)", async () => {
    expect(await sha256Hex(new Uint8Array(0))).toBe(SHA256_EMPTY_HEX);
    expect(SHA256_EMPTY_HEX).toBe("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  });

  it("`name` is OUTSIDE the signature (§13.5.1): it is not an input at all", async () => {
    // The wire header carries `name`; the signed input's seven lines do not. Two signers differing only in
    // display name must produce the SAME signature -- proving the field cannot leak into the bytes.
    const a = await signAgentSender(FIELDS, SEED);
    const b = await signAgentSender({ ...FIELDS }, SEED);
    expect(a).toBe(b);
    const input = new TextDecoder().decode(await agentSenderSignedInput(FIELDS));
    expect(input).not.toContain("claude-code"); // the name in B.13's header example
  });

  it("changing ANY signed field changes the signature (the vector is not degenerate)", async () => {
    const base = await signAgentSender(FIELDS, SEED);
    for (const [k, v] of [["subject", "agents.prompt.other.alice.example"], ["ts", "2026-08-28T12:00:01Z"], ["nonce", "nonce-x"]] as const) {
      const sig = await signAgentSender({ ...FIELDS, [k]: v }, SEED);
      expect(sig, `field ${k} must be covered by the signature`).not.toBe(base);
    }
  });
});
