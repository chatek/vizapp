/**
 * check-update tests (B12, L3-a; audit 2026-08-30: version source is the
 * jsr.io public API — npm registry is FROZEN at 1.0.2 and the old
 * `npm view @vclawhub/agent` form queried a dead package).
 *
 * formatUpdateStatus is pure (no network). fetchLatestVersion IS exercised
 * with a stubbed global fetch (jsr.io shape: { latestVersion }).
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import {
  formatUpdateStatus,
  fetchLatestVersion,
  JSR_META_URL,
} from "../../src/commands/check-update.js";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("check-update output", () => {
  it("reports up to date when installed == latest", () => {
    const msg = formatUpdateStatus("0.7.2", "0.7.2");
    expect(msg).toContain("up to date");
    expect(msg).toContain("0.7.2");
  });

  it("reports the diff and suggests the bundled-CLI re-download when behind", () => {
    const msg = formatUpdateStatus("0.7.1", "0.7.2");
    expect(msg).toContain("v0.7.1 → v0.7.2");
    expect(msg).toContain("curl -fsSL https://vclawhub.com/agent.js");
    expect(msg).toContain("-o ~/.vclaw/agent.js");
  });

  it("handles patch and major gaps", () => {
    const major = formatUpdateStatus("0.6.11", "1.0.0");
    expect(major).toContain("v0.6.11 → v1.0.0");
    expect(major).toContain("curl -fsSL https://vclawhub.com/agent.js");
  });

  it("never suggests a registry install (npm-free end goal)", () => {
    const msg = formatUpdateStatus("1.2.0", "1.2.2");
    expect(msg).not.toContain("npm i");
    expect(msg).not.toContain("npm install");
    expect(msg).not.toContain("bunx @jsr");
    expect(msg).not.toContain("@vchatemail");
  });

  it("never suggests a command when equal (no false positive)", () => {
    const msg = formatUpdateStatus("0.7.2", "0.7.2");
    expect(msg).not.toContain("curl");
  });
});

describe("fetchLatestVersion (jsr.io public API)", () => {
  it("GETs the @vclawhub/agent metadata and returns latestVersion", async () => {
    const mock = vi.fn(async () =>
      new Response(JSON.stringify({ scope: "vclawhub", name: "agent", latestVersion: "1.2.2" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      })
    );
    vi.stubGlobal("fetch", mock);
    await expect(fetchLatestVersion()).resolves.toBe("1.2.2");
    expect(mock).toHaveBeenCalledWith(
      JSR_META_URL,
      expect.objectContaining({ headers: { Accept: "application/json" } })
    );
  });

  it("throws on a non-OK jsr.io response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response("nope", { status: 503 }))
    );
    await expect(fetchLatestVersion()).rejects.toThrow("503");
  });

  it("throws when the payload carries no latestVersion", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        new Response(JSON.stringify({ scope: "vclawhub", name: "agent" }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        })
      )
    );
    await expect(fetchLatestVersion()).rejects.toThrow("latestVersion");
  });
});
