/**
 * presence-v2-emission.test.ts — v9 W3 lead emission.
 *
 * Verify (UPGRADE.md §6 W3 + §5 G2): v1 agents unaffected (no children option
 * ⇒ byte-identical pre-v9 v1 wire) · v2 lead announcements verify with
 * children[] (mirror refresh via reannounce) · cross-segment invisible
 * (subject pin identical across versions) · graceful offline keeps version.
 */
import { describe, it, expect } from "vitest";
import { nkeys } from "@nats-io/nats-core";
import { startPresence } from "../../src/net/presence.js";
import { verifyAnnouncement, watchDirectory } from "../../src/net/directory.js";
import {
  canonicalAnnouncementBytes,
  canonicalAnnouncementV2Bytes,
  ANNOUNCEMENT_V2_FIELD_ORDER,
} from "../../src/contracts/contracts.js";
import type { FamilyChildEntry } from "../../src/contracts/contracts.js";
import { V2_CHILDREN } from "../helpers/announcement-fixtures.js";

// ── mock NATS bus (publish + subscribe with > / * wildcard matching) ──────
function subjectMatches(filter: string, subject: string): boolean {
  const f = filter.split(".");
  const s = subject.split(".");
  let i = 0;
  for (; i < f.length; i++) {
    if (f[i] === ">") return i < s.length;
    if (i >= s.length) return false;
    if (f[i] !== "*" && f[i] !== s[i]) return false;
  }
  return i === s.length;
}

function mockBus() {
  const subs: Array<{ filter: string; cb: (subject: string, data: Uint8Array) => void }> = [];
  const published: Array<{ subject: string; data: Uint8Array }> = [];
  const nc = {
    publish(subject: string, data: Uint8Array) {
      published.push({ subject, data });
      for (const s of subs) {
        if (subjectMatches(s.filter, subject)) s.cb(subject, data);
      }
    },
    subscribe(filter: string, opts: { callback: (e: unknown, msg: { subject: string; data: Uint8Array }) => void }) {
      const cb = (subject: string, data: Uint8Array) => opts.callback(null, { subject, data });
      const entry = { filter, cb };
      subs.push(entry);
      return {
        unsubscribe: () => {
          const i = subs.indexOf(entry);
          if (i >= 0) subs.splice(i, 1);
        },
      };
    },
  };
  return { nc: nc as never, published };
}

const dec = new TextDecoder();
const decode = (d: Uint8Array) => JSON.parse(dec.decode(d)) as Record<string, unknown>;
const flush = () => new Promise((r) => setTimeout(r, 15));

const kp = nkeys.createUser();
const seed = new TextDecoder().decode(kp.getSeed());
const pub = kp.getPublicKey();

describe("v9 W3 lead emission (startPresence children option)", () => {
  it("v1 agents unaffected: no children option ⇒ v1 wire (no v key), v1 canonical order + sig", async () => {
    const bus = mockBus();
    let v1Fired = 0;
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "plain-agent" }, {
      seed, segment: "default", capabilities: ["code"], model: "gpt-4o", online: true,
      heartbeat: false,
      onAnnounce: () => { v1Fired++; },
    });
    await flush();
    await presence.stop();
    await flush();

    const wire = decode(bus.published[0].data);
    expect(wire.v, "plain agent must NOT announce v2").toBeUndefined();
    expect(wire.children).toBeUndefined();
    expect(wire.online).toBe(true);
    expect(v1Fired).toBeGreaterThan(0);
    // v1 canonical order is the pre-v9 J0.0 contract order (byte-identical path).
    const { sig: _drop, ...ann } = wire;
    expect(Object.keys(JSON.parse(dec.decode(canonicalAnnouncementBytes(ann as never))))).toEqual(
      ["ts", "name", "nkey", "segment", "capabilities", "online", "model", "sdk_version"],
    );
    // subject pin — v1 baseline
    expect(bus.published[0].subject).toBe(`$SRV.INFO.agents.default.${pub}`);
  });

  it("lead emission: children provider ⇒ v2 wire; directory projects children[]", async () => {
    const bus = mockBus();
    const watch = watchDirectory(bus.nc, "default", {});
    const children: FamilyChildEntry[] = [
      { name: "worker-a", role: "researcher", caps: ["code", "search"], state: "running" },
      { name: "worker-b", role: "reviewer", caps: [], state: "idle" },
    ];
    let v2Fired = 0;
    let v1Fired = 0;
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "lead-agent" }, {
      seed, segment: "default", capabilities: ["code"], model: "gpt-4o", online: true,
      heartbeat: false,
      children: () => children,
      onAnnounce: () => { v1Fired++; },
      onAnnounceV2: (ann) => { v2Fired++; expect(ann.v).toBe(2); },
    });
    await flush();

    const wire = decode(bus.published[0].data);
    expect(wire.v).toBe(2);
    expect(wire.children).toEqual(children);
    expect(v2Fired).toBe(1);
    expect(v1Fired).toBe(0);

    const entry = watch.directory.get(pub);
    expect(entry, "v2 lead announce must project").toBeDefined();
    expect(entry!.v).toBe(2);
    expect(entry!.children).toEqual(children);
    expect(watch.directory.accepted).toBe(1);
    expect(watch.directory.rejected).toBe(0);

    const r = verifyAnnouncement(bus.published[0].subject, bus.published[0].data, Date.now());
    expect(r.ok).toBe(true);
    expect(r.entry!.children).toEqual(children);

    await presence.stop();
    watch.stop();
  });

  it("v2 sig verifies over canonicalAnnouncementV2Bytes (children in canonical bytes)", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "canon-lead" }, {
      seed, segment: "default", heartbeat: false,
      children: () => [{ name: "w", role: "", caps: [], state: "idle" }],
    });
    await flush();
    await presence.stop();

    const wire = decode(bus.published[0].data);
    const { sig, ...ann } = wire;
    const verifier = nkeys.fromPublic(pub);
    expect(verifier.verify(canonicalAnnouncementV2Bytes(ann as never), new Uint8Array(Buffer.from(sig as string, "base64")))).toBe(true);
    // canonical field order is the W0 v2 contract (children last).
    expect(Object.keys(JSON.parse(dec.decode(canonicalAnnouncementV2Bytes(ann as never))))).toEqual(
      [...ANNOUNCEMENT_V2_FIELD_ORDER],
    );
  });

  it("mirror refresh: provider state flip → reannounce publishes updated children (30s-tick mirror)", async () => {
    const bus = mockBus();
    const watch = watchDirectory(bus.nc, "default", {});
    const children: FamilyChildEntry[] = [{ name: "w", role: "researcher", caps: ["code"], state: "running" }];
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "mirror-lead" }, {
      seed, segment: "default", heartbeat: false,
      children: () => children,
    });
    await flush();
    expect(watch.directory.get(pub)!.children![0]!.state).toBe("running");

    children[0] = { ...children[0]!, state: "idle" }; // daemon wrote Idle on completion
    await presence.reannounce();
    await flush();

    expect(decode(bus.published.at(-1)!.data).children).toEqual(children);
    expect(watch.directory.get(pub)!.children![0]!.state).toBe("idle");
    await presence.stop();
    watch.stop();
  });

  it("childless lead ⇒ v2 WITHOUT the children key (W0 no-children golden shape)", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "empty-lead" }, {
      seed, segment: "default", heartbeat: false,
      children: () => [],
    });
    await flush();
    await presence.stop();

    const wire = decode(bus.published[0].data);
    expect(wire.v).toBe(2);
    expect("children" in wire).toBe(false);
    // canonical key set = v2 field order minus children (undefined-skip).
    const { sig: _drop, ...ann } = wire;
    expect(Object.keys(JSON.parse(dec.decode(canonicalAnnouncementV2Bytes(ann as never))))).toEqual(
      [...ANNOUNCEMENT_V2_FIELD_ORDER].filter((k) => k !== "children"),
    );
  });

  it("cross-segment invisible: v2 lead announces on the same $SRV.INFO.agents.<segment> subject", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "eng-lead" }, {
      seed, segment: "eng", heartbeat: false,
      children: () => [{ name: "w", role: "", caps: [], state: "running" }],
    });
    await flush();
    await presence.stop();
    expect(bus.published[0].subject).toBe(`$SRV.INFO.agents.eng.${pub}`);
    expect(decode(bus.published[0].data).segment).toBe("eng");
  });

  it("graceful offline keeps the version: a lead's final online:false announce is v2", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "offline-lead" }, {
      seed, segment: "default", online: true, heartbeat: false,
      children: () => V2_CHILDREN as unknown as FamilyChildEntry[],
    });
    await flush();
    expect(decode(bus.published.at(-1)!.data).online).toBe(true);
    await presence.stop();
    await flush();
    const last = decode(bus.published.at(-1)!.data);
    expect(last.v).toBe(2);
    expect(last.online).toBe(false);
    expect((last.children as FamilyChildEntry[]).length).toBe(2);
  });
});
