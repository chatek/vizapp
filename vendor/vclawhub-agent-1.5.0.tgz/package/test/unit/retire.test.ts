/**
 * retire command (J16a, Phase-1 steward path) — unit tests.
 *
 * Wire contract per vgate/internal/agentidp/retire.go + AGENT_RETIRE.md §2:
 *   exit 0 retired/idempotent-200 (purge still honoured) · 1 local
 *   precondition (self-path before J16c naming the alternative, purge-local
 *   guard, missing id_token, non-TTY without --yes) · 2 not_claimed ·
 *   3 forbidden · 4 unreachable.
 * E1: --nkey passes through in EITHER form (server canonicalizes; the CLI
 * never converts); canonical_nkey in --json is the SERVER's `retired`.
 *
 * store.js is fully mocked (loadCredentials/clear*); the HTTP client is
 * injected as a stub — no network, no fs writes.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("node:fs", () => ({
  existsSync: vi.fn(() => false),
}));

vi.mock("../../src/lib/store.js", () => ({
  loadCredentials: vi.fn().mockResolvedValue(null),
  clearCredentials: vi.fn().mockResolvedValue(undefined),
  clearPendingFlag: vi.fn().mockResolvedValue(undefined),
  credentialFileTiers: vi.fn(() => ["/home/testuser/.config/vclaw/credentials.json"]),
  pendingFlagPaths: vi.fn(() => ["/home/testuser/.config/vclaw/.pending"]),
  configFilePaths: vi.fn(() => ["/home/testuser/.config/vclaw/config.json"]),
}));

import { retire } from "../../src/commands/retire.js";
import { existsSync } from "node:fs";
import type { RetireResult } from "../../src/lib/vgate.js";

const mockedLoadCredentials = vi.mocked((await import("../../src/lib/store.js")).loadCredentials);
const mockedClearCredentials = vi.mocked((await import("../../src/lib/store.js")).clearCredentials);
const mockedClearPendingFlag = vi.mocked((await import("../../src/lib/store.js")).clearPendingFlag);
const mockedExistsSync = vi.mocked(existsSync);

/** Local identity fixture — BOTH forms on disk (public_key U-form,
 *  agent_nkey base64url status surface; onboard.ts:133-135). */
const LOCAL = {
  seed: "SAA".padEnd(58, "0"),
  public_key: "ULOCALAGENTPUBKEY000000000000000000000000000000000",
  agent_nkey: "b64url_LOCALAGENTrawpubAAAAAAAAAAAAAAAAAAAAAAA",
  name: "test-agent",
  steward: "steward@example.com",
  created_at: "2026-09-16T00:00:00Z",
};

const U_OTHER = "UOTHERAGENTPUBKEY0000000000000000000000000000000000";

function stubClient(result: RetireResult) {
  const retireAgent = vi.fn().mockResolvedValue(result);
  return { client: { retireAgent }, retireAgent };
}

beforeEach(() => {
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
  delete process.env.VCLAW_ID_TOKEN;
  // Named target for every default-path test (the §2 preflight guard requires
  // an explicitly named target in non-interactive runs).
  process.env.VCLAW_API_URL = "http://harness.test";
  mockedLoadCredentials.mockResolvedValue(null);
  mockedClearCredentials.mockClear();
  mockedClearPendingFlag.mockClear();
  mockedExistsSync.mockReturnValue(false);
});

afterEach(() => {
  vi.restoreAllMocks();
  delete process.env.VCLAW_API_URL;
  delete process.env.VCHAT_API_URL;
  delete process.env.VGATE_URL;
  delete process.env.API_URL;
});

describe("§2 preflight — target guard (fail closed onto the built-in default)", () => {
  it("no named target + --yes: refuses (exit 1), names the cure, sends nothing", async () => {
    delete process.env.VCLAW_API_URL;
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(out.message).toContain("built-in default");
    expect(out.message).toContain("VCLAW_API_URL");
    expect(retireAgent).not.toHaveBeenCalled();
  });

  it("no named target + non-TTY without --yes: also refuses (non-interactive)", async () => {
    delete process.env.VCLAW_API_URL;
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(retireAgent).not.toHaveBeenCalled();
  });

  it("bare legacy VGATE_URL (unrecognized name) does NOT count as named — refuses (no warning: the run never proceeds)", async () => {
    delete process.env.VCLAW_API_URL;
    process.env.VGATE_URL = "http://harness.test"; // WRONG namespace — ignored by env()
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(retireAgent).not.toHaveBeenCalled();
    // namedTarget is false here, so the warning (which fires only when a run
    // PROCEEDS on a named target) must NOT appear — refusal is the signal.
    expect(console.error).not.toHaveBeenCalledWith(expect.stringContaining("NOT read by this SDK"));
  });

  it("legacy warning FIRES when a named target also exists (the run proceeds) — asserted, because its failure mode is silence", async () => {
    // VCLAW_API_URL present (named → proceeds) + a bare legacy name present:
    // the run must succeed AND warn that the legacy name is being ignored —
    // the warning exists to stop silence reading as "applied", so it gets an
    // explicit expect (implicit exercise lets it regress to nothing).
    process.env.VGATE_URL = "http://somewhere-else.test";
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
    expect(out.code).toBe(0);
    expect(retireAgent).toHaveBeenCalledTimes(1);
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining("VGATE_URL is NOT read by this SDK"),
    );
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining("it is being ignored"),
    );
  });

  it("explicitly naming the DEFAULT URL is deliberate and allowed to proceed", async () => {
    process.env.VCLAW_API_URL = "https://api.vclawhub.com"; // named == deliberate
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
    expect(out.code).toBe(0);
    expect(retireAgent).toHaveBeenCalledTimes(1);
  });

  it("opts.targetUrl counts as named (test/CI injection)", async () => {
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", targetUrl: "http://harness.test", client });
    expect(out.code).toBe(0);
    expect(retireAgent).toHaveBeenCalledTimes(1);
  });
});

describe("local preconditions (exit 1, checked before any network)", () => {
  it("no --nkey: self-path before J16c, naming the alternative verbatim", async () => {
    const out = await retire({ yes: true, idToken: "tok" });
    expect(out.code).toBe(1);
    expect(out.message).toContain("self-retire lands with J16c");
    expect(out.message).toContain("--nkey <pub> with a steward session");
  });

  it("--purge-local with NO local identity: refused, nothing sent", async () => {
    const { client, retireAgent } = stubClient({ ok: true, retired: LOCAL.public_key, audit_id: "a.b" });
    const out = await retire({ nkey: LOCAL.public_key, purgeLocal: true, yes: true, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(out.message).toContain("--purge-local refused");
    expect(retireAgent).not.toHaveBeenCalled();
  });

  it("--purge-local on SOMEONE ELSE's nkey (both local forms mismatched): refused, nothing sent", async () => {
    mockedLoadCredentials.mockResolvedValue(LOCAL);
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a.b" });
    const out = await retire({ nkey: U_OTHER, purgeLocal: true, yes: true, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(out.message).toContain("refused");
    expect(out.message).toContain(LOCAL.name);
    expect(retireAgent).not.toHaveBeenCalled(); // the ORDER guarantee: no server call either
  });

  it("missing id_token: names VCLAW_ID_TOKEN, nothing sent", async () => {
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a.b" });
    const out = await retire({ nkey: U_OTHER, yes: true, client });
    expect(out.code).toBe(1);
    expect(out.message).toContain("VCLAW_ID_TOKEN");
    expect(retireAgent).not.toHaveBeenCalled();
  });

  it("non-TTY without --yes: refused (vitest stdin is not a TTY)", async () => {
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a.b" });
    const out = await retire({ nkey: U_OTHER, idToken: "tok", client });
    expect(out.code).toBe(1);
    expect(out.message).toContain("--yes");
    expect(retireAgent).not.toHaveBeenCalled();
  });
});

describe("server call shape", () => {
  it("sends the raw caller-supplied key form + confirm:true + reason, Bearer token from env", async () => {
    process.env.VCLAW_ID_TOKEN = "env-tok";
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "audit.x" });
    const out = await retire({ nkey: LOCAL.agent_nkey, reason: "ci validation 2026", yes: true, client });
    expect(retireAgent).toHaveBeenCalledWith({
      nkey: LOCAL.agent_nkey, // base64url passed through — the SERVER canonicalizes (E1)
      reason: "ci validation 2026",
      confirm: true,
      idToken: "env-tok",
    });
    expect(out.code).toBe(0);
  });

  it("reason defaults to decommissioned — never compromised", async () => {
    const { client, retireAgent } = stubClient({ ok: true, retired: U_OTHER, audit_id: "a" });
    await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
    expect(retireAgent.mock.calls[0][0].reason).toBe("decommissioned");
  });
});

describe("success (fresh and idempotent 200 are indistinguishable by design)", () => {
  it("code 0, --json shape {retired, audit_id, tombstone, canonical_nkey, cleaned[]} — canonical from the SERVER", async () => {
    const { client } = stubClient({ ok: true, retired: U_OTHER, audit_id: "vgate.audit.agent.retired.UOTHER" });
    const out = await retire({ nkey: LOCAL.agent_nkey, yes: true, idToken: "tok", json: true, client });
    expect(out.code).toBe(0);
    // E1a: canonical_nkey = the server's canonical U-form answer, even though
    // the caller passed base64url — CI asserts vchat_retired.<canonical_nkey>.
    expect(out.json?.canonical_nkey).toBe(U_OTHER);
    expect(out.json?.retired).toBe(U_OTHER);
    expect(out.json?.audit_id).toBe("vgate.audit.agent.retired.UOTHER");
    expect(out.json?.tombstone).toBe(`vchat_retired.${U_OTHER}`);
    expect(out.json?.target).toBe("http://harness.test");
    expect(out.json?.cleaned).toEqual([]);
    expect(console.log).toHaveBeenCalledWith(expect.stringContaining("vgate.audit.agent.retired.UOTHER"));
  });

  it("--purge-local allowed via EITHER local form; runs only AFTER server success; cleaned lists removed files", async () => {
    mockedLoadCredentials.mockResolvedValue(LOCAL);
    mockedExistsSync.mockImplementation((p: unknown) =>
      p === "/home/testuser/.config/vclaw/credentials.json" || p === "/home/testuser/.config/vclaw/config.json",
    );
    const { client } = stubClient({ ok: true, retired: LOCAL.public_key, audit_id: "a.b" });
    // caller uses the base64url form — matches agent_nkey locally, canonical U-form returned
    const out = await retire({
      nkey: LOCAL.agent_nkey, purgeLocal: true, yes: true, idToken: "tok", json: true, client,
    });
    expect(out.code).toBe(0);
    expect(mockedClearCredentials).toHaveBeenCalledTimes(1);
    expect(mockedClearPendingFlag).toHaveBeenCalledTimes(1);
    expect(out.json?.cleaned).toEqual([
      "/home/testuser/.config/vclaw/credentials.json",
      "/home/testuser/.config/vclaw/config.json",
    ]);
  });

  it("purge also honoured on a TTY-confirmed run via public_key (U-form) match", async () => {
    mockedLoadCredentials.mockResolvedValue(LOCAL);
    const { client } = stubClient({ ok: true, retired: LOCAL.public_key, audit_id: "a.b" });
    const out = await retire({ nkey: LOCAL.public_key, purgeLocal: true, yes: true, idToken: "tok", client });
    expect(out.code).toBe(0);
    expect(mockedClearCredentials).toHaveBeenCalledTimes(1);
  });
});

describe("failure mapping (§2 exit codes)", () => {
  const cases: Array<[RetireResult, 0 | 1 | 2 | 3 | 4, string]> = [
    [{ ok: false, status: 404, error: "not_claimed", message: "no claimed agent with this nkey" }, 2, "sweeper"],
    [{ ok: false, status: 403, error: "forbidden_role", message: "only the agent's steward" }, 3, "forbidden"],
    [{ ok: false, status: 401, error: "unauthorized", message: "invalid id_token: exp" }, 1, "VCLAW_ID_TOKEN"],
    [{ ok: false, status: 400, error: "confirm_required", message: "retirement requires confirm:true" }, 1, "client error"],
    [{ ok: false, status: 0, error: "unreachable", message: "fetch failed" }, 4, "unreachable"],
    [{ ok: false, status: 503, error: "http_503", message: "boom" }, 4, "did not complete"],
  ];

  for (const [result, wantCode, wantText] of cases) {
    it(`${result.status === 0 ? "network" : `HTTP ${result.status}`} → exit ${wantCode}`, async () => {
      const { client } = stubClient(result);
      const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", client });
      expect(out.code).toBe(wantCode);
      expect(out.message).toContain(wantText);
    });
  }

  it("failures never purge (ORDER: purge strictly after server success)", async () => {
    mockedLoadCredentials.mockResolvedValue(LOCAL);
    const { client } = stubClient({ ok: false, status: 403, error: "forbidden_role", message: "no" });
    const out = await retire({ nkey: LOCAL.public_key, purgeLocal: true, yes: true, idToken: "tok", client });
    expect(out.code).toBe(3);
    expect(mockedClearCredentials).not.toHaveBeenCalled();
  });

  it("--json failure prints {code, error}", async () => {
    const { client } = stubClient({ ok: false, status: 404, error: "not_claimed", message: "none" });
    const out = await retire({ nkey: U_OTHER, yes: true, idToken: "tok", json: true, client });
    expect(out.code).toBe(2);
    expect(console.log).toHaveBeenCalledWith(expect.stringContaining('"code": 2'));
    expect(out.json).toBeUndefined();
  });
});
