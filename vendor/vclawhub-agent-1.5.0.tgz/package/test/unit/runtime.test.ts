/**
 * B4 — src/agent/runtime.ts unit tests (spec §5 gate 3).
 *
 * Covers the shared-runtime contract: identity helpers, the three connect
 * paths (prod-JWT / dev-nkey / dev-plain), gate construct-vs-skip, the
 * presence pass-through (plain + gate-function form), and close ordering
 * (presence.stop → drain → close). lifecycle/contracts/capabilities/
 * transport-node are mocked — no network, no timers.
 */
import { describe, it, expect, beforeEach, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  connectViaJWT: vi.fn(),
  connectViaNKey: vi.fn(),
  startPresence: vi.fn(),
  setTenantSegment: vi.fn(),
  plainConnect: vi.fn(),
}));

vi.mock("../../src/agent/lifecycle.js", () => ({
  connectViaJWT: mocks.connectViaJWT,
  connectViaNKey: mocks.connectViaNKey,
  startPresence: mocks.startPresence,
}));
vi.mock("../../src/contracts/contracts.js", () => ({
  setTenantSegment: mocks.setTenantSegment,
}));
vi.mock("@nats-io/transport-node", () => ({
  connect: mocks.plainConnect,
}));

import {
  identityFromCreds,
  devEphemeralIdentity,
  startAgentRuntime,
} from "../../src/agent/runtime.js";
import { OnlineGate } from "../../src/net/capabilities.js";

/** Fake nc recording drain/close order. */
function fakeNc() {
  const calls: string[] = [];
  return {
    calls,
    info: { client_id: 42 },
    drain: vi.fn(async () => { calls.push("drain"); }),
    close: vi.fn(async () => { calls.push("close"); }),
  };
}
function fakePresence(calls: string[]) {
  return {
    stop: vi.fn(async () => { calls.push("presence.stop"); }),
    reannounce: vi.fn(async () => {}),
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  delete process.env.VCHAT_SEGMENT;
  delete process.env.VCHAT_AGENT_LLM;
});

describe("identityFromCreds", () => {
  it("prefers public_key and falls back through name/nkey", () => {
    expect(identityFromCreds({ public_key: "PUB", agent_nkey: "LEG", name: "n", steward: "s" }))
      .toEqual({ nkey: "PUB", nonce: "n", owner: "s" });
    expect(identityFromCreds({ agent_nkey: "LEG" }))
      .toEqual({ nkey: "LEG", nonce: "LEG", owner: "" });
  });
});

describe("devEphemeralIdentity", () => {
  it("returns an SU seed and a user-prefixed nkey", () => {
    const { identity, seed } = devEphemeralIdentity();
    expect(seed).toMatch(/^SU/);
    expect(identity.nonce).toBe("dev-agent");
    expect(identity.nkey.startsWith("U")).toBe(true);
  });
});

describe("startAgentRuntime — prod path", () => {
  it("switches segment, connects via JWT provider, builds gate + presence", async () => {
    const nc = fakeNc();
    const presence = fakePresence(nc.calls);
    mocks.connectViaJWT.mockResolvedValue(nc);
    mocks.startPresence.mockReturnValue(presence);

    const identity = { nkey: "PUB", nonce: "n", owner: "s" };
    const presenceOpts = { seed: "SUxx" };
    const rt = await startAgentRuntime({
      connName: "agent-s1",
      identity,
      seed: "SUxx",
      server: "nats://x:4223",
      jwtProvider: () => "JWT1",
      presence: presenceOpts,
    });

    expect(mocks.setTenantSegment).toHaveBeenCalledWith("vchat"); // default
    expect(mocks.connectViaJWT).toHaveBeenCalledWith("nats://x:4223", expect.any(Function), "SUxx", "agent-s1");
    // Provider passes the CURRENT token through.
    expect((mocks.connectViaJWT.mock.calls[0] as unknown[])[1]()).toBe("JWT1");
    expect(rt.gate).toBeInstanceOf(OnlineGate);
    // J8: the presence segment is DEFAULT-FILLED with the runtime's RESOLVED
    // segment ("JWT1" is not a decodable JWT → no server segment → fallback).
    expect(mocks.startPresence).toHaveBeenCalledWith(nc, identity, { ...presenceOpts, segment: "vchat" });
    expect(rt.segment).toBe("vchat");
    expect(rt.segmentSource).toBe("fallback");
    expect(rt.presence).toBe(presence);

    await rt.close();
    expect(nc.calls).toEqual(["presence.stop", "drain", "close"]);
  });

  it("respects explicit segment over env/default", async () => {
    mocks.connectViaJWT.mockResolvedValue(fakeNc());
    process.env.VCHAT_SEGMENT = "envseg";
    await startAgentRuntime({ connName: "c", identity: { nkey: "P", nonce: "n", owner: "" }, seed: "S", server: "s", jwtProvider: () => "J", segment: "s1" });
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("s1");
    // no presence opts → no presence, close still safe
  });
});

describe("startAgentRuntime — dev paths", () => {
  it("dev nkey: connectViaNKey with the decoded seed", async () => {
    const nc = fakeNc();
    mocks.connectViaNKey.mockResolvedValue(nc);
    const { identity, seed } = devEphemeralIdentity();
    const rt = await startAgentRuntime({
      connName: "agent-d", identity, seed,
      dev: { auth: "nkey", server: "nats://127.0.0.1:14223" },
    });
    expect(mocks.connectViaNKey).toHaveBeenCalledWith(
      "nats://127.0.0.1:14223",
      expect.any(Uint8Array),
      "agent-d",
    );
    expect(mocks.connectViaJWT).not.toHaveBeenCalled();
    expect(rt.gate).toBeInstanceOf(OnlineGate); // CLI-style: gate in dev too
    await rt.close();
  });

  it("dev plain + skipGate: transport-node connect, gate null, presence online=true", async () => {
    const nc = fakeNc();
    const presence = fakePresence(nc.calls);
    mocks.plainConnect.mockResolvedValue(nc);
    mocks.startPresence.mockReturnValue(presence);

    let onlineFn: () => Promise<boolean> | boolean = () => false;
    const rt = await startAgentRuntime({
      connName: "pi-dev", identity: { nkey: "U1", nonce: "dev-agent", owner: "" }, seed: "SUd",
      dev: { auth: "plain", server: "127.0.0.1:4222" },
      skipGate: true,
      presence: (gate) => {
        expect(gate).toBeNull();
        return {
          seed: "SUd",
          online: (onlineFn = async () => true),
        };
      },
    });
    expect(mocks.plainConnect).toHaveBeenCalledWith({ servers: ["127.0.0.1:4222"] });
    expect(rt.gate).toBeNull();
    // The ext's hermetic provider shape resolves through the function form.
    expect(mocks.startPresence).toHaveBeenCalledWith(nc, rt.identity, expect.objectContaining({ seed: "SUd" }));
    await expect((onlineFn as () => Promise<boolean>)()).resolves.toBe(true);
    await rt.close();
  });
});

describe("startAgentRuntime — guards", () => {
  it("throws without server+jwtProvider in prod mode", async () => {
    await expect(startAgentRuntime({
      connName: "c", identity: { nkey: "P", nonce: "n", owner: "" }, seed: "S",
    })).rejects.toThrow(/server \+ jwtProvider/);
  });
});
