/**
 * J8 — SEGMENT ADOPTION (the unit half of the keystone fix).
 *
 * THE DEFECT (measured 2026-10-02): a freshly-claimed agent's issued NATS JWT
 * grants `tenant.default.*` (the callout falls back to the configured tenant
 * when the ownership row carries no segment), while the client pinned
 * `segment || env || "vchat"` before connecting → every subscription denied
 * (alive but deaf), or (with the pre-J8 check) an unattended host died with a
 * demand to set VCLAW_SEGMENT instead of connecting.
 *
 * THE FIX under test: ONE order, applied before any subscribe/publish —
 *   1. explicit (opts.segment || VCLAW_SEGMENT/VCHAT_SEGMENT)
 *   2. the SERVER's segment, decoded from the issued JWT's `tenant.<seg>.*` grants
 *   3. "vchat" as the LAST resort (only when the server says nothing legible)
 * An explicit value that CONTRADICTS the server's grant still THROWS.
 *
 * Two kinds of test here:
 *  (a) behavioural — the decoder, the pure resolver, and startAgentRuntime with
 *      a mocked transport (no network);
 *  (b) STRUCTURAL (source scan) — the old order must not survive anywhere, and
 *      the count of setTenantSegment call sites is pinned.
 */
import { describe, it, expect, beforeEach, vi } from "vitest";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));

const mocks = vi.hoisted(() => ({
  connectViaJWT: vi.fn(),
  connectViaNKey: vi.fn(),
  startPresence: vi.fn(),
  setTenantSegment: vi.fn(),
}));

vi.mock("../../src/agent/lifecycle.js", () => ({
  connectViaJWT: mocks.connectViaJWT,
  connectViaNKey: mocks.connectViaNKey,
  startPresence: mocks.startPresence,
}));
vi.mock("../../src/contracts/contracts.js", () => ({
  setTenantSegment: mocks.setTenantSegment,
}));
vi.mock("@nats-io/transport-node", () => ({
  connect: vi.fn(async () => ({ info: { client_id: 9 }, drain: vi.fn(), close: vi.fn() })),
}));

import {
  FALLBACK_SEGMENT,
  decodeJwtPayload,
  resolveTenantSegment,
  serverSegmentFromJWT,
  startAgentRuntime,
} from "../../src/agent/runtime.js";

// ── JWT fixtures ───────────────────────────────────────────────────────────

const b64url = (o: unknown): string => Buffer.from(JSON.stringify(o), "utf8").toString("base64url");
const makeJWT = (payload: unknown, sig = "signature-not-verified"): string =>
  `${b64url({ typ: "JWT", alg: "ed25519-nkey" })}.${b64url(payload)}.${sig}`;

/**
 * A REAL vgate-shaped claimed-agent user JWT (token.go DeriveClaimedPermissions):
 * `nats.{pub,sub} = { allow: [...], deny: [...] }` — the shape the pre-J8 check
 * mis-read (it took Object.keys of nats.pub and saw "allow"/"deny").
 */
function claimedJWT(segment: string, nkey = "UAGENT"): string {
  const pub = [
    `$SRV.INFO.agents.${segment}.${nkey}`,
    `tenant.${segment}.user.${nkey}.agent.${nkey}.>`,
    `tenant.${segment}.a2a.>`,
    `tenant.${segment}.policy.>`,
    "_INBOX.>",
  ];
  const sub = [
    `$SRV.INFO.agents.${segment}.>`,
    `tenant.${segment}.user.${nkey}.agent.${nkey}.>`,
    `tenant.${segment}.a2a.${nkey}.>`,
    `tenant.${segment}.agent.retired.${nkey}`,
    "$KV.vchat_roster.>",
    "_INBOX.>",
  ];
  return makeJWT({
    jti: "jti", iat: 1, iss: "AACCOUNT", sub: nkey,
    nats: { type: "user", version: 2, pub: { allow: pub, deny: ["$SYS.>"] }, sub: { allow: sub, deny: ["$SYS.>"] } },
  });
}

/** A SITE_MESH user JWT (V3.1): grants `agents.*.<site-id>.*`, zero tenant grants. */
function siteMeshJWT(): string {
  return makeJWT({
    jti: "j2", iat: 1, iss: "AACC", sub: "USITE",
    nats: {
      type: "user", version: 2,
      pub: { allow: ["agents.prompt.*.USITE.>", "agents.hb.*.USITE.>", "_INBOX.>"], deny: ["$SYS.>"] },
      sub: { allow: ["agents.hb.>", "agents.prompt.*.USITE.>", "_INBOX.>"], deny: ["$SYS.>"] },
    },
  });
}

function fakeNc() {
  return { info: { client_id: 7 }, drain: vi.fn(async () => {}), close: vi.fn(async () => {}) };
}
function fakePresence() {
  return { stop: vi.fn(async () => {}), reannounce: vi.fn(async () => {}) };
}

beforeEach(() => {
  vi.clearAllMocks();
  delete process.env.VCLAW_SEGMENT;
  delete process.env.VCHAT_SEGMENT;
  delete process.env.VCLAW_AGENT_LLM;
  delete process.env.VCHAT_AGENT_LLM;
  mocks.connectViaJWT.mockResolvedValue(fakeNc());
});

// ── (a1) the decoder ───────────────────────────────────────────────────────

describe("serverSegmentFromJWT — the server is the source of truth", () => {
  it("reads the segment out of a REAL vgate-shaped JWT (nats.pub.allow / nats.sub.allow)", () => {
    expect(serverSegmentFromJWT(claimedJWT("default"))).toBe("default");
    expect(serverSegmentFromJWT(claimedJWT("vchat"))).toBe("vchat");
    expect(serverSegmentFromJWT(claimedJWT("vclaw-site-1"))).toBe("vclaw-site-1");
  });

  it("reads the early flat draft shape (nats.permissions as a subject map)", () => {
    const jwt = makeJWT({ nats: { permissions: { pub: { "tenant.vchat.user.U.agent.U.>": { allow: ["x"] } } } } });
    expect(serverSegmentFromJWT(jwt)).toBe("vchat");
    const jwt2 = makeJWT({ nats: { permissions: { "tenant.default.a2a.>": {} } } });
    expect(serverSegmentFromJWT(jwt2)).toBe("default");
  });

  it("returns \"\" when the JWT carries no tenant subject (site-mesh grants)", () => {
    expect(serverSegmentFromJWT(siteMeshJWT())).toBe("");
  });

  it("returns \"\" for a malformed payload (garbage / truncated / non-JSON / bad base64)", () => {
    expect(serverSegmentFromJWT("")).toBe("");
    expect(serverSegmentFromJWT("JWT1")).toBe("");                       // not a 3-part JWT
    expect(serverSegmentFromJWT("a.b")).toBe("");
    expect(serverSegmentFromJWT("aaa.bbb.ccc")).toBe("");                // payload not JSON
    expect(serverSegmentFromJWT(makeJWT({ nats: "not-an-object" }))).toBe("");   // nats present but not a grant object
    expect(serverSegmentFromJWT(makeJWT({ nats: {} }))).toBe("");
    expect(serverSegmentFromJWT(makeJWT({ nats: { pub: { allow: [] }, sub: { allow: [] } } }))).toBe("");
    expect(serverSegmentFromJWT(undefined as unknown as string)).toBe("");
    expect(serverSegmentFromJWT(null as unknown as string)).toBe("");
  });

  it("does NOT accept the unsubstituted <segment> placeholder as a segment", () => {
    expect(serverSegmentFromJWT(makeJWT({ nats: { pub: { allow: ["tenant.<segment>.a2a.>"] } } }))).toBe("");
  });

  it("takes the FIRST granted tenant subject (primary segment on a multi-grant JWT)", () => {
    expect(serverSegmentFromJWT(makeJWT({
      nats: {
        pub: { allow: ["tenant.default.user.U.agent.U.>", "tenant.vclaw.a2a.>"] },
        sub: { allow: ["tenant.vclaw.>", "tenant.default.>"] },
      },
    }))).toBe("default");
  });

  it("exposes the payload decoder separately (null on anything malformed)", () => {
    expect(decodeJwtPayload(claimedJWT("vchat"))?.["nats"]).toBeTruthy();
    expect(decodeJwtPayload("nope.nope")).toBeNull();
    expect(decodeJwtPayload("a.b.c")).toBeNull();
    expect(decodeJwtPayload(undefined)).toBeNull();
  });
});

// ── (a2) the pure resolver: the ORDER ──────────────────────────────────────

describe("resolveTenantSegment — explicit → server → fallback", () => {
  it("1. an explicit segment WINS (and agrees): source=explicit", () => {
    expect(resolveTenantSegment({ explicit: "vchat", serverSegment: "vchat" }))
      .toMatchObject({ segment: "vchat", source: "explicit" });
    // explicit + server says nothing → still explicit
    expect(resolveTenantSegment({ explicit: "vchat", serverSegment: "" }))
      .toMatchObject({ segment: "vchat", source: "explicit" });
  });

  it("1b. an explicit segment that CONTRADICTS the server is a MISMATCH (never overridden)", () => {
    const r = resolveTenantSegment({ explicit: "vchat", serverSegment: "default" });
    expect(r.mismatch).toEqual({ explicit: "vchat", server: "default" });
    expect(r.source).toBe("explicit");
  });

  it("2. NO explicit segment → ADOPT the server's (the defect case)", () => {
    expect(resolveTenantSegment({ explicit: undefined, serverSegment: "default" }))
      .toEqual({ segment: "default", source: "server", serverSegment: "default" });
  });

  it("3. neither → the last-resort fallback, NOT an effective default", () => {
    const r = resolveTenantSegment({});
    expect(r.segment).toBe(FALLBACK_SEGMENT);
    expect(r.source).toBe("fallback");
    expect(FALLBACK_SEGMENT).toBe("vchat"); // pinned: the only literal left
  });

  it("trims/normalises an empty explicit choice away (env set but empty)", () => {
    expect(resolveTenantSegment({ explicit: "  ", serverSegment: "default" }).segment).toBe("default");
    expect(resolveTenantSegment({ explicit: " default ", serverSegment: "default" })).toMatchObject({ source: "explicit" });
  });
});

// ── (a3) startAgentRuntime: the adoption + contradiction, end to end (mocked transport) ──

describe("startAgentRuntime — segment adoption (ACCEPTANCE 1 + 3)", () => {
  const base = { connName: "agent-s1", identity: { nkey: "UAGENT", nonce: "n", owner: "s" }, seed: "SUxx", server: "nats://x:4223" };

  it("ACCEPTANCE 1+3: NO env var + a tenant.default.* JWT → connects on `default` (was: threw)", async () => {
    const jwt = claimedJWT("default");
    const rt = await startAgentRuntime({ ...base, jwtProvider: () => jwt });
    // ACCEPTANCE 3 — assert the VALUE, not that a decode ran.
    expect(serverSegmentFromJWT(jwt)).toBe("default");
    expect(rt.segment).toBe("default");
    expect(rt.segmentSource).toBe("server");
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("default");
    expect(mocks.connectViaJWT).toHaveBeenCalledTimes(1);
    // the SAME cached JWT the segment was read from is the one presented
    const presented = (mocks.connectViaJWT.mock.calls[0] as unknown[])[1] as () => string;
    expect(presented()).toBe(jwt);
  });

  it("ACCEPTANCE 2 (negative control): the SAME identity + VCLAW_SEGMENT=vchat still THROWS", async () => {
    process.env.VCLAW_SEGMENT = "vchat";
    await expect(startAgentRuntime({ ...base, jwtProvider: () => claimedJWT("default") }))
      .rejects.toThrow(/Segment mismatch: explicit "vchat" contradicts the server's JWT grant "tenant\.default\.\*"/);
    expect(mocks.connectViaJWT).not.toHaveBeenCalled();
    expect(mocks.setTenantSegment).not.toHaveBeenCalled();
  });

  it("the VCHAT_SEGMENT legacy alias is the same explicit choice (still throws)", async () => {
    process.env.VCHAT_SEGMENT = "vchat";
    await expect(startAgentRuntime({ ...base, jwtProvider: () => claimedJWT("default") })).rejects.toThrow(/Segment mismatch/);
  });

  it("opts.segment is an explicit choice too (agreement is fine, no throw)", async () => {
    const rt = await startAgentRuntime({ ...base, segment: "default", jwtProvider: () => claimedJWT("default") });
    expect(rt.segment).toBe("default");
    expect(rt.segmentSource).toBe("explicit");
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("default");
  });

  it("an undecodable JWT keeps the old behaviour: connect on the fallback, do not throw", async () => {
    const rt = await startAgentRuntime({ ...base, jwtProvider: () => "JWT1" });
    expect(rt.segment).toBe(FALLBACK_SEGMENT);
    expect(rt.segmentSource).toBe("fallback");
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("vchat");
  });

  it("the presence segment follows the RESOLVED segment (plain object gets it filled)", async () => {
    const presence = fakePresence();
    mocks.startPresence.mockReturnValue(presence);
    await startAgentRuntime({ ...base, jwtProvider: () => claimedJWT("default"), presence: { seed: "SUxx" } });
    expect(mocks.startPresence).toHaveBeenCalledWith(
      expect.anything(), base.identity, { seed: "SUxx", segment: "default" },
    );
  });

  it("the presence FUNCTION form receives the resolved segment as its 2nd arg", async () => {
    const seen: string[] = [];
    mocks.startPresence.mockReturnValue(fakePresence());
    await startAgentRuntime({
      ...base, jwtProvider: () => claimedJWT("vclaw"), presence: (_gate, segment) => { seen.push(segment); return { seed: "SUxx" }; },
    });
    expect(seen).toEqual(["vclaw"]);
    expect(mocks.startPresence).toHaveBeenCalledWith(expect.anything(), base.identity, { seed: "SUxx", segment: "vclaw" });
  });

  it("dev mode never reads a JWT provider for the segment decision", async () => {
    const provider = vi.fn(() => claimedJWT("default"));
    const rt = await startAgentRuntime({
      connName: "agent-d", identity: base.identity, seed: base.seed,
      dev: { auth: "plain", server: "127.0.0.1:4222" }, skipGate: true, jwtProvider: provider,
    });
    expect(provider).not.toHaveBeenCalled();
    expect(rt.segment).toBe(FALLBACK_SEGMENT);
  });
});

// ── (b) STRUCTURAL: the old order must not survive (ACCEPTANCE 4) ──────────

function tsFiles(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) tsFiles(p, out);
    else if (p.endsWith(".ts")) out.push(p);
  }
  return out;
}

describe("STRUCTURAL — segment assignment sites (the verifier's grep acceptance)", () => {
  const srcRoot = join(HERE, "..", "..", "src");
  const files = tsFiles(srcRoot).map((f) => ({ f, rel: relative(srcRoot, f), text: readFileSync(f, "utf8") }));

  /** Source with comments removed — the doc comments QUOTE the old order. */
  const stripComments = (t: string): string =>
    t.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/[^\n]*/g, "$1");

  it("exactly ONE setTenantSegment CALL site, fed by resolveTenantSegment (was TWO before the rpc sidecar was deleted 2026-10-24)", () => {
    const calls = files
      .filter(({ text }) => /^\s*setTenantSegment\(/m.test(stripComments(text)))
      .map(({ rel }) => rel).sort();
    expect(calls).toEqual(["agent/runtime.ts"]);
    for (const { rel, text } of files) {
      const code = stripComments(text);
      if (!/^\s*setTenantSegment\(/m.test(code)) continue;
      expect(code, rel).toMatch(/resolveTenantSegment\(/);
    }
  });

  it("NO site keeps the old `|| \"vchat\"` / `?? \"vchat\"` order", () => {
    for (const { rel, text } of files) {
      const code = stripComments(text);
      expect(code, rel).not.toMatch(/env\("SEGMENT"\)\s*\|\|\s*"vchat"/);
      expect(code, rel).not.toMatch(/\|\|\s*"vchat"/);
      expect(code, rel).not.toMatch(/\?\?\s*"vchat"/);
    }
  });

  it("the literal \"vchat\" survives as ONE assignment: FALLBACK_SEGMENT in runtime.ts", () => {
    const assignments = files
      .flatMap(({ rel, text }) => stripComments(text).split("\n").map((l) => ({ rel, l })))
      .filter(({ l }) => /= *"vchat"/.test(l))
      .map(({ rel, l }) => `${rel}: ${l.trim()}`);
    expect(assignments).toEqual(['agent/runtime.ts: export const FALLBACK_SEGMENT = "vchat";']);
  });

  it("the two ENTRY paths do not bake an explicit \"vchat\" (they pass only a real choice)", () => {
    const start = files.find((f) => f.rel === "commands/start.ts")!;
    const ext = files.find((f) => f.rel === "pi-extension/index.ts")!;
    // explicit source is the raw env read (start) / session default (rpc), not a literal
    expect(stripComments(start.text)).toMatch(/const explicitSegment = env\("SEGMENT"\);/);
    expect(stripComments(ext.text)).toMatch(/const SEGMENT = env\("SEGMENT"\);/);
    // both read the RESOLVED value back out of the runtime
    expect(stripComments(ext.text)).toMatch(/const segment = rt\.segment;/);
    expect(stripComments(start.text)).toMatch(/presence: wantPresence\s*\?\s*\(gate, segment\)/);
  });
});
