/**
 * mint-nats-user-jwt.test.ts — v9 W0.5 scope 1 unit coverage.
 *
 * The client_assertion build is exercised OFFLINE through the PRODUCTION
 * function (src/agent/lifecycle.ts fetchNatsUserJWT — the same code path the
 * mint helper calls; fetch is stubbed, no network). Asserts the full vgate
 * wire format: POST /v1/agent/token, grant_type=client_credentials, and a
 * 3-part client_assertion whose header/payload claims are correct and whose
 * ed25519 signature VERIFIES against the public NKey (real crypto, offline).
 *
 * Also covers the helper surface: vgate-URL precedence (start.ts order),
 * credentials loading (--creds path + canonical tiers via VCLAW_CREDS_DIR),
 * and the real-key-not-legacy-id principal rule.
 */
import { describe, it, expect, afterEach, vi } from "vitest";
import { nkeys } from "@nats-io/nats-core";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fetchNatsUserJWT } from "../../src/agent/lifecycle.js";
import {
  mintNatsUserJwt,
  readCredentials,
  resolveVgateUrl,
  DEFAULT_VGATE_URL,
} from "../helpers/mint-nats-user-jwt.js";

const b64urlDecode = (s: string) => Buffer.from(s, "base64url").toString("utf8");
const b64urlDecodeBytes = (s: string) => new Uint8Array(Buffer.from(s, "base64url"));

// Real ed25519 keypair (offline signing + verification).
const kp = nkeys.createUser();
const seed = new TextDecoder().decode(kp.getSeed());
const pub = kp.getPublicKey();

const ENV_KEYS = ["VCLAW_API_URL", "VCHAT_API_URL", "VCLAW_VGATE_URL", "VCHAT_VGATE_URL", "VCLAW_CREDS_DIR", "VCHAT_CREDS_DIR"];
afterEach(() => {
  for (const k of ENV_KEYS) delete process.env[k];
  vi.unstubAllGlobals();
  for (const d of tmpDirs) rmSync(d, { recursive: true, force: true });
  tmpDirs.length = 0;
});
const tmpDirs: string[] = [];
const tmpCredsFile = (body: unknown): string => {
  const d = mkdtempSync(join(tmpdir(), "mint-test-"));
  tmpDirs.push(d);
  const f = join(d, "credentials.json");
  writeFileSync(f, JSON.stringify(body));
  return f;
};
const creds = (over: Record<string, unknown> = {}) => ({
  seed,
  public_key: pub,
  agent_nkey: "LEGACY-SESSION-ID-NOT-A-REAL-PUB",
  name: "test-agent",
  steward: "test@vchat.email",
  created_at: "2026-09-04T00:00:00.000Z",
  ...over,
});

/** Stub global fetch; returns the recorded (url, init) for assertions. */
function stubTokenFetch(opts: { ok?: boolean; status?: number; token?: string } = {}) {
  const { ok = true, status = 200, token = "nats-user-jwt-abc" } = opts;
  const fn = vi.fn(async (_url: string, init?: RequestInit) => ({
    ok,
    status,
    text: async () => (ok ? "" : `denied by policy (status ${status})`),
    json: async () => ({ access_token: token }),
  }));
  vi.stubGlobal("fetch", fn);
  return fn;
}

interface Assertion { header: Record<string, unknown>; payload: Record<string, unknown>; sig: string; signingInput: string; }
function decodeAssertion(assertion: string): Assertion {
  const [h, p, sig] = assertion.split(".");
  expect([h, p, sig].every(Boolean), "assertion must be a 3-part JWT").toBe(true);
  return { header: JSON.parse(b64urlDecode(h)), payload: JSON.parse(b64urlDecode(p)), sig, signingInput: `${h}.${p}` };
}

describe("client_assertion build — offline (W0.5 scope 1 core)", () => {
  it("fetchNatsUserJWT posts a verifiable NKey-signed assertion to /v1/agent/token", async () => {
    const url = "https://vgate.test";
    const fn = stubTokenFetch();
    const token = await fetchNatsUserJWT(url, pub, seed);

    expect(token).toBe("nats-user-jwt-abc");
    expect(fn).toHaveBeenCalledTimes(1);
    const [calledUrl, init] = fn.mock.calls[0] as [string, RequestInit];
    expect(calledUrl).toBe(`${url}/v1/agent/token`);
    expect(init.method).toBe("POST");
    expect((init.headers as Record<string, string>)["Content-Type"]).toBe("application/json");

    const body = JSON.parse(init.body as string) as { client_assertion: string; grant_type: string };
    expect(body.grant_type).toBe("client_credentials");
    const a = decodeAssertion(body.client_assertion);

    // Header + claims (ochat API_specs §5 wire shape).
    expect(a.header).toEqual({ alg: "ed25519-nkey", typ: "JWT" });
    expect(a.payload.iss).toBe(pub);
    expect(a.payload.sub).toBe(pub);
    expect(a.payload.aud).toBe(url);
    expect((a.payload.exp as number) - (a.payload.iat as number)).toBe(300);
    expect(Math.abs((a.payload.iat as number) - Math.floor(Date.now() / 1000))).toBeLessThan(60);
    expect(typeof a.payload.jti).toBe("string");
    expect((a.payload.jti as string).length).toBeGreaterThan(0);

    // Real crypto, offline: the sig verifies over `${header}.${payload}`.
    const verifier = nkeys.fromPublic(pub);
    expect(verifier.verify(new TextEncoder().encode(a.signingInput), b64urlDecodeBytes(a.sig))).toBe(true);
  });

  it("rejects on endpoint error, surfacing the vgate status", async () => {
    stubTokenFetch({ ok: false, status: 401 });
    await expect(fetchNatsUserJWT("https://vgate.test", pub, seed)).rejects.toThrow(/401/);
  });
});

describe("mintNatsUserJwt — real-key principal + delegation", () => {
  it("uses creds.public_key (NOT the legacy agent_nkey) as the assertion iss/sub", async () => {
    const url = "https://vgate.test";
    const fn = stubTokenFetch();
    await mintNatsUserJwt(creds(), url);
    const body = JSON.parse((fn.mock.calls[0][1] as RequestInit).body as string) as { client_assertion: string };
    const a = decodeAssertion(body.client_assertion);
    expect(a.payload.iss).toBe(pub);
    expect(a.payload.iss).not.toBe("LEGACY-SESSION-ID-NOT-A-REAL-PUB");
  });

  it("falls back to agent_nkey when public_key is absent (structural parity with identityFromCreds)", async () => {
    const fn = stubTokenFetch();
    await mintNatsUserJwt(creds({ public_key: undefined }), "https://vgate.test");
    const body = JSON.parse((fn.mock.calls[0][1] as RequestInit).body as string) as { client_assertion: string };
    expect(decodeAssertion(body.client_assertion).payload.iss).toBe("LEGACY-SESSION-ID-NOT-A-REAL-PUB");
  });
});

describe("resolveVgateUrl — start.ts precedence", () => {
  it("defaults to https://api.vclawhub.com", () => {
    expect(resolveVgateUrl()).toBe(DEFAULT_VGATE_URL);
    expect(resolveVgateUrl(undefined)).toBe(DEFAULT_VGATE_URL);
  });

  it("honors env VGATE_URL (VCLAW_ first, VCHAT_ fallback), API_URL checked first (start.ts order)", () => {
    process.env.VCLAW_API_URL = "https://api.example";
    expect(resolveVgateUrl()).toBe("https://api.example");
    delete process.env.VCLAW_API_URL;

    process.env.VCHAT_API_URL = "https://api-legacy.example";
    expect(resolveVgateUrl()).toBe("https://api-legacy.example");
    delete process.env.VCHAT_API_URL;

    process.env.VCLAW_VGATE_URL = "https://vgate.example";
    expect(resolveVgateUrl()).toBe("https://vgate.example");
    delete process.env.VCLAW_VGATE_URL;

    process.env.VCHAT_VGATE_URL = "https://vgate-legacy.example";
    expect(resolveVgateUrl()).toBe("https://vgate-legacy.example");
  });

  it("--vgate-url flag beats every env (and API_URL beats VGATE_URL when both set — start.ts order)", () => {
    process.env.VCLAW_API_URL = "https://api.example";
    process.env.VCLAW_VGATE_URL = "https://vgate.example";
    expect(resolveVgateUrl("https://flag.example")).toBe("https://flag.example");
    expect(resolveVgateUrl()).toBe("https://api.example"); // API_URL first
  });
});

describe("readCredentials", () => {
  it("--creds parses + validates a real keypair file", async () => {
    const f = tmpCredsFile(creds());
    const got = await readCredentials(f);
    expect(got.seed).toBe(seed);
    expect(got.public_key).toBe(pub);
  });

  it("--creds: invalid JSON / bad seed / missing public key each throw a clear error", async () => {
    // RAW text (JSON.stringify would quote it into a VALID json string) — write directly.
    const d0 = mkdtempSync(join(tmpdir(), "mint-badjson-"));
    tmpDirs.push(d0);
    writeFileSync(join(d0, "credentials.json"), "{not json");
    await expect(readCredentials(join(d0, "credentials.json"))).rejects.toThrow(/not valid JSON/);

    const badSeed = tmpCredsFile(creds({ seed: "NOT-A-SEED" }));
    await expect(readCredentials(badSeed)).rejects.toThrow(/invalid seed/);

    const noKey = tmpCredsFile(creds({ public_key: undefined, agent_nkey: undefined }));
    await expect(readCredentials(noKey)).rejects.toThrow(/no public key/);

    await expect(readCredentials(join(tmpdir(), "does-not-exist-xyz.json"))).rejects.toThrow(/cannot read/);
  });

  it("without --creds: reads the canonical tier via store.loadCredentials (CREDS_DIR override)", async () => {
    const d = mkdtempSync(join(tmpdir(), "mint-tier-"));
    tmpDirs.push(d);
    writeFileSync(join(d, "credentials.json"), JSON.stringify(creds()));
    process.env.VCLAW_CREDS_DIR = d;
    const got = await readCredentials();
    expect(got.public_key).toBe(pub);
  });

  it("throws a helpful error when no credentials exist anywhere", async () => {
    // Point CREDS_DIR at an empty temp dir so the canonical tier is hermetic.
    const d = mkdtempSync(join(tmpdir(), "mint-none-"));
    tmpDirs.push(d);
    process.env.VCLAW_CREDS_DIR = d;
    await expect(readCredentials()).rejects.toThrow(/no credentials found/);
  });
});
