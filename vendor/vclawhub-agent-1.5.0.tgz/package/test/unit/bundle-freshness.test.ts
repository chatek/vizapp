/**
 * Bundle freshness marker (Batch A4b, per the tests-lane F3 sketch): a
 * tracked bundle must be AT LEAST as new (same minute counts) as every
 * source file it inlines. A source edit that skips the re-bundle leaves src
 * strictly newer → this fails and names the rebuild command.
 *
 * Minute granularity is deliberate: a fresh clone writes dist/ before src/
 * inside one checkout burst, so ns-level comparison would false-positive on
 * every clean clone; real staleness is minutes-to-days wide.
 *
 * src/ whole-tree is deliberately a SUPERSET of the pi bundle's import graph:
 * over-strict beats stale (the rebuild is ~56 ms measured). Offline + fast:
 * filesystem stats only — no build, no network.
 */

import { describe, it, expect } from "vitest";
import { readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, "..", "..");

/** Every .ts file under a directory (recursive), as minute-truncated mtimes. */
function srcMinutes(dir: string): number[] {
  const out: number[] = [];
  const walk = (d: string): void => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const p = join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name.endsWith(".ts")) out.push(Math.floor(statSync(p).mtimeMs / 60_000));
    }
  };
  walk(dir);
  return out;
}

/** [bundle, source roots it inlines, the rebuild command] */
const BUNDLES: Array<[string, string[], string]> = [
  [
    "dist/pi-extension/index.bundled.js",
    ["src"],
    "node scripts/build-pi-extension.mjs",
  ],
  [
    "dist/ext-synadia/index.bundled.js",
    ["packages/ext-synadia/src", "packages/protocol-core/src"],
    "node scripts/build-ext-synadia.mjs",
  ],
];

describe("tracked bundles are fresh (A4b freshness marker)", () => {
  for (const [bundle, roots, rebuild] of BUNDLES) {
    it(`${bundle} is at least as new as every source file it inlines`, () => {
      const bundleMin = Math.floor(statSync(join(ROOT, bundle)).mtimeMs / 60_000);
      const srcMax = Math.max(...roots.flatMap((r) => srcMinutes(join(ROOT, r))));
      expect(
        bundleMin,
        `STALE BUNDLE: ${bundle} is older than its newest source file — re-bundle with \`${rebuild}\`, then commit the bundle alongside the source change.`,
      ).toBeGreaterThanOrEqual(srcMax);
    });
  }
});
