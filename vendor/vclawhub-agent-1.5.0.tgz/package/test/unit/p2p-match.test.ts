/**
 * p2p-match.test.ts — NATS-style subject matching (Pears Tier P, M2).
 *
 * The sidecar preserves seam subjects verbatim (net/transport.ts froze them),
 * so room delivery needs NATS token semantics. These cases mirror the shapes
 * net/a2a.ts actually subscribes (`tenant.default.a2a.<nkey>.>`) and what it
 * publishes against them (`...req`, acks to reply inboxes).
 */
import { describe, it, expect } from "vitest";
import { subjectMatches, validatePattern } from "../../src/net/p2p/sidecar/src/match.js";

describe("subjectMatches", () => {
  it("exact subjects match exactly", () => {
    expect(subjectMatches("a.b.c", "a.b.c")).toBe(true);
    expect(subjectMatches("a.b.c", "a.b.d")).toBe(false);
    expect(subjectMatches("a.b.c", "a.b")).toBe(false);
    expect(subjectMatches("a.b", "a.b.c")).toBe(false);
  });

  it("'*' matches exactly one token", () => {
    expect(subjectMatches("tenant.*.a2a.X.req", "tenant.default.a2a.X.req")).toBe(true);
    expect(subjectMatches("tenant.*.a2a.X.req", "tenant.a.b.a2a.X.req")).toBe(false);
    expect(subjectMatches("a.*.c", "a.b.c")).toBe(true);
    expect(subjectMatches("a.*", "a.b.c")).toBe(false);
  });

  it("'>' matches one-or-more trailing tokens (the a2a mailbox shape)", () => {
    expect(subjectMatches("tenant.default.a2a.NKEY.>", "tenant.default.a2a.NKEY.req")).toBe(true);
    expect(subjectMatches("tenant.default.a2a.NKEY.>", "tenant.default.a2a.NKEY.deep.nested")).toBe(true);
    expect(subjectMatches("tenant.default.a2a.NKEY.>", "tenant.default.a2a.NKEY")).toBe(false);
    expect(subjectMatches("tenant.default.a2a.NKEY.>", "tenant.default.a2a.OTHER.req")).toBe(false);
  });

  it("mixed '*'/literal before a trailing '>' works", () => {
    expect(subjectMatches("tenant.*.a2a.>", "tenant.default.a2a.NKEY.req")).toBe(true);
    expect(subjectMatches("tenant.*.a2a.>", "tenant.elsewhere.a2a.x")).toBe(true);
    expect(subjectMatches("tenant.*.a2a.>", "tenant.default.h2a.NKEY")).toBe(false);
  });

  it("empty subject never matches a non-empty pattern", () => {
    expect(subjectMatches("a.b", "")).toBe(false);
  });
});

describe("validatePattern", () => {
  it("accepts the seam's real patterns", () => {
    expect(validatePattern("tenant.default.a2a.NKEY123.>")).toBe("");
    expect(validatePattern("tenant.*.a2a.*.req")).toBe("");
    expect(validatePattern("inbox.>")).toBe("");
  });

  it("rejects malformed patterns loudly (subscribe-time, not delivery-time)", () => {
    expect(validatePattern("")).not.toBe("");
    expect(validatePattern("a.>.b")).not.toBe(""); // '>' not last
    expect(validatePattern("a..b")).not.toBe(""); // empty token
    expect(validatePattern(".a")).not.toBe("");
    expect(validatePattern("a.")).not.toBe("");
  });
});
