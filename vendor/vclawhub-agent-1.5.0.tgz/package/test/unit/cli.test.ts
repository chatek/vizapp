/**
 * CLI registration smoke test (B12).
 *
 * Builds dist (tsc) then runs the real bin entry point with --help and
 * asserts the three new commands register. This exercises the full
 * commander registration chain without hitting the network.
 */

import { describe, it, expect, beforeAll } from "vitest";
import { execSync } from "node:child_process";
import { fileURLToPath } from "node:url";

/** agent-sdk package root (test/unit/ → ../..). */
const PKG_ROOT = fileURLToPath(new URL("../..", import.meta.url));

describe("CLI registration smoke", () => {
  let help: string;

  beforeAll(() => {
    // bin/agent.js loads dist/cli.js — rebuild so it reflects this source.
    execSync("node node_modules/typescript/bin/tsc", {
      cwd: PKG_ROOT,
      stdio: "pipe",
    });
    help = execSync("node bin/agent.js --help", {
      cwd: PKG_ROOT,
      encoding: "utf-8",
    });
  });

  it("registers export", () => {
    expect(help).toContain("export");
    expect(help).toContain("cross-machine");
  });

  it("registers import", () => {
    expect(help).toContain("import");
  });

  it("registers check-update", () => {
    expect(help).toContain("check-update");
    expect(help).toContain("against jsr.io");
  });

  it("registers start --dev (replica/test-fabric plain NKey connect)", () => {
    const startHelp = execSync("node bin/agent.js start --help", {
      cwd: PKG_ROOT,
      encoding: "utf-8",
    });
    expect(startHelp).toContain("--dev");
    expect(startHelp).toContain("VCLAW_DEV");
  });

  it("still registers the core commands (no regression)", () => {
    expect(help).toContain("onboard");
    expect(help).toContain("status");
    expect(help).toContain("start");
  });
});
