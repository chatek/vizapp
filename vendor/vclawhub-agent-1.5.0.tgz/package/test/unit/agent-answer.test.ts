import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

// Keep parseDirective / config round-trip REAL; only stub llmChat so the
// configured + On Line branch is exercised without network. vi.mock is hoisted
// above the imports below.
vi.mock("../../src/lib/llm.js", async (importActual) => {
  const actual = await importActual<typeof import("../../src/lib/llm.js")>();
  return { ...actual, llmChat: vi.fn(async () => "real llm reply") };
});

import { agentAnswer, LLM_ACTION, LLM_HELPERS, HELP_MENU, LLM_OL_CTA } from "../../src/commands/start.js";
import { OnlineGate } from "../../src/net/capabilities.js";
import * as llm from "../../src/lib/llm.js";

let tmp: string;
const label = "alpha-test-agent";

/** Stub the network for the REAL llmChat (verifyLLMEndpoint lives inside
 * llm.js, so the vi.mock above does NOT stub its internal call — the set
 * path must exercise real fetch against a fake endpoint). */
function stubLLMEndpoint(ok = true) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok,
      status: ok ? 200 : 404,
      text: async () => (ok ? "" : "no such model"),
      json: async () => ({ choices: [{ message: { content: "pong" } }] }),
    })),
  );
}

beforeEach(() => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), "agentAnswer-test-"));
});
afterEach(() => {
  fs.rmSync(tmp, { recursive: true, force: true });
  vi.unstubAllGlobals();
  vi.clearAllMocks();
});

/** Minimal OnlineGate stub — agentAnswer only calls isOnlineNow(). */
function gate(online: boolean): OnlineGate {
  return { isOnlineNow: async () => online } as unknown as OnlineGate;
}
function answer(online: boolean) {
  return agentAnswer(label, tmp, gate(online));
}

describe("agentAnswer — LLM-configure tips (C2/R2)", () => {
  it("On Rack + unconfigured → status line + action + helpers", async () => {
    const r = await answer(false)([{ role: "user", content: "hello" }]);
    expect(r).toContain("I'm On Rack now");
    expect(r).toContain(label);
    expect(r).toContain(LLM_ACTION);
    expect(r).toContain("llm set url=");
    expect(r).toContain(LLM_HELPERS);
    expect(r).toContain("llm status");
    expect(r).toContain("llm unset");
  });

  it("On Line + unconfigured → concise OL CTA (no duplication, no flow note)", async () => {
    const r = await answer(true)([{ role: "user", content: "hello" }]);
    expect(r).not.toContain("On Rack");
    expect(r).toContain(LLM_OL_CTA(label));
    expect(r).toContain(LLM_HELPERS);
    // The set line appears EXACTLY once (no CTA/tips duplication).
    expect(r.match(/llm set url=/g)).toHaveLength(1);
    expect(r).not.toContain("Configure me here");
  });

  it("On Rack + configured → status line only (no tips)", async () => {
    llm.saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret123", model: "m1" });
    const r = await answer(false)([{ role: "user", content: "hello" }]);
    expect(r).toContain("On Rack now");
    expect(r).not.toContain("llm set url=");
    expect(r).not.toContain(LLM_HELPERS);
  });

  it("On Line + configured → real LLM reply (no tips, no status)", async () => {
    llm.saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret123", model: "m1" });
    const r = await answer(true)([{ role: "user", content: "hello" }]);
    expect(r).toBe("real llm reply");
    expect(llm.llmChat).toHaveBeenCalledOnce();
    expect(r).not.toContain("llm set");
  });
});

describe("agentAnswer — directive passthrough (RAW last user msg, @mention tolerant)", () => {
  it("'llm set' validates endpoint, writes config, confirms with transition CTA", async () => {
    stubLLMEndpoint(true);
    const r = await answer(false)([{ role: "user", content: "llm set url=http://h:11434 key=sk-secret123 model=m1" }]);
    expect(r).toBe("✅ LLM configured — m1 @ http://h:11434.\nNow ask me anything — I answer as the real model.");
    expect(llm.loadLLMConfig(tmp)).toEqual({ base_url: "http://h:11434", api_key: "sk-secret123", model: "m1" });
  });

  it("'llm set' with a failing endpoint → actionable error, config NOT saved", async () => {
    stubLLMEndpoint(false);
    const r = await answer(false)([{ role: "user", content: "llm set url=http://bad:1 key=sk-secret123 model=nope" }]);
    expect(r).toContain("⚠️ llm set FAILED");
    expect(r).toContain("config NOT saved");
    expect(llm.loadLLMConfig(tmp)).toBeNull();
  });

  it("leading @mention is tolerated (room-message flow)", async () => {
    stubLLMEndpoint(true);
    const r = await answer(true)([{ role: "user", content: `@${label} llm set url=http://h:11434 key=sk-secret123 model=m1` }]);
    expect(r).toBe("✅ LLM configured — m1 @ http://h:11434.\nNow ask me anything — I answer as the real model.");
  });

  it("'help' returns the deterministic OL menu", async () => {
    const r = await answer(true)([{ role: "user", content: "help" }]);
    expect(r).toBe(HELP_MENU(label));
  });

  it("'llm models' lists endpoint models when configured", async () => {
    llm.saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret123", model: "m1" });
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: true,
        status: 200,
        text: async () => "",
        json: async () => ({ data: [{ id: "m1" }, { id: "m2-uncensored" }] }),
      })),
    );
    const r = await answer(true)([{ role: "user", content: "llm models" }]);
    expect(r).toBe("Models @ http://h:11434:\nm1\nm2-uncensored");
  });

  it("'llm models' without config → hint to run llm set first", async () => {
    const r = await answer(true)([{ role: "user", content: "llm models" }]);
    expect(r).toContain("run llm set");
  });

  it("'@name help' is tolerated; 'help me' → invalid", async () => {
    const r1 = await answer(true)([{ role: "user", content: `@${label} help` }]);
    expect(r1).toBe(HELP_MENU(label));
    const r2 = await answer(true)([{ role: "user", content: "help me" }]);
    expect(r2).toBe("⚠️ help takes no arguments");
  });

  it("uses the RAW last user message, not a role-joined form", async () => {
    // The assistant turn embeds "user: llm set ..." (what a naive join would
    // emit). agentAnswer must parse the REAL last user message ("llm status"),
    // not the embedded directive.
    const msgs = [
      { role: "user", content: "earlier" },
      { role: "assistant", content: "user: llm set url=http://h:11434 key=sk-secret123 model=m1" },
      { role: "user", content: "llm status" },
    ];
    const r = await answer(true)(msgs);
    expect(r).toBe("No LLM configured. Use: llm set url=<base-url> key=<api-key> model=<model>");
  });

  it("'llm status' reports when configured", async () => {
    llm.saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret123456", model: "m1" });
    const r = await answer(true)([{ role: "user", content: "llm status" }]);
    expect(r).toBe("LLM: m1 @ http://h:11434 (key sk-s…3456)");
  });

  it("'llm unset' clears and confirms", async () => {
    llm.saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret123", model: "m1" });
    const r = await answer(true)([{ role: "user", content: "llm unset" }]);
    expect(r).toBe("LLM config cleared — back to On Rack status replies.");
    expect(llm.loadLLMConfig(tmp)).toBeNull();
  });

  it("invalid directive → warning with reason", async () => {
    const r = await answer(true)([{ role: "user", content: "llm set url=http://x key=k" }]);
    expect(r).toBe("⚠️ usage: llm set url=<base-url> key=<api-key> model=<model>");
  });
});

describe("maskSensitive — llm set key never leaks to logs/scrollback", () => {
  it("redacts key=… in a directive line", () => {
    expect(llm.maskSensitive("llm set url=http://h:11434 key=sk-super-secret-999 model=m1")).toBe(
      "llm set url=http://h:11434 key=sk-s…-999 model=m1",
    );
  });
  it("leaves ordinary text untouched", () => {
    expect(llm.maskSensitive("hello, what's the weather? no secrets here")).toBe(
      "hello, what's the weather? no secrets here",
    );
  });
});
