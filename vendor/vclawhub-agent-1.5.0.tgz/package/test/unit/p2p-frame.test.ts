/**
 * p2p-frame.test.ts — Tier P frame seal/open + the mandatory digest (M2).
 *
 * The Q5 gate made app-layer digests MANDATORY: encryption failures are
 * silent, so receivers must detect garbage themselves. This suite proves the
 * frame layer (sidecar/src/frame.ts, imported directly — no process needed):
 *   1. seal->open round-trips byte-exact with the digest verifying;
 *   2. opening with the WRONG key returns undecryptable, NEVER throws;
 *   3. a valid encryption with a WRONG digest returns digest-mismatch;
 *   4. ciphertext never contains the plaintext at any position.
 */
import { describe, it, expect } from "vitest";
import { buildEnvelope, envelopeDigest, sealFrame, openFrame, fromB64, toB64 } from "../../src/net/p2p/sidecar/src/frame.js";

const KEY = new Uint8Array(32).fill(0x42);
const TOPIC_HEX = "ab".repeat(32);

function plaintextBlock(i: number): Uint8Array {
  const prefix = Buffer.from("BLOCK-" + String(i).padStart(3, "0") + "-", "utf8");
  const filler = Buffer.alloc(80, "A".charCodeAt(0));
  return new Uint8Array(Buffer.concat([prefix, filler]));
}

describe("sealFrame / openFrame", () => {
  it("round-trips byte-exact and the digest verifies", () => {
    const data = plaintextBlock(0);
    const envelope = buildEnvelope("tenant.default.a2a.X.req", "", toB64(data));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    const opened = openFrame(KEY, frame);
    expect(opened.ok).toBe(true);
    if (!opened.ok) throw new Error("unreachable");
    expect(opened.envelope).toBe(envelope);
    expect(opened.digest).toBe(envelopeDigest(envelope));
    const parsed = JSON.parse(opened.envelope) as { subject: string; reply: string; data: string };
    expect(parsed.subject).toBe("tenant.default.a2a.X.req");
    expect(parsed.reply).toBe("");
    expect(Buffer.from(fromB64(parsed.data))).toEqual(Buffer.from(data));
  });

  it("the wire frame carries NO plaintext at any position", () => {
    const data = plaintextBlock(7);
    const envelope = buildEnvelope("s", "", toB64(data));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    const wire = Buffer.from(JSON.stringify(frame), "utf8");
    expect(wire.indexOf("BLOCK-007")).toBe(-1);
    expect(wire.indexOf("AAAAAAAA")).toBe(-1);
  });

  it("wrong key: undecryptable, NEVER an exception (the Q5 silent-garbage contract)", () => {
    const envelope = buildEnvelope("s", "", toB64(plaintextBlock(0)));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    const opened = openFrame(new Uint8Array(32).fill(0x99), frame);
    expect(opened).toEqual({ ok: false, reason: "undecryptable" });
  });

  it("null key (the non-member experience): undecryptable, no exception", () => {
    const envelope = buildEnvelope("s", "", toB64(plaintextBlock(0)));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    expect(openFrame(null, frame)).toEqual({ ok: false, reason: "undecryptable" });
  });

  it("valid encryption + WRONG digest: digest-mismatch (mandatory app-layer digest)", () => {
    const envelope = buildEnvelope("s", "", toB64(plaintextBlock(0)));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    const tampered = { ...frame, d: envelopeDigest(buildEnvelope("other-subject", "", toB64(plaintextBlock(0)))) };
    expect(openFrame(KEY, tampered)).toEqual({ ok: false, reason: "digest-mismatch" });
  });

  it("tampered ciphertext: undecryptable (MAC catches it before the digest)", () => {
    const envelope = buildEnvelope("s", "", toB64(plaintextBlock(0)));
    const frame = sealFrame(KEY, TOPIC_HEX, envelope);
    const ct = Buffer.from(frame.ct, "base64");
    ct[0] ^= 0xff;
    const tampered = { ...frame, ct: ct.toString("base64") };
    expect(openFrame(KEY, tampered)).toEqual({ ok: false, reason: "undecryptable" });
  });

  it("rejects non-32B keys at seal time (programming error, loud)", () => {
    const envelope = buildEnvelope("s", "", toB64(plaintextBlock(0)));
    expect(() => sealFrame(new Uint8Array(31), TOPIC_HEX, envelope)).toThrow(/32 bytes/);
  });
});
