/**
 * family-contracts.test.ts — v9 W0 envelope `family{}` fields + Tier W family
 * subject helpers (UPGRADE.md §4.1/§4.2, deliverables 1+2).
 *
 * VERIFY bar:
 *  - `family { role?, steer?, receipt? }` on A2aRequest validates; every field
 *    optional; a pre-v9 envelope (no family) still validates — §5.6 tolerance.
 *  - `receipt` = "delivered"|"queued" on A2aResponse when requested.
 *  - Unknown extension fields stay tolerated on BOTH payloads (forward-compat).
 *  - Family subject template: exact Tier W shape under the LIVE SUBJECT_ROOT,
 *    verbs prompt.req|hb|events|reply.<conv_id>, token sanitization.
 *  - mintFamilyId(): UUIDv4, unique, pass-through in subjects (hyphens legal).
 *  - G1 structural half: every family-lane claim is inside CLAIMED_AGENT
 *    pub+sub (the live-JWT half lives in g1-perm-probe.test.ts + the CLI).
 */
import { describe, it, expect, afterEach } from "vitest";
import { Value } from "@sinclair/typebox/value";
import {
  A2aRequestPayload,
  A2aResponsePayload,
  FAMILY_STATIC_VERBS,
  FamilySubject,
  familyReplyVerb,
  familySubjectV9,
  familyWildcardV9,
  mintFamilyId,
  setTenantSegment,
  SUBJECT_ROOT,
  PERMISSIONS,
} from "../../src/contracts/contracts.js";
import {
  claimedAgentGrants,
  familyProbeClaims,
  probeFamilyGrants,
} from "../helpers/g1-perm-probe.js";

// ── minimal valid payloads (pre-v9 wire shapes) ───────────────
const v8Request = {
  type: "a2a_request",
  id: "req-1",
  prompt: "do the thing",
  from: { nkey: "U_SENDER" },
  ts: "2026-09-04T00:00:00.000Z",
};
const v8Response = {
  type: "a2a_response",
  id: "res-1",
  from: { nkey: "U_WORKER" },
  text: "done",
  ts: "2026-09-04T00:00:00.000Z",
};

afterEach(() => {
  setTenantSegment("default"); // family subjects read the LIVE root — restore
});

describe("envelope v9: family block on A2aRequest (§4.1)", () => {
  it("accepts family { role, steer, receipt } — all three fields", () => {
    const wire = {
      ...v8Request,
      family: { role: "worker", steer: "focus on the parser", receipt: true },
    };
    expect(Value.Check(A2aRequestPayload, wire)).toBe(true);
  });

  it("every family field is optional (role-only / steer-only / receipt-only wires)", () => {
    expect(Value.Check(A2aRequestPayload, { ...v8Request, family: { role: "lead" } })).toBe(true);
    expect(Value.Check(A2aRequestPayload, { ...v8Request, family: { steer: "go" } })).toBe(true);
    expect(Value.Check(A2aRequestPayload, { ...v8Request, family: { receipt: true } })).toBe(true);
  });

  it("pre-v9 envelope (no family) still validates — backward tolerance", () => {
    expect(Value.Check(A2aRequestPayload, v8Request)).toBe(true);
  });

  it("§5.6 tolerance: unknown extension fields are tolerated on read (old receivers skip new fields)", () => {
    // A v9 envelope seen by a v8 decoder: the family field is unknown but the
    // schema leaves additionalProperties open → the OLD schema still accepts
    // the NEW wire. (The symmetric direction — new schema, old wire — is the
    // no-family case above.)
    expect(Value.Check(A2aRequestPayload, { ...v8Request, family: { role: "x" } })).toBe(true);
  });

  it("rejects a non-boolean family.receipt (wire discipline)", () => {
    const wire = { ...v8Request, family: { receipt: "yes" } };
    expect(Value.Check(A2aRequestPayload, wire)).toBe(false);
  });
});

describe("envelope v9: receipt on A2aResponse (§4.1)", () => {
  it("accepts receipt delivered|queued when the request asked for one", () => {
    expect(Value.Check(A2aResponsePayload, { ...v8Response, receipt: "delivered" })).toBe(true);
    expect(Value.Check(A2aResponsePayload, { ...v8Response, receipt: "queued" })).toBe(true);
  });

  it("receipt is optional (replies without a requested receipt stay valid)", () => {
    expect(Value.Check(A2aResponsePayload, v8Response)).toBe(true);
  });

  it("rejects receipt values outside delivered|queued", () => {
    expect(Value.Check(A2aResponsePayload, { ...v8Response, receipt: "maybe" })).toBe(false);
    expect(Value.Check(A2aResponsePayload, { ...v8Response, receipt: true })).toBe(false);
  });
});

describe("family lane subjects (§4.2, Tier W)", () => {
  it("builds the exact Tier W shape under the live SUBJECT_ROOT", () => {
    const s = familySubjectV9("U_LEAD", "0a80903e-1c4d-4f6e-9a2b-3f5c6d7e8f90", "worker-a", "prompt.req");
    expect(s).toBe(
      "tenant.default.user.U_LEAD.agent.U_LEAD.family.0a80903e-1c4d-4f6e-9a2b-3f5c6d7e8f90.worker-a.prompt.req",
    );
  });

  it("follows a segment switch (build reads the LIVE root — segmented agents)", () => {
    setTenantSegment("vclaw");
    const s = familySubjectV9("U_LEAD", "f-1", "w", "hb");
    expect(s).toBe("tenant.vclaw.user.U_LEAD.agent.U_LEAD.family.f-1.w.hb");
    expect(SUBJECT_ROOT).toBe("tenant.vclaw");
  });

  it("sanitizes the worker name to a single NATS token (spaces → _)", () => {
    const s = familySubjectV9("U_LEAD", "f-1", "Worker Two", "hb");
    expect(s).toContain(".family.f-1.Worker_Two.hb");
  });

  it("static verbs are exactly prompt.req | hb | events", () => {
    expect([...FAMILY_STATIC_VERBS]).toEqual(["prompt.req", "hb", "events"]);
  });

  it("familyReplyVerb builds reply.<conv_id> with a sanitized conversation id", () => {
    expect(familyReplyVerb("conv-1")).toBe("reply.conv-1");
    expect(familyReplyVerb("room 7/thread#2")).toBe("reply.room_7_thread_2");
    const s = familySubjectV9("U_LEAD", "f-1", "w", familyReplyVerb("conv-1"));
    expect(s.endsWith(".family.f-1.w.reply.conv-1")).toBe(true);
  });

  it("familyWildcardV9 is the per-agent family claim …family.>", () => {
    expect(familyWildcardV9("U_LEAD")).toBe("tenant.default.user.U_LEAD.agent.U_LEAD.family.>");
  });

  it("FamilySubject template carries the documented pattern + params schema", () => {
    expect(FamilySubject.pattern).toBe(
      "tenant.<tenant>.user.<nkey>.agent.<nkey>.family.<family_id>.<name>.<verb>",
    );
    expect(Value.Check(FamilySubject.params, { tenant: "default", nkey: "U", familyId: "f", name: "w", verb: "hb" })).toBe(true);
  });
});

describe("mintFamilyId (§4.2: UUIDv4 at first worker spawn, persisted by the lead)", () => {
  it("mints a UUIDv4", () => {
    const id = mintFamilyId();
    expect(id).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
  });

  it("mints unique ids (no reuse across spawns)", () => {
    const ids = new Set(Array.from({ length: 50 }, () => mintFamilyId()));
    expect(ids.size).toBe(50);
  });

  it("a minted id survives the subject build unchanged (hyphens are legal tokens)", () => {
    const id = mintFamilyId();
    expect(familySubjectV9("U_LEAD", id, "w", "hb")).toContain(`.family.${id}.`);
  });
});

describe("G1 structural half: family lane inside CLAIMED_AGENT (pub+sub)", () => {
  const SEG = "eng";
  const NKEY = "UA3TESTAGENT";

  it("every family-lane claim is allowed for BOTH planes via the agent-path .> grant", () => {
    const grants = claimedAgentGrants(SEG, NKEY);
    const rows = probeFamilyGrants(grants, {
      segment: SEG,
      nkey: NKEY,
      familyId: "0a80903e-1c4d-4f6e-9a2b-3f5c6d7e8f90",
      name: "worker-a",
    });
    expect(rows.length).toBe(1 + FAMILY_STATIC_VERBS.length * 2 + 2); // wildcard + verbs×(pub+sub) + reply pub+sub
    for (const r of rows) {
      expect(r.allowed, `${r.plane} ${r.claim} must be allowed`).toBe(true);
      expect(r.matchedGrant, "matched grant must be the agent-path wildcard").toBe(
        `tenant.${SEG}.user.${NKEY}.agent.${NKEY}.>`,
      );
    }
  });

  it("the wildcard claim itself is a legal subscription subject under the grants", () => {
    const grants = claimedAgentGrants(SEG, NKEY);
    const claims = familyProbeClaims({ segment: SEG, nkey: NKEY, familyId: "f", name: "w" });
    expect(claims[0]).toEqual({
      plane: "sub",
      subject: `tenant.${SEG}.user.${NKEY}.agent.${NKEY}.family.>`,
    });
  });

  it("the a2a grant does NOT cover the family lane (matchedGrant is the agent path, nothing else)", () => {
    const grants = claimedAgentGrants(SEG, NKEY);
    const rows = probeFamilyGrants(grants, { segment: SEG, nkey: NKEY, familyId: "f", name: "w" });
    for (const r of rows) {
      expect(r.matchedGrant).not.toContain("a2a");
      expect(r.matchedGrant).not.toContain("$SRV");
    }
    // sanity: the a2a grant exists but is scoped away from user.<nkey>.agent paths
    expect(PERMISSIONS.CLAIMED_AGENT.pub).toContain(`tenant.<segment>.a2a.>`);
  });
});
