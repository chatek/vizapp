/**
 * p2p-listen.test.ts — the 0.3.0 listen-mode surface that needs NO sidecar
 * process (PROTOCOL.md §9, sidecar/src/listen.ts + the client's attach path).
 *
 * Boundary discipline:
 *   - The listener is driven through a REAL duplex (a node Duplex fed by
 *     push()) so "frames in / frames out" is exercised as the socket sees it,
 *     not through a hand-written fake of the codec.
 *   - The peer derivation check (§9 handshake) runs against a REAL unix-socket
 *     server that speaks one ready hello — the accept case proves the check
 *     passes for the local derivation, the refuse case proves a foreign
 *     helper on the same socket is REJECTED with E_PEER_MISMATCH.
 *   - The spawn-or-connect DECISION (§9: ENOENT ⇒ spawn, ECONNREFUSED ⇒ dead
 *     debris ⇒ clear + spawn) is proven by pointing attachHelper at a scratch
 *     "sidecar dir" whose dist/main.js is a controlled stub: the stderr fatal
 *     code surfaces, and a wedged start is bounded instead of hanging. No real
 *     sidecar is spawned by this file.
 */
import { describe, it, expect, afterEach } from "vitest";
import { Duplex } from "node:stream";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import net from "node:net";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";

import { HelperConn, HelperListener, acquireHelperLock } from "../../src/net/p2p/sidecar/src/listen.js";
import { attachHelper, SidecarOpError } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair } from "../../src/net/p2p/identity.js";

/* ── a real duplex standing in for the accepted socket ────────────────── */

interface LineStream {
  stream: Duplex;
  /** The exact bytes written, concatenated. */
  raw(): string;
  lines(): string[];
  frames(): Record<string, unknown>[];
  feed(line: string): void;
  close(): void;
}

function lineStream(): LineStream {
  const written: string[] = [];
  const stream = new Duplex({
    read() {},
    write(chunk: Buffer | string, _enc, cb: (err?: Error | null) => void) {
      written.push(typeof chunk === "string" ? chunk : chunk.toString("utf8"));
      cb();
    },
  });
  const lines = (): string[] => written.join("").split("\n").filter((l) => l !== "");
  return {
    stream,
    raw: () => written.join(""),
    lines,
    frames: () => lines().map((l) => JSON.parse(l) as Record<string, unknown>),
    feed: (line: string) => void stream.push(line + "\n"),
    close: () => {
      stream.push(null);
      stream.destroy();
    },
  };
}

const tick = (ms = 5): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

/** The delegate stub: records every parsed frame, emits the configured hello. */
function stubDelegate() {
  const seen: { conn: HelperConn; msg: Record<string, unknown> }[] = [];
  const state = { phase: "spawned" as "spawned" | "ready" };
  return {
    seen,
    state,
    delegate: {
      onLine: (conn: HelperConn, msg: Record<string, unknown>) => void seen.push({ conn, msg }),
      hello: () => ({
        event: "hello",
        phase: state.phase,
        name: "@vclawhub/pears-sidecar",
        version: "0.3.0",
        node: process.version,
        pid: process.pid,
      }),
    },
  };
}

const scratchDirs: string[] = [];
function scratch(prefix: string): string {
  const dir = mkdtempSync(path.join(tmpdir(), prefix));
  scratchDirs.push(dir);
  return dir;
}

const servers: net.Server[] = [];
const children: ReturnType<typeof spawn>[] = [];

afterEach(async () => {
  for (const s of servers.splice(0)) await new Promise<void>((r) => s.close(() => r()));
  for (const c of children.splice(0)) {
    if (c.exitCode === null && c.signalCode === null) c.kill("SIGKILL");
  }
  for (const d of scratchDirs.splice(0)) rmSync(d, { recursive: true, force: true });
});

/* ── frames ───────────────────────────────────────────────────────────── */

describe("listen-mode frames (NDJSON in, one JSON object per line out)", () => {
  it("greets every connection with a hello before any frame is read", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const conn = listener.accept(s.stream as never);
    await tick();
    expect(d.seen).toHaveLength(0); // hello is the listener's, not the delegate's
    expect(s.frames()).toHaveLength(1);
    expect(s.frames()[0]).toMatchObject({ event: "hello", phase: "spawned", version: "0.3.0" });
    expect(typeof s.frames()[0]!.pid).toBe("number");
    expect(conn.helloPhase).toBe("spawned");
    listener.closeAll();
  });

  it("encodes exactly one JSON line per frame (no length prefix, trailing newline)", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const conn = listener.accept(s.stream as never);
    conn.send({ id: 3, ok: true, note: "line breaks are escaped" });
    await tick();
    // one write per frame, each ending in a single "\n", each parsing on its own
    expect(s.lines()).toHaveLength(2);
    for (const line of s.lines()) {
      expect(line).not.toContain("\n");
      expect(() => JSON.parse(line)).not.toThrow();
    }
    const expectedLine = JSON.stringify({ id: 3, ok: true, note: "line breaks are escaped" });
    expect(s.lines()[1]).toBe(expectedLine);
    // exactly one terminator per frame: two frames, two newlines, no more
    expect(s.raw().split("\n")).toHaveLength(3);
    expect(s.raw().endsWith(expectedLine + "\n")).toBe(true);
    listener.closeAll();
  });

  it("decodes a frame and hands it to the delegate with its op intact", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const conn = listener.accept(s.stream as never);
    s.feed(JSON.stringify({ op: "stats", id: 7 }));
    await tick();
    expect(d.seen).toHaveLength(1);
    expect(d.seen[0]!.conn).toBe(conn);
    expect(d.seen[0]!.msg).toEqual({ op: "stats", id: 7 });
    listener.closeAll();
  });

  it("answers unparseable JSON with E_BAD_JSON and never calls the delegate", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    listener.accept(s.stream as never);
    s.feed("{not json");
    await tick();
    expect(d.seen).toHaveLength(0);
    expect(s.frames().at(-1)).toMatchObject({ event: "error", code: "E_BAD_JSON" });
    listener.closeAll();
  });

  it("answers a frame without a string op with E_BAD_FRAME (null, array, numeric op)", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    listener.accept(s.stream as never);
    s.feed("null");
    s.feed("[1,2,3]");
    s.feed(JSON.stringify({ op: 5, id: 1 }));
    await tick();
    expect(d.seen).toHaveLength(0);
    const errors = s.frames().filter((f) => f.event === "error");
    expect(errors).toHaveLength(3);
    for (const e of errors) expect(e.code).toBe("E_BAD_FRAME");
    listener.closeAll();
  });

  it("ignores blank and whitespace-only lines", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    listener.accept(s.stream as never);
    s.feed("");
    s.feed("   ");
    await tick();
    expect(d.seen).toHaveLength(0);
    expect(s.frames().filter((f) => f.event === "error")).toHaveLength(0);
    listener.closeAll();
  });

  it("a client's socket ERROR (async EPIPE) kills only that connection, never the listener", async () => {
    // Regression: an async EPIPE from write() reached the readline Interface as
    // an unhandled 'error' and took the WHOLE helper process down — one client
    // disconnecting mid-hello killed every other client's helper.
    const bad = lineStream();
    const good = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const badConn = listener.accept(bad.stream as never);
    const goodConn = listener.accept(good.stream as never);
    listener.noteAttach(badConn, "dlg");
    listener.noteAttach(goodConn, "dlg");
    expect(listener.connCount).toBe(2);

    // emit the error the socket would emit after a peer vanished mid-write
    bad.stream.emit("error", Object.assign(new Error("write EPIPE"), { code: "EPIPE" }));
    await tick(20);

    expect(badConn.alive).toBe(false);
    expect(listener.connCount).toBe(1);
    expect(listener.attachedCount("dlg")).toBe(1); // the survivor is still counted
    expect(goodConn.alive).toBe(true);
    // the surviving connection still works
    expect(listener.routeMsg(1, { event: "msg", subId: 1 })).toBe(false); // unowned sub, no throw
    listener.broadcast({ event: "peer", peer: "ab", state: "connected" });
    await tick();
    expect(good.frames().filter((f) => f.event === "peer")).toHaveLength(1);
    listener.closeAll();
  });

  it("a write after the stream closed is a no-op, never a throw", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const conn = listener.accept(s.stream as never);
    s.close();
    await tick(20);
    expect(conn.alive).toBe(false);
    expect(() => conn.send({ id: 1, ok: true })).not.toThrow();
    listener.closeAll();
  });
});

/* ── hello phases ─────────────────────────────────────────────────────── */

describe("hello phases (spawned -> ready)", () => {
  it("bootComplete upgrades a pre-boot connection exactly once", async () => {
    const s = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const conn = listener.accept(s.stream as never);
    await tick();
    d.state.phase = "ready";
    listener.bootComplete();
    await tick();
    const hellos = s.frames().filter((f) => f.event === "hello");
    expect(hellos.map((h) => h.phase)).toEqual(["spawned", "ready"]);
    expect(conn.helloPhase).toBe("ready");
    listener.bootComplete(); // already ready — no third hello
    await tick();
    expect(s.frames().filter((f) => f.event === "hello")).toHaveLength(2);
    listener.closeAll();
  });

  it("a connection accepted after boot gets the ready hello immediately", async () => {
    const d = stubDelegate();
    d.state.phase = "ready";
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const s = lineStream();
    const conn = listener.accept(s.stream as never);
    await tick();
    expect(conn.helloPhase).toBe("ready");
    expect(s.frames()).toEqual([expect.objectContaining({ event: "hello", phase: "ready" })]);
    listener.closeAll();
  });
});

/* ── attach refcount ──────────────────────────────────────────────────── */

describe("attach refcount (the number stats reports as attachedConnections)", () => {
  it("counts connections per delegation — idempotent per connection", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const ca = listener.accept(a.stream as never);
    const cb = listener.accept(b.stream as never);

    expect(listener.attachedCount("dlg")).toBe(0); // nothing attached yet
    listener.noteAttach(ca, "dlg");
    listener.noteAttach(ca, "dlg"); // a re-attach on the same connection
    expect(listener.attachedCount("dlg")).toBe(1);
    listener.noteAttach(cb, "dlg");
    expect(listener.attachedCount("dlg")).toBe(2);
    // a second delegation counts independently
    listener.noteAttach(cb, "dlg-2");
    expect(listener.attachedCount("dlg-2")).toBe(1);
    listener.closeAll();
  });

  it("drops a closed connection from every delegation's count", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const ca = listener.accept(a.stream as never);
    const cb = listener.accept(b.stream as never);
    listener.noteAttach(ca, "dlg");
    listener.noteAttach(ca, "dlg-2");
    listener.noteAttach(cb, "dlg");
    expect(listener.attachedCount("dlg")).toBe(2);

    a.close();
    await tick(20);
    expect(listener.attachedCount("dlg")).toBe(1); // b still attached
    expect(listener.attachedCount("dlg-2")).toBe(0); // a was the only one
    expect(listener.connCount).toBe(1);
    listener.closeAll();
  });
});

/* ── linger ───────────────────────────────────────────────────────────── */

describe("linger (last close -> cancel/reschedule -> onLastClosed)", () => {
  it("fires onLastClosed only AFTER the linger window, never immediately", async () => {
    const s = lineStream();
    const d = stubDelegate();
    let closedAt: number | null = null;
    const listener = new HelperListener({
      lingerMs: 40,
      delegate: d.delegate,
      onLastClosed: () => {
        closedAt = Date.now();
      },
    });
    listener.accept(s.stream as never);
    const t0 = Date.now();
    s.close();
    await tick(10);
    expect(closedAt).toBeNull(); // inside the linger window
    await tick(120);
    expect(closedAt).not.toBeNull();
    expect((closedAt as unknown as number) - t0).toBeGreaterThanOrEqual(30);
    listener.closeAll();
  });

  it("a new connection inside the window CANCELS the pending close", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    let fired = 0;
    const listener = new HelperListener({ lingerMs: 60, delegate: d.delegate, onLastClosed: () => (fired += 1) });
    listener.accept(a.stream as never);
    a.close();
    await tick(10);
    listener.accept(b.stream as never); // cancels
    await tick(150);
    expect(fired).toBe(0);
    expect(listener.connCount).toBe(1);
    listener.closeAll();
  });

  it("two closes in a row schedule one close, not two", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    let fired = 0;
    const listener = new HelperListener({ lingerMs: 30, delegate: d.delegate, onLastClosed: () => (fired += 1) });
    listener.accept(a.stream as never);
    listener.accept(b.stream as never);
    a.close();
    b.close();
    await tick(120);
    expect(fired).toBe(1);
    listener.closeAll();
  });

  it("closeAll cancels a pending linger (a shutting-down helper never re-fires)", async () => {
    const s = lineStream();
    const d = stubDelegate();
    let fired = 0;
    const listener = new HelperListener({ lingerMs: 40, delegate: d.delegate, onLastClosed: () => (fired += 1) });
    listener.accept(s.stream as never);
    s.close();
    listener.closeAll();
    await tick(120);
    expect(fired).toBe(0);
    expect(listener.connCount).toBe(0);
  });

  it("accept after closeAll is refused", () => {
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 40, delegate: d.delegate, onLastClosed: () => {} });
    listener.closeAll();
    expect(() => listener.accept(lineStream().stream as never)).toThrow(/closed/);
  });
});

/* ── subscription routing ─────────────────────────────────────────────── */

describe("subscription routing (msg fans out to the OWNING connection only)", () => {
  it("delivers to the owner, misses for a stranger, and cleans up on close", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const ca = listener.accept(a.stream as never);
    const cb = listener.accept(b.stream as never);
    listener.registerSub(ca, 11, "dlg");
    listener.registerSub(cb, 22, "dlg");
    await tick();

    expect(listener.routeMsg(11, { event: "msg", subId: 11, subject: "s" })).toBe(true);
    await tick();
    expect(a.frames().filter((f) => f.event === "msg")).toHaveLength(1);
    expect(b.frames().filter((f) => f.event === "msg")).toHaveLength(0);

    expect(listener.routeMsg(999, { event: "msg", subId: 999 })).toBe(false); // nobody owns it

    a.close();
    await tick(20);
    expect(listener.routeMsg(11, { event: "msg", subId: 11 })).toBe(false); // owner gone
    listener.closeAll();
  });

  it("unregisterSub removes ownership; a broadcast reaches every live connection", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const ca = listener.accept(a.stream as never);
    const cb = listener.accept(b.stream as never);
    listener.registerSub(ca, 11, "dlg");
    listener.unregisterSub(ca, 11);
    expect(listener.routeMsg(11, { event: "msg", subId: 11 })).toBe(false);

    listener.broadcast({ event: "peer", peer: "ab", state: "connected" });
    await tick();
    for (const s of [a, b]) {
      expect(s.frames().filter((f) => f.event === "peer")).toHaveLength(1);
    }
    // unsubscribe of a sub another connection owns must not steal ownership
    listener.registerSub(cb, 33, "dlg");
    listener.unregisterSub(ca, 33);
    expect(listener.routeMsg(33, { event: "msg", subId: 33 })).toBe(true);
    listener.closeAll();
  });
});

/* ── per-connection state ─────────────────────────────────────────────── */

describe("per-connection state (request ids and put sessions never cross)", () => {
  it("keeps subscriptions and put sessions in separate maps per connection", async () => {
    const a = lineStream();
    const b = lineStream();
    const d = stubDelegate();
    const listener = new HelperListener({ lingerMs: 5_000, delegate: d.delegate, onLastClosed: () => {} });
    const ca = listener.accept(a.stream as never);
    const cb = listener.accept(b.stream as never);
    expect(ca).not.toBe(cb);
    expect(ca.subs).not.toBe(cb.subs);
    expect(ca.puts).not.toBe(cb.puts);
    // the SAME request id in flight on both connections is legal
    ca.puts.set(1, { delegationId: "dlg", size: 4, sha256: "ab".repeat(32), expectedSeq: 0, received: 0, chunks: [] });
    cb.puts.set(1, { delegationId: "dlg", sha256: "cd".repeat(32), size: 8, expectedSeq: 0, received: 0, chunks: [] });
    expect(ca.puts.get(1)?.sha256).toBe("ab".repeat(32));
    expect(cb.puts.get(1)?.sha256).toBe("cd".repeat(32));
    listener.closeAll();
  });
});

/* ── the lockfile (§9: O_EXCL + live-holder-pid) ──────────────────────── */

describe("helper lockfile (flock-equivalent posture)", () => {
  function deadPid(): number {
    // Walk a few candidate pids until one demonstrably does not exist.
    for (const candidate of [999_999, 4_194_303, 2_147_483_646]) {
      try {
        process.kill(candidate, 0);
      } catch (e) {
        if ((e as NodeJS.ErrnoException).code === "ESRCH") return candidate;
      }
    }
    throw new Error("no dead pid found for this platform");
  }

  it("creates the lock with this pid and releases it", () => {
    const dir = scratch("pears-lock-");
    const lockPath = path.join(dir, "helper.sock.lock");
    const first = acquireHelperLock(lockPath);
    expect(first.ok).toBe(true);
    const record = JSON.parse(readFileSync(lockPath, "utf8")) as { pid: number; ts: number };
    expect(record.pid).toBe(process.pid);
    expect(typeof record.ts).toBe("number");
    if (first.ok) first.lock.release();
    expect(existsSync(lockPath)).toBe(false);
  });

  it("refuses while a LIVE holder owns it, naming the holder", () => {
    const dir = scratch("pears-lock-");
    const lockPath = path.join(dir, "helper.sock.lock");
    const first = acquireHelperLock(lockPath);
    expect(first.ok).toBe(true);
    const second = acquireHelperLock(lockPath);
    expect(second.ok).toBe(false);
    expect(second.ok === false && second.holderPid).toBe(process.pid);
    if (first.ok) first.lock.release();
  });

  it("clears a DEAD holder's file (stale debris) and takes the lock", () => {
    const dir = scratch("pears-lock-");
    const lockPath = path.join(dir, "helper.sock.lock");
    writeFileSync(lockPath, JSON.stringify({ pid: deadPid(), ts: Date.now() }) + "\n");
    const result = acquireHelperLock(lockPath);
    expect(result.ok).toBe(true);
    expect(JSON.parse(readFileSync(lockPath, "utf8")).pid).toBe(process.pid);
    if (result.ok) result.lock.release();
  });

  it("treats an unparseable lockfile as stale (a torn write must not wedge the host)", () => {
    const dir = scratch("pears-lock-");
    const lockPath = path.join(dir, "helper.sock.lock");
    writeFileSync(lockPath, "{\"pid\":");
    const result = acquireHelperLock(lockPath);
    expect(result.ok).toBe(true);
    if (result.ok) result.lock.release();
  });
});

/* ── the handshake: peer derivation, accept + refuse ──────────────────── */

describe("attachHelper handshake — the helper serves ONE owner", () => {
  /** A unix-socket server that speaks exactly one ready hello. */
  async function fakeHelper(peerHex: string): Promise<{ sockPath: string; pid: number }> {
    const dir = scratch("pears-helper-");
    const sockPath = path.join(dir, "helper.sock");
    const server = net.createServer((socket) => {
      socket.write(
        JSON.stringify({
          event: "hello",
          phase: "ready",
          name: "@vclawhub/pears-sidecar",
          version: "0.3.0",
          node: process.version,
          pid: 4242,
          peer: { publicKey: peerHex },
          dht: { host: "127.0.0.1", port: 1 },
          storeDir: dir,
          readyFingerprint: "f".repeat(64),
        }) + "\n",
      );
    });
    servers.push(server);
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(sockPath, () => resolve());
    });
    return { sockPath, pid: 4242 };
  }

  it("ACCEPTS a helper whose ready-hello peer key equals the LOCAL derivation", async () => {
    const seed = new Uint8Array(randomBytes(32));
    const expected = Buffer.from((await derivePeerKeyPair(seed)).publicKey).toString("hex");
    const { sockPath } = await fakeHelper(expected);
    const session = await attachHelper({ seed, socketPath: sockPath, bootTimeoutMs: 5_000 });
    expect(session.peerPublicKey).toBe(expected);
    expect(session.helperPid).toBe(4242); // the ready-hello pid IS the helper pid
    expect(session.spawned).toBe(false); // attached, never forked
    expect(session.socketPath).toBe(sockPath);
    await session.close();
  });

  it("REFUSES a helper serving a DIFFERENT peer (E_PEER_MISMATCH), and never returns a session", async () => {
    const mine = new Uint8Array(randomBytes(32));
    const someoneElse = new Uint8Array(randomBytes(32));
    const foreign = Buffer.from((await derivePeerKeyPair(someoneElse)).publicKey).toString("hex");
    const { sockPath } = await fakeHelper(foreign);
    const err = await attachHelper({ seed: mine, socketPath: sockPath, bootTimeoutMs: 5_000 }).then(
      () => null,
      (e: unknown) => e as Error,
    );
    expect(err).toBeInstanceOf(SidecarOpError);
    expect((err as SidecarOpError).code).toBe("E_PEER_MISMATCH");
    expect(err?.message).toContain("ONE owner");
  });
});

/* ── spawn-or-connect decisions (no real sidecar) ─────────────────────── */

describe("spawn-or-connect decision (§9: ENOENT ⇒ spawn, ECONNREFUSED ⇒ clear debris ⇒ spawn)", () => {
  /** A scratch sidecar dir whose dist/main.js is a controlled stub. */
  function fakeSidecarDir(script: string): string {
    const dir = scratch("pears-fake-sidecar-");
    mkdirSync(path.join(dir, "dist"), { recursive: true });
    writeFileSync(path.join(dir, "dist", "main.js"), script);
    return dir;
  }

  it("ENOENT (nothing there) ⇒ it SPAWNS, and a helper that dies on start surfaces its stderr fatal code", async () => {
    const dir = scratch("pears-sock-");
    const sockPath = path.join(dir, "helper.sock");
    expect(existsSync(sockPath)).toBe(false);
    const sidecarDir = fakeSidecarDir(
      'process.stderr.write(\'{"event":"fatal","code":"E_HELPER_LOCKED","message":"stub: another helper owns the socket"}\\n\');\nprocess.exit(1);\n',
    );
    const err = await attachHelper({
      seed: new Uint8Array(randomBytes(32)),
      socketPath: sockPath,
      sidecarDir,
      bootTimeoutMs: 1_500,
      retryDelayMs: 50,
    }).then(
      () => null,
      (e: unknown) => e as Error,
    );
    expect(err).toBeInstanceOf(SidecarOpError);
    expect((err as SidecarOpError).code).toBe("E_HELPER_LOCKED"); // the stub's own code, verbatim
  }, 20_000);

  it("ECONNREFUSED (a dead owner's socket) ⇒ debris cleared, then it spawns", async () => {
    // A REAL unix socket left behind by a SIGKILLed owner: the file exists,
    // nothing accepts on it — exactly the crash debris §9 describes.
    const dir = scratch("pears-sock-");
    const sockPath = path.join(dir, "helper.sock");
    const lockPath = sockPath + ".lock";
    const owner = spawn(process.execPath, [
      "-e",
      'const net=require("net");const s=net.createServer(()=>{});s.listen(process.argv[1],()=>process.stdout.write("LISTENING\\n"))',
      sockPath,
    ]);
    children.push(owner);
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("stub owner never listened")), 10_000);
      owner.stdout?.on("data", (chunk: Buffer) => {
        if (chunk.toString().includes("LISTENING")) {
          clearTimeout(timer);
          resolve();
        }
      });
    });
    owner.kill("SIGKILL");
    await new Promise<void>((resolve) => owner.once("exit", () => resolve()));
    expect(existsSync(sockPath)).toBe(true); // the crash left the file behind
    writeFileSync(lockPath, JSON.stringify({ pid: owner.pid, ts: Date.now() }) + "\n");

    const probe = spawnSync(process.execPath, [
      "-e",
      'const s=require("net").connect(process.argv[1]);s.on("error",(e)=>{process.stdout.write(e.code);process.exit(0)})',
      sockPath,
    ]);
    if (probe.stdout.toString().trim() !== "ECONNREFUSED") {
      // Some platforms report ENOTSOCK/ENXIO for a socket whose owner died;
      // the case is then not reachable here — say so instead of asserting a lie.
      console.warn("skipped ECONNREFUSED arm: connect() reported " + probe.stdout.toString().trim());
      return;
    }

    const sidecarDir = fakeSidecarDir('process.stderr.write(\'{"event":"fatal","code":"E_BIND_FAILED"}\\n\');\nprocess.exit(1);\n');
    const err = await attachHelper({
      seed: new Uint8Array(randomBytes(32)),
      socketPath: sockPath,
      sidecarDir,
      bootTimeoutMs: 1_500,
      retryDelayMs: 50,
    }).then(
      () => null,
      (e: unknown) => e as Error,
    );
    // The decision under test: ECONNREFUSED unlinked the debris and moved on to
    // the spawn path (whose stub then failed with its own fatal code).
    expect(existsSync(sockPath)).toBe(false);
    expect(existsSync(lockPath)).toBe(false);
    expect(err).toBeInstanceOf(SidecarOpError);
    expect((err as SidecarOpError).code).toBe("E_BIND_FAILED");
  }, 30_000);

  it("a helper that starts but never binds is BOUNDED, never a hang (E_HELPER_TIMEOUT)", async () => {
    const dir = scratch("pears-sock-");
    const sockPath = path.join(dir, "helper.sock");
    const sidecarDir = fakeSidecarDir("setTimeout(() => process.exit(0), 3000);\n");
    const started = Date.now();
    const err = await attachHelper({
      seed: new Uint8Array(randomBytes(32)),
      socketPath: sockPath,
      sidecarDir,
      bootTimeoutMs: 800,
      retryDelayMs: 50,
    }).then(
      () => null,
      (e: unknown) => e as Error,
    );
    const elapsed = Date.now() - started;
    expect(err).toBeInstanceOf(SidecarOpError);
    expect((err as SidecarOpError).code).toBe("E_HELPER_TIMEOUT");
    expect(elapsed).toBeLessThan(10_000);
  }, 20_000);
});
