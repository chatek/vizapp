import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest';
import { startHeartbeat } from '../../src/net/heartbeat.js';

// Minimal fake NatsConnection: records published (subject, payload).
function fakeNc() {
  const published: Array<{ subject: string; data: Uint8Array }> = [];
  return {
    published,
    publish(subject: string, data: Uint8Array) {
      published.push({ subject, data });
    },
  } as never;
}

const enc = new TextDecoder();

describe('startHeartbeat online provider', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('re-evaluates a FUNCTION online provider on every tick (fleet toggle without restart)', async () => {
    const nc = fakeNc();
    let online = false;
    const stop = startHeartbeat(nc, { nkey: 'UHEARTBEATPROV01', nonce: 'hb-prov' }, {
      intervalMs: 30_000,
      online: () => online,
    });

    // First publish (immediate): On Rack.
    // NB: the payload is now built by an exported async builder, so the immediate publish
    // settles after TWO microtasks, not one. The contract asserted here is "publishes
    // promptly with the right state", not "within exactly one microtask" — flush twice.
    await Promise.resolve();
    await Promise.resolve();
    expect(nc.published.length).toBe(1);
    expect(JSON.parse(enc.decode(nc.published[0].data)).online).toBe(false);

    // Flip the gate → next tick advertises On Line.
    online = true;
    await vi.advanceTimersByTimeAsync(30_000);
    expect(nc.published.length).toBe(2);
    expect(JSON.parse(enc.decode(nc.published[1].data)).online).toBe(true);

    stop();
  });

  it('keeps a static boolean (back-compat) and defaults online=false', async () => {
    const nc = fakeNc();
    const stop = startHeartbeat(nc, { nkey: 'UHEARTBEATSTAT01', nonce: 'hb-static' }, {
      online: true,
    });
    await Promise.resolve();
    expect(JSON.parse(enc.decode(nc.published[0].data)).online).toBe(true);
    stop();

    const nc2 = fakeNc();
    const stop2 = startHeartbeat(nc2, { nkey: 'UHEARTBEATSTAT02', nonce: 'hb-none' }, {});
    await Promise.resolve();
    expect(JSON.parse(enc.decode(nc2.published[0].data)).online).toBe(false);
    stop2();
  });
});
