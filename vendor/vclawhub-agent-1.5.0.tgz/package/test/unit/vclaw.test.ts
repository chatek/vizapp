/**
 * vclaw.test.ts — the roadmap-A contract: parsing, exit codes, and the three
 * verbs against a synthetic HOME (no dependence on this machine's real state).
 *
 * The mandate these pin: every verb answers with NO credentials, NO fabric and
 * NO model; `--json` is the machine surface and its shape is stable.
 */

import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { completions, parseArgs, runVclaw, usageText } from "../../src/vclaw/run.js";
import { whoRowOf } from "../../src/vclaw/verbs/who.js";
import { generateNkeyPair } from "../../src/lib/keygen.js";

let home: string;
let prevHome: string | undefined;

beforeEach(() => {
  prevHome = process.env.HOME;
  home = mkdtempSync(join(tmpdir(), "vclaw-test-"));
  process.env.HOME = home;
});

afterEach(() => {
  if (prevHome !== undefined) process.env.HOME = prevHome;
  rmSync(home, { recursive: true, force: true });
});

describe("parseArgs (one grammar for every surface)", () => {
  it("verb + positional args + value flags", () => {
    const a = parseArgs(["peers", "--tier", "cloud"]);
    expect(a.verb).toBe("peers");
    expect(a.flags.tier).toBe("cloud");
    expect(a.args).toEqual([]);
  });

  it("boolean flags take no value, so the next token stays an argument", () => {
    const a = parseArgs(["status", "--json", "--deep"]);
    expect(a.verb).toBe("status");
    expect(a.flags.json).toBe(true);
    expect(a.flags.deep).toBe(true);
    expect(a.args).toEqual([]);
    // a boolean flag must not consume a following positional
    expect(parseArgs(["peers", "--all", "extra"]).args).toEqual(["extra"]);
  });

  it("--key=value form", () => {
    expect(parseArgs(["peers", "--tier=site"]).flags.tier).toBe("site");
  });

  it("bare flag with no value is true", () => {
    expect(parseArgs(["status", "--deep"]).flags.deep).toBe(true);
  });
});

describe("dispatch and exit codes", () => {
  it("no verb prints usage, exit 0", async () => {
    const r = await runVclaw([]);
    expect(r.exit).toBe(0);
    expect(r.text).toContain("vclaw — one command, no model required");
  });

  it("unknown verb is a usage error (2) and lists the verbs", async () => {
    const r = await runVclaw(["nope"]);
    expect(r.exit).toBe(2);
    expect(r.result.ok).toBe(false);
    expect(r.text).toContain('unknown verb "nope"');
    expect(r.text).toContain("status");
  });

  it("usage lists every verb", () => {
    const u = usageText();
    for (const v of ["status", "doctor", "peers"]) expect(u).toContain(v);
  });

  it("completions come from the table", () => {
    expect(completions("").length).toBeGreaterThanOrEqual(3);
    expect(completions("do").map((c) => c.label)).toEqual(["doctor"]);
    expect(completions("zzz")).toEqual([]);
  });
});

describe("status — answers with nothing configured (the mandate)", () => {
  it("no credentials → unavailable, exit 4, stable JSON shape", async () => {
    const r = await runVclaw(["status"]);
    expect(r.exit).toBe(4);
    expect(r.result.state).toBe("unavailable");
    const d = r.result.data as Record<string, Record<string, unknown>> & { next: string };
    expect(d.identity.present).toBe(false);
    expect(d.identity.pendingClaim).toBe(false);
    expect(typeof d.site.present).toBe("boolean");
    expect(typeof d.pears.available).toBe("boolean");
    expect(d.peers.total).toBe(0);
    expect(typeof d.next).toBe("string");
    expect(d.next).toContain("claim");
  });

  it("renders a dashboard rather than an error", async () => {
    const r = await runVclaw(["status"]);
    expect(r.text).toContain("vclaw status");
    expect(r.text).toContain("identity");
    expect(r.text).toContain("next");
    for (const label of ["identity", "claim", "cloud", "site", "tier P", "inbox", "peers", "next"]) {
      expect(r.text).toContain(label);
    }
  });
});

describe("doctor — every check names its fix", () => {
  it("with nothing configured: identity fails, exit 4, every failure has a fix", async () => {
    const r = await runVclaw(["doctor"]);
    expect(r.exit).toBe(4);
    const d = r.result.data as { checks: Array<{ id: string; ok: boolean; fix?: string }>; failures: string[] };
    expect(d.checks.map((c) => c.id)).toEqual(["identity", "claim", "cloud-config", "site-fabric", "tier-p"]);
    expect(d.failures).toContain("identity");
    for (const c of d.checks.filter((c) => !c.ok)) {
      expect(typeof c.fix === "string" && c.fix.length > 0).toBe(true);
    }
    expect(r.text).toContain("fix:");
  });
});

describe("peers — cached rosters only, tier-annotated", () => {
  it("no creds and no roster → exit 4", async () => {
    const r = await runVclaw(["peers"]);
    expect(r.exit).toBe(4);
    expect(r.result.state).toBe("unavailable");
  });

  it("reads a roster and merges the buddy list", async () => {
    const dir = join(home, ".omp", "agent");
    mkdirSync(dir, { recursive: true });
    writeFileSync(
      join(dir, "roster.demo.json"),
      JSON.stringify({
        "demo.alpha": { nkey: "demo.alpha", name: "alpha", owner: "demo", fabric: "demo", buddy: false, lastSeen: "2026-10-30T00:00:00Z" },
      }),
    );
    writeFileSync(join(dir, "cross_buddies.demo.json"), JSON.stringify(["demo.alpha", "demo.ghost"]));

    const r = await runVclaw(["peers"]);
    expect(r.exit).toBe(0);
    const d = r.result.data as { peers: Array<{ id: string; tier: string; buddy: boolean; source: string }> };
    expect(d.peers.map((p) => p.id)).toEqual(["demo.alpha", "demo.ghost"]);
    const alpha = d.peers.find((p) => p.id === "demo.alpha")!;
    expect(alpha.tier).toBe("cloud");
    expect(alpha.buddy).toBe(true); // merged from cross_buddies
    expect(d.peers.find((p) => p.id === "demo.ghost")!.tier).toBe("unknown");
    expect(r.text).toContain("cached");
  });

  it("--tier filters, and a bad tier is a usage error", async () => {
    const dir = join(home, ".omp", "agent");
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, "cross_buddies.demo.json"), JSON.stringify(["demo.ghost"]));

    const filtered = await runVclaw(["peers", "--tier", "unknown"]);
    expect((filtered.result.data as { peers: unknown[] }).peers.length).toBe(1);

    const bad = await runVclaw(["peers", "--tier", "nope"]);
    expect(bad.exit).toBe(2);
  });
});

describe("signup — an existing identity is a no-op, never a second signup", () => {
  it("reports 'already signed up' and creates nothing", async () => {
    const kp = await generateNkeyPair();
    const dir = join(home, ".config", "vclaw");
    mkdirSync(dir, { recursive: true });
    writeFileSync(
      join(dir, "credentials.json"),
      JSON.stringify({
        seed: kp.seed,
        public_key: kp.publicKey,
        agent_nkey: Buffer.from(kp.rawPublicKey).toString("base64url"),
        name: "demo-agent",
        steward: "demo",
        created_at: "2026-01-01T00:00:00.000Z",
      }),
      { mode: 0o600 },
    );
    writeFileSync(join(dir, "config.json"), JSON.stringify({ server: "nats://127.0.0.1:4222" }), { mode: 0o600 });

    const r = await runVclaw(["signup"]);
    expect(r.exit).toBe(0);
    expect(r.text).toContain("already signed up");
    expect(r.text).toContain("demo-agent");
    // and `status` now answers with an identity, not "not onboarded"
    const st = await runVclaw(["status"]);
    expect(st.exit).toBe(0);
    expect((st.result.data as { identity: { present: boolean } }).identity.present).toBe(true);
  });
});

describe("who — announcement parsing tolerates shape drift", () => {
  it("reads nkey/name/state/segment and drops records without an nkey", () => {
    expect(whoRowOf({ nkey: "U1", name: "a", state: "online", segment: "default", ts: "T" })).toEqual({
      nkey: "U1", name: "a", state: "online", segment: "default", seen: "T",
    });
    expect(whoRowOf({ nkey: "U2", nonce: "b", status: "idle" })).toEqual({ nkey: "U2", name: "b", state: "idle" });
    expect(whoRowOf({ name: "no-key" })).toBeNull();
    expect(whoRowOf(null)).toBeNull();
    expect(whoRowOf("nope")).toBeNull();
  });
});
