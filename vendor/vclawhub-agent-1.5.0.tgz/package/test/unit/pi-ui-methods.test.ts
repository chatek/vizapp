/**
 * Completeness gate for the daemon's extension-UI policy (worker-pi.ts).
 *
 * WHY THIS EXISTS: the daemon auto-cancels modal `extension_ui_request` frames
 * so a worker with no human never hangs. That policy enumerated methods BY NAME
 * ("select", "confirm", "input") and therefore MISSED "editor" — a fourth modal
 * method that pi implements as a bare promise (rpc-mode.js): no `opts`, no
 * timeout, no signal. An extension calling `ui.editor(...)` in a worker waited on
 * a response the daemon never sent, and the worker WEDGED rather than failed —
 * pi's `select/confirm/input` only arm a timer when the caller passes a timeout,
 * and there is no per-turn wall clock to convert the wait into an error.
 *
 * Modality is NOT derivable from pi's declarations: `select/confirm/input` carry
 * an optional `timeout?`, `editor` carries none, and `setTitle` also has a
 * `title` field — so the two lists stay hand-maintained. What CAN be mechanised
 * is COMPLETENESS: every method pi declares must be classified into exactly one
 * of the two lists. A method added upstream then fails this test until somebody
 * decides which it is — the step that was skipped for `editor`.
 *
 * ── ANCHORING: the gate must assert against the runtime that is IN FORCE ──────
 * The declarations are read from the binary that `resolveRuntime()` resolves —
 * the SAME resolver the daemon uses (flag > VCLAW_PI_BIN > config `runtime` >
 * "pi") — not from this file's own idea of where pi lives. An earlier version
 * searched `npm root -g` and friends, which coincides with the resolver on a
 * stock host and silently diverges the moment `VCLAW_PI_BIN` or the config
 * `runtime` field points at a fork: the gate would keep passing while asserting
 * against a pi that is not running. That is "citing a revision that is not the
 * one in force" — inside the very gate written to prevent it.
 *
 * THREE OUTCOMES, kept distinguishable on purpose:
 *   SKIP  — no runtime is resolvable at all (pi genuinely absent). Nothing to assert.
 *   FAIL  — a runtime IS resolved but its declarations cannot be found. That is
 *           "this runtime's UI-method contract is UNVERIFIED", which is exactly
 *           what the gate exists to detect; it must never read as green.
 *   PASS  — a runtime was resolved, its declarations were read, and every declared
 *           method is classified. The path and version are printed so that green
 *           carries its own provenance.
 *
 * SCOPE: this gate makes the CLASSIFICATION exhaustive. It does NOT exercise the
 * cancel path at runtime — that remains unverified and is a separate claim.
 */

import { describe, it, expect } from "vitest";
import { existsSync, readFileSync, realpathSync } from "node:fs";
import { dirname, join } from "node:path";

import { MODAL_UI_METHODS, IGNORED_UI_METHODS } from "../../src/daemon/worker-pi.js";
import { resolveRuntime } from "../../src/lib/runtime.js";

const PI_TYPES_REL = "dist/modes/rpc/rpc-types.d.ts";

interface Anchor {
  /** Absolute path to the declarations, or null when the runtime has none. */
  typesPath: string | null;
  /** The binary the daemon would actually run. */
  bin: string;
  /** Which layer supplied it: flag | env | config | default. */
  source: string;
  /** True when that binary resolves to something that exists on this host. */
  present: boolean;
}

function realpathSafe(p: string): string {
  try {
    return realpathSync(p);
  } catch {
    return p;
  }
}

/** PATH lookup for a bare name, without spawning a shell. */
function whichSync(name: string): string | null {
  if (name.includes("/")) return existsSync(name) ? name : null;
  for (const dir of (process.env.PATH ?? "").split(":")) {
    if (!dir) continue;
    const candidate = join(dir, name);
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

/**
 * Walk up from the resolved binary to the package that declares the RPC types.
 * The entry is normally a symlink three levels below the package root
 * (`<pkg>/dist/bundle/cli.js`), so this walks rather than counting dirnames.
 */
function findTypesUpward(from: string): string | null {
  let dir = dirname(realpathSafe(from));
  for (let i = 0; i < 8; i++) {
    const candidate = join(dir, PI_TYPES_REL);
    if (existsSync(candidate)) return candidate;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

function locateAnchor(): Anchor {
  const { bin, source } = resolveRuntime();
  const resolved = whichSync(bin);
  return {
    typesPath: resolved ? findTypesUpward(resolved) : null,
    bin,
    source,
    present: resolved !== null,
  };
}

const anchor = locateAnchor();

/** Every `method: "x"` inside pi's RpcExtensionUIRequest union. */
function declaredMethods(): string[] {
  const src = readFileSync(anchor.typesPath as string, "utf-8");
  const start = src.indexOf("export type RpcExtensionUIRequest");
  expect(start, "RpcExtensionUIRequest not found in the runtime's rpc-types.d.ts").toBeGreaterThanOrEqual(0);
  const end = src.indexOf("\n};", start);
  const union = src.slice(start, end === -1 ? undefined : end);
  const found = [...union.matchAll(/method:\s*"([^"]+)"/g)].map((m) => m[1]);
  expect(found.length, "no method declarations parsed — did the runtime change the shape?").toBeGreaterThan(0);
  return found;
}

/** Version of the package owning the resolved declarations, for the provenance line. */
function anchorVersion(): string {
  let dir = dirname(anchor.typesPath as string);
  for (let i = 0; i < 8; i++) {
    const pkg = join(dir, "package.json");
    if (existsSync(pkg)) {
      try {
        return (JSON.parse(readFileSync(pkg, "utf-8")) as { version?: string }).version ?? "unknown";
      } catch {
        return "unparseable";
      }
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return "unknown";
}

// SKIP only when no runtime is resolvable: with no runtime there is nothing to
// assert about. A runtime that EXISTS but exposes no declarations is a FAIL below.
const suite = anchor.present ? describe : describe.skip;

suite("pi extension-UI method classification", () => {
  it("anchors on the runtime in force, and green carries its provenance", () => {
    // Printed so a passing run states WHAT it asserted against. Without this,
    // "asserted against X", "no runtime" and "no declarations" all read as green.
    console.log(
      `[pi-ui-methods] asserted against ${anchor.typesPath} (v${anchorVersion()}) ` +
        `— runtime "${anchor.bin}" via ${anchor.source}`,
    );
    expect(anchor.typesPath, "a runtime resolved but exposed no rpc-types.d.ts").toBeTruthy();
  });

  it("classifies EVERY method the running runtime declares — modal or ignored, never neither", () => {
    const classified = new Set<string>([...MODAL_UI_METHODS, ...IGNORED_UI_METHODS]);
    const unclassified = declaredMethods().filter((m) => !classified.has(m));

    expect(
      unclassified,
      `the runtime declares extension-UI method(s) this daemon has not classified: ${unclassified.join(", ")}. ` +
        `Decide for each: does it AWAIT a human response (add to MODAL_UI_METHODS — it must be ` +
        `cancelled or the worker wedges), or does it emit-and-return (add to IGNORED_UI_METHODS)?`,
    ).toEqual([]);
  });

  it("carries no stale entry for a method the runtime no longer declares", () => {
    const declared = new Set(declaredMethods());
    const stale = [...MODAL_UI_METHODS, ...IGNORED_UI_METHODS].filter((m) => !declared.has(m));
    expect(stale, `classified but absent from the runtime's declarations: ${stale.join(", ")}`).toEqual([]);
  });

  it("keeps the two lists disjoint — a method cannot be both", () => {
    const overlap = MODAL_UI_METHODS.filter((m) =>
      (IGNORED_UI_METHODS as readonly string[]).includes(m),
    );
    expect(overlap).toEqual([]);
  });

  it("regression: `editor` is MODAL", () => {
    // The specific bug this file exists for. If someone simplifies the list back
    // to three entries, this is the assertion that fails.
    expect(MODAL_UI_METHODS as readonly string[]).toContain("editor");
    expect(IGNORED_UI_METHODS as readonly string[]).not.toContain("editor");
  });
});
