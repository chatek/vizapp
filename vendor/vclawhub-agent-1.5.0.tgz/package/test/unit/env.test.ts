/**
 * env() accessor tests (Wave-1 vclaw migration).
 *
 * Canonical VCLAW_* names with VCHAT_* legacy fallback: deployed agents
 * that still export VCHAT_* keep working; VCLAW_* wins when both are set.
 */

import { describe, it, expect, afterEach } from "vitest";
import { env } from "../../src/env.js";

afterEach(() => {
  delete process.env.VCLAW_SEGMENT;
  delete process.env.VCHAT_SEGMENT;
  delete process.env.VCLAW_CREDS_DIR;
  delete process.env.VCHAT_CREDS_DIR;
});

describe("env() — canonical VCLAW_* with VCHAT_* fallback", () => {
  it("reads the canonical VCLAW_* name", () => {
    process.env.VCLAW_SEGMENT = "prod";
    expect(env("SEGMENT")).toBe("prod");
  });

  it("still honors legacy VCHAT_* when VCLAW_* is unset (deployed-agent compat)", () => {
    delete process.env.VCLAW_SEGMENT;
    process.env.VCHAT_SEGMENT = "legacy-seg";
    expect(env("SEGMENT")).toBe("legacy-seg");
  });

  it("VCLAW_* wins when BOTH are set", () => {
    process.env.VCLAW_SEGMENT = "canonical";
    process.env.VCHAT_SEGMENT = "legacy";
    expect(env("SEGMENT")).toBe("canonical");
  });

  it("returns undefined when neither form is set", () => {
    expect(env("SEGMENT")).toBeUndefined();
  });

  it("treats empty-string values as unset (falls through to the legacy form)", () => {
    process.env.VCLAW_CREDS_DIR = "";
    process.env.VCHAT_CREDS_DIR = "/legacy/dir";
    expect(env("CREDS_DIR")).toBe("/legacy/dir");
  });
});
