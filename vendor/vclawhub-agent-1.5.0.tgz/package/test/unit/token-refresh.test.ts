import { describe, expect, it, vi, afterEach } from "vitest";
import { fetchNatsUserJWT } from "../../src/agent/lifecycle.js";

// ── fetchNatsUserJWT retry (L1-G5) ─────────────────────────────────────────
// The token fetch must survive transient failures: 3 attempts with backoff.

const NKEY_PUB = "UC5KIIF52YZZWYZWJPNAKCAU3FSK2R634ERQZARRT6NYHGRFJ3J4M574";
const SEED = "SUAJOU4JEUZ4TSI2AOHPO3TIBXACJXC7TA3HVLCFYN263PD4UDWK2M3QTE";

function mockFetchOnce(fn: (url: string, init: RequestInit) => Promise<Response> | Response) {
  const mock = vi.fn(fn);
  vi.stubGlobal("fetch", mock);
  return mock;
}

function okResponse(token: string): Response {
  return new Response(JSON.stringify({ access_token: token }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

function errResponse(status: number): Response {
  return new Response(`{"error":"boom"}`, { status, headers: { "Content-Type": "application/json" } });
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("fetchNatsUserJWT", () => {
  it("succeeds on the first attempt", async () => {
    const mock = mockFetchOnce(() => okResponse("jwt-1"));
    const jwt = await fetchNatsUserJWT("http://vgate.test", NKEY_PUB, SEED);
    expect(jwt).toBe("jwt-1");
    expect(mock).toHaveBeenCalledTimes(1);
  });

  it("retries (3x backoff) after transient 5xx then succeeds", async () => {
    const mock = mockFetchOnce(() => {
      const calls = mock.mock.calls.length;
      return calls <= 2 ? errResponse(503) : okResponse("jwt-after-retry");
    });
    const jwt = await fetchNatsUserJWT("http://vgate.test", NKEY_PUB, SEED);
    expect(jwt).toBe("jwt-after-retry");
    expect(mock).toHaveBeenCalledTimes(3);
  });

  it("rejects after 3 consecutive failures", async () => {
    const mock = mockFetchOnce(() => errResponse(500));
    await expect(fetchNatsUserJWT("http://vgate.test", NKEY_PUB, SEED)).rejects.toThrow(/500/);
    expect(mock).toHaveBeenCalledTimes(3);
  });

  it("rejects when the response has no access_token", async () => {
    mockFetchOnce(() => okResponse(""));
    await expect(fetchNatsUserJWT("http://vgate.test", NKEY_PUB, SEED)).rejects.toThrow(
      /no access_token/,
    );
  });
});
