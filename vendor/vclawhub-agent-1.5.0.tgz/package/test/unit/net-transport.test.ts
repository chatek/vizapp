/**
 * net-transport.test.ts — M1 seam passthrough parity (Pears Tier P).
 *
 * Spec: A2A/pears-assessment/M1-SEAM-DESIGN.md §4.3 (risks R1–R4). A structural
 * fake NatsConnection implements publish/subscribe only — the seam proves its
 * own abstraction. The REAL client is exercised unchanged by the integration
 * suites (a2a-presence-roundtrip, conv-identity), whose off-the-wire frame
 * assertions are the byte-level parity proof; this unit pins the adapter's
 * contract directly:
 *
 *   1. publish forwards the exact subject and the exact Uint8Array (identity).
 *   2. subscribe delivers {subject, data, reply} field-for-field, INCLUDING
 *      reply: "" — the falsy `if (msg.reply)` ack branch has zero other test
 *      coverage (no `.request(` anywhere in test/), so this is R1's only guard.
 *   3. the returned handle IS the underlying subscription object (===), and
 *      unsubscribe() reaches it (R2).
 *   4. publish rethrows whatever the connection throws — no swallowed errors (R4).
 *   5. callback delivery is synchronous and exactly-once (R2).
 */
import { describe, it, expect, vi } from "vitest";
import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { natsTransport } from "../../src/net/transport.js";

interface SubRecord {
  subject: string;
  sub: Subscription;
  /** Deliver exactly as nats-core does: reply is a string, "" when absent. */
  deliver: (msg: { subject: string; data: Uint8Array; reply: string }) => void;
  deliverError: (err: Error) => void;
}

function fakeNc(): { nc: NatsConnection; published: { subject: string; data: Uint8Array }[]; subs: SubRecord[] } {
  const published: { subject: string; data: Uint8Array }[] = [];
  const subs: SubRecord[] = [];
  const nc = {
    publish(subject: string, data: Uint8Array) {
      published.push({ subject, data });
    },
    subscribe(subject: string, opts: { callback: (e: Error | null, m: unknown) => void }) {
      const unsubscribe = vi.fn();
      const sub = { unsubscribe } as unknown as Subscription;
      subs.push({
        subject,
        sub,
        deliver: (msg) => opts.callback(null, msg),
        deliverError: (err) => opts.callback(err, { subject: "", data: new Uint8Array(), reply: "" }),
      });
      return sub;
    },
  } as unknown as NatsConnection;
  return { nc, published, subs };
}

describe("natsTransport — M1 seam passthrough parity", () => {
  it("1. publish forwards the exact subject and the exact Uint8Array (identity, no re-encode)", () => {
    const { nc, published } = fakeNc();
    const t = natsTransport(nc);
    const bytes = new TextEncoder().encode('{"type":"a2a_request"}');
    t.publish("tenant.vchat.a2a.TARGET.req", bytes);
    expect(published).toHaveLength(1);
    expect(published[0].subject).toBe("tenant.vchat.a2a.TARGET.req");
    expect(published[0].data).toBe(bytes); // R3: bytes pass through untouched
  });

  it("2. subscribe delivers {subject, data, reply} field-for-field — INCLUDING reply: '' (R1's only guard)", () => {
    const { nc, subs } = fakeNc();
    const t = natsTransport(nc);
    const got: { subject: string; data: Uint8Array; reply: string }[] = [];
    t.subscribe("tenant.vchat.a2a.ME.>", { callback: (_err, msg) => void got.push(msg) });

    expect(subs).toHaveLength(1);
    expect(subs[0].subject).toBe("tenant.vchat.a2a.ME.>");

    const data = new TextEncoder().encode("x");
    subs[0].deliver({ subject: "tenant.vchat.a2a.ME.req", data, reply: "" });
    subs[0].deliver({ subject: "tenant.vchat.a2a.ME.req", data, reply: "_INBOX.abc" });

    expect(got).toHaveLength(2);
    expect(got[0]).toEqual({ subject: "tenant.vchat.a2a.ME.req", data, reply: "" });
    expect(got[0].data).toBe(data);
    expect(got[0].reply).toBe(""); // "" — NOT undefined; `if (msg.reply)` stays falsy
    expect(got[1].reply).toBe("_INBOX.abc");
  });

  it("3. the returned handle IS the underlying subscription object (===) and unsubscribe() reaches it (R2)", () => {
    const { nc, subs } = fakeNc();
    const t = natsTransport(nc);
    const handle = t.subscribe("s", { callback: () => {} });
    expect(subs).toHaveLength(1);
    expect(handle).toBe(subs[0].sub); // object identity — callers keep today's handle
    handle.unsubscribe();
    expect((subs[0].sub as unknown as { unsubscribe: ReturnType<typeof vi.fn> }).unsubscribe).toHaveBeenCalledTimes(1);
  });

  it("4. publish rethrows whatever the connection throws — no swallowed errors (R4)", () => {
    const boom = new Error("connection closed");
    const nc = {
      publish() {
        throw boom;
      },
    } as unknown as NatsConnection;
    const t = natsTransport(nc);
    expect(() => t.publish("s", new Uint8Array())).toThrow(boom);
  });

  it("5. callback delivery is synchronous and exactly-once (R2); error deliveries pass the same Error through", () => {
    const { nc, subs } = fakeNc();
    const t = natsTransport(nc);
    let calls = 0;
    let insideDeliver = false;
    let syncDelivery = false;
    const seenErrs: (Error | null)[] = [];
    t.subscribe("s", {
      callback: (err, _msg) => {
        calls++;
        if (insideDeliver) syncDelivery = true;
        seenErrs.push(err);
      },
    });

    insideDeliver = true;
    subs[0].deliver({ subject: "s", data: new Uint8Array(), reply: "" });
    insideDeliver = false;

    const err = new Error("subscription error");
    insideDeliver = true;
    subs[0].deliverError(err);
    insideDeliver = false;

    expect(calls).toBe(2); // once per delivery, never duplicated
    expect(syncDelivery).toBe(true); // invoked during deliver(), not deferred
    expect(seenErrs).toEqual([null, err]); // the exact Error object, not a re-wrap
  });
});
