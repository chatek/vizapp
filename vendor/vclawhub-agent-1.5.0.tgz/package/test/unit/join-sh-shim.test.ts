/**
 * join-sh-shim.test.ts — hermetic tests for bin/join.sh (the thin | sh entrypoint).
 *
 * The shim's whole job: bun >=1.2 gate (junk versions fail closed), consent-gated
 * bun install (R2: never a side effect), --install-bun filtered from the
 * passthrough, exit-code propagation, handoff `curl JOIN_URL | bun - args`.
 *
 * Hermetic by construction: temp HOME, PATH containing ONLY fakes + /usr/bin:/bin
 * (no system bun can leak in), file:// JOIN_URL and installer URL (no network).
 * Lane: release 1.3.0 (2026-10-02). Non-vacuity: renaming --install-bun or
 * breaking the filter/gate turns these RED.
 */
import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync, chmodSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const SHIM = join(fileURLToPath(new URL("../../bin/join.sh", import.meta.url)));

interface Fixture {
  home: string;
  fakeDir: string;
  joinUrl: string;
  installerUrl: string;
  cleanup: () => void;
}

function fixture(bunVersion?: string, installerCreatesBun = true): Fixture {
  const t = mkdtempSync(join(tmpdir(), "join-shim-"));
  const home = join(t, "home");
  const fakeDir = join(t, "bin");
  mkdirSync(home);
  mkdirSync(fakeDir);
  const bunScript = bunVersion === undefined
    ? "#!/bin/sh\nexit 42\n" // never invoked (absent from PATH)
    : `#!/bin/sh\nif [ "$1" = "--version" ]; then echo "${bunVersion}"; exit 0; fi\necho "FAKEBUN_ARGS:$*"\ncat > /dev/null\nexit 7\n`;
  writeFileSync(join(fakeDir, "bun"), bunScript);
  chmodSync(join(fakeDir, "bun"), 0o755);
  writeFileSync(join(t, "join.ts"), 'console.log("PAYLOAD");\n');
  // stub installer: records the run; optionally drops a working faux bun into $HOME/.bun/bin
  writeFileSync(join(t, "installer.sh"), installerCreatesBun
    ? `#!/bin/sh\necho "STUB_INSTALLER_RAN"\nmkdir -p "$HOME/.bun/bin"\nprintf '%s\\n' '#!/bin/sh' 'if [ "$1" = "--version" ]; then echo "1.4.0"; exit 0; fi' 'echo "INSTALLEDBUN_ARGS:$*"' 'cat > /dev/null' 'exit 0' > "$HOME/.bun/bin/bun"\nchmod +x "$HOME/.bun/bin/bun"\n`
    : '#!/bin/sh\necho "STUB_INSTALLER_RAN"\n');
  chmodSync(join(t, "installer.sh"), 0o755);
  return {
    home,
    fakeDir,
    joinUrl: `file://${join(t, "join.ts")}`,
    installerUrl: `file://${join(t, "installer.sh")}`,
    cleanup: () => rmSync(t, { recursive: true, force: true }),
  };
}

function runShim(fx: Fixture, args: string[], opts: { withFakeBun?: boolean; env?: Record<string, string> } = {}) {
  const { withFakeBun = true, env = {} } = opts;
  try {
    const stdout = execFileSync("sh", [SHIM, ...args], {
      encoding: "utf8",
      env: {
        HOME: fx.home,
        VCLAW_JOIN_URL: fx.joinUrl,
        VCLAW_BUN_INSTALL_URL: fx.installerUrl,
        PATH: `${withFakeBun ? fx.fakeDir + ":" : ""}/usr/bin:/bin`,
        ...env,
      },
    });
    return { code: 0, stdout };
  } catch (e) {
    const err = e as { status?: number; stdout?: string; stderr?: string };
    return { code: err.status ?? -1, stdout: err.stdout ?? "", stderr: err.stderr ?? "" };
  }
}

describe("bin/join.sh thin shim", () => {
  it("hands off: payload through the pipe, args passthrough (bun sees `- <args>`), exit code propagates", () => {
    const fx = fixture("1.4.0");
    const r = runShim(fx, ["my-agent", "--runtime", "pi"]);
    expect(r.code).toBe(7); // fake bun exits 7 — must propagate
    expect(r.stdout).toContain("handing off to");
    expect(r.stdout).toContain("FAKEBUN_ARGS:- my-agent --runtime pi");
    fx.cleanup();
  });

  it("filters --install-bun out of the passthrough (and does NOT install when bun is present)", () => {
    const fx = fixture("1.4.0");
    const r = runShim(fx, ["my-agent", "--install-bun"]);
    expect(r.code).toBe(7);
    expect(r.stdout).toContain("FAKEBUN_ARGS:- my-agent");
    expect(r.stdout).not.toContain("--install-bun");
    expect(r.stdout).not.toContain("STUB_INSTALLER_RAN");
    fx.cleanup();
  });

  it("old bun (<1.2) is refused: exit 1, no handoff, no installer", () => {
    const fx = fixture("0.6.14");
    const r = runShim(fx, []);
    expect(r.code).toBe(1);
    expect(r.stderr).toContain("required");
    expect(r.stdout).not.toContain("FAKEBUN_ARGS");
    expect(r.stdout).not.toContain("STUB_INSTALLER_RAN");
    fx.cleanup();
  });

  it("junk `bun --version` output fails CLOSED (refused, not guessed)", () => {
    const fx = fixture("not.a.version");
    const r = runShim(fx, []);
    expect(r.code).toBe(1);
    expect(r.stderr).toContain("required");
    fx.cleanup();
  });

  it("bun absent + no consent: exit 1, hint names bun.sh, nothing installed", () => {
    const fx = fixture(undefined);
    const r = runShim(fx, [], { withFakeBun: false });
    expect(r.code).toBe(1);
    expect(r.stderr).toContain("bun.sh/install");
    expect(r.stdout).not.toContain("STUB_INSTALLER_RAN");
    fx.cleanup();
  });

  it("bun absent + --install-bun consent: stub installer runs, installed bun receives the handoff", () => {
    const fx = fixture(undefined);
    const r = runShim(fx, ["--install-bun", "consent-agent"], { withFakeBun: false });
    expect(r.code).toBe(0);
    expect(r.stdout).toContain("STUB_INSTALLER_RAN");
    expect(r.stdout).toContain("INSTALLEDBUN_ARGS:- consent-agent");
    fx.cleanup();
  });

  it("INSTALL_BUN=1 env is equivalent consent to the flag", () => {
    const fx = fixture(undefined);
    const r = runShim(fx, ["env-consent"], { withFakeBun: false, env: { INSTALL_BUN: "1" } });
    expect(r.code).toBe(0);
    expect(r.stdout).toContain("INSTALLEDBUN_ARGS:- env-consent");
    fx.cleanup();
  });
});
