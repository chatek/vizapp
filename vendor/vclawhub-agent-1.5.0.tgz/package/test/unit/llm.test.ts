import { describe, it, expect, afterEach, beforeEach } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  parseDirective,
  saveLLMConfig,
  loadLLMConfig,
  clearLLMConfig,
  maskKey,
  chatCompletionsURL,
} from "../../src/lib/llm.js";

let tmp: string;

beforeEach(() => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), "llm-test-"));
});
afterEach(() => {
  fs.rmSync(tmp, { recursive: true, force: true });
});

describe("parseDirective", () => {
  it("parses llm set with url/key/model tokens (order-insensitive)", () => {
    expect(parseDirective("llm set model=llama3.2:1b key=sk-abc url=http://localhost:11434")).toEqual({
      kind: "set",
      url: "http://localhost:11434",
      key: "sk-abc",
      model: "llama3.2:1b",
    });
  });

  it("tolerates a leading @mention (the room-message flow)", () => {
    expect(parseDirective("@alpha-hello-1 llm set url=http://h:18080 key=sk-mock model=mock-1")).toEqual({
      kind: "set",
      url: "http://h:18080",
      key: "sk-mock",
      model: "mock-1",
    });
  });

  it("parses a directive on the first line of a multi-line message", () => {
    expect(parseDirective("llm unset\nthanks")).toEqual({ kind: "unset" });
  });

  it("parses llm status", () => {
    expect(parseDirective("llm status")).toEqual({ kind: "status" });
  });

  it("rejects missing fields with a usage hint", () => {
    const d = parseDirective("llm set url=http://x key=sk-1");
    expect(d?.kind).toBe("invalid");
  });

  it("rejects non-key=value tokens", () => {
    const d = parseDirective("llm set bare-token url=x key=k model=m");
    expect(d?.kind).toBe("invalid");
  });

  it("returns null for non-directive messages", () => {
    expect(parseDirective("hello there")).toBeNull();
    expect(parseDirective("  llmish set url=x")).toBeNull();
  });
});

describe("config round-trip", () => {
  it("saves, loads, clears", () => {
    const p = path.join(tmp, "llm.json");
    expect(loadLLMConfig(tmp)).toBeNull();
    saveLLMConfig(tmp, { base_url: "http://h:11434", api_key: "sk-secret", model: "m1" });
    expect(loadLLMConfig(tmp)).toEqual({ base_url: "http://h:11434", api_key: "sk-secret", model: "m1" });
    // 0600 on the file (holds a secret)
    const mode = fs.statSync(p).mode & 0o777;
    expect(mode).toBe(0o600);
    clearLLMConfig(tmp);
    expect(loadLLMConfig(tmp)).toBeNull();
  });

  it("treats corrupt JSON as unconfigured", () => {
    fs.writeFileSync(path.join(tmp, "llm.json"), "{not json");
    expect(loadLLMConfig(tmp)).toBeNull();
  });
});

describe("maskKey", () => {
  it("masks the middle", () => {
    expect(maskKey("sk-abcdefghijklmnop")).toBe("sk-a…mnop");
  });
  it("masks short keys fully", () => {
    expect(maskKey("short")).toBe("•••");
  });
});

describe("chatCompletionsURL", () => {
  it("appends /v1/chat/completions", () => {
    expect(chatCompletionsURL("http://localhost:11434")).toBe("http://localhost:11434/v1/chat/completions");
  });
  it("keeps an explicit /v1", () => {
    expect(chatCompletionsURL("https://api.openai.com/v1")).toBe("https://api.openai.com/v1/chat/completions");
  });
  it("strips trailing slashes", () => {
    expect(chatCompletionsURL("http://h:11434///")).toBe("http://h:11434/v1/chat/completions");
  });
});
