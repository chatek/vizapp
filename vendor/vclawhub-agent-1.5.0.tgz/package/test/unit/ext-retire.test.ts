/**
 * W4 lane B — retired-identity propagation tests (additive).
 *
 * Layers:
 *   B-control: receiving the retire control subject
 *     (tenant.<seg>.agent.retired.<nkey>, via SubjectTree.RETIRED) triggers
 *     the TERMINAL path: presence.stop (graceful offline announce online:false)
 *     + nc.close + identity_retired event + banner; /vchat-connect afterwards
 *     refuses with E_RETIRED (never auto re-onboard; credentials kept).
 *   B-403: JWT fetch 403 agent_not_claimed (token.go:111) → status probe →
 *     absent ownership AND absent pending → same retired UX (identity_retired
 *     event + E_CONNECT carrying the retired banner).
 *   B-transient: 403 + pending status → NOT retired (original error, no
 *     identity_retired); 500 token error → NOT retired, NO probe fired.
 *
 * Harness discipline: same as ext-gate.test.ts (capturing mock pi;
 * store/lifecycle/directory/contracts/subjects mocked; @nats-io/kv faked for
 * the real OnlineGate). The retire subject mock uses the live-segment form
 * "tenant.vchat.agent.retired.<nkey>".
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  loadCredentials: vi.fn(),
  hasPendingFlag: vi.fn(),
  readConfig: vi.fn(),
  saveConfig: vi.fn(),
  fetchNatsUserJWT: vi.fn(),
  connectViaJWT: vi.fn(),
  startPresence: vi.fn(),
  subA2A: vi.fn(),
  watchDirectory: vi.fn(),
  setTenantSegment: vi.fn(),
}));

vi.mock("../../src/lib/store.js", () => ({
  loadCredentials: mocks.loadCredentials,
  hasPendingFlag: mocks.hasPendingFlag,
  readConfig: mocks.readConfig,
  saveConfig: mocks.saveConfig,
}));
vi.mock("../../src/agent/lifecycle.js", () => ({
  fetchNatsUserJWT: mocks.fetchNatsUserJWT,
  connectViaJWT: mocks.connectViaJWT,
  startPresence: mocks.startPresence,
  subA2A: mocks.subA2A,
}));
vi.mock("../../src/net/directory.js", () => ({
  watchDirectory: mocks.watchDirectory,
}));
vi.mock("../../src/contracts/contracts.js", () => ({
  setTenantSegment: mocks.setTenantSegment,
}));
vi.mock("../../src/agent/subjects.js", () => ({
  SubjectTree: {
    CLAIM: () => "tenant.vchat.claim.FAKE_NKEY",
    PROMPT: () => "tenant.vchat.user.FAKE_NKEY.agent.FAKE_NKEY.prompt.>",
    RETIRED: (nkey: string) => `tenant.vchat.agent.retired.${nkey}`,
  },
}));
vi.mock("@nats-io/kv", () => ({
  Kvm: class {
    constructor(_nc: unknown) { /* nc ignored by the fake */ }
    async open(_bucket: string) {
      return { get: async () => null };
    }
  },
}));

const NKEY = "UAARETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRET";

const CREDS = {
  seed: "SUARETIREDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEED",
  public_key: "UAARETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRET",
  agent_nkey: "UAARETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRET",
  name: "test-agent",
  steward: "tester@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
} as const;

const RETIRED_SUBJECT = `tenant.vchat.agent.retired.${NKEY}`;

/** Captures subscribe(subject, {callback}) — lets tests fire the retire msg. */
function fakeNc() {
  const subs = new Map<string, { cb?: (err: unknown, msg: unknown) => void }>();
  return {
    subs,
    subscribe: vi.fn((subject: string, opts?: { callback?: (err: unknown, msg: unknown) => void }) => {
      subs.set(subject, { cb: opts?.callback });
      return {
        subject,
        unsubscribe: vi.fn(),
        [Symbol.asyncIterator]() {
          return { next: async () => ({ done: true as const, value: undefined }) };
        },
      };
    }),
    publish: vi.fn(),
    drain: vi.fn(async () => {}),
    close: vi.fn(() => {}),
  };
}

let presenceStop: ReturnType<typeof vi.fn>;

beforeEach(async () => {
  vi.clearAllMocks();
  vi.unstubAllGlobals();
  delete process.env.VCHAT_AGENT_LLM;
  presenceStop = vi.fn(async () => {});
  mocks.loadCredentials.mockResolvedValue(CREDS);
  mocks.fetchNatsUserJWT.mockResolvedValue("JWT-x");
  mocks.startPresence.mockReturnValue({ stop: presenceStop });
  mocks.subA2A.mockReturnValue(undefined);
  mocks.watchDirectory.mockReturnValue({ directory: { snapshot: () => [] }, stop: () => {} });
  vi.resetModules();
});

afterEach(() => {
  vi.unstubAllGlobals();
  delete process.env.VCHAT_AGENT_LLM;
});

async function factory() {
  return (await import("../../src/pi-extension/index.ts")).default;
}

function harness(factoryFn: (pi: unknown) => void) {
  const commands = new Map<string, (args: string, ctx: unknown) => Promise<void>>();
  const pi = {
    on: vi.fn(),
    registerCommand: vi.fn((name: string, spec: { handler: (a: string, c: unknown) => Promise<void> }) =>
      commands.set(name, spec.handler)),
    sendUserMessage: vi.fn(),
  };
  factoryFn(pi);
  return { commands, pi };
}

/** notify-capturing ctx; frames = raw notify strings (structured events + command results). */
function notifyCtx() {
  const frames: Array<{ m: string; t?: string }> = [];
  const ctx = {
    hasUI: true,
    ui: { notify: (m: string, t?: "info" | "warning" | "error") => { frames.push({ m, t }); } },
  };
  return { frames, ctx };
}

async function connect(factoryFn: (pi: unknown) => void, nc: ReturnType<typeof fakeNc>) {
  mocks.connectViaJWT.mockResolvedValue(nc);
  const { commands } = harness(factoryFn);
  const { frames, ctx } = notifyCtx();
  await commands.get("vchat-connect")!("", ctx);
  return { commands, frames };
}

function parsed(frames: Array<{ m: string; t?: string }>) {
  return frames
    .map((f) => { try { return JSON.parse(f.m) as Record<string, unknown>; } catch { return null; } })
    .filter((p): p is Record<string, unknown> => p !== null && p.__vchat === true);
}

// ── B-control: control-subject receipt is terminal ───────────────────────────
describe("B-control: retire control subject receipt", () => {
  it("presence.stop + nc.close + identity_retired event + banner; connect refuses after", async () => {
    const f = await factory();
    const nc = fakeNc();
    const { commands, frames } = await connect(f, nc);

    // Fire the retire control message (vgate publish contract: reason/steward).
    const cb = nc.subs.get(RETIRED_SUBJECT)?.cb;
    expect(cb).toBeTruthy();
    cb!(null, {
      // The subscription is the exact own-nkey subject (no wildcard), so the
      // delivered subject IS the subscription subject. A frame with no subject
      // cannot be routed — the extension refuses it early
      // (src/pi-extension/index.ts:550) — so the fixture must carry one.
      subject: RETIRED_SUBJECT,
      data: new TextEncoder().encode(
        JSON.stringify({ retired_at: "2026-08-19T10:00:00Z", reason: "decommissioned", steward: "tester@vchat.email" }),
      ),
    });

    await vi.waitFor(() => expect(presenceStop).toHaveBeenCalledTimes(1));
    await vi.waitFor(() => expect(nc.close).toHaveBeenCalled()); // drain+close in runtime.close()
    expect(nc.drain).toHaveBeenCalled();

    await vi.waitFor(() => {
      expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(1);
    });
    const events = parsed(frames).filter((p) => p.kind === "identity_retired");
    expect(events[0]).toMatchObject({ kind: "identity_retired", nkey: NKEY, reason: "decommissioned", steward: "tester@vchat.email" });

    // Terminal: a subsequent /vchat-connect refuses (never auto re-onboard).
    const { frames: f2frames, ctx: f2ctx } = notifyCtx();
    await commands.get("vchat-connect")!("", f2ctx);
    const results = parsed(f2frames).filter((p) => p.kind === "command_result");
    expect(results[0]).toMatchObject({ command: "connect", success: false, code: "E_RETIRED" });
    expect((results[0].error as string).toLowerCase()).toContain("identity retired");
  });

  it("malformed payload still retires (subject is authoritative); idempotent second receipt", async () => {
    const f = await factory();
    const nc = fakeNc();
    const { frames } = await connect(f, nc);
    const cb = nc.subs.get(RETIRED_SUBJECT)?.cb!;

    cb(null, { subject: RETIRED_SUBJECT, data: new TextEncoder().encode("not-json") });
    await vi.waitFor(() => expect(presenceStop).toHaveBeenCalledTimes(1));
    await vi.waitFor(() => {
      expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(1);
    });

    // Second receipt: idempotent — no extra close/event.
    cb(null, { subject: RETIRED_SUBJECT, data: new TextEncoder().encode(JSON.stringify({ reason: "compromised" })) });
    await new Promise((r) => setTimeout(r, 10));
    expect(presenceStop).toHaveBeenCalledTimes(1);
    expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(1);
  });
});

// ── B-403: JWT 403 agent_not_claimed → status probe → retired UX ─────────────
describe("B-403: 403 agent_not_claimed probes ownership", () => {
  it("absent ownership AND absent pending → retired UX (event + retired connect error)", async () => {
    mocks.fetchNatsUserJWT.mockRejectedValue(
      new Error('token endpoint 403: {"error":"agent_not_claimed","message":"agent not claimed or already issued"}'),
    );
    const statusFetch = vi.fn(async () => ({ ok: true, json: async () => ({ claimed: false }) }));
    vi.stubGlobal("fetch", statusFetch);

    const f = await factory();
    const nc = fakeNc();
    const { commands, frames } = await connect(f, nc);

    // Probe fired with the status URL (status.go normalizes both nkey forms).
    expect(statusFetch).toHaveBeenCalledWith(expect.stringContaining("/v1/agent/status?nkey="));

    await vi.waitFor(() => {
      expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(1);
    });
    const events = parsed(frames).filter((p) => p.kind === "identity_retired");
    expect(events[0]).toMatchObject({ kind: "identity_retired", nkey: NKEY });

    const results = parsed(frames).filter((p) => p.kind === "command_result");
    expect(results[0]).toMatchObject({ command: "connect", success: false });
    expect((results[0].error as string).toLowerCase()).toContain("identity retired");

    // Terminal going forward: the same module's connect command now refuses.
    const { frames: f2frames, ctx: f2ctx } = notifyCtx();
    await commands.get("vchat-connect")!("", f2ctx);
    const r2 = parsed(f2frames).filter((p) => p.kind === "command_result");
    expect(r2[0]?.code).toBe("E_RETIRED");
  });

  it("pending status → NOT retired (original error, no identity_retired)", async () => {
    mocks.fetchNatsUserJWT.mockRejectedValue(
      new Error('token endpoint 403: {"error":"agent_not_claimed"}'),
    );
    const statusFetch = vi.fn(async () => ({ ok: true, json: async () => ({ claimed: false, status: "pending" }) }));
    vi.stubGlobal("fetch", statusFetch);

    const f = await factory();
    const nc = fakeNc();
    const { frames } = await connect(f, nc);

    expect(statusFetch).toHaveBeenCalled(); // probe ran
    expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(0);
    const results = parsed(frames).filter((p) => p.kind === "command_result");
    expect(results[0]).toMatchObject({ command: "connect", success: false });
    expect((results[0].error as string)).toContain("token endpoint 403"); // original error — NOT retired
    expect(presenceStop).not.toHaveBeenCalled();
  });

  it("transient 500 → NOT retired, NO probe fired", async () => {
    mocks.fetchNatsUserJWT.mockRejectedValue(new Error("token endpoint 500: upstream down"));
    const statusFetch = vi.fn(async () => ({ ok: true, json: async () => ({ claimed: false }) }));
    vi.stubGlobal("fetch", statusFetch);

    const f = await factory();
    const nc = fakeNc();
    const { frames } = await connect(f, nc);

    expect(statusFetch).not.toHaveBeenCalled(); // 403-only probe
    expect(parsed(frames).filter((p) => p.kind === "identity_retired")).toHaveLength(0);
    const results = parsed(frames).filter((p) => p.kind === "command_result");
    expect((results[0].error as string)).toContain("token endpoint 500");
  });
});
