/**
 * p2p-toolchain.test.ts — VISIBILITY for the Tier P sidecar toolchain (M2).
 *
 * Plan §5b.2: an agent without node is a fully functional Tier W agent — the
 * sidecar being unavailable is VALID. But a test suite that silently skips
 * its gates is a vacuous pass (the pitfall log has a lane that shipped one).
 * So this test ALWAYS runs and fails unless either (a) the toolchain is
 * present (node + built sidecar) or (b) PEARS_SIDECAR_OPTIONAL=1 explicitly
 * declares the skip intended, printing exactly what is missing either way.
 */
import { describe, it, expect } from "vitest";
import { toolchain } from "../helpers/pears-sidecar.js";

describe("Tier P sidecar toolchain", () => {
  it("node runtime + built sidecar are present, or the skip is EXPLICIT", () => {
    const tc = toolchain();
    const explicitlyOptional = process.env.PEARS_SIDECAR_OPTIONAL === "1";
    // eslint-disable-next-line no-console
    console.log(
      "[pears-toolchain] node=" + (tc.nodeVersion ?? "MISSING") + " built=" + String(tc.built) + " optional=" + String(explicitlyOptional),
    );
    if (tc.ok) return; // present: nothing to assert, and we said so above
    expect(explicitlyOptional, "Tier P toolchain missing (node=" + (tc.nodeVersion ?? "absent") + ", sidecar built=" + tc.built + "). Set PEARS_SIDECAR_OPTIONAL=1 only when this host is deliberately a Tier W agent.").toBe(true);
  });
});
