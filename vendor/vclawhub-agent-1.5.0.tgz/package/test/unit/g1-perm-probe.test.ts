/**
 * g1-perm-probe.test.ts — v9 G1 grant-reach probe (UPGRADE.md §5 G1, W0
 * deliverable 5). Verifies the PROBE ITSELF (matcher semantics, JWT decode,
 * table format) and runs the STRUCTURAL half of the G1 table against
 * PERMISSIONS.CLAIMED_AGENT (token.go mirror — pinned by the R2-collapse
 * conformance test). The LIVE-JWT half is the CLI:
 *   bun test/helpers/g1-perm-probe.ts --jwt <file|JWT> [--segment s] [--nkey n]
 * and reads "PENDING — needs claimed-agent JWT" until a credential is supplied.
 */
import { describe, it, expect } from "vitest";
import { FAMILY_STATIC_VERBS } from "../../src/contracts/contracts.js";
import {
  claimedAgentGrants,
  extractJwtGrants,
  formatProbeTable,
  g1Verdict,
  G1_PENDING,
  matchGrant,
  probeFamilyGrants,
} from "../helpers/g1-perm-probe.js";

describe("matchGrant — nats-server token semantics", () => {
  it("grant > swallows one-or-more trailing tokens", () => {
    expect(matchGrant("a.b.>", "a.b.c")).toBe(true);
    expect(matchGrant("a.b.>", "a.b.c.d.e")).toBe(true);
    expect(matchGrant("a.b.>", "a.b")).toBe(false); // > needs >=1 token
  });

  it("grant * matches exactly one token", () => {
    expect(matchGrant("a.*.c", "a.b.c")).toBe(true);
    expect(matchGrant("a.*.c", "a.b.d.c")).toBe(false);
    expect(matchGrant("a.*", "a.b")).toBe(true);
  });

  it("exact grants never cover wildcards or deeper subjects", () => {
    expect(matchGrant("a.b", "a.b")).toBe(true);
    expect(matchGrant("a.b", "a.>")).toBe(false); // subject > vs literal grant token
    expect(matchGrant("a.b", "a.b.c")).toBe(false);
  });

  it("family claim: agent-path .> grant covers the family.> subscription subject", () => {
    const grant = "tenant.eng.user.UN.agent.UN.>";
    expect(matchGrant(grant, "tenant.eng.user.UN.agent.UN.family.>")).toBe(true);
    expect(matchGrant(grant, "tenant.eng.user.UN.agent.UN.family.FID.w.prompt.req")).toBe(true);
    expect(matchGrant(grant, "tenant.eng.user.UN.agent.UN.hb")).toBe(true);
  });

  it("scope isolation: a2a / discovery grants do NOT cover the family lane", () => {
    const fam = "tenant.eng.user.UN.agent.UN.family.FID.w.hb";
    expect(matchGrant("tenant.eng.a2a.>", fam)).toBe(false);
    expect(matchGrant("tenant.eng.a2a.UN.>", fam)).toBe(false);
    expect(matchGrant("$SRV.INFO.agents.eng.UN", fam)).toBe(false);
    expect(matchGrant("$KV.vchat_roster.>", fam)).toBe(false);
  });
});

describe("extractJwtGrants — nats JWT payload decode", () => {
  const payload = (nats: Record<string, unknown>): string => {
    const enc = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");
    return `${enc({ alg: "Ed25519", typ: "JWT" })}.${enc({ sub: "U_AGENT", nats })}.c2ln`;
  };

  it("decodes nats.perms with array form", () => {
    const grants = extractJwtGrants(payload({ perms: { pub: ["a.>"], sub: ["b.>"], resp: true } }));
    expect(grants).not.toBeNull();
    expect(grants!.pubAllow).toEqual(["a.>"]);
    expect(grants!.subAllow).toEqual(["b.>"]);
  });

  it("decodes nats.permissions with {allow,deny} form", () => {
    const grants = extractJwtGrants(
      payload({ permissions: { pub: { allow: ["x.y"], deny: ["$SYS.>"] }, sub: { allow: ["z"] } } }),
    );
    expect(grants!.pubAllow).toEqual(["x.y"]);
    expect(grants!.pubDeny).toEqual(["$SYS.>"]);
    expect(grants!.subAllow).toEqual(["z"]);
  });

  it("returns null for garbage / non-JWT input", () => {
    expect(extractJwtGrants("")).toBeNull();
    expect(extractJwtGrants("not-a-jwt")).toBeNull();
    expect(extractJwtGrants("a.b")).toBeNull();
    const badPayload = Buffer.from("not json").toString("base64url");
    expect(extractJwtGrants(`x.${badPayload}.y`)).toBeNull();
  });
});

describe("G1 probe table — structural half (token.go mirror)", () => {
  const SEG = "eng";
  const NKEY = "UA3TESTAGENT";
  const FAMILY_ID = "0a80903e-1c4d-4f6e-9a2b-3f5c6d7e8f90";

  const rows = probeFamilyGrants(claimedAgentGrants(SEG, NKEY), {
    segment: SEG,
    nkey: NKEY,
    familyId: FAMILY_ID,
    name: "worker-a",
    conversationId: "conv-1",
  });

  it("covers the wildcard claim + every verb × both planes", () => {
    // 1 wildcard (sub) + 4 verbs (3 static + reply) × (pub + sub)
    expect(rows.length).toBe(1 + (FAMILY_STATIC_VERBS.length + 1) * 2);
    expect(rows[0].claim).toBe(`tenant.${SEG}.user.${NKEY}.agent.${NKEY}.family.>`);
  });

  it("ALL rows allow — the G1 structural claim holds today", () => {
    for (const r of rows) expect(r.allowed).toBe(true);
  });

  it("the matching grant is ALWAYS the agent-path .> wildcard (no narrower template)", () => {
    for (const r of rows) {
      expect(r.matchedGrant).toBe(`tenant.${SEG}.user.${NKEY}.agent.${NKEY}.>`);
    }
  });

  it("reply.<conv_id> claims are covered too (per-conversation routing, G3)", () => {
    // Explicit-segment subject (a probe row is built for the probe's segment,
    // NOT the runtime SUBJECT_ROOT this test process happens to carry).
    const replySubject = `tenant.${SEG}.user.${NKEY}.agent.${NKEY}.family.${FAMILY_ID}.worker-a.reply.conv-1`;
    const replyRows = rows.filter((r) => r.claim === replySubject);
    expect(replyRows.map((r) => r.plane).sort()).toEqual(["pub", "sub"]);
    for (const r of replyRows) expect(r.allowed).toBe(true);
  });

  it("formats a readable table with allow verdicts", () => {
    const table = formatProbeTable(rows);
    const lines = table.split("\n");
    expect(lines[0]).toContain("plane");
    expect(lines[0]).toContain("claim");
    expect(lines[0]).toContain("allow?");
    expect(table.split("\n").length).toBe(rows.length + 2);
    expect(table).not.toContain("DENY");
  });

  it("verdict: structural PASS notes the live-JWT PENDING marker", () => {
    const v = g1Verdict(rows, "structural");
    expect(v).toContain("G1 PASS");
    expect(v).toContain(G1_PENDING);
  });
});

describe("G1 probe — a narrowed template WOULD fail (the gate has teeth)", () => {
  it("if token.go narrowed the agent path to .hb/.prompt forms, family claims DENY", () => {
    const narrowed = {
      pubAllow: ["tenant.eng.user.UN.agent.UN.hb", "tenant.eng.user.UN.agent.UN.prompt.>"],
      pubDeny: ["$SYS.>"],
      subAllow: ["tenant.eng.user.UN.agent.UN.hb"],
      subDeny: ["$SYS.>"],
    };
    const rows = probeFamilyGrants(narrowed, { segment: "eng", nkey: "UN", familyId: "f", name: "w" });
    expect(rows.every((r) => !r.allowed)).toBe(true);
    expect(g1Verdict(rows, "structural")).toContain("G1 FAIL");
  });
});
