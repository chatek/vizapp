/**
 * v3-grants-conformance.test.ts — THE R2 COLLAPSE.
 *
 * Asserts agent-sdk's claimed-agent grant set (contracts.ts PERMISSIONS.
 * CLAIMED_AGENT) is set-equal to vgate's author­itative grant source:
 *   vgate/internal/agentidp/token.go → DeriveClaimedPermissions(segment, nkey, "", "")
 *
 * WHY THIS TEST EXISTS: token.go is the SINGLE grant source BOTH emit paths
 * (JWT mint + auth callout) call after the S0/R2 collapse (see the docstring
 * on DeriveClaimedPermissions). agent-sdk's PERMISSIONS.CLAIMED_AGENT must
 * mirror it EXACTLY — a drift here means the contract the sidecar/W3 builds
 * against disagrees with what vgate actually enforces at CONNECT.
 *
 * METHOD: the expected grant set below is TRANSCRIBED from reading token.go
 * (the literal PubAllow/SubAllow/PubDeny/SubDeny strings DeriveClaimedPermissions
 * emits). It is NOT a port — there is no Go runtime here. When token.go's
 * grants change, update this fixture + PERMISSIONS.CLAIMED_AGENT together.
 *
 * PERMISSIONS.CLAIMED_AGENT uses `<segment>` / `<nkey>` placeholders (callout-
 * substituted at CONNECT); this test instantiates them with concrete values
 * and compares SETS (NATS allow-lists are order-independent).
 */
import { describe, it, expect } from "vitest";
import { PERMISSIONS } from "../../src/contracts/contracts.js";

const SEG = "eng";
const NKEY = "UA3TESTAGENT";

/**
 * Instantiate a placeholder grant role into concrete pub/sub/deny sets.
 * PERMISSIONS uses one `deny` array applied to both pub + sub (token.go has
 * identical PubDeny + SubDeny = ["$SYS.>"]), so `deny` fans out to both.
 */
function instantiate(
  role: { pub: readonly string[]; sub: readonly string[]; deny: readonly string[] },
  segment: string,
  nkey: string,
): { pubAllow: string[]; pubDeny: string[]; subAllow: string[]; subDeny: string[] } {
  const sub = (s: string): string =>
    s.replaceAll("<segment>", segment).replaceAll("<nkey>", nkey);
  return {
    pubAllow: role.pub.map(sub),
    pubDeny: [...role.deny],
    subAllow: role.sub.map(sub),
    subDeny: [...role.deny],
  };
}

/** Set-equality for grant lists (order-independent — NATS allow-lists). */
const sameSet = (a: string[], b: string[]) => {
  expect(new Set(a), "grant SET mismatch").toEqual(new Set(b));
  expect(a.length, "grant list length (no dup drift)").toBe(b.length);
};

describe("CLAIMED_AGENT grants == vgate token.go DeriveClaimedPermissions (R2 collapse)", () => {
  // ── EXPECTED: transcribed from vgate/internal/agentidp/token.go
  //    DeriveClaimedPermissions(segment, nkey, "", "") ──
  //    (PubAllow 14 / SubAllow 8 / PubDeny = SubDeny = ["$SYS.>"]). Do NOT
  //    edit these literals without re-reading token.go.
  const EXPECTED = {
    pubAllow: [
      `$SRV.INFO.agents.${SEG}.${NKEY}`,
      `tenant.${SEG}.user.${NKEY}.agent.${NKEY}.>`,
      `tenant.${SEG}.a2a.>`,
      `tenant.${SEG}.policy.>`,
      "$JS.API.STREAM.MSG.GET.KV_vchat_roster",
      "$JS.API.STREAM.MSG.GET.KV_vchat_roster.>",
      "$JS.API.STREAM.MSG.GET.KV_vchat_capabilities",
      "$JS.API.STREAM.MSG.GET.KV_vchat_capabilities.>",
      "$JS.API.DIRECT.GET.KV_vchat_roster",
      "$JS.API.DIRECT.GET.KV_vchat_roster.>",
      "$JS.API.DIRECT.GET.KV_vchat_capabilities",
      "$JS.API.DIRECT.GET.KV_vchat_capabilities.>",
      "$JS.API.INFO.>",
      "_INBOX.>",
    ],
    pubDeny: ["$SYS.>"],
    subAllow: [
      `$SRV.INFO.agents.${SEG}.>`,
      `tenant.${SEG}.user.${NKEY}.agent.${NKEY}.>`,
      `tenant.${SEG}.a2a.${NKEY}.>`,
      `tenant.${SEG}.agent.retired.${NKEY}`,
      "$KV.vchat_roster.>",
      "$KV.vchat_capabilities.>",
      "$JS.API.INFO.>",
      "_INBOX.>",
    ],
    subDeny: ["$SYS.>"],
  };

  it("pubAllow set == token.go", () => {
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG, NKEY);
    sameSet(got.pubAllow, EXPECTED.pubAllow);
  });

  it("subAllow set == token.go", () => {
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG, NKEY);
    sameSet(got.subAllow, EXPECTED.subAllow);
  });

  it("pubDeny + subDeny == token.go (only $SYS.>; _INBOX is ALLOWED)", () => {
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG, NKEY);
    sameSet(got.pubDeny, EXPECTED.pubDeny);
    sameSet(got.subDeny, EXPECTED.subDeny);
    // Explicit: request-reply must work (_INBOX.> in BOTH allows, not deny).
    expect(got.pubAllow).toContain("_INBOX.>");
    expect(got.subAllow).toContain("_INBOX.>");
  });

  it("segment is parametric — no hardcoded 'default' in any tenant./$SRV grant", () => {
    // Instantiate under a NON-default segment; every tenant./$SRV grant must
    // carry that segment (proves the grant is ownership-derived, not baked).
    const SEG2 = "vclaw";
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG2, NKEY);
    for (const g of [...got.pubAllow, ...got.subAllow]) {
      if (g.startsWith("tenant.") || g.startsWith("$SRV.INFO.agents.")) {
        expect(g, `grant must carry the runtime segment: ${g}`).toContain(SEG2);
        expect(g, `grant must NOT bake 'tenant.default': ${g}`).not.toContain("tenant.default");
      }
    }
    // And the discovery pub/sub are segment-scoped (not bare $SRV.INFO).
    expect(got.pubAllow).toContain(`$SRV.INFO.agents.${SEG2}.${NKEY}`);
    expect(got.subAllow).toContain(`$SRV.INFO.agents.${SEG2}.>`);
  });

  it("NO wallet / trade / app / audit grant anywhere (P2 deny-by-default)", () => {
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG, NKEY);
    for (const g of [...got.pubAllow, ...got.subAllow, ...got.pubDeny, ...got.subDeny]) {
      expect(g, `P2 commerce must be absent: ${g}`).not.toMatch(/wallet|trade|\.app\.|audit/);
    }
  });

  it("NO $KV publish (J4b KV-write retirement — roster/capabilities are vgate-written)", () => {
    const got = instantiate(PERMISSIONS.CLAIMED_AGENT, SEG, NKEY);
    for (const g of got.pubAllow) {
      expect(g, `agent must not publish to $KV: ${g}`).not.toMatch(/^\$KV\./);
    }
    // KV READS are present (sub watch + JetStream GET pub).
    expect(got.subAllow).toContain("$KV.vchat_roster.>");
    expect(got.subAllow).toContain("$KV.vchat_capabilities.>");
    expect(got.pubAllow).toContain("$JS.API.DIRECT.GET.KV_vchat_roster.>");
    expect(got.pubAllow).toContain("$JS.API.DIRECT.GET.KV_vchat_capabilities.>");
  });
});

// ═══════════════════════════════════════════════════════════════
// SITE_MESH (V3.1) — customer-intranet leaf principal
// Truth source: vgate/internal/agentidp/token.go DeriveSiteSiteMeshPermissions
// → DeriveSiteMeshPermissions. Invariants beyond set-equality: exact-3-token
// Micro literals (non-collision with the V3 announcement plane), site-id
// namespace pinning on pub, zero IDP-plane grants. Go mirror test:
// TestDeriveSiteMeshPermissions (token_test.go).
// ═══════════════════════════════════════════════════════════════
describe("SITE_MESH grants == vgate token.go DeriveSiteMeshPermissions (V3.1)", () => {
  const GO_PUB_ALLOW = [
    "agents.prompt.*.>",
    "agents.a2a.*.>",
    "agents.hb.*.<site-id>.>",
    "agents.status.*.<site-id>.>",
    "agents.reply.*.<site-id>.>",
    "agents.events.*.<site-id>.>",
    "agents.buddy_request.*.<site-id>.>",
    "agents.buddy_accept.*.<site-id>.>",
    "agents.buddy_reject.*.<site-id>.>",
    "$SRV.INFO.agents",
    "$SRV.PING.agents",
    "_INBOX.>",
  ];
  const GO_SUB_ALLOW = [
    "agents.hb.>",
    "agents.prompt.*.<site-id>.>",
    "agents.a2a.*.<site-id>.>",
    "agents.status.*.<site-id>.>",
    "agents.reply.*.<site-id>.>",
    "agents.events.*.<site-id>.>",
    "agents.buddy_request.*.<site-id>.>",
    "agents.buddy_accept.*.<site-id>.>",
    "agents.buddy_reject.*.<site-id>.>",
    "$SRV.INFO.agents",
    "$SRV.PING.agents",
    "_INBOX.>",
  ];

  it("TS PERMISSIONS.SITE_MESH matches the Go output set (placeholder form)", () => {
    sameSet([...PERMISSIONS.SITE_MESH.pub], GO_PUB_ALLOW);
    sameSet([...PERMISSIONS.SITE_MESH.sub], GO_SUB_ALLOW);
    expect([...PERMISSIONS.SITE_MESH.deny]).toEqual(["$SYS.>"]);
  });

  it("invariant: Micro subjects are EXACT literals — no `>` form (non-collision with V3 announcement plane)", () => {
    for (const s of [...PERMISSIONS.SITE_MESH.pub, ...PERMISSIONS.SITE_MESH.sub]) {
      expect(s, `wildcard Micro grant: ${s}`).not.toMatch(/^\$SRV\.(INFO|PING)\.agents\./);
    }
  });

  it("invariant (F1+Q8): pub — send verbs mesh-wide, identity verbs site-pinned, no literal <agent>", () => {
    for (const s of PERMISSIONS.SITE_MESH.pub) {
      expect(s, `F1 regression: literal placeholder: ${s}`).not.toContain("<agent>");
      if (s.startsWith("agents.")) {
        const verb = s.split(".")[1];
        const pinned = /\.<site-id>\.>$/.test(s);
        const send = verb === "prompt" || verb === "a2a";
        if (send) expect(s, `send verb must be mesh-wide (Q8): ${s}`).not.toMatch(/\.<site-id>/);
        else expect(s, `identity verb must be site-pinned: ${s}`).toMatch(/\.<site-id>\.>$/);
      }
    }
  });

  it("invariant (F3): sub — only hb mesh-wide, everything else site-pinned", () => {
    for (const s of PERMISSIONS.SITE_MESH.sub) {
      expect(s, `F1 regression: literal placeholder: ${s}`).not.toContain("<agent>");
      if (s.startsWith("agents.") && s !== "agents.hb.>") {
        expect(s, `sub not site-pinned (F3): ${s}`).toMatch(/\.<site-id>\.>$/);
      }
    }
  });

  it("invariant: zero IDP-plane grants (tenant.*, $KV.*) — policy rides as overlay, not subjects", () => {
    for (const s of [...PERMISSIONS.SITE_MESH.pub, ...PERMISSIONS.SITE_MESH.sub]) {
      expect(s, `IDP-plane grant: ${s}`).not.toMatch(/^(tenant\.|\$KV\.)/);
    }
  });
});
