/**
 * lifecycle connect hardening (Batch A1) — the reconnect-safety options and
 * closed() observers on the two agent dial paths, WITHOUT a live server.
 *
 * @nats-io/transport-node's connect() is mocked, so the OPTIONS OBJECT is
 * asserted directly (maxReconnectAttempts / pingInterval / timeout / name /
 * authenticator), and a fake NatsConnection drives closed() through both of
 * its resolutions:
 *   - Error close (revoked credential / auth violation / server close):
 *     connectViaJWT logs LOUDLY and EXITS the process — a silent close under
 *     a live JWT refresh timer is a zombie; connectViaNKey logs loudly only,
 *     because its one-shot consumers (cli, uninstall, mcp fabric-tools inside
 *     the long-lived MCP server) own their own exit paths.
 *   - void (client-initiated close()/drain()): ignored by both observers.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { nkeys } from "@nats-io/nats-core";

const mocks = vi.hoisted(() => ({
  connect: vi.fn(),
  nkeyAuthenticator: vi.fn(() => () => new Uint8Array()),
}));

vi.mock("@nats-io/transport-node", () => ({
  connect: mocks.connect,
  nkeyAuthenticator: mocks.nkeyAuthenticator,
}));

import { connectViaJWT, connectViaNKey } from "../../src/agent/lifecycle.js";

/** Minimal fake NatsConnection: closed() resolves with `closeWith` async. */
function fakeNc(closeWith?: Error) {
  return {
    closed: vi.fn(
      () =>
        new Promise<void | Error>((resolve) =>
          setTimeout(() => resolve(closeWith), 0),
        ),
    ),
  } as never;
}

/** Flush the observer's .then chain (closed() settles on a 0-timeout). */
const settle = () => new Promise((r) => setTimeout(r, 5));

/** A REAL encoded seed so the REAL jwtAuthenticator() construction succeeds
 *  (the authenticator never RUNS — connect() is mocked). */
const SEED = new TextDecoder().decode(nkeys.createUser().getSeed());

beforeEach(() => {
  mocks.connect.mockReset();
});
afterEach(() => {
  vi.restoreAllMocks();
});

describe("connectViaJWT — reconnect-safe options + zombie guard", () => {
  it("pins infinite reconnect, a short ping interval, name + authenticator", async () => {
    mocks.connect.mockResolvedValue(fakeNc());
    await connectViaJWT("nats://x:4223", () => "JWT1", SEED, "agent-t");
    expect(mocks.connect).toHaveBeenCalledTimes(1);
    const opts = mocks.connect.mock.calls[0][0] as Record<string, unknown>;
    expect(opts.servers).toEqual(["nats://x:4223"]);
    expect(opts.maxReconnectAttempts).toBe(-1);
    expect(opts.pingInterval).toBe(10_000);
    expect(opts.timeout).toBe(10_000);
    expect(opts.name).toBe("agent-t");
    expect(opts.authenticator).toBeTypeOf("function");
  });

  it("ERROR close logs LOUDLY and exits non-zero (the zombie guard)", async () => {
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const exitSpy = vi
      .spyOn(process, "exit")
      .mockImplementation((() => undefined) as never);
    mocks.connect.mockResolvedValue(fakeNc(new Error("authorization violation")));
    await connectViaJWT("nats://x:4223", "JWT", SEED, "agent-t");
    await settle();
    expect(errSpy).toHaveBeenCalledWith(
      expect.stringContaining("closed unexpectedly"),
    );
    expect(exitSpy).toHaveBeenCalledWith(1);
  });

  it("clean close (client close/drain) — no exit, no noise", async () => {
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const exitSpy = vi
      .spyOn(process, "exit")
      .mockImplementation((() => undefined) as never);
    mocks.connect.mockResolvedValue(fakeNc());
    await connectViaJWT("nats://x:4223", "JWT", SEED, "agent-t");
    await settle();
    expect(errSpy).not.toHaveBeenCalled();
    expect(exitSpy).not.toHaveBeenCalled();
  });
});

describe("connectViaNKey — same reconnect options, loud log WITHOUT exit", () => {
  it("pins infinite reconnect + short ping; name optional", async () => {
    mocks.connect.mockResolvedValue(fakeNc());
    await connectViaNKey("nats://dev:4223", new Uint8Array(32), "dev-agent");
    const opts = mocks.connect.mock.calls[0][0] as Record<string, unknown>;
    expect(opts.servers).toEqual(["nats://dev:4223"]);
    expect(opts.maxReconnectAttempts).toBe(-1);
    expect(opts.pingInterval).toBe(10_000);
    expect(opts.timeout).toBe(10_000);
    expect(opts.name).toBe("dev-agent");
    expect(opts.authenticator).toBeTypeOf("function");
  });

  it("ERROR close logs LOUDLY but does NOT exit (one-shot/MCP-server consumers own exit)", async () => {
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const exitSpy = vi
      .spyOn(process, "exit")
      .mockImplementation((() => undefined) as never);
    mocks.connect.mockResolvedValue(fakeNc(new Error("stale connection")));
    await connectViaNKey("nats://dev:4223", new Uint8Array(32));
    await settle();
    expect(errSpy).toHaveBeenCalledWith(
      expect.stringContaining("closed unexpectedly"),
    );
    expect(exitSpy).not.toHaveBeenCalled();
  });

  it("clean close — silent", async () => {
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    mocks.connect.mockResolvedValue(fakeNc());
    await connectViaNKey("nats://dev:4223", new Uint8Array(32));
    await settle();
    expect(errSpy).not.toHaveBeenCalled();
  });
});
