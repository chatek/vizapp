import { describe, expect, it } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  sessionHeader,
  entryId,
  userEntry,
  assistantEntry,
  toolResultEntry,
  attachmentEntry,
  compactionEntry,
  usageBlock,
  createSessionFile,
  appendEntry,
  readSessionFile,
  contextView,
} from "../../src/session/format.js";
import { SessionStore, SessionModeError } from "../../src/session/store.js";
import { sessionSubjectV2, sessionWildcardV2 } from "../../src/net/session.js";

function tmpDir(): string {
  return mkdtempSync(join(tmpdir(), "vchat-session-test-"));
}

describe("pi JSONL v3 format writer (validated against real sessions)", () => {
  it("writes a header matching the real pi format", () => {
    const h = sessionHeader("/tmp/work");
    expect(h.type).toBe("session");
    expect(h.version).toBe(3);
    expect(typeof h.id).toBe("string");
    expect(h.id).toMatch(/^[0-9a-f-]{36}$/); // uuid
    expect(h.timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    expect(h.cwd).toBe("/tmp/work");
  });

  it("round-trips a REAL captured user entry (2026-07-27 sample)", () => {
    // Real entry: {"type":"message","id":"667ac5f5","parentId":"69f8932d",
    // "timestamp":"2026-07-27T11:07:28.391Z","message":{"role":"user",
    // "content":[{"type":"text","text":"..."}],"timestamp":1785150448240}}
    const entry = userEntry("hello agent", "69f8932d", { id: "667ac5f5", ts: "2026-07-27T11:07:28.391Z", ms: 1785150448240 });
    expect(entry).toMatchObject({
      type: "message",
      id: "667ac5f5",
      parentId: "69f8932d",
      timestamp: "2026-07-27T11:07:28.391Z",
      message: { role: "user", content: [{ type: "text", text: "hello agent" }], timestamp: 1785150448240 },
    });
  });

  it("round-trips a REAL captured assistant entry with usage (2026-07-27 sample)", () => {
    // Real: message.role="assistant", api/provider/model, usage{input,output,
    // cacheRead,cacheWrite,reasoning,totalTokens,cost{...}}, stopReason, responseId
    const entry = assistantEntry("hi", "667ac5f5", {
      id: "e8468f31",
      api: "openai-completions",
      provider: "oclaw",
      model: "deepseek-v4-flash",
      usage: usageBlock(4426, 160),
      stopReason: "toolUse",
    });
    const msg = entry.message as Record<string, unknown>;
    expect(entry.type).toBe("message");
    expect(msg.role).toBe("assistant");
    expect(msg.api).toBe("openai-completions");
    expect(msg.model).toBe("deepseek-v4-flash");
    expect((msg.usage as { input: number }).input).toBe(4426);
    expect((msg.usage as { totalTokens: number }).totalTokens).toBe(4586);
    expect(msg.stopReason).toBe("toolUse");
  });

  it("round-trips a REAL captured toolResult entry (message.role=toolResult, NOT a flat type)", () => {
    const entry = toolResultEntry("call_00_abc", "read", "file contents", "e8468f31");
    expect(entry.type).toBe("message");
    expect(entry.message).toMatchObject({
      role: "toolResult",
      toolCallId: "call_00_abc",
      toolName: "read",
      content: [{ type: "text", text: "file contents" }],
    });
  });

  it("writes attachment blocks as custom_message (real custom_message shape)", () => {
    const entry = attachmentEntry(
      { asset_ref: "ast-1", mime: "image/png", url: "https://agents.vclawhub.com/a/ast-1", chatto_msg_id: "msg-1" },
      "a1",
    );
    expect(entry.type).toBe("custom_message");
    expect(entry.customType).toBe("attachment");
    expect(entry.display).toBe(false);
    expect(entry.details).toMatchObject({ asset_ref: "ast-1", mime: "image/png" });
  });

  it("writes compaction as type compaction with summary (real format, NOT compactionSummary)", () => {
    const entry = compactionEntry("long context summarized", "a1");
    expect(entry.type).toBe("compaction");
    expect(entry.summary).toBe("long context summarized");
    expect(Object.keys(entry)).not.toContain("compactionSummary");
  });

  it("file round-trip: header + appended entries parse back with tree intact", () => {
    const dir = tmpDir();
    try {
      const { path, header } = createSessionFile(dir, "/tmp/work");
      const u = userEntry("first", null);
      appendEntry(path, u);
      const a = assistantEntry("reply", u.id as string);
      appendEntry(path, a);
      const t = toolResultEntry("call-1", "read", "data", a.id as string);
      appendEntry(path, t);

      const { header: h2, entries } = readSessionFile(path);
      expect(h2.id).toBe(header.id);
      expect(entries).toHaveLength(3);
      expect(entries[0].id).toBe(u.id);
      expect(entries[1].parentId).toBe(u.id);
      expect(entries[2].parentId).toBe(a.id);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("contextView prunes to the head chain (read-only window)", () => {
    const dir = tmpDir();
    try {
      const { path } = createSessionFile(dir, "/tmp/work");
      const u1 = userEntry("first", null);
      appendEntry(path, u1);
      const a1 = assistantEntry("r1", u1.id as string);
      appendEntry(path, a1);
      const u2 = userEntry("second", a1.id as string);
      appendEntry(path, u2);
      const a2 = assistantEntry("r2", u2.id as string);
      appendEntry(path, a2);
      const { entries } = readSessionFile(path);
      const view = contextView(entries, 2);
      expect(view).toHaveLength(4); // 2 pairs
      // Transcript order: oldest first (u1, a1, u2, a2)
      expect(view[0].text).toBe("first");
      expect(view[1].role).toBe("assistant");
      expect(view[2].text).toBe("second");
      expect(view[view.length - 1].role).toBe("assistant");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("SessionStore", () => {
  it("per-room append writes a pi-valid file; read returns it", () => {
    const dir = tmpDir();
    try {
      const store = new SessionStore({ dataDir: dir, cwd: "/tmp/work" });
      const rs = store.ensure("room-1", "UABC", "per-room");
      expect(rs.mode).toBe("per-room");
      expect(rs.path.endsWith(".jsonl")).toBe(true);

      const { headId } = store.appendUser("room-1", {
        text: "hi agent",
        chatto_msg_id: "msg-1",
        chatto_actor: "U1",
        attachments: [{ mime: "image/png", asset_ref: "ast-1" }],
      });
      expect(headId).toBeTruthy();

      const view = store.read("room-1");
      expect(view.mode).toBe("per-room");
      expect(view.liveView).toBe(false);
      // header + attachment custom_message + user entry + chatto_ref custom
      expect(view.entries.length).toBeGreaterThanOrEqual(3);
      const roles = view.entries.map((e) => (e as { message?: { role?: string } }).message?.role).filter(Boolean);
      expect(roles).toContain("user");

      const ctx = store.context("room-1");
      expect(ctx.length).toBeGreaterThan(0);
      expect(ctx[0].text).toBe("hi agent");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("REFUSES append for main-mode rooms (read-only window, §9.1)", () => {
    const dir = tmpDir();
    try {
      const store = new SessionStore({ dataDir: dir, cwd: "/tmp/work" });
      store.ensure("room-main", "UABC", "main");
      expect(() =>
        store.appendUser("room-main", { text: "hi", chatto_msg_id: "m1", chatto_actor: "U1" }),
      ).toThrow(SessionModeError);
      // read works (live_view=true, no owned file)
      const view = store.read("room-main");
      expect(view.liveView).toBe(true);
      expect(view.mode).toBe("main");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("REFUSES append for unbound rooms", () => {
    const dir = tmpDir();
    try {
      const store = new SessionStore({ dataDir: dir, cwd: "/tmp/work" });
      expect(() => store.appendUser("nope", { text: "hi", chatto_msg_id: "m1", chatto_actor: "U1" })).toThrow(
        SessionModeError,
      );
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("session subject builder (D1 mirror)", () => {
  it("builds session.*.req subjects on the agent segment", () => {
    expect(sessionSubjectV2("UABC", "append")).toBe("tenant.default.user.UABC.agent.UABC.session.append.req");
    expect(sessionSubjectV2("UABC", "stream")).toBe("tenant.default.user.UABC.agent.UABC.session.stream.req");
    expect(sessionWildcardV2("UABC")).toBe("tenant.default.user.UABC.agent.UABC.session.>");
  });
});

describe("entry ids", () => {
  it("are 8-char hex", () => {
    expect(entryId()).toMatch(/^[0-9a-f]{8}$/);
    const ids = new Set(Array.from({ length: 50 }, () => entryId()));
    expect(ids.size).toBe(50);
  });
});
