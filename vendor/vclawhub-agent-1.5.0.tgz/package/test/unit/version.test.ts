/**
 * Version stamping tests (W-J7a — the bundled CLI's B1 blocker fix).
 *
 * sdkVersion() resolution order: AGENT_SDK_VERSION env (build-time define
 * stamp) → adjacent package.json → "0.0.0" sentinel. The bundled CLI's
 * --version is entirely env-driven (scripts/build-cli-bundle.mjs injects the
 * jsr.json version via bun build --define).
 */

import { describe, it, expect, afterEach } from "vitest";
import { sdkVersion, SDK_VERSION } from "../../src/version.js";

afterEach(() => {
  delete process.env.AGENT_SDK_VERSION;
});

describe("sdkVersion() stamping", () => {
  it("returns the build stamp when AGENT_SDK_VERSION is set (bundled CLI path)", () => {
    process.env.AGENT_SDK_VERSION = "1.2.0";
    expect(sdkVersion()).toBe("1.2.0");
  });

  it("falls back to the adjacent package.json version in the source tree", () => {
    delete process.env.AGENT_SDK_VERSION;
    const v = sdkVersion();
    expect(v).toMatch(/^\d+\.\d+\.\d+$/);
    expect(v).not.toBe("0.0.0"); // package.json sits next to src/ in this repo
  });

  it("exports an eagerly-resolved SDK_VERSION constant for announcement modules", () => {
    expect(SDK_VERSION).toMatch(/^\d+\.\d+\.\d+$/);
  });

  it("prefers the stamp even when a package.json exists (stamp wins)", () => {
    process.env.AGENT_SDK_VERSION = "9.9.9";
    expect(sdkVersion()).toBe("9.9.9");
  });
});
