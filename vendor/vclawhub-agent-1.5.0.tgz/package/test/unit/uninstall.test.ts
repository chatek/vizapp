/**
 * uninstall.test.ts — clean uninstall (packaging sprint L1, stage 5).
 *
 * The L1 enumeration (.prime/handoff/packaging-sprint/L1-lifecycle-gaps.md)
 * is the spec: every install-time write must be reversible, and the
 * mcpServers.vclaw un-wire must be SURGICAL (the join pipe upserts one key;
 * this reverses exactly that one key).
 *
 * Hermetic: a temp home is wired through the SAME env overrides the store
 * and daemon/paths resolve lazily (VCLAW_CREDS_DIR / VCLAW_FAMILY_DIR), the
 * fabric retire is injected as a spy, and the offline announce is injected —
 * no network, no real-home writes. The --home guard in uninstall() enforces
 * exactly this pairing.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createUser } from "@nats-io/nkeys";

import { uninstall, unwireMcpVclaw, unwireNpmrcLine, printUninstallReport } from "../../src/commands/uninstall.js";
import type { RetireOutcome } from "../../src/commands/retire.js";
import type { StoredCredentials } from "../../src/types.js";

/* ── env hygiene: EVERYTHING home-relative resolves through overrides ── */

const ENV_KEYS = [
  "VCLAW_CREDS_DIR", "VCHAT_CREDS_DIR",
  "VCLAW_FAMILY_DIR", "VCHAT_FAMILY_DIR",
  "VCLAW_PRIME_AGENT_DIR", "VCLAW_PRIME_AGENT_BIN_DIR",
  "XDG_DATA_HOME",
];

let home: string;

beforeEach(() => {
  for (const k of ENV_KEYS) delete process.env[k];
  home = mkdtempSync(join(tmpdir(), "vclaw-uninstall-"));
  process.env.VCLAW_CREDS_DIR = join(home, ".config", "vclaw");
  process.env.VCLAW_FAMILY_DIR = join(home, ".config", "vclaw", "family");
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
});

afterEach(() => {
  for (const k of ENV_KEYS) delete process.env[k];
  rmSync(home, { recursive: true, force: true });
  vi.restoreAllMocks();
});

/* ── fixtures ────────────────────────────────────────────────────────── */

// REAL keypair: the store validates seeds with nkeys.fromSeed, and the
// retire-refusal warning enriches itself with the loaded public key.
const kp = createUser();
const SEED = new TextDecoder().decode(kp.getSeed());
const PUB = kp.getPublicKey();
const CREDS: StoredCredentials = {
  seed: SEED,
  public_key: PUB,
  agent_nkey: PUB,
  name: "uninstall-fixture",
  steward: "steward@example.com",
  created_at: "2026-10-14T00:00:00Z",
};

const SELF_REFUSAL: RetireOutcome = {
  code: 1,
  message: "self-retire lands with J16c — use --nkey <pub> with a steward session",
};

function refusedRetire() {
  return vi.fn(async (_opts: Parameters<typeof import("../../src/commands/retire.js").retire>) => SELF_REFUSAL);
}
const announce = vi.fn(async () => {});

function installFixture(h: string): { npmrcOther: string } {
  const cfgDir = join(h, ".config", "vclaw");
  mkdirSync(cfgDir, { recursive: true });
  writeFileSync(join(cfgDir, "credentials.json"), JSON.stringify(CREDS, null, 2));
  writeFileSync(join(cfgDir, ".pending"), PUB);
  writeFileSync(join(cfgDir, "config.json"), JSON.stringify({ runtime: "pi", segment: "s1" }));
  writeFileSync(join(cfgDir, "credentials.json.bak-2026-10-01T00-00-00-000Z"), JSON.stringify(CREDS));
  mkdirSync(join(cfgDir, "family", "lead"), { recursive: true });
  writeFileSync(join(cfgDir, "family", "lead", "family.json"), "{}");

  mkdirSync(join(h, ".vclaw"), { recursive: true });
  writeFileSync(join(h, ".vclaw", "identity.json"), "{}");
  writeFileSync(join(h, ".vclaw", "agent.js"), "// bundled CLI");

  mkdirSync(join(h, ".config", "pi-a2a"), { recursive: true });
  writeFileSync(join(h, ".config", "pi-a2a", "identity.seed"), SEED);

  const bin = join(h, ".local", "bin");
  mkdirSync(bin, { recursive: true });
  writeFileSync(join(bin, "vclaw-agent"), '#!/bin/sh\nexec bun "$HOME/.vclaw/agent.js" "$@"\n');

  const npmrcOther = "registry=https://registry.npmjs.org/";
  writeFileSync(join(h, ".npmrc"), `${npmrcOther}\n@jsr:registry=https://npm.jsr.io\n`);

  // Host configs pre-wired the way the join pipe leaves them: vclaw beside
  // OTHER servers and other top-level keys.
  const piDir = join(h, ".pi", "agent");
  mkdirSync(piDir, { recursive: true });
  writeFileSync(
    join(piDir, "mcp.json"),
    JSON.stringify(
      {
        mcpServers: {
          other: { command: "npx", args: ["-y", "other-mcp"] },
          vclaw: {
            command: "/opt/bun/bin/bun",
            args: [join(h, ".vclaw", "agent.js"), "mcp"],
            description: "vclaw IDP identity + onboarding tools",
            exposure: "deferred",
          },
        },
      },
      null,
      2,
    ) + "\n",
  );
  const primeDir = join(h, ".prime", "agent");
  mkdirSync(primeDir, { recursive: true });
  writeFileSync(
    join(primeDir, "settings.json"),
    JSON.stringify(
      {
        model: "claude-x",
        mcpServers: {
          vclaw: { type: "stdio", command: "/opt/bun/bin/bun", args: [join(h, ".vclaw", "agent.js"), "mcp"], startupTimeoutMs: 10000 },
          other2: { type: "stdio", command: "some-other-server" },
        },
      },
      null,
      2,
    ) + "\n",
  );

  // Runtime group: tree + funnel wrapper + node shim + provisioned node.
  const primeTree = join(h, ".local", "share", "vclaw", "prime-agent");
  mkdirSync(join(primeTree, "bin"), { recursive: true });
  writeFileSync(join(primeTree, "bin", "prime-agent"), " ELF-ish");
  writeFileSync(join(bin, "prime-agent"), '#!/bin/sh\nexec "/opt/bun/bin/bun" "' + join(primeTree, "bin", "prime-agent") + '" "$@"\n');
  writeFileSync(join(bin, "node"), '#!/bin/sh\nexec "/opt/bun/bin/bun" "$@"\n');
  const nodeTree = join(h, ".local", "share", "vclaw", "node");
  mkdirSync(join(nodeTree, "bin"), { recursive: true });
  writeFileSync(join(nodeTree, "bin", "node"), "node-bin");

  // Host-owned session store (must survive every uninstall shape).
  mkdirSync(join(piDir, "sessions"), { recursive: true });
  writeFileSync(join(piDir, "sessions", "room-1.jsonl"), "{}\n");

  return { npmrcOther };
}

const paths = (h: string) => ({
  creds: join(h, ".config", "vclaw", "credentials.json"),
  pending: join(h, ".config", "vclaw", ".pending"),
  config: join(h, ".config", "vclaw", "config.json"),
  bak: join(h, ".config", "vclaw", "credentials.json.bak-2026-10-01T00-00-00-000Z"),
  family: join(h, ".config", "vclaw", "family"),
  identityJson: join(h, ".vclaw", "identity.json"),
  agentJs: join(h, ".vclaw", "agent.js"),
  seed: join(h, ".config", "pi-a2a", "identity.seed"),
  shim: join(h, ".local", "bin", "vclaw-agent"),
  npmrc: join(h, ".npmrc"),
  piMcp: join(h, ".pi", "agent", "mcp.json"),
  primeSettings: join(h, ".prime", "agent", "settings.json"),
  primeTree: join(h, ".local", "share", "vclaw", "prime-agent"),
  wrapper: join(h, ".local", "bin", "prime-agent"),
  nodeShim: join(h, ".local", "bin", "node"),
  nodeTree: join(h, ".local", "share", "vclaw", "node"),
  sessions: join(h, ".pi", "agent", "sessions"),
});

/* ── full uninstall ──────────────────────────────────────────────────── */

describe("uninstall — full (default) run", () => {
  it("removes every L1 local artifact, un-wires ONLY mcpServers.vclaw, leaves the runtime + host sessions", async () => {
    const { npmrcOther } = installFixture(home);
    const P = paths(home);
    const retireSpy = refusedRetire();

    const r = await uninstall({ yes: true, home, retireImpl: retireSpy, announceOffline: announce });

    // retire attempted via the CLI's own self path (no nkey) and its refusal surfaced
    expect(retireSpy).toHaveBeenCalledTimes(1);
    expect(retireSpy).toHaveBeenCalledWith({ reason: "uninstall", yes: true });
    expect(announce).toHaveBeenCalledTimes(1);
    expect(r.retired).toBe(false);
    expect(r.warnings.join("\n")).toContain("fabric retire NOT completed");
    expect(r.warnings.join("\n")).toContain("J16c");
    expect(r.warnings.join("\n")).toContain(PUB); // refusal names the key steward retire needs

    // host configs: vclaw gone, other servers + top-level keys intact
    const pi = JSON.parse(readFileSync(P.piMcp, "utf8"));
    expect(pi.mcpServers.vclaw).toBeUndefined();
    expect(pi.mcpServers.other).toEqual({ command: "npx", args: ["-y", "other-mcp"] });
    expect(Object.keys(pi.mcpServers)).toEqual(["other"]);
    const prime = JSON.parse(readFileSync(P.primeSettings, "utf8"));
    expect(prime.mcpServers.vclaw).toBeUndefined();
    expect(prime.mcpServers.other2).toEqual({ type: "stdio", command: "some-other-server" });
    expect(prime.model).toBe("claude-x");
    expect(r.unwired).toEqual([P.piMcp, P.primeSettings]);

    // local artifacts gone
    for (const p of [P.creds, P.pending, P.config, P.bak, P.identityJson, P.agentJs, P.seed, P.shim, P.family]) {
      expect(existsSync(p), `${p} should be removed`).toBe(false);
    }
    expect(r.removed).toContain(P.creds);
    expect(r.removed).toContain(P.pending);
    expect(r.removed).toContain(P.config);
    expect(r.removed).toContain(P.bak);
    expect(r.removed).toContain(P.identityJson);
    expect(r.removed).toContain(P.agentJs);
    expect(r.removed).toContain(P.seed);
    expect(r.removed).toContain(P.shim);
    expect(r.removed).toContain(P.family);
    expect(r.removed).toContain(`${P.npmrc} (removed the @jsr:registry=https://npm.jsr.io line)`);

    // npmrc: ONLY our line went, the user's line survives
    expect(readFileSync(P.npmrc, "utf8")).toBe(`${npmrcOther}\n`);

    // runtime group + host sessions deliberately left (and reported)
    for (const p of [P.primeTree, P.wrapper, P.nodeShim, P.nodeTree, P.sessions]) {
      expect(existsSync(p), `${p} must survive the default run`).toBe(true);
      expect(r.left).toContain(p);
    }
    expect(r.warnings.join("\n")).toContain("--with-runtime");
    expect(r.warnings.join("\n")).toContain("pi host's session store");
    printUninstallReport(r); // printer must not throw
  });
});

describe("uninstall --keep-identity", () => {
  it("preserves identity/credential tiers + skips the retire attempt, but still un-wires hosts and removes the bundle", async () => {
    installFixture(home);
    const P = paths(home);
    const retireSpy = refusedRetire();

    const r = await uninstall({ yes: true, keepIdentity: true, home, retireImpl: retireSpy });

    expect(retireSpy).not.toHaveBeenCalled(); // --keep-identity skips the fabric attempt
    for (const p of [P.creds, P.pending, P.bak, P.identityJson, P.seed]) {
      expect(existsSync(p), `${p} must survive --keep-identity`).toBe(true);
      expect(r.left).toContain(p);
    }
    expect(existsSync(P.config)).toBe(false); // config is machine state, not identity
    expect(existsSync(P.agentJs)).toBe(false);
    expect(existsSync(P.shim)).toBe(false);
    expect(r.unwired).toEqual([P.piMcp, P.primeSettings]); // un-wiring is not identity
    expect(r.warnings.join("\n")).toContain("--keep-identity");
  });
});

describe("idempotency", () => {
  it("a second run is a no-op and host files stay byte-identical", async () => {
    installFixture(home);
    const P = paths(home);
    const retireSpy = refusedRetire();
    await uninstall({ yes: true, home, retireImpl: retireSpy, announceOffline: announce });
    const piBytes = readFileSync(P.piMcp);
    const primeBytes = readFileSync(P.primeSettings);
    const npmrcBytes = readFileSync(P.npmrc);

    const r2 = await uninstall({ yes: true, home, retireImpl: retireSpy, announceOffline: announce });

    expect(r2.unwired).toEqual([]); // nothing to un-wire again
    expect(r2.removed.filter((p) => !p.includes("disabled"))).toEqual([]); // no new deletions
    expect(readFileSync(P.piMcp)).toEqual(piBytes); // no rewrite when vclaw absent
    expect(readFileSync(P.primeSettings)).toEqual(primeBytes);
    expect(readFileSync(P.npmrc)).toEqual(npmrcBytes);
    expect(r2.retired).toBe(false); // retire still attempted (identity flag off)
  });

  it("runs cleanly on an empty machine (nothing installed)", async () => {
    const r = await uninstall({ yes: true, home, retireImpl: refusedRetire() });
    expect(r.removed).toEqual([]);
    expect(r.unwired).toEqual([]);
    expect(r.left).toEqual([]);
    expect(r.warnings.join("\n")).toContain("fabric retire NOT completed"); // surfaced, not fatal
  });
});

describe("host-config guards (the upsert discipline, reversed)", () => {
  it("an unparseable host config is left untouched with a warning", async () => {
    installFixture(home);
    const P = paths(home);
    const bad = "{not json";
    writeFileSync(P.primeSettings, bad);
    const r = await uninstall({ yes: true, home, retireImpl: refusedRetire() });
    expect(readFileSync(P.primeSettings, "utf8")).toBe(bad);
    expect(r.unwired).toEqual([P.piMcp]); // the GOOD host still got un-wired
    expect(r.warnings.join("\n")).toContain("not valid JSON");
  });

  it("wrong-shape mcpServers (array) is refused, file untouched", () => {
    const file = join(home, "mcp-bad.json");
    const raw = JSON.stringify({ mcpServers: [{ vclaw: true }] });
    writeFileSync(file, raw);
    const r = unwireMcpVclaw(file);
    expect(r.removed).toBe(false);
    expect(r.warning).toContain("not an object");
    expect(readFileSync(file, "utf8")).toBe(raw);
  });

  it("null JSON root is refused, file untouched", () => {
    const file = join(home, "mcp-null.json");
    writeFileSync(file, "null");
    expect(unwireMcpVclaw(file)).toEqual({ removed: false, warning: expect.stringContaining("not a JSON object") });
    expect(readFileSync(file, "utf8")).toBe("null");
  });
});

describe("~/.npmrc @jsr line — only when provably ours", () => {
  it("a foreign @jsr:registry line is left with a warning", async () => {
    installFixture(home);
    const P = paths(home);
    const foreign = "registry=https://registry.npmjs.org/\n@jsr:registry=https://npm.pkg.rs\n";
    writeFileSync(P.npmrc, foreign);
    const r = await uninstall({ yes: true, home, retireImpl: refusedRetire() });
    expect(readFileSync(P.npmrc, "utf8")).toBe(foreign);
    expect(r.warnings.join("\n")).toContain("not the funnel's");
  });

  it("two @jsr lines cannot be attributed — left with a warning", () => {
    const file = join(home, ".npmrc");
    const raw = "@jsr:registry=https://npm.jsr.io\n@jsr:registry=https://npm.pkg.rs\n";
    writeFileSync(file, raw);
    const r = unwireNpmrcLine(file);
    expect(r.removed).toBe(false);
    expect(r.warning).toContain("2 @jsr:registry lines");
    expect(readFileSync(file, "utf8")).toBe(raw);
  });

  it("no @jsr line at all → no rewrite, no warning", () => {
    const file = join(home, ".npmrc");
    const raw = "registry=https://registry.npmjs.org/\n";
    writeFileSync(file, raw);
    expect(unwireNpmrcLine(file)).toEqual({ removed: false });
    expect(readFileSync(file, "utf8")).toBe(raw);
  });

  it("our line in the middle keeps the rest byte-exact (trailing newline preserved)", () => {
    const file = join(home, ".npmrc");
    writeFileSync(file, "a=1\n@jsr:registry=https://npm.jsr.io\nb=2\n");
    expect(unwireNpmrcLine(file).removed).toBe(true);
    expect(readFileSync(file, "utf8")).toBe("a=1\nb=2\n");
  });
});

describe("provably-ours guards for pipe-written launchers", () => {
  it("a foreign ~/.local/bin/vclaw-agent is left with a warning", async () => {
    installFixture(home);
    const P = paths(home);
    writeFileSync(P.shim, "#!/usr/bin/env python\nprint('custom launcher')\n");
    const r = await uninstall({ yes: true, home, retireImpl: refusedRetire() });
    expect(existsSync(P.shim)).toBe(true);
    expect(r.left).toContain(P.shim);
    expect(r.warnings.join("\n")).toContain("not the funnel's shim");
  });
});

describe("uninstall --with-runtime", () => {
  it("removes the funnel wrapper, node shim and provisioned node; NEVER the prime-agent tree — prints its own uninstaller", async () => {
    installFixture(home);
    const P = paths(home);
    const r = await uninstall({ yes: true, withRuntime: true, home, retireImpl: refusedRetire() });

    expect(existsSync(P.wrapper)).toBe(false);
    expect(existsSync(P.nodeShim)).toBe(false);
    expect(existsSync(P.nodeTree)).toBe(false);
    expect(r.removed).toContain(P.wrapper);
    expect(r.removed).toContain(P.nodeShim);
    expect(r.removed).toContain(P.nodeTree);

    expect(existsSync(P.primeTree), "another project's tree is never deleted").toBe(true);
    expect(r.left).toContain(P.primeTree);
    expect(r.warnings.join("\n")).toContain('BUN_INSTALL="');
    expect(r.warnings.join("\n")).toContain("bun remove -g prime-agent");
  });

  it("a foreign wrapper is left even under --with-runtime", async () => {
    installFixture(home);
    const P = paths(home);
    writeFileSync(P.wrapper, "#!/bin/sh\nexec /usr/local/bin/something-else\n");
    const r = await uninstall({ yes: true, withRuntime: true, home, retireImpl: refusedRetire() });
    expect(existsSync(P.wrapper)).toBe(true);
    expect(r.left).toContain(P.wrapper);
    expect(r.warnings.join("\n")).toContain("not the funnel's wrapper");
  });
});

describe("step order + failure tolerance", () => {
  it("an unreachable fabric only warns: announce failure never blocks, local uninstall still completes", async () => {
    installFixture(home);
    const P = paths(home);
    const r = await uninstall({
      yes: true,
      home,
      retireImpl: refusedRetire(),
      announceOffline: async () => {
        throw new Error("fabric down");
      },
    });
    expect(r.warnings.join("\n")).toContain("offline announce failed");
    expect(r.warnings.join("\n")).toContain("fabric down");
    expect(existsSync(P.creds)).toBe(false);
    expect(r.unwired).toEqual([P.piMcp, P.primeSettings]);
  });

  it("a successful retire (code 0, e.g. J16c landing) is reported as retired", async () => {
    installFixture(home);
    const ok = vi.fn(async () => ({ code: 0 as const, message: `retired ${PUB} · audit-1` }));
    const r = await uninstall({ yes: true, home, retireImpl: ok });
    expect(r.retired).toBe(true);
    expect(r.warnings.join("\n")).not.toContain("fabric retire NOT completed");
  });
});

describe("guard rails", () => {
  it("--home without the env overrides throws (credential tiers must not aim at a real home)", async () => {
    delete process.env.VCLAW_CREDS_DIR;
    delete process.env.VCHAT_CREDS_DIR;
    await expect(uninstall({ yes: true, home })).rejects.toThrow(/--home requires VCLAW_CREDS_DIR/);
  });

  it("non-interactive without --yes refuses", async () => {
    await expect(uninstall({ home })).rejects.toThrow(/--yes is required/);
  });
});
