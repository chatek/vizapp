/**
 * protocol-core.test.ts — the one-wire-core conformance suite.
 *
 * Covers (per BRIEF-BUILD lane A dispatch):
 *  (1) round-trip through BOTH serializers (pi-a2a + agent-sdk)
 *  (2) unknown-field tolerance (forward-compat bag preserved)
 *  (3) camelCase canonicalization (snake_case accepted on read, never emitted)
 *  (4) AgentDescriptor grammar unification (Synadia ↔ tenant)
 *  (5) wire-shape fidelity vs the two shipping envelopes (byte-level layout)
 *
 * Ground truth shapes:
 *   pi-a2a    A2A/pi-a2a/src/a2a/protocol.ts:178-190 (A2aRequest), :275-283 (A2aResponse)
 *   agent-sdk agent-sdk/src/net/types.ts:76-95
 */

import { describe, it, expect } from "vitest";

import {
  type CoreEnvelope,
  serializeCore,
  parseCore,
  serializePiA2a,
  parsePiA2a,
  serializeAgentSdk,
  parseAgentSdk,
  fromSynadia,
  fromTenant,
  toSynadiaFrom,
  toTenantFrom,
  describeAgent,
  snakeToCamel,
  normalizeCasing,
} from "../../packages/protocol-core/src/index.js";

const FIXTURE: CoreEnvelope = {
  type: "a2a_request",
  id: "req-001",
  from: { agent: "pi", owner: "chance", name: "worker-1", segment: "vchat", nkey: "UA1BC2" },
  ts: "2026-08-16T02:00:00.000Z",
  replySubject: "agents.reply.pi.chance.worker-1",
  prompt: "audit the auth module",
  attachments: [{ filename: "scope.txt", content: "src/auth/**" }],
  routing: { intent: "request", conversationId: "conv-9", fabric: "vchat-email", sensitivity: "normal" },
  ttlS: 120,
};

describe("round-trip: pi-a2a serialization", () => {
  it("core → pi-a2a → core preserves all core fields", () => {
    const wire = serializePiA2a(FIXTURE);
    const back = parsePiA2a(wire);
    expect(back.type).toBe(FIXTURE.type);
    expect(back.id).toBe(FIXTURE.id);
    expect(back.ts).toBe(FIXTURE.ts);
    expect(back.prompt).toBe(FIXTURE.prompt);
    expect(back.attachments).toEqual(FIXTURE.attachments);
    expect(back.routing).toEqual(FIXTURE.routing);
    expect(back.ttlS).toBe(FIXTURE.ttlS);
    expect(back.replySubject).toBe(FIXTURE.replySubject);
    expect(back.from.agent).toBe("pi");
    expect(back.from.owner).toBe("chance");
    expect(back.from.name).toBe("worker-1");
  });

  it("pi-a2a wire layout matches the shipping shape (from = {agent,owner,name}; replySubject inside a2a)", () => {
    const wire = serializePiA2a(FIXTURE) as Record<string, unknown>;
    expect(wire.from).toEqual({ agent: "pi", owner: "chance", name: "worker-1" });
    expect(wire.a2a).toMatchObject({ intent: "request", conversationId: "conv-9", replySubject: FIXTURE.replySubject });
    expect(wire.replySubject).toBeUndefined(); // NOT top-level on the pi-a2a wire
    expect(wire.type).toBe("a2a_request");
  });
});

describe("round-trip: agent-sdk serialization", () => {
  it("core → agent-sdk → core preserves all core fields", () => {
    const wire = serializeAgentSdk(FIXTURE);
    const back = parseAgentSdk(wire);
    expect(back.type).toBe(FIXTURE.type);
    expect(back.prompt).toBe(FIXTURE.prompt);
    expect(back.replySubject).toBe(FIXTURE.replySubject);
    expect(back.routing).toEqual(FIXTURE.routing);
    expect(back.from.nkey).toBe("UA1BC2");
  });

  it("agent-sdk wire layout matches the shipping shape (from = {nkey,name})", () => {
    const wire = serializeAgentSdk(FIXTURE) as Record<string, unknown>;
    expect(wire.from).toEqual({ nkey: "UA1BC2", name: "worker-1" });
    expect(wire.a2a).toMatchObject({ conversationId: "conv-9", replySubject: FIXTURE.replySubject });
  });

  it("response envelopes carry text/error/errorCode", () => {
    const resp: CoreEnvelope = {
      type: "a2a_response",
      id: "resp-1",
      from: fromTenant({ nkey: "UA1BC2", name: "w1" }),
      ts: "2026-08-16T02:01:00.000Z",
      text: "3 findings",
      error: false,
    };
    const sdk = serializeAgentSdk(resp) as Record<string, unknown>;
    expect(sdk.text).toBe("3 findings");
    expect(sdk.error).toBe(false);
    const back = parseAgentSdk(sdk);
    expect(back.text).toBe("3 findings");
    expect(back.error).toBe(false);
  });
});

describe("unknown-field tolerance", () => {
  it("unknown top-level fields survive both round-trips", () => {
    const env: CoreEnvelope = { ...FIXTURE, futureField: { nested: true }, versionTag: 2 };
    for (const [name, ser, par] of [
      ["pi-a2a", serializePiA2a, parsePiA2a],
      ["agent-sdk", serializeAgentSdk, parseAgentSdk],
      ["core", serializeCore, parseCore],
    ] as const) {
      const back = par(ser(env));
      expect(back.futureField, name).toEqual({ nested: true });
      expect(back.versionTag, name).toBe(2);
    }
  });

  it("parse accepts real pi-a2a wire JSON verbatim", () => {
    // Shape as pi-a2a publishes it on agents.a2a.pi.{owner}.{name} today.
    const rawWire = {
      type: "a2a_request",
      id: "w-77",
      prompt: "sync roster",
      from: { agent: "pi", owner: "chance", name: "lead" },
      a2a: { intent: "request", replySubject: "agents.reply.pi.chance.lead", conversationId: "c1" },
      ts: "2026-08-16T01:00:00.000Z",
      ttlS: 60,
    };
    const core = parsePiA2a(rawWire);
    expect(core.from.owner).toBe("chance");
    expect(core.replySubject).toBe("agents.reply.pi.chance.lead");
    expect(core.routing?.intent).toBe("request");
  });
});

describe("camelCase canonicalization (§4)", () => {
  it("snake_case is accepted on read", () => {
    const snake = {
      type: "a2a_request",
      id: "s1",
      reply_subject: "agents.reply.pi.chance.x",
      ts: "2026-08-16T00:00:00.000Z",
      from: { agent: "pi", owner: "chance", name: "x" },
      a2a: { conversation_id: "c2", in_reply_to: "m1" },
    };
    const core = parseCore(snake);
    expect(core.replySubject).toBe("agents.reply.pi.chance.x");
    expect(core.routing?.conversationId).toBe("c2");
    expect(core.routing?.inReplyTo).toBe("m1");
  });

  it("canonical output NEVER emits snake_case for known fields", () => {
    const snake = {
      type: "a2a_request",
      id: "s2",
      reply_subject: "r",
      ts: "2026-08-16T00:00:00.000Z",
      from: { nkey: "U1", name: "y" },
      a2a: { conversation_id: "c", in_reply_to: "m" },
    };
    const json = JSON.stringify(serializeCore(parseCore(snake)));
    expect(json).not.toContain("reply_subject");
    expect(json).not.toContain("conversation_id");
    expect(json).toContain("replySubject");
    expect(json).toContain("conversationId");
  });

  it("snakeToCamel + normalizeCasing units", () => {
    expect(snakeToCamel("reply_subject")).toBe("replySubject");
    expect(snakeToCamel("alreadyCamel")).toBe("alreadyCamel");
    const n = normalizeCasing({ a_b: { c_d: [1] }, e: 2 }) as Record<string, unknown>;
    expect(n.a_b).toBeUndefined();
    expect((n.aB as Record<string, unknown>).cD).toEqual([1]);
    expect(n.e).toBe(2);
  });
});

describe("AgentDescriptor grammar unification", () => {
  it("Synadia ↔ descriptor round-trip", () => {
    const d = fromSynadia({ agent: "pi", owner: "chance", name: "scout" }, { segment: "vchat" });
    expect(toSynadiaFrom(d)).toEqual({ agent: "pi", owner: "chance", name: "scout" });
    expect(d.segment).toBe("vchat");
  });

  it("tenant ↔ descriptor round-trip", () => {
    const d = fromTenant({ nkey: "UA9", name: "w2" }, "vchat", { metadata: { site_id: "s1" } });
    expect(toTenantFrom(d)).toEqual({ nkey: "UA9", name: "w2" });
    expect(d.segment).toBe("vchat");
    expect(d.metadata?.site_id).toBe("s1");
  });

  it("describeAgent falls back per grammar", () => {
    expect(describeAgent(fromSynadia({ agent: "pi", owner: "chance", name: "lead" }))).toBe("lead");
    expect(describeAgent(fromTenant({ nkey: "UABCDEFG123456" }))).toBe("UABCDEFG1234");
    expect(describeAgent({})).toBe("(anonymous)");
  });

  it("core envelope holds BOTH grammars simultaneously (the bridge)", () => {
    const both = fromSynadia({ agent: "pi", owner: "chance", name: "worker-1" }, { nkey: "UA1", segment: "vchat" });
    const env: CoreEnvelope = { type: "a2a_request", id: "x", from: both, ts: "t" };
    const pi = serializePiA2a(env) as Record<string, unknown>;
    const sdk = serializeAgentSdk(env) as Record<string, unknown>;
    expect(pi.from).toEqual({ agent: "pi", owner: "chance", name: "worker-1" }); // Synadia grammar out
    expect(sdk.from).toEqual({ nkey: "UA1", name: "worker-1" }); // tenant grammar out
  });
});
