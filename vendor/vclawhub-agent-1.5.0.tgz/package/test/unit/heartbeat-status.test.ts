/**
 * heartbeat-status.test.ts — the lifecycle status is PUBLISHABLE (L1 audit finding).
 *
 * The contract (`HeartbeatPayload.status`) allows online|busy|idle|away|offline, but the emitter derived only
 * `online ? "online" : "idle"` — so `offline`/`away` could never appear on the wire and an agent had no way to
 * say it was off. This pins the fix AND the backwards-compatible default.
 */
import { describe, it, expect } from "vitest";
import { Decode } from "@sinclair/typebox/value";
import { HeartbeatPayload } from "../../src/contracts/contracts.js";
import { buildHeartbeatPayload } from "../../src/net/heartbeat.js";

const IDENTITY = { nkey: "UAAGENTFIXTUREKEY000000000000000000000000000000000000000", nonce: "n-1" } as never;

describe("heartbeat status — every contract value is reachable", () => {
  it("default derivation is UNCHANGED (online ? online : idle)", async () => {
    expect((await buildHeartbeatPayload(IDENTITY, { online: true }, 30_000)).status).toBe("online");
    expect((await buildHeartbeatPayload(IDENTITY, { online: false }, 30_000)).status).toBe("idle");
  });

  it("an explicit offline is emitted, and forces online:false + lm:disconnected", async () => {
    const hb = await buildHeartbeatPayload(IDENTITY, { online: true, status: "offline" }, 30_000);
    expect(hb.status).toBe("offline");
    expect(hb.online).toBe(false);           // never contradicted
    expect(hb.lm).toBe("disconnected");
    expect(() => Decode(HeartbeatPayload, hb)).not.toThrow();
  });

  it("away and busy are reachable (they were not before)", async () => {
    for (const st of ["away", "busy", "offline"] as const) {
      const hb = await buildHeartbeatPayload(IDENTITY, { online: true, status: st }, 30_000);
      expect(hb.status).toBe(st);
      expect(() => Decode(HeartbeatPayload, hb)).not.toThrow();
    }
  });
});
