/**
 * Unit tests for runtime resolution (src/lib/runtime.ts).
 *
 * The resolver is the SINGLE source of truth for which runtime binary the SDK
 * drives, so these tests pin the precedence contract rather than behaviour:
 *
 *   flag  >  env (VCLAW_PI_BIN)  >  config (~/.config/vclaw/config.json)  >  "pi"
 *
 * Isolation: VCLAW_CREDS_DIR redirects the store's canonical config dir to a
 * temp directory (the store's documented single-dir override) — real file I/O,
 * no mocking, so the config layer is exercised for real.
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { chmodSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import {
  resolveRuntime,
  resolvePiBin,
  setRuntime,
  DEFAULT_RUNTIME,
} from "../../src/lib/runtime.js";
import { readConfigSync } from "../../src/lib/store.js";

let dir: string;

function writeConfig(obj: unknown): void {
  writeFileSync(join(dir, "config.json"), JSON.stringify(obj), "utf-8");
}

function clearRuntimeEnv(): void {
  delete process.env.VCLAW_PI_BIN;
  delete process.env.VCHAT_PI_BIN;
}

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), "vclaw-runtime-"));
  process.env.VCLAW_CREDS_DIR = dir;
  clearRuntimeEnv();
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
  delete process.env.VCLAW_CREDS_DIR;
  clearRuntimeEnv();
});

describe("resolveRuntime — precedence", () => {
  it("falls back to the built-in default when nothing is set", () => {
    expect(resolveRuntime()).toEqual({ bin: DEFAULT_RUNTIME, source: "default" });
  });

  it("uses the config layer when present", () => {
    writeConfig({ runtime: "prime-agent" });
    expect(resolveRuntime()).toEqual({ bin: "prime-agent", source: "config" });
  });

  it("env outranks config", () => {
    writeConfig({ runtime: "prime-agent" });
    process.env.VCLAW_PI_BIN = "/opt/fake-pi";
    expect(resolveRuntime()).toEqual({ bin: "/opt/fake-pi", source: "env" });
  });

  it("the legacy VCHAT_ env still resolves (fallback tier)", () => {
    process.env.VCHAT_PI_BIN = "/opt/legacy-pi";
    expect(resolveRuntime()).toEqual({ bin: "/opt/legacy-pi", source: "env" });
  });

  it("an explicit override outranks everything, including env", () => {
    writeConfig({ runtime: "prime-agent" });
    process.env.VCLAW_PI_BIN = "/opt/fake-pi";
    expect(resolveRuntime("/explicit/pi")).toEqual({ bin: "/explicit/pi", source: "flag" });
  });

  it("a malformed config is never fatal — it just means 'no config layer'", () => {
    writeFileSync(join(dir, "config.json"), "{ not json", "utf-8");
    expect(resolveRuntime()).toEqual({ bin: DEFAULT_RUNTIME, source: "default" });
  });

  it("blank/whitespace values are ignored at every layer", () => {
    writeConfig({ runtime: "   " });
    process.env.VCLAW_PI_BIN = "  ";
    expect(resolveRuntime("   ")).toEqual({ bin: DEFAULT_RUNTIME, source: "default" });
  });

  it("resolvePiBin keeps its old signature (a single string)", () => {
    expect(resolvePiBin()).toBe(DEFAULT_RUNTIME);
    expect(resolvePiBin("/x")).toBe("/x");
  });
});

describe("setRuntime — persistence", () => {
  it("writes the choice and preserves every other field", async () => {
    writeConfig({ segment: "vmaker", server: "nats://example:4222" });
    await setRuntime("prime-agent");

    expect(readConfigSync()).toMatchObject({
      segment: "vmaker",
      server: "nats://example:4222",
      runtime: "prime-agent",
    });
    expect(resolveRuntime()).toEqual({ bin: "prime-agent", source: "config" });
  });

  it("null clears the field without disturbing the rest", async () => {
    writeConfig({ runtime: "prime-agent", segment: "vmaker" });
    await setRuntime(null);

    expect(readConfigSync()).toEqual({ segment: "vmaker" });
    expect(resolveRuntime().source).toBe("default");
  });

  it("refuses to overwrite an unparseable config — never destroys what it cannot read", async () => {
    const broken = "{ not json";
    writeFileSync(join(dir, "config.json"), broken, "utf-8");

    await expect(setRuntime("prime-agent")).rejects.toThrow(/unparseable/);

    // Byte-for-byte untouched, and no layer silently absorbs the failure.
    expect(readFileSync(join(dir, "config.json"), "utf-8")).toBe(broken);
    expect(resolveRuntime().source).toBe("default");
  });

  it("clearing on an unparseable config also refuses (the guard is not value-dependent)", async () => {
    writeFileSync(join(dir, "config.json"), "not json at all", "utf-8");
    await expect(setRuntime(null)).rejects.toThrow(/unparseable/);
    expect(readFileSync(join(dir, "config.json"), "utf-8")).toBe("not json at all");
  });

  it("enforces 0600 even when the file already existed with a looser mode", async () => {
    // writeFile's `mode` is CREATE-ONLY: a pre-existing 0644 file stays 0644
    // unless the mode is asserted afterwards. Measured before the fix.
    writeConfig({ segment: "vmaker" });
    chmodSync(join(dir, "config.json"), 0o644);
    expect(statSync(join(dir, "config.json")).mode & 0o777).toBe(0o644);

    await setRuntime("prime-agent");

    expect(statSync(join(dir, "config.json")).mode & 0o777).toBe(0o600);
    expect(readConfigSync()).toMatchObject({ segment: "vmaker", runtime: "prime-agent" });
  });
});
