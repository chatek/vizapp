/**
 * dual-extension.test.ts — prove BOTH shipped bundles load and coexist in
 * one process (lane L; the BUILD-G meta-package matrix's regression gate).
 *
 * Targets (package.json pi.extensions — the dist/ entries that fix the §0
 * publishing bug in dash/docs/sprint-unified-a2a/01-agent-sdk-meta-package.md):
 *   dist/pi-extension/index.bundled.js   (ext-segment — cloud/IDP transport)
 *   dist/ext-synadia/index.bundled.js    (ext-synadia — local site fabric)
 *
 * CI story: `pnpm build:extensions` produces both bundles before this suite;
 * when either is absent the file SKIPS with a clear message (dev boxes that
 * haven't built).
 *
 * All assertions below are grounded in the bundles as built:
 *   vchat-{claim-status,connect,directory,family,onboard,status}
 *   synadia-{buddies,send,status}
 * (/vchat-family shipped 2026-09-04 in 3609d75 — this header predates it; the
 * tracked pi-extension bundle was rebuilt 2026-10-03 and now exposes it here.)
 * (verified via grep over the bundle outputs — see the lane report).
 */

import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const EXT_SEGMENT_BUNDLE = join(HERE, "../../dist/pi-extension/index.bundled.js");
const EXT_SYNADIA_BUNDLE = join(HERE, "../../dist/ext-synadia/index.bundled.js");

const HAVE_BUNDLES = existsSync(EXT_SEGMENT_BUNDLE) && existsSync(EXT_SYNADIA_BUNDLE);
const itBundles = HAVE_BUNDLES ? it : it.skip;

/** Env keys this test mutates — saved/restored around every case. */
const ENV_KEYS = [
  "VCHAT_AGENT_AUTOSTART",
  "VCHAT_CREDS_DIR",
  "VCHAT_DEV",
  "SYNADIA_AUTOSTART",
  "SYNADIA_LOCAL_NATS_URL",
] as const;

const savedEnv = new Map<string, string | undefined>();
beforeAll(() => {
  for (const k of ENV_KEYS) savedEnv.set(k, process.env[k]);
});
afterEach(() => {
  for (const [k, v] of savedEnv) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  vi.restoreAllMocks();
});

// ── The stub host (a shared ExtensionAPI, capturing registrations) ───────

interface CommandOpts {
  description: string;
  handler: (args: string, ctx: unknown) => unknown;
}
type EventHandler = (...args: unknown[]) => unknown;

function stubHost() {
  const commands = new Map<string, CommandOpts>();
  const events = new Map<string, EventHandler[]>();
  const notifies: string[] = [];
  const api = {
    registerCommand(name: string, opts: CommandOpts) {
      if (commands.has(name)) throw new Error(`command collision: ${name}`);
      commands.set(name, opts);
    },
    on(event: string, cb: EventHandler) {
      const list = events.get(event) ?? [];
      list.push(cb);
      events.set(event, list);
    },
    sendUserMessage(_msg: string) {
      /* captured only — never driven here */
    },
  };
  const sessionCtx = { hasUI: true, ui: { notify: (m: string) => notifies.push(m) } };
  const fire = (event: string, ...args: unknown[]) =>
    (events.get(event) ?? []).map((cb) => cb(...args));
  return { api, commands, events, notifies, sessionCtx, fire };
}

/** stderr capture (ext-synadia logs via console.error). */
function spyStderr(): string[] {
  const lines: string[] = [];
  vi.spyOn(console, "error").mockImplementation((...a: unknown[]) => {
    lines.push(a.map(String).join(" "));
  });
  return lines;
}

/** Deterministic, side-effect-free env for both extensions. */
function hermeticEnv(over: Partial<Record<(typeof ENV_KEYS)[number], string>>) {
  delete process.env.VCHAT_DEV; // no dev-mode plain connect
  process.env.VCHAT_CREDS_DIR = join(mkdtempSync(join(tmpdir(), "dual-ext-creds-")), "creds"); // no creds → "not onboarded" path
  process.env.SYNADIA_LOCAL_NATS_URL = "nats://127.0.0.1:1"; // unroutable: ungated start fails fast, never touches a real fabric
  for (const [k, v] of Object.entries(over)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
}

describe("dual-extension load + coexistence (shipped bundles)", () => {
  itBundles("both bundles import in ONE process and export factories", async () => {
    const seg = await import(EXT_SEGMENT_BUNDLE);
    const syn = await import(EXT_SYNADIA_BUNDLE);
    expect(typeof seg.default).toBe("function");
    expect(typeof syn.default).toBe("function");
  });

  itBundles("both register their commands + lifecycle hooks on a SHARED host, no collisions", async () => {
    hermeticEnv({ VCHAT_AGENT_AUTOSTART: "0", SYNADIA_AUTOSTART: "0" });
    const { api, commands, events } = stubHost();

    (await import(EXT_SEGMENT_BUNDLE)).default(api as never); // must not throw
    (await import(EXT_SYNADIA_BUNDLE)).default(api as never); // must not throw (same process, same host object)

    const names = [...commands.keys()];
    const vchat = names.filter((n) => n.startsWith("vchat-"));
    const synadia = names.filter((n) => n.startsWith("synadia-"));
    // EXACT set (not a subset): vchat-family is the 6th command — see the header note.
    expect(vchat.sort()).toEqual(["vchat-claim-status", "vchat-connect", "vchat-directory", "vchat-family", "vchat-onboard", "vchat-status"]);
    expect(synadia.sort()).toEqual(["synadia-buddies", "synadia-send", "synadia-status"]);
    expect(names.length).toBe(vchat.length + synadia.length); // namespaces disjoint — nothing else registered

    expect((events.get("session_start") ?? []).length).toBeGreaterThanOrEqual(2); // BOTH hooked, independently
    expect((events.get("session_shutdown") ?? []).length).toBeGreaterThanOrEqual(2);
  });

  itBundles("autostart gates are INDEPENDENT — VCHAT_AGENT_AUTOSTART=0 silences ext-segment only", async () => {
    const stderr = spyStderr();
    const { api, notifies, fire, sessionCtx } = stubHost();
    hermeticEnv({ VCHAT_AGENT_AUTOSTART: "0" }); // synadia UNGATED (will attempt connect → fails fast on :1)

    (await import(EXT_SEGMENT_BUNDLE)).default(api as never);
    (await import(EXT_SYNADIA_BUNDLE)).default(api as never);
    fire("session_start", {}, sessionCtx);
    await new Promise((r) => setTimeout(r, 50)); // let the ungated synadia start() reject

    expect(notifies).toEqual([]); // ext-segment gated: no "not onboarded" notify
    expect(stderr.some((l) => l.includes("[ext-synadia]"))).toBe(true); // synadia tried (independent gate)
    fire("session_shutdown"); // clean teardown of nothing-started — must not throw
  });

  itBundles("autostart gates are INDEPENDENT — SYNADIA_AUTOSTART=0 silences ext-synadia only", async () => {
    const stderr = spyStderr();
    const { api, notifies, fire, sessionCtx } = stubHost();
    hermeticEnv({ SYNADIA_AUTOSTART: "0" }); // ext-segment UNGATED (no creds → deterministic "not onboarded" notify)

    (await import(EXT_SEGMENT_BUNDLE)).default(api as never);
    (await import(EXT_SYNADIA_BUNDLE)).default(api as never);
    fire("session_start", {}, sessionCtx);
    await new Promise((r) => setTimeout(r, 50));

    expect(notifies.some((n) => n.includes("not onboarded"))).toBe(true); // ext-segment ran its gate-free path
    expect(stderr.some((l) => l.includes("[ext-synadia]"))).toBe(false); // synadia gated: silent
    fire("session_shutdown");
  });

  itBundles("module states are isolated — driving one lifecycle leaves the other's registrations intact", async () => {
    const stderr = spyStderr();
    const { api, commands, events, fire, sessionCtx } = stubHost();
    hermeticEnv({ VCHAT_AGENT_AUTOSTART: "0", SYNADIA_AUTOSTART: "0" });

    const seg = await import(EXT_SEGMENT_BUNDLE);
    const syn = await import(EXT_SYNADIA_BUNDLE);
    seg.default(api as never);
    syn.default(api as never);

    const before = [...commands.keys()].sort();

    // Drive ext-segment's full lifecycle twice (idempotent), then verify the
    // shared host still holds EVERY registration (both namespaces) and the
    // synadia module's handlers are untouched.
    fire("session_start", {}, sessionCtx);
    fire("session_shutdown");
    fire("session_shutdown");
    expect([...commands.keys()].sort()).toEqual(before);
    expect((events.get("session_start") ?? []).length).toBeGreaterThanOrEqual(2);

    // And the reverse: synadia lifecycle then ext-segment registrations intact.
    fire("session_start", {}, sessionCtx); // both gated → no-ops
    expect([...commands.keys()].sort()).toEqual(before);
    expect(stderr.filter((l) => l.includes("[ext-synadia]"))).toEqual([]); // never started
  });
});

describe("bundle absence guard", () => {
  it("skips dual tests with a clear message when bundles are unbuilt (CI: build:extensions first)", () => {
    if (HAVE_BUNDLES) return; // bundles present here — the guard is documented for CI/dev parity
    expect(HAVE_BUNDLES).toBe(false);
    // (itBundles.skip communicates the missing-build state to the runner)
  });
});
