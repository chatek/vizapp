/**
 * BUILD lane K — OnlineGate wiring tests (additive).
 *
 * Layers:
 *   K-gate: the REAL OnlineGate (src/net/capabilities.js, unmocked) against a
 *           faked @nats-io/kv Kvm — on→off→on transitions (cache + forced),
 *           absent-record fail-closed, VCHAT_AGENT_LLM env fallback.
 *   K-wire: startRuntime passes a gate-consulting `online` provider to
 *           startPresence (captured via the lifecycle mock) — transitions
 *           flow through the provider; /vchat-status surfaces the gate label.
 *   K-dev:  VCHAT_DEV=1 keeps the hermetic () => true provider (no gate).
 *
 * Harness discipline: same as ext-upgrade.test.ts (capturing mock pi;
 * store/lifecycle/directory/contracts/subjects mocked). capabilities.js is
 * deliberately NOT mocked — only @nats-io/kv is faked so the real gate logic
 * (cache TTL, fallback order) runs.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  loadCredentials: vi.fn(),
  hasPendingFlag: vi.fn(),
  readConfig: vi.fn(),
  saveConfig: vi.fn(),
  fetchNatsUserJWT: vi.fn(),
  connectViaJWT: vi.fn(),
  startPresence: vi.fn(),
  subA2A: vi.fn(),
  watchDirectory: vi.fn(),
  setTenantSegment: vi.fn(),
}));

/** Fake KV store backing the mocked @nats-io/kv Kvm. */
const fakeKv = vi.hoisted(() => ({
  entries: new Map<string, { value: Uint8Array }>(),
  openCalls: 0,
}));

vi.mock("../../src/lib/store.js", () => ({
  loadCredentials: mocks.loadCredentials,
  hasPendingFlag: mocks.hasPendingFlag,
  readConfig: mocks.readConfig,
  saveConfig: mocks.saveConfig,
}));
vi.mock("../../src/agent/lifecycle.js", () => ({
  fetchNatsUserJWT: mocks.fetchNatsUserJWT,
  connectViaJWT: mocks.connectViaJWT,
  startPresence: mocks.startPresence,
  subA2A: mocks.subA2A,
}));
vi.mock("../../src/net/directory.js", () => ({
  watchDirectory: mocks.watchDirectory,
}));
vi.mock("../../src/contracts/contracts.js", () => ({
  setTenantSegment: mocks.setTenantSegment,
}));
vi.mock("../../src/agent/subjects.js", () => ({
  SubjectTree: {
    CLAIM: () => "tenant.vchat.claim.FAKE_NKEY",
    PROMPT: () => "tenant.vchat.user.FAKE_NKEY.agent.FAKE_NKEY.prompt.>",
  },
}));
vi.mock("@nats-io/kv", () => ({
  Kvm: class {
    constructor(_nc: unknown) { /* nc ignored by the fake */ }
    async open(_bucket: string) {
      fakeKv.openCalls++;
      return {
        get: async (key: string) => fakeKv.entries.get(key) ?? null,
      };
    }
  },
}));

import { OnlineGate } from "../../src/net/capabilities.js";

const NKEY = "UAAGATEKEYGATEKEYGATEKEYGATEKEYGATEKEYGATEKEYGATEKEYGATEKEYGATE";

const CREDS = {
  seed: "SUATESTSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEED",
  public_key: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  agent_nkey: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  name: "test-agent",
  steward: "tester@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
} as const;

function setKv(online: boolean | null): void {
  if (online === null) {
    fakeKv.entries.delete(NKEY);
    return;
  }
  fakeKv.entries.set(NKEY, {
    value: new TextEncoder().encode(JSON.stringify({ online, capabilities: ["collaborate"] })),
  });
}

function fakeNc() {
  return {
    subscribe: vi.fn(() => ({
      unsubscribe() {},
      [Symbol.asyncIterator]() {
        return { next: async () => ({ done: true as const, value: undefined }) };
      },
    })),
    publish: vi.fn(),
    drain: vi.fn(async () => {}),
    close: vi.fn(() => {}),
  };
}

/** Captures startPresence options so tests can invoke the online provider. */
let presenceOpts: { online?: () => boolean | Promise<boolean> } | null = null;

beforeEach(async () => {
  vi.clearAllMocks();
  delete process.env.VCHAT_AGENT_LLM;
  fakeKv.entries.clear();
  fakeKv.openCalls = 0;
  presenceOpts = null;
  mocks.startPresence.mockImplementation((_nc: unknown, _id: unknown, opts: unknown) => {
    presenceOpts = opts as { online?: () => boolean | Promise<boolean> };
    return { stop: async () => {} };
  });
  vi.resetModules();
});

afterEach(() => {
  delete process.env.VCHAT_AGENT_LLM;
});

async function factory() {
  return (await import("../../src/pi-extension/index.ts")).default;
}

function harness(factoryFn: (pi: unknown) => void) {
  const commands = new Map<string, (args: string, ctx: unknown) => Promise<void>>();
  const pi = {
    on: vi.fn(),
    registerCommand: vi.fn((name: string, spec: { handler: (a: string, c: unknown) => Promise<void> }) =>
      commands.set(name, spec.handler)),
    sendUserMessage: vi.fn(),
  };
  factoryFn(pi);
  return { commands, pi };
}

async function connect(factoryFn: (pi: unknown) => void) {
  mocks.loadCredentials.mockResolvedValue(CREDS);
  mocks.fetchNatsUserJWT.mockResolvedValue("JWT-x");
  mocks.connectViaJWT.mockResolvedValue(fakeNc());
  mocks.subA2A.mockReturnValue(undefined);
  mocks.watchDirectory.mockReturnValue({ directory: { snapshot: () => [] }, stop: () => {} });
  const { commands } = harness(factoryFn);
  await commands.get("vchat-connect")!("", { hasUI: false, ui: { notify() {} } });
  return commands;
}

async function statusFrames(commands: Map<string, (a: string, c: unknown) => Promise<void>>) {
  const frames: Array<{ p: Record<string, unknown> }> = [];
  const ctx = {
    hasUI: true,
    ui: { notify: (m: string) => { try { frames.push({ p: JSON.parse(m) }); } catch { /* */ } } },
  };
  await commands.get("vchat-status")!("", ctx);
  return frames.filter((f) => f.p.__vchat === true && f.p.kind === "command_result");
}

// ── K-gate: real OnlineGate behavior ─────────────────────────────────────────
describe("K-gate: OnlineGate against fake KV", () => {
  it("on→off→on transitions honored (isOnlineNow — forced re-read)", async () => {
    const nc = fakeNc();
    const gate = new OnlineGate(nc as never, NKEY, { envFallback: () => false });
    setKv(true);
    expect(await gate.isOnlineNow()).toBe(true);
    setKv(false);
    expect(await gate.isOnlineNow()).toBe(false);
    setKv(true);
    expect(await gate.isOnlineNow()).toBe(true);
  });

  it("cache window: cached online state within cacheMs (no re-read)", async () => {
    const nc = fakeNc();
    const gate = new OnlineGate(nc as never, NKEY, { cacheMs: 60_000, envFallback: () => false });
    setKv(true);
    expect(await gate.isOnline()).toBe(true);
    setKv(false); // flip mid-window
    const readsBefore = fakeKv.openCalls;
    expect(await gate.isOnline()).toBe(true); // still cached true
    expect(fakeKv.openCalls).toBe(readsBefore); // no KV touch
    expect(await gate.isOnlineNow()).toBe(false); // forced read sees the flip
  });

  it("absent record → envFallback (FAIL-CLOSED default false; env override honored)", async () => {
    const nc = fakeNc();
    setKv(null);
    const closed = new OnlineGate(nc as never, NKEY, { envFallback: () => false });
    expect(await closed.isOnlineNow()).toBe(false);
    const envOn = new OnlineGate(nc as never, NKEY, { envFallback: () => !!process.env.VCHAT_AGENT_LLM });
    process.env.VCHAT_AGENT_LLM = "1";
    expect(await envOn.isOnlineNow()).toBe(true);
  });
});

// ── K-wire: startRuntime provider + /vchat-status ────────────────────────────
describe("K-wire: presence provider consults the gate; status surfaces it", () => {
  it("online provider follows KV transitions (on→off→on, honoring the 30s cache TTL)", async () => {
    vi.useFakeTimers(); // gate TTL uses Date.now() — mocked by fake timers
    try {
      const f = await factory();
      await connect(f);
      expect(presenceOpts?.online).toBeTruthy();
      const nkey = CREDS.public_key;
      const set = (online: boolean) => {
        fakeKv.entries.set(nkey, { value: new TextEncoder().encode(JSON.stringify({ online })) });
      };
      // First read populates the cache.
      set(true);
      expect(await presenceOpts!.online!()).toBe(true);
      // Flip mid-window: cached state still served (no KV re-read).
      set(false);
      expect(await presenceOpts!.online!()).toBe(true);
      // Past the 30s TTL: the flip is honored.
      vi.advanceTimersByTime(31_000);
      expect(await presenceOpts!.online!()).toBe(false);
      set(true);
      vi.advanceTimersByTime(31_000);
      expect(await presenceOpts!.online!()).toBe(true);
    } finally {
      vi.useRealTimers();
    }
  });

  it("/vchat-status reports on-line / on-rack / unknown from the KV record", async () => {
    const f = await factory();
    const commands = await connect(f);
    const nkey = CREDS.public_key;
    fakeKv.entries.set(nkey, { value: new TextEncoder().encode(JSON.stringify({ online: true })) });
    let frames = await statusFrames(commands);
    expect(frames[0].p.data).toMatchObject({ gate: "on-line" });

    fakeKv.entries.set(nkey, { value: new TextEncoder().encode(JSON.stringify({ online: false })) });
    frames = await statusFrames(commands);
    expect(frames[0].p.data).toMatchObject({ gate: "on-rack" });

    fakeKv.entries.delete(nkey);
    frames = await statusFrames(commands);
    expect(frames[0].p.data).toMatchObject({ gate: "unknown" });
  });
});

// ── K-dev: VCHAT_DEV=1 hermetic bypass ────────────────────────────────────────
describe("K-dev: VCHAT_DEV=1 keeps () => true (no gate)", () => {
  it("provider returns true with NO KV record present (hermetic)", async () => {
    process.env.VCHAT_DEV = "1";
    vi.resetModules();
    vi.doMock("@nats-io/transport-node", () => ({
      connect: async () => fakeNc(),
    }));
    const f = (await import("../../src/pi-extension/index.ts")).default;
    const commands = await connect(f);
    delete process.env.VCHAT_DEV;

    expect(presenceOpts?.online).toBeTruthy();
    setKv(null); // no record — would be fail-closed if a gate existed
    expect(await presenceOpts!.online!()).toBe(true);

    // /vchat-status labels the dev bypass.
    const frames = await statusFrames(commands);
    expect(frames[0].p.data).toMatchObject({ gate: "on-line (dev bypass)" });
    vi.doUnmock("@nats-io/transport-node");
  });
});
