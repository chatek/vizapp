/**
 * J15 — incus-repackager plan invariants (dry-run harness, no incus needed).
 *
 * Each test pins one §8.3 REJECT to a mechanical property of the plan DATA:
 * zero identity in build paths · nothing prompts · publish from STOPPED ·
 * product correctness (prime-agent, never /usr/bin/pi).
 */
import { describe, it, expect } from "vitest";
import { fastPlan, cleanPlan, validatePlan } from "../../skills/incus-repackager/src/plan.js";
import { checkPlan } from "../../skills/incus-repackager/src/steps.js";

const shText = (p: ReturnType<typeof fastPlan>) =>
  p.steps.filter((s): s is Extract<typeof s, { kind: "sh" }> => s.kind === "sh").map((s) => s.argv.join(" "));

describe("plan invariants (§8.3 REJECTs)", () => {
  it("fast/clean/validate plans pass checkPlan (no violations)", () => {
    expect(checkPlan(fastPlan({ ver: "0.9.5" }))).toEqual([]);
    expect(checkPlan(cleanPlan({ ver: "0.9.4" }))).toEqual([]);
    expect(checkPlan(validatePlan({ alias: "vclaw-agent:trixie-prime-0.9.4", ver: "0.9.4" }))).toEqual([]);
  });

  it("ZERO IDENTITY in build paths: onboard/join.ts appear ONLY in validate", () => {
    for (const build of [fastPlan({ ver: "0.9.5" }), cleanPlan({ ver: "0.9.4" })]) {
      for (const t of shText(build)) {
        expect(t).not.toMatch(/\bonboard\b/);
        expect(t).not.toMatch(/join\.ts/);
      }
    }
    const v = shText(validatePlan({ alias: "a", ver: "1" }));
    expect(v.some((t) => t.includes("join.ts"))).toBe(true); // identity NOW, in validate only
  });

  it("PUBLISH FROM STOPPED: stop strictly precedes publish in fast and clean", () => {
    for (const p of [fastPlan({ ver: "0.9.5" }), cleanPlan({ ver: "0.9.4" })]) {
      const ids = p.steps.map((s) => (s.kind === "sh" ? s.argv.slice(0, 2).join(" ") : ""));
      const stop = ids.indexOf("incus stop");
      const pub = ids.indexOf("incus publish");
      expect(pub).toBeGreaterThan(-1);
      expect(stop).toBeGreaterThan(-1);
      expect(stop).toBeLessThan(pub);
    }
  });

  it("NOTHING PROMPTS: no TTY exec, no interactive installers, no unattended apt", () => {
    for (const p of [fastPlan({ ver: "0.9.5" }), cleanPlan({ ver: "0.9.4" }), validatePlan({ alias: "a", ver: "1" })]) {
      for (const t of shText(p)) {
        expect(t).not.toMatch(/--interactive/);
        expect(t).not.toMatch(/\bread\s+-[rp]\s/);
        // sed -i is fine (in-place edit, not interactive) — regression pin for the regex itself
      }
      for (const s of p.steps) {
        if (s.kind === "sh" && s.argv[0] === "incus" && s.argv[1] === "exec") {
          expect(s.argv).not.toContain("-t");
          expect(s.argv).not.toContain("--force-interactive");
        }
      }
    }
  });

  it("PRODUCT = prime-agent: never installs/pushes /usr/bin/pi or the wrong package", () => {
    for (const p of [fastPlan({ ver: "0.9.5" }), cleanPlan({ ver: "0.9.4" })]) {
      for (const t of shText(p)) {
        expect(t).not.toContain("@vchatemail");
        expect(t).not.toMatch(/file push [^\s]*pi\b/); // never PUSH /usr/bin/pi (§8.2 wrong-binary)
      }
    }
  });

  it("NO CREDENTIAL in argv anywhere (O37: systemctl show is world-readable)", () => {
    for (const p of [fastPlan({ ver: "0.9.5" }), cleanPlan({ ver: "0.9.4" }), validatePlan({ alias: "a", ver: "1" })]) {
      for (const t of shText(p)) {
        expect(t).not.toMatch(/--nkey\s+\S+/);
        expect(t).not.toMatch(/--seed(\s|=)/);
        expect(t).not.toMatch(/--token(\s|=)/);
        expect(t).not.toMatch(/X-VChat-Service-Token/i);
      }
    }
  });

  it("checkPlan catches violations: a plan that bakes identity is refused", () => {
    const bad = fastPlan({ ver: "0.9.5" });
    const i = bad.steps.findIndex((s) => s.kind === "sh" && s.id === "install");
    (bad.steps[i] as Extract<typeof bad.steps[number], { kind: "sh" }>).argv.push("vclaw-agent onboard --yes");
    const v = checkPlan(bad);
    expect(v.some((x) => x.rule === "zero-identity-in-build")).toBe(true);
  });

  it("checkPlan catches publish-before-stop (order matters, not just presence)", () => {
    const bad = cleanPlan({ ver: "0.9.4" });
    const stopIdx = bad.steps.findIndex((s) => s.id === "stop");
    const pubIdx = bad.steps.findIndex((s) => s.id === "publish");
    const stopStep = bad.steps[stopIdx];
    bad.steps[stopIdx] = bad.steps[pubIdx]; // publish EARLY …
    bad.steps[pubIdx] = stopStep; // … stop LATE (swap captured before mutating)
    expect(checkPlan(bad).some((x) => x.rule === "publish-from-stopped")).toBe(true);
  });

  it("validate carries the J16 retire hook as a VISIBLE stub (never silent)", () => {
    const stubs = validatePlan({ alias: "a", ver: "1" }).steps.filter((s) => s.kind === "stub");
    expect(stubs).toHaveLength(1);
    expect(stubs[0]).toMatchObject({ id: "retire-hook" });
  });
});
