/**
 * J15 — executor discipline: dry-run executes NOTHING, real runs abort on
 * RED, evidence refuses fabrication, stdin is ignored.
 */
import { describe, it, expect } from "vitest";
import { runPlan, hostRun } from "../../skills/incus-repackager/src/exec.js";
import { fastPlan, validatePlan } from "../../skills/incus-repackager/src/plan.js";
import { writeEvidence } from "../../skills/incus-repackager/src/evidence.js";
import { mkdtempSync, readFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

describe("runPlan", () => {
  it("DRY-RUN executes nothing: no runner calls, every sh step reported 'dry'", async () => {
    let spawns = 0;
    const runner = async (argv: string[]) => { spawns++; return { rc: 0, stdout: "", stderr: "" }; };
    const report = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), { execute: false, runner });
    expect(spawns).toBe(0);
    expect(report.results.filter((r) => r.status === "dry").length).toBeGreaterThan(0);
    expect(report.executed).toBe(false);
  });

  it("REAL run with a failing version assert ABORTS at the RED step (never continues past a gate)", async () => {
    const runner = async (argv: string[]) => {
      if (argv.join(" ").includes("prime-agent --version")) return { rc: 0, stdout: "\n", stderr: "" }; // EMPTY = T1 class
      return { rc: 0, stdout: "ok\n", stderr: "" };
    };
    const report = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), { execute: true, runner });
    const red = report.results.find((r) => r.status === "RED");
    expect(red?.stepId).toBe("ver-prime-a");
    // nothing after the RED step ran
    const after = report.results.slice(report.results.findIndex((r) => r.stepId === red?.stepId) + 1);
    expect(after.filter((r) => r.status === "ok" || r.durationMs !== undefined)).toHaveLength(0);
  });

  it("REAL run: a RED sh command aborts the run with its stderr surfaced", async () => {
    const runner = async (argv: string[]) =>
      argv[0] === "incus" && argv[1] === "launch"
        ? { rc: 1, stdout: "", stderr: "Error: Instance not found" }
        : { rc: 0, stdout: "ok\n", stderr: "" };
    const report = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), { execute: true, runner });
    const red = report.results.find((r) => r.status === "RED");
    expect(red?.detail).toContain("Instance not found");
  });

  it("validate: stub steps never abort the run but are reported as stubs", async () => {
    const runner = async (argv: string[]) => {
      const j = argv.join(" ");
      if (j.includes("cloud-init")) return { rc: 0, stdout: "status: done\nextended_status: done\n", stderr: "" };
      if (j.includes("vclaw-agent status")) return { rc: 0, stdout: "claimed: true\n", stderr: "" };
      if (j.includes("--version")) return { rc: 0, stdout: "1\n", stderr: "" }; // ver "1" satisfies both --version asserts
      if (j.includes("vchat3")) return { rc: 0, stdout: "INFO {}\n", stderr: "" };
      if (j.includes("%a")) return { rc: 0, stdout: "600\n", stderr: "" };
      return { rc: 0, stdout: "ok\n", stderr: "" };
    };
    const report = await runPlan(validatePlan({ alias: "a", ver: "1" }), { execute: true, runner });
    expect(report.results.some((r) => r.status === "stub" && r.stepId === "retire-hook")).toBe(true);
    // evidence must then carry the residual-identity marker — see below
    expect(report.results.find((r) => r.status === "RED")).toBeUndefined();
  });

  it("hostRun config pins stdin ignore (source-level contract — §2.2.4)", async () => {
    // Reading the source is the honest check: spawning anything real here would
    // execute on a dev vantage. Assert the spawn options in the file.
    const src = readFileSync(new URL("../../skills/incus-repackager/src/exec.ts", import.meta.url), "utf8");
    expect(src).toContain(`stdio: ["ignore", "pipe", "pipe"]`);
  });
});

describe("writeEvidence — never fabricated", () => {
  it("REFUSES a dry-run report", async () => {
    const report = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), { execute: false });
    const dir = mkdtempSync(join(tmpdir(), "j15-"));
    expect(() => writeEvidence(report, { vantage: "test" }, dir)).toThrow(/DRY/);
    expect(existsSync(join(dir, ".."))).toBe(true); // no file written (dir itself may exist)
  });

  it("REFUSES a RED run; writes vantage + size + residual marker for a green one", async () => {
    const red = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), {
      execute: true,
      runner: async (argv) => {
        if (argv.join(" ").includes("prime-agent --version")) return { rc: 0, stdout: "\n", stderr: "" };
        return { rc: 0, stdout: "ok\n", stderr: "" };
      },
    });
    expect(() => writeEvidence(red, { vantage: "t" }, mkdtempSync(join(tmpdir(), "j15-")))).toThrow(/RED/);

    const runner = async (argv: string[]) => {
      if (argv[1] === "image" && argv[2] === "info") {
        return { rc: 0, stdout: "Fingerprint: e7ccedc63ada\nSize: 797.13MiB\n", stderr: "" };
      }
      const j = argv.join(" ");
      if (j.includes("bun --version")) return { rc: 0, stdout: "1.3.14\n", stderr: "" };
      if (j.includes("uv --version")) return { rc: 0, stdout: "uv 0.12.14 (x86_64-unknown-linux-gnu)\n", stderr: "" };
      if (j.includes("--version")) return { rc: 0, stdout: "0.9.5\n", stderr: "" };
      if (j.includes("NATS_URL")) return { rc: 0, stdout: "(none)\n", stderr: "" };
      return { rc: 0, stdout: "ok\n", stderr: "" };
    };
    const report = await runPlan(fastPlan({ ver: "0.9.5", tgz: "/tmp/x.tgz" }), { execute: true, runner });
    expect(report.results.find((r) => r.status === "RED")).toBeUndefined();
    const dir = mkdtempSync(join(tmpdir(), "j15-"));
    const file = writeEvidence(report, { vantage: "ct17-test" }, dir);
    const text = readFileSync(file, "utf8");
    expect(text).toContain("ct17-test");
    expect(text).toContain("797.13MiB");
    expect(text).toContain("e7ccedc63ada");
  });

  it("validate evidence carries the RESIDUAL-IDENTITY warning while J16 is stubbed", async () => {
    const runner = async (argv: string[]) => {
      const j = argv.join(" ");
      if (j.includes("cloud-init")) return { rc: 0, stdout: "status: done\n", stderr: "" };
      if (j.includes("status")) return { rc: 0, stdout: "claimed\n", stderr: "" };
      if (j.includes("--version")) return { rc: 0, stdout: "0.9.4\n", stderr: "" };
      if (j.includes("%a")) return { rc: 0, stdout: "600\n", stderr: "" };
      if (j.includes("vchat3")) return { rc: 0, stdout: "INFO {\"server_id\":…}\n", stderr: "" };
      return { rc: 0, stdout: "ok\n", stderr: "" };
    };
    const report = await runPlan(validatePlan({ alias: "a", ver: "0.9.4" }), { execute: true, runner });
    expect(report.results.find((r) => r.status === "RED")).toBeUndefined();
    const dir = mkdtempSync(join(tmpdir(), "j15-"));
    const file = writeEvidence(report, { vantage: "ct17-test" }, dir);
    expect(readFileSync(file, "utf8")).toContain("RESIDUAL IDENTITY");
  });
});
