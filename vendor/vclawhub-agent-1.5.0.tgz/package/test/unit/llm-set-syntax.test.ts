/**
 * llm-set-syntax.test.ts — the cross-runtime `llm set` syntax contract.
 *
 * Mirrors W1's Go `TestLLMSetSyntaxCanonical` (dash/sidecar/internal/fleet):
 * both sides assert the IDENTICAL literal so the TS `LLM_SET_SYNTAX` and the
 * Go `llmSetInstructionSyntax` can't drift. Also pins the single-source
 * invariant: the literal appears EXACTLY ONCE in src/ (the constant definition
 * in constants/messages.ts) — any re-typed literal anywhere else fails here.
 */
import { describe, it, expect } from "vitest";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { LLM_SET_SYNTAX } from "../../src/constants/messages.js";

/** The canonical literal — IDENTICAL to Go reconciler.go llmSetInstructionSyntax. */
const CANONICAL = "llm set url=<base-url> key=<api-key> model=<model>";
const SRC_DIR = join(process.cwd(), "src");

function tsFiles(dir: string): string[] {
  const out: string[] = [];
  for (const ent of readdirSync(dir)) {
    const p = join(dir, ent);
    if (statSync(p).isDirectory()) out.push(...tsFiles(p));
    else if (ent.endsWith(".ts")) out.push(p);
  }
  return out;
}

describe("LLM_SET_SYNTAX (cross-runtime canonical)", () => {
  it("equals the canonical literal byte-for-byte (matches Go llmSetInstructionSyntax)", () => {
    // If this fails, the TS and Go sides have drifted — update BOTH +
    // every runtime that cites it (reconciler.go, fleet-ui Svelte).
    expect(LLM_SET_SYNTAX).toBe(CANONICAL);
  });

  it("is single-sourced: the literal appears EXACTLY ONCE in src/ (the constant definition)", () => {
    const perFile = tsFiles(SRC_DIR)
      .map((f) => ({
        file: relative(process.cwd(), f),
        count: readFileSync(f, "utf8").split(CANONICAL).length - 1,
      }))
      .filter((x) => x.count > 0);
    const total = perFile.reduce((n, x) => n + x.count, 0);
    expect(
      total,
      `the literal must appear exactly once in src/ (the constant def). Found: ${JSON.stringify(perFile)}`,
    ).toBe(1);
    // And the lone definition lives in the canonical messages module.
    expect(perFile[0]?.file).toBe("src/constants/messages.ts");
  });
});
