/**
 * offline-command.test.ts — the `offline` / `online` state declaration (L1: OFFLINE was MISSING as a command).
 *
 * Asserts the WIRE, not just that something was published: the announcement goes to the V3 discovery
 * subject, carries the declared `online`, and its signature VERIFIES against the publishing key (presence
 * is signed by ruling — an unsigned declaration would be a false claim on the fabric).
 */
import { describe, it, expect } from "vitest";
import { createUser, fromPublic } from "@nats-io/nkeys";
import { Decode } from "@sinclair/typebox/value";
import { setPresenceState } from "../../src/commands/offline.js";
import { hbSubjectV2 } from "../../src/net/heartbeat.js";
import { canonicalAnnouncementBytes, HeartbeatPayload } from "../../src/contracts/contracts.js";

function recordingNc() {
  const published: Array<{ subject: string; data: Uint8Array }> = [];
  return {
    published,
    publish(subject: string, data: Uint8Array) { published.push({ subject, data }); },
  } as never;
}
const dec = new TextDecoder();
const kp = createUser();
const SEED = dec.decode(kp.getSeed());
const PUB = kp.getPublicKey();
const IDENTITY = { nkey: PUB, nonce: "offline-fixture" };

describe("setPresenceState — the declared state reaches the wire, SIGNED", () => {
  it("offline: announces online:false to $SRV.INFO.agents.<segment>.<nkey> with a VERIFYING signature", async () => {
    const nc = recordingNc();
    await setPresenceState(nc, IDENTITY, "offline", { seed: SEED, segment: "default" });

    const annPub = (nc as unknown as { published: Array<{ subject: string; data: Uint8Array }> })
      .published.find((p) => p.subject.startsWith("$SRV.INFO.agents."));
    expect(annPub, "an announcement must be published to the discovery subject").toBeTruthy();
    expect(annPub!.subject).toBe(`$SRV.INFO.agents.default.${PUB}`);

    const wire = JSON.parse(dec.decode(annPub!.data)) as Record<string, unknown> & { sig: string };
    expect(wire.online).toBe(false);
    expect(wire.nkey).toBe(PUB);

    // the signature must verify over the canonical bytes (=> the declaration is authentic)
    const { sig, ...ann } = wire;
    const ok = fromPublic(PUB).verify(canonicalAnnouncementBytes(ann as never), Buffer.from(sig, "base64"));
    expect(ok, "the offline announcement's signature must verify against the publishing key").toBe(true);
  });

  it("offline: the heartbeat carries status=offline (schema-valid), on the hb subject", async () => {
    const nc = recordingNc();
    await setPresenceState(nc, IDENTITY, "offline", { seed: SEED });
    const hb = (nc as unknown as { published: Array<{ subject: string; data: Uint8Array }> })
      .published.find((p) => p.subject === hbSubjectV2(PUB));
    expect(hb, "a heartbeat must be published").toBeTruthy();
    const payload = JSON.parse(dec.decode(hb!.data));
    expect(payload.status).toBe("offline");
    expect(payload.online).toBe(false);
    expect(() => Decode(HeartbeatPayload, payload)).not.toThrow();
  });

  it("away and online are distinct and coherent", async () => {
    for (const [state, expectOnline, expectStatus] of [["away", false, "away"], ["online", true, "online"]] as const) {
      const nc = recordingNc();
      const res = await setPresenceState(nc, IDENTITY, state, { seed: SEED });
      expect((res.announcement as { online: boolean }).online).toBe(expectOnline);
      expect(res.heartbeat.status).toBe(expectStatus);
      expect(res.heartbeat.online).toBe(expectOnline);
    }
  });
});
