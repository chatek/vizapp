/**
 * announcement-v2.test.ts — v9 W0 announcement v2 conformance (deliverable 3+4,
 * gate G2): schema v:2 with optional children[], v1 unchanged + still valid,
 * canonical-byte signing covers children[], directory accepts BOTH versions.
 *
 * Golden canonical JSON strings live in test/helpers/announcement-fixtures.ts —
 * they are the TS↔Go lockstep artifact (port, never re-derive).
 */
import { describe, it, expect } from "vitest";
import { Value } from "@sinclair/typebox/value";
import { nkeys } from "@nats-io/nats-core";
import {
  AgentAnnouncement,
  AgentAnnouncementV2,
  ANNOUNCEMENT_V2_FIELD_ORDER,
  ANNOUNCEMENT_FIELD_ORDER,
  canonicalAnnouncementBytes,
  canonicalAnnouncementV2Bytes,
  signAnnouncement,
  signAnnouncementV2,
} from "../../src/contracts/contracts.js";
import { verifyAnnouncement } from "../../src/net/directory.js";
import {
  V1_ANNOUNCEMENT,
  V1_CANONICAL_JSON,
  V2_CHILDREN,
  V2_ANNOUNCEMENT_WITH_CHILDREN,
  V2_CANONICAL_JSON_WITH_CHILDREN,
  V2_ANNOUNCEMENT_NO_CHILDREN,
  V2_CANONICAL_JSON_NO_CHILDREN,
} from "../helpers/announcement-fixtures.js";

// Real ed25519 keypair per test run (signing round-trips; the GOLDEN bytes are
// sig-independent — sig is never part of any canonical input).
const kp = nkeys.createUser();
const seed = new TextDecoder().decode(kp.getSeed());
const pub = kp.getPublicKey();

// Subject the lead publishes from (exact-path-pinned — same rule as v1).
const SUBJECT = `$SRV.INFO.agents.default.${pub}`;

/** Wire format (presence.ts discipline): announcement JSON + sig sibling (base64-std). */
async function wireFor(ann: Record<string, unknown>, sign: (a: never, s: string) => Promise<Uint8Array>) {
  const sig = await sign(ann as never, seed);
  return new TextEncoder().encode(JSON.stringify({ ...ann, sig: Buffer.from(sig).toString("base64") }));
}

describe("v1 announcement — UNCHANGED (golden bytes + old pipeline)", () => {
  it("canonical bytes still match the pinned v1 golden JSON", () => {
    const canon = new TextDecoder().decode(canonicalAnnouncementBytes(V1_ANNOUNCEMENT as never));
    expect(canon).toBe(V1_CANONICAL_JSON);
  });

  it("field order is untouched (the v1 byte contract)", () => {
    expect([...ANNOUNCEMENT_FIELD_ORDER]).toEqual([
      "ts", "name", "nkey", "segment", "capabilities", "online", "model", "sdk_version",
    ]);
  });

  it("v1 schema REJECTS a v2 wire (additionalProperties:false — clean discrimination)", () => {
    expect(Value.Check(AgentAnnouncement, V2_ANNOUNCEMENT_WITH_CHILDREN)).toBe(false);
    expect(Value.Check(AgentAnnouncement, V2_ANNOUNCEMENT_NO_CHILDREN)).toBe(false);
  });

  it("v1 sign → directory verify round-trip, entry.v === 1", async () => {
    // FRESH ts — the golden fixture's pinned ts is outside the verify freshness
    // window by design; round-trips sign a live-shaped announcement.
    const ann = { ...V1_ANNOUNCEMENT, nkey: pub, ts: new Date().toISOString() };
    const data = await wireFor(ann, signAnnouncement);
    const r = verifyAnnouncement(`$SRV.INFO.agents.default.${pub}`, data, Date.now());
    expect(r.ok).toBe(true);
    expect(r.entry!.v).toBe(1);
    expect(r.entry!.children).toBeUndefined();
  });
});

describe("v2 announcement schema (v:2 + optional children[])", () => {
  it("validates with children", () => {
    expect(Value.Check(AgentAnnouncementV2, V2_ANNOUNCEMENT_WITH_CHILDREN)).toBe(true);
  });

  it("validates WITHOUT children (children optional)", () => {
    expect(Value.Check(AgentAnnouncementV2, V2_ANNOUNCEMENT_NO_CHILDREN)).toBe(true);
  });

  it("v2 schema REJECTS a v1 wire (v:2 discriminator required)", () => {
    expect(Value.Check(AgentAnnouncementV2, V1_ANNOUNCEMENT)).toBe(false);
  });

  it("rejects an unknown extra field (additionalProperties:false — deterministic bytes)", () => {
    expect(Value.Check(AgentAnnouncementV2, { ...V2_ANNOUNCEMENT_NO_CHILDREN, extra: 1 })).toBe(false);
  });

  it("rejects a malformed child entry (child fields are required)", () => {
    const bad = { ...V2_ANNOUNCEMENT_NO_CHILDREN, children: [{ name: "w" }] };
    expect(Value.Check(AgentAnnouncementV2, bad)).toBe(false);
  });
});

describe("v2 canonical bytes + signing (G2: children[] INSIDE the signed input)", () => {
  it("canonical v2 bytes match the golden JSON WITH children (children last)", () => {
    const canon = new TextDecoder().decode(canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_WITH_CHILDREN as never));
    expect(canon).toBe(V2_CANONICAL_JSON_WITH_CHILDREN);
  });

  it("canonical v2 bytes match the golden JSON WITHOUT children (undefined-skip)", () => {
    const canon = new TextDecoder().decode(canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_NO_CHILDREN as never));
    expect(canon).toBe(V2_CANONICAL_JSON_NO_CHILDREN);
  });

  it("field order puts v first and children last", () => {
    expect(ANNOUNCEMENT_V2_FIELD_ORDER[0]).toBe("v");
    expect(ANNOUNCEMENT_V2_FIELD_ORDER.at(-1)).toBe("children");
    expect(ANNOUNCEMENT_V2_FIELD_ORDER.length).toBe(ANNOUNCEMENT_FIELD_ORDER.length + 2);
  });

  it("children order is the canonical byte order (reordered children → different bytes → different sig)", async () => {
    const a = { ...V2_ANNOUNCEMENT_WITH_CHILDREN, children: [V2_CHILDREN[0], V2_CHILDREN[1]] } as never;
    const b = { ...V2_ANNOUNCEMENT_WITH_CHILDREN, children: [V2_CHILDREN[1], V2_CHILDREN[0]] } as never;
    const bytesA = new TextDecoder().decode(canonicalAnnouncementV2Bytes(a));
    const bytesB = new TextDecoder().decode(canonicalAnnouncementV2Bytes(b));
    expect(bytesA).not.toBe(bytesB);
  });

  it("v2 sign → directory verify round-trip, entry.v === 2, children carried", async () => {
    const ann = { ...V2_ANNOUNCEMENT_WITH_CHILDREN, nkey: pub, ts: new Date().toISOString() };
    const data = await wireFor(ann, signAnnouncementV2);
    const r = verifyAnnouncement(SUBJECT, data, Date.now());
    expect(r.ok).toBe(true);
    expect(r.entry!.v).toBe(2);
    expect(r.entry!.children).toEqual(V2_CHILDREN);
  });

  it("v2 WITHOUT children verifies (children absent ⇒ skipped in canonical bytes)", async () => {
    const ann = { ...V2_ANNOUNCEMENT_NO_CHILDREN, nkey: pub, ts: new Date().toISOString() };
    const data = await wireFor(ann, signAnnouncementV2);
    const r = verifyAnnouncement(SUBJECT, data, Date.now());
    expect(r.ok).toBe(true);
    expect(r.entry!.v).toBe(2);
    expect(r.entry!.children).toBeUndefined();
  });

  it("TAMPERED children are rejected — children[] is covered by the signature (G2 core)", async () => {
    const ann = { ...V2_ANNOUNCEMENT_WITH_CHILDREN, nkey: pub, ts: new Date().toISOString() } as Record<string, unknown>;
    const data = await wireFor(ann, signAnnouncementV2);
    // Mutate a child AFTER signing (a lying lead inflating a worker state).
    const wire = JSON.parse(new TextDecoder().decode(data)) as Record<string, unknown>;
    const children = wire.children as Array<Record<string, unknown>>;
    children[0].state = "idle"; // signed as "running"
    const tampered = new TextEncoder().encode(JSON.stringify(wire));
    const r = verifyAnnouncement(SUBJECT, tampered, Date.now());
    expect(r.ok).toBe(false);
    expect(r.reason).toBe("bad_signature");
  });

  it("TAMPERED v2 body field (model) is rejected", async () => {
    const ann = { ...V2_ANNOUNCEMENT_NO_CHILDREN, nkey: pub, ts: new Date().toISOString() } as Record<string, unknown>;
    const data = await wireFor(ann, signAnnouncementV2);
    const wire = JSON.parse(new TextDecoder().decode(data)) as Record<string, unknown>;
    wire.model = "evil-model";
    const r = verifyAnnouncement(SUBJECT, new TextEncoder().encode(JSON.stringify(wire)), Date.now());
    expect(r.ok).toBe(false);
    expect(r.reason).toBe("bad_signature");
  });

  it("a v2 announcement signed with the WRONG key fails (lead-only publication guard)", async () => {
    const ann = { ...V2_ANNOUNCEMENT_NO_CHILDREN, nkey: pub, ts: new Date().toISOString() } as Record<string, unknown>;
    const evil = nkeys.createUser();
    const evilSig = await signAnnouncementV2(ann as never, new TextDecoder().decode(evil.getSeed()));
    const data = new TextEncoder().encode(
      JSON.stringify({ ...ann, sig: Buffer.from(evilSig).toString("base64") }),
    );
    const r = verifyAnnouncement(SUBJECT, data, Date.now());
    expect(r.ok).toBe(false);
    expect(r.reason).toBe("bad_signature");
  });

  it("a v2 body signed with the v1 canonicalizer fails (canonicalizers are version-bound)", async () => {
    const ann = { ...V2_ANNOUNCEMENT_NO_CHILDREN, nkey: pub, ts: new Date().toISOString() } as Record<string, unknown>;
    // Cross-signature: sig computed over v1 bytes (which would SKIP v — never valid for v2).
    const wrongSig = await signAnnouncement(ann as never, seed);
    const data = new TextEncoder().encode(
      JSON.stringify({ ...ann, sig: Buffer.from(wrongSig).toString("base64") }),
    );
    const r = verifyAnnouncement(SUBJECT, data, Date.now());
    expect(r.ok).toBe(false);
    expect(r.reason).toBe("bad_signature");
  });
});
