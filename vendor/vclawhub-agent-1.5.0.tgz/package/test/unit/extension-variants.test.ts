/**
 * J3d — extension variant harness (bundled = runtime winner; DECISION RESOLVED).
 *
 * Two artifacts ship in src/pi-extension/:
 *   • index.ts         — the EDIT-SOURCE (human edits; re-bundle after changes).
 *   • index.bundled.js — the RUNTIME entry (bun build --format=esm --target=node);
 *                        the package.json `pi.extensions` manifest points HERE.
 *
 * ── DECISION RESOLVED (J1c; docs/e2e-q2-onesidecar.md §5) ────────────────────
 * The self-bundle is the runtime winner. The un-bundled source (index.ts) can
 * NEVER connect under pi.dev on any path (connectViaJWT OR VCHAT_DEV): the
 * @nats-io/nkeys library's internal getter-re-exports are not materialized
 * under pi.dev's jiti/virtualModules (`nkeys_1.Prefixes` is undefined), and the
 * failure is LOADER-LEVEL + CRED-INDEPENDENT — the dev-path ANNOUNCE trips it
 * with NO creds involved (J1c used test-provided creds that bypassed createUser,
 * yet the announce still failed un-bundled). The "un-bundled might connect with
 * valid creds" branch is DEAD; it is no longer asserted here.
 *
 * The bundle inlines nkeys + tweetnacl → fixes the fromSeed/signing seam, so
 * the CONNECT path works. J1c confirms presence_update / peer_discovered /
 * directory all fire with the bundle; J1d (Tier C) confirms it on production.
 *
 * ── createUser FACET (root-caused; fix VERIFIED — distinct from fromSeed/signing) ─
 * PRIOR "nested Prefixes dropped" read was WRONG: createUser + fromSeed SHARE the
 * codec→Prefixes path, and fromSeed (decode) works inlined ⇒ that path is fine.
 * createUser's ONLY fromSeed-independent dep is tweetnacl's randomBytes (createUser
 * → createPair → nacl.randomBytes, to mint the random seed). tweetnacl's PRNG
 * detection is:
 *     var crypto2 = typeof self !== "undefined" ? self.crypto || self.msCrypto : null;
 *     if (crypto2 && crypto2.getRandomValues) { … Web-Crypto PRNG … }
 *     else if (true) { crypto2 = __require("crypto"); … = createRequire(import.meta.url)("crypto") … }
 * node AND pi.dev have no `self` ⇒ Web-Crypto branch skipped ⇒ the createRequire
 * branch runs. Under pi.dev's virtualModules `import.meta.url` is not a usable
 * file:// URL ⇒ createRequire can't resolve crypto ⇒ PRNG never set ⇒ createUser
 * can't mint random bytes. fromSeed is unaffected (tweetnacl EMBEDDED hash, no PRNG).
 *
 * FIX (a) — VERIFIED: post-build patch the detection to find globalThis.crypto
 * (Web Crypto, available node ≥19 + pi.dev) so createRequire is never reached:
 *     perl -0777 -pi -e 's/var crypto2 = typeof self !== "undefined" \? self\.crypto || self\.msCrypto : null;/var crypto2 = (typeof self !== "undefined" ? self.crypto || self.msCrypto : null) || globalThis.crypto;/g' dist/pi-extension/index.bundled.js
 * (2 sites in the bun-built bundle — sign + curve tweetnacl copies; run AFTER
 * `bun build`. NOTE 2026-10-03: the esbuild rebuild in
 * scripts/build-pi-extension.mjs inlines ONE nacl copy, so the script patches
 * 1 site — that is the expected count there, not a failed patch; the counts are
 * NKeysErrorCode 146→73 / setPRNG 6→3 / msCrypto 2→1, i.e. exactly the duplicate
 * copy disappearing.) Verified:
 * createUser mints valid distinct User keys via Web Crypto with createRequire
 * DISABLED (simulating pi.dev); real bundle load-safe (factory + 6 commands —
 * see EXPECTED_COMMANDS; the 6th, /vchat-family, shipped 2026-09-04 in 3609d75,
 * i.e. AFTER this header was written, and only reached the tracked bundle in the
 * 2026-10-03 rebuild).
 * pi.dev-verify PENDING (couldn't reproduce the loader locally — node + pi 0.84.1
 * jiti both resolve createRequire(import.meta.url) fine). Until applied, the
 * ephemeral/onboard-in-process path stays DEFERRED; the extension connects via
 * fromSeed (test-provided creds), and onboard stays CLI-side (node, createUser works).
 *
 * These tests lock the BUNDLE's structural contract (the runtime path): it is
 * self-contained for nkeys + tweetnacl AND typebox (omp §3 row 4 — see
 * scripts/build-pi-extension.mjs), externalizes only node builtins, and
 * exposes the factory + all 6 commands. The source's role
 * (edit-source, root-cause of the seam) is documented by the static test below.
 */
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const SRC = join(__dirname, "../../src/pi-extension/index.ts");
const BUNDLE = join(__dirname, "../../dist/pi-extension/index.bundled.js");

// The FULL command surface the shipped bundle must register — an EXACT set, not
// a subset. /vchat-family joined the surface 2026-09-04 (3609d75 "cp3 lead
// /vchat-family"; CHANGELOG.md records it) and the 2026-10-03 rebuild made the
// tracked bundle agree with src/pi-extension/index.ts. Keep this list in lockstep
// with the registerCommand() calls in that source.
const EXPECTED_COMMANDS = ["vchat-onboard", "vchat-status", "vchat-connect", "vchat-claim-status", "vchat-directory", "vchat-family"];

describe("extension variants — static architecture", () => {
  it("index.ts (edit-source) pulls nkeys transitively — NOT self-contained (root-cause of the seam)", () => {
    const src = readFileSync(SRC, "utf-8");
    // The extension has no direct @nats-io/nkeys import; it composes
    // ../agent/lifecycle.js (+ store/keygen), which resolve nkeys at runtime via
    // the host loader. Under pi.dev's jiti those getter-re-exports (Prefixes,
    // NKeysErrorCode, …) are not materialized → the ANNOUNCE trips it
    // loader-level + cred-independently (J1c). This is WHY the source can never
    // connect and the manifest points at the bundle.
    expect(src).toMatch(/from ["']\.\.\/agent\/lifecycle/);
    expect(src).not.toContain("NKeysErrorCode"); // not inlined — loaded at runtime (the seam surface)
  });

  it("index.bundled.js (runtime entry) inlines nkeys — self-contained, no external @nats-io/nkeys import", () => {
    const b = readFileSync(BUNDLE, "utf-8");
    // nkeys internals are inlined (the enum + codec live in the bundle):
    expect(b).toContain("NKeysErrorCode");
    // the bundled consumer does not import the CJS nkeys package at runtime:
    expect(b).not.toMatch(/from\s+["']@nats-io\/nkeys["']/);
    expect(b).not.toMatch(/require\(["']@nats-io\/nkeys["']\)/);
    // NOTE — createUser facet (root-caused; see header): NOT a "Prefixes drop" —
    // createUser's only fromSeed-independent dep is tweetnacl randomBytes, whose
    // PRNG falls to createRequire(import.meta.url)("crypto") (fails under pi.dev's
    // virtualModules). Fix = Web-Crypto PRNG patch (header recipe). createUser +
    // Prefixes.* appear textually in the bundle (the codec path is fine); the
    // break is the randomBytes/crypto-require, exercised only by createUser.
    expect(b).toContain("createUser");
  });

  it("index.bundled.js inlines @sinclair/typebox TOO — omp shims typebox onto packages/omptype, so an external import dies at runtime (OMP §3 row 4); only node builtins external", () => {
    const b = readFileSync(BUNDLE, "utf-8");
    // The OLD contract externalized typebox (pi.dev was believed to shim it).
    // The esbuild migration settled it the other way — scripts/build-pi-extension.mjs
    // documents why (schema validator rejects `Unknown type` without the
    // bundle's own copy). Script, committed bundle and this test now agree:
    // NO typebox import statement; typebox CODE inlined (TypeBoxError is
    // typebox-only). NOTE: ext-synadia keeps the OLD policy (typebox
    // external) — different host, different contract; do not "align" them.
    expect(b).not.toMatch(/from ["']@sinclair\/typebox["']/);
    expect(b).toContain("TypeBoxError");
    // no runtime dependency on the host pi package (the ExtensionAPI import is type-only → erased):
    expect(b).not.toMatch(/from ["']@earendil-works\/pi-coding-agent["']/);
  });
});

describe("runtime bundle — load + command surface (node loader)", () => {
  // The bundle is the manifest entry + runtime winner (J1c). Under node/vitest
  // it loads + registers the full command surface; under pi.dev it connects
  // (presence_update/peer_discovered/directory fire — J1c; J1d confirms prod).
  // The un-bundled source load is no longer asserted — that branch is dead.

  it("index.bundled.js — default export is a factory that registers all 6 commands", async () => {
    const mod = await import("../../dist/pi-extension/index.bundled.js");
    expect(typeof mod.default).toBe("function");
    const commands: string[] = [];
    const pi = {
      on: () => {},
      registerCommand: (n: string) => commands.push(n),
      sendUserMessage: () => {},
    };
    expect(() => mod.default(pi)).not.toThrow();
    expect(commands.sort()).toEqual([...EXPECTED_COMMANDS].sort());
  });
});
