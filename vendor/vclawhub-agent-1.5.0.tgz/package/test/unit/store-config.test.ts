/**
 * J3a — config-persistence tests for readConfig/saveConfig (src/lib/store.ts).
 *
 * ~/.vchat/config.json is written by /vchat-connect (with the wizard's
 * segment/server/vgateUrl) and read by session_start so the held presence
 * session auto-connects without env management in the host lane. These tests
 * codify the persistence contract: round-trip, owner-only (0o600) perms,
 * missing-config → null (no throw), and dir autocreation.
 *
 * Mirrors the store.test.ts convention: every fs/os call is mocked so no real
 * I/O occurs.
 */
import { describe, it, expect, beforeEach, vi } from "vitest";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir } from "node:os";

vi.mock("node:fs/promises");
vi.mock("node:fs");
vi.mock("node:os", () => ({ homedir: vi.fn(() => "/home/testuser") }));

import { readConfig, saveConfig } from "../../src/lib/store.js";

const mockedReadFile = vi.mocked(readFile);
const mockedWriteFile = vi.mocked(writeFile);
const mockedMkdir = vi.mocked(mkdir);
const mockedExistsSync = vi.mocked(existsSync);
const mockedHomedir = vi.mocked(homedir);

const CONFIG_PATH = "/home/testuser/.config/vclaw/config.json";
const VCHAT_DIR = "/home/testuser/.config/vclaw"; // Q4: writes go to the NEW dir
const LEGACY_DIR = "/home/testuser/.vchat"; // Q4: read-order fallback

beforeEach(() => {
  vi.resetAllMocks();
  mockedHomedir.mockReturnValue("/home/testuser");
});

describe("readConfig()", () => {
  it("returns null when config.json is absent (ENOENT) — session_start treats this as 'no saved config'", async () => {
    const enoent = new Error("ENOENT");
    (enoent as NodeJS.ErrnoException).code = "ENOENT";
    mockedReadFile.mockRejectedValue(enoent);

    await expect(readConfig()).resolves.toBeNull();
    // Wave-1 read-order: all three tiers attempted before null.
    expect(mockedReadFile).toHaveBeenCalledTimes(3);
  });

  it("returns null on malformed JSON (no throw) — auto-connect falls back to defaults", async () => {
    mockedReadFile.mockResolvedValue("{ not json");
    await expect(readConfig()).resolves.toBeNull();
  });

  it("returns the parsed VchatConfig when valid JSON is present", async () => {
    const cfg = { segment: "vchat", server: "nats://vchat3:4223", vgateUrl: "https://api.vclawhub.com" };
    mockedReadFile.mockResolvedValue(JSON.stringify(cfg));

    await expect(readConfig()).resolves.toEqual(cfg);
  });

  it("tolerates a partially-populated config (only some fields set)", async () => {
    mockedReadFile.mockResolvedValue(JSON.stringify({ segment: "vchat" }));
    await expect(readConfig()).resolves.toEqual({ segment: "vchat" });
  });
});

describe("saveConfig()", () => {
  it("creates the new config dir when missing before writing (Q4: ~/.config/vchat)", async () => {
    mockedExistsSync.mockReturnValue(false);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveConfig({ segment: "vchat" });

    expect(mockedExistsSync).toHaveBeenCalledWith(VCHAT_DIR);
    expect(mockedMkdir).toHaveBeenCalledWith(VCHAT_DIR, { recursive: true });
  });

  it("skips mkdir when the config dir already exists", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveConfig({ segment: "vchat" });

    expect(mockedMkdir).not.toHaveBeenCalled();
  });

  it("writes config.json with owner-read/write (0o600) permissions", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);

    await saveConfig({ segment: "vchat", server: "nats://vchat3:4223" });

    expect(mockedWriteFile).toHaveBeenCalledWith(
      CONFIG_PATH,
      expect.any(String),
      { encoding: "utf-8", mode: 0o600 },
    );
  });

  it("serialises the config with 2-space indent (stable, human-readable)", async () => {
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockResolvedValue(undefined);
    const cfg = { segment: "vchat", server: "nats://x:4223", vgateUrl: "https://y" };

    await saveConfig(cfg);

    const written = mockedWriteFile.mock.calls[0][1] as string;
    expect(JSON.parse(written)).toEqual(cfg);
    expect(written).toContain("\n  "); // 2-space indent
  });
});

describe("config round-trip (saveConfig → readConfig)", () => {
  it("what /vchat-connect writes, session_start reads back unchanged", async () => {
    // saveConfig captures the payload; readConfig returns the same bytes.
    const cfg = { segment: "acme", server: "nats://n:4223", vgateUrl: "https://g" };
    let captured = "";
    mockedExistsSync.mockReturnValue(true);
    mockedWriteFile.mockImplementation(async (_p, data) => { captured = data as string; });
    mockedReadFile.mockImplementation(async () => captured);

    await saveConfig(cfg);
    const back = await readConfig();

    expect(back).toEqual(cfg);
  });
});
