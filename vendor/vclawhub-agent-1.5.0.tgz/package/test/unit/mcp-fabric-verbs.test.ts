/**
 * MCP FABRIC verb tests (lane mcp-fabric-verbs, wave 2) — HERMETIC.
 *
 * Boundary discipline (mirrors mcp-server.test.ts):
 *   - Transport: InMemoryTransport round-trips against buildMcpServer() —
 *     every assertion goes through a real MCP Client.callTool/listTools, so
 *     RENAMING A FABRIC TOOL (or breaking registration) turns this suite RED.
 *   - Network: connectViaNKey is mocked at the agent/lifecycle.js boundary.
 *     The default mock THROWS — any tool that dials without a test wiring a
 *     fake nc fails loudly instead of reaching a real NATS server. No socket
 *     is ever opened; nats://vchat3:4223 is never touched.
 *   - Disk: VCLAW_CREDS_DIR points at a fresh temp dir per test (store.ts
 *     resolves paths lazily at call time), so no real ~/.config/vclaw is
 *     read or written.
 *   - Secrets: every result is JSON-serialised and swept for the REAL seed
 *     plus a config.json sentinel — on every code path, success and error.
 *   - Directory/announcement fixtures use the REAL codecs (generateNkeyPair,
 *     signAnnouncement, canonicalAnnouncementBytes, nkeys.fromPublic) so the
 *     verify pipeline under test is the wire-true one, not a stub of it.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { fromPublic } from "@nats-io/nkeys";

// Fail-closed connect mock — EVERY dial must be wired by a test.
vi.mock("../../src/agent/lifecycle.js", async (importOriginal) => {
  const orig = await importOriginal<typeof import("../../src/agent/lifecycle.js")>();
  return { ...orig, connectViaNKey: vi.fn(async () => { throw new Error("unexpected fabric dial in test"); }) };
});

import { buildMcpServer, MCP_TOOLS } from "../../src/mcp/server.js";
import { resetFabricMemory } from "../../src/mcp/fabric-tools.js";
import { checkPublishSubject, checkSubscribeSubject } from "../../src/mcp/fabric-tools.js";
import { SEED_PATTERN } from "../../src/mcp/redact.js";
import { generateNkeyPair } from "../../src/lib/keygen.js";
import { saveCredentials } from "../../src/lib/store.js";
import { signAnnouncement, canonicalAnnouncementBytes } from "../../src/contracts/contracts.js";
import type { StoredCredentials } from "../../src/types.js";
import type { NatsConnection } from "@nats-io/nats-core";

/* ── env hygiene ─────────────────────────────────────────────────────── */

const ENV_KEYS = [
  "VCLAW_NATS_URL", "VCHAT_NATS_URL",
  "VCLAW_SEGMENT", "VCHAT_SEGMENT",
  "VCLAW_CREDS_DIR", "VCHAT_CREDS_DIR",
];

let credsDir: string;

beforeEach(() => {
  vi.unstubAllGlobals();
  vi_mocked_connectReset();
  for (const k of ENV_KEYS) delete process.env[k];
  credsDir = mkdtempSync(join(tmpdir(), "mcp-fabric-"));
  process.env.VCLAW_CREDS_DIR = credsDir;
  resetFabricMemory(); // module-scoped roster cache + last-announce memory
});

afterEach(() => {
  vi.unstubAllGlobals();
  for (const k of ENV_KEYS) delete process.env[k];
  rmSync(credsDir, { recursive: true, force: true });
});

/* ── harness ─────────────────────────────────────────────────────────── */

async function harness() {
  const server = buildMcpServer();
  const [serverTransport, clientTransport] = InMemoryTransport.createLinkedPair();
  await server.connect(serverTransport);
  const client = new Client({ name: "mcp-fabric-test", version: "0.0.0" });
  await client.connect(clientTransport);
  return { server, client };
}

function payload(result: { content: Array<{ type: string; text: string }> }) {
  expect(result.content[0]?.type).toBe("text");
  return JSON.parse(result.content[0]!.text) as Record<string, unknown>;
}

/** Serialize a full CallToolResult and sweep it for secrets. */
function assertNoSecrets(result: unknown, ...needles: string[]) {
  const text = JSON.stringify(result);
  expect(text.match(SEED_PATTERN), `seed-shaped leak in: ${text.slice(0, 200)}`).toBeNull();
  for (const n of needles) expect(text).not.toContain(n);
  return text;
}

/** A REAL keypair + stored credentials in the temp dir. */
async function seedIdentity() {
  const kp = await generateNkeyPair();
  const creds: StoredCredentials = {
    seed: kp.seed,
    public_key: kp.publicKey,
    agent_nkey: kp.publicKey,
    name: "fabric-agent",
    steward: "unknown",
    created_at: "2026-01-01T00:00:00.000Z",
  };
  await saveCredentials(creds);
  return { kp, creds };
}

/** config.json with a segment + a sentinel secret (contents must never leak). */
function writeConfig(segment?: string, server?: string) {
  const sentinel = "sk-llm-SENTINEL-f9e8d7c6b5";
  writeFileSync(
    join(credsDir, "config.json"),
    JSON.stringify({ ...(segment ? { segment } : {}), ...(server ? { server } : {}), api_key: sentinel }, null, 2),
  );
  return sentinel;
}

/* ── fake fabric (NatsConnection surface the tools actually use) ─────── */

interface FakeMsg { subject: string; data: Uint8Array; reply?: string }
type SubCallback = (err: unknown | null, msg: FakeMsg | null) => void;
interface FakeSub { subject: string; callback?: SubCallback; unsubscribed: boolean; unsubscribe(): void }

function fakeNc() {
  const published: Array<{ subject: string; data: string }> = [];
  const subs: FakeSub[] = [];
  const state = {
    published,
    subs,
    closed: false,
    /** Fire-and-forget delivery to every matching subscription (async, like a
     *  real server dispatching after the subscribe round-trip). */
    deliver(msg: FakeMsg): void {
      for (const s of subs) {
        if (s.unsubscribed) continue;
        if (s.subject !== msg.subject && !matchWildcard(s.subject, msg.subject)) continue;
        setTimeout(() => s.callback?.(null, msg), 0);
      }
    },
  };
  const nc = {
    publish(subject: string, data: Uint8Array) {
      published.push({ subject, data: new TextDecoder().decode(data) });
    },
    subscribe(subject: string, opts?: { callback?: SubCallback }) {
      const sub: FakeSub = {
        subject,
        callback: opts?.callback,
        unsubscribed: false,
        unsubscribe() {
          this.unsubscribed = true;
        },
      };
      subs.push(sub);
      return sub;
    },
    async close() {
      state.closed = true;
    },
    async drain() { /* no-op */ },
  };
  return { nc: nc as unknown as NatsConnection, state };
}

/** NATS `>` tail-wildcard matching (last token only) + `*` token matching. */
function matchWildcard(pattern: string, subject: string): boolean {
  const p = pattern.split(".");
  const s = subject.split(".");
  for (let i = 0; i < p.length; i++) {
    if (p[i] === ">") return i === p.length - 1; // '>' only legal as the last token
    if (p[i] === "*") continue;
    if (p[i] !== s[i]) return false;
  }
  return p.length === s.length;
}

/** Wire the mocked connectViaNKey to return the fake nc. */
async function wireConnect(nc: NatsConnection) {
  const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
  vi.mocked(connectViaNKey).mockResolvedValue(nc);
}

/** Reset the connect mock back to fail-closed. */
function vi_mocked_connectReset() {
  // vi.mocked() resolves lazily; this runs after the vi.mock factory above.
  const mod = vi.mocked(require_connectViaNKey());
  mod.mockReset();
  mod.mockImplementation(async () => {
    throw new Error("unexpected fabric dial in test");
  });
}
// Hoisted indirection so beforeEach can reset the mock before any import use.
import * as lifecycleMod from "../../src/agent/lifecycle.js";
function require_connectViaNKey() {
  return lifecycleMod.connectViaNKey as unknown as ReturnType<typeof vi.fn>;
}


/** Wire the mocked connect to a fake nc that delivers `msgs` once the
 *  subscription for `matchSubject` lands (inside the tool's listen window). */
async function wireConnectWithDelivery(matchSubject: string, msgs: Array<{ subject: string; data: Uint8Array }>) {
  const { nc, state } = fakeNc();
  await wireConnect(nc);
  void vi.waitFor(() => {
    const sub = state.subs.find((s) => s.subject === matchSubject && !s.unsubscribed);
    expect(sub).toBeTruthy();
  }).then(() => {
    for (const m of msgs) state.deliver(m);
  });
  return { nc, state };
}

/* ── announcement fixtures (REAL sign path — the wire-true one) ──────── */

const enc = new TextEncoder();

/** A signed peer announcement (v1 wire: JSON + base64-std sig sibling). */
async function signedAnnouncement(kp: Awaited<ReturnType<typeof generateNkeyPair>>, segment = "default") {
  const ann = {
    ts: new Date().toISOString(),
    name: "peer-agent",
    nkey: kp.publicKey,
    segment,
    capabilities: ["collaborate"],
    online: true,
    model: "",
    sdk_version: "test",
  };
  const sig = await signAnnouncement(ann, kp.seed);
  return { ann, wire: JSON.stringify({ ...ann, sig: Buffer.from(sig).toString("base64") }) };
}

/** Verify a published announcement wire against the signer's public key. */
function verifyPublishedAnnouncement(published: { subject: string; data: string }, nkey: string) {
  const wire = JSON.parse(published.data) as Record<string, unknown> & { sig?: string };
  expect(wire.sig).toBeTruthy();
  const { sig, ...ann } = wire;
  const ok = fromPublic(nkey).verify(
    canonicalAnnouncementBytes(ann as never),
    new Uint8Array(Buffer.from(sig as string, "base64")),
  );
  expect(ok).toBe(true);
  return ann;
}

const U_FORM = /^U[A-Z2-7]{55}$/;

/* ── tool surface (a rename anywhere → RED) ──────────────────────────── */

describe("mcp tool surface (fabric verbs)", () => {
  it("lists the four identity tools PLUS the five fabric verbs PLUS the three artifact verbs", async () => {
    const { client } = await harness();
    const tools = await client.listTools();
    expect(tools.tools.map((t) => t.name).sort()).toEqual(
      [
        MCP_TOOLS.identityStatus,
        MCP_TOOLS.onboardStart,
        MCP_TOOLS.onboardPoll,
        MCP_TOOLS.health,
        MCP_TOOLS.presenceStatus,
        MCP_TOOLS.roster,
        MCP_TOOLS.announceOnce,
        MCP_TOOLS.a2aPublish,
        MCP_TOOLS.a2aSubscribePoll,
        MCP_TOOLS.artifactPut,
        MCP_TOOLS.artifactGet,
        MCP_TOOLS.artifactList,
      ].sort(),
    );
  });
});

/* ── vclaw_presence_status ───────────────────────────────────────────── */

describe("vclaw_presence_status", () => {
  it("reports an empty host honestly: no identity, no subjects, no live connection", async () => {
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.presenceStatus, arguments: {} });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.onboarded).toBe(false);
    expect(p.pending).toBe(false);
    expect(p.public_key).toBeNull();
    expect(p.subjects).toBeNull();
    expect(p.declared_state).toBeNull();
    expect(p.last_announcement).toBeNull();
    expect(p.live_connection).toBe(false);
    expect(p.segment).toBe("default");
    expect(p.server).toBe("nats://vchat3:4223");
    assertNoSecrets(res);
  });

  it("derives the announcement/heartbeat/mailbox subjects from identity + config segment", async () => {
    const { kp } = await seedIdentity();
    const sentinel = writeConfig("vchat"); // config segment wins over "default"

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.presenceStatus, arguments: {} });
    const p = payload(res as never);
    expect(p.onboarded).toBe(true);
    expect(p.segment).toBe("vchat");
    expect(p.public_key).toEqual({
      u_form: kp.publicKey,
      base64url: Buffer.from(kp.rawPublicKey).toString("base64url"),
    });
    expect((p.public_key as { u_form: string }).u_form).toMatch(U_FORM);
    const subjects = p.subjects as Record<string, string>;
    // The segment scopes the DISCOVERY plane explicitly…
    expect(subjects.discovery).toBe(`$SRV.INFO.agents.vchat.${kp.publicKey}`);
    // …while the V2 tenant planes stay on the SDK's current tenant root
    // (tenant.default — this module never switches it; segment-adoption
    // invariant guards setTenantSegment to the two runtime entry points,
    // and the CLI's own one-shots behave identically).
    expect(subjects.heartbeat).toBe(`tenant.default.user.${kp.publicKey}.agent.${kp.publicKey}.hb`);
    expect(subjects.a2a_mailbox).toBe(`tenant.default.a2a.${kp.publicKey}`);
    assertNoSecrets(res, kp.seed, sentinel);
  });

  it("surfaces VCLAW_SEGMENT env and never the seed", async () => {
    process.env.VCLAW_SEGMENT = "eng";
    const { kp } = await seedIdentity();
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.presenceStatus, arguments: {} });
    const p = payload(res as never);
    expect(p.segment).toBe("eng");
    expect((p.subjects as Record<string, string>).discovery).toBe(`$SRV.INFO.agents.eng.${kp.publicKey}`);
    assertNoSecrets(res, kp.seed);
  });
});

/* ── vclaw_roster ────────────────────────────────────────────────────── */

describe("vclaw_roster", () => {
  it("listen_ms=0 never dials: empty cache reported honestly", async () => {
    const { kp } = await seedIdentity();
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.roster, arguments: { listen_ms: 0 } });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.listened).toBe(false);
    expect(p.server).toBeNull();
    expect(p.entries).toEqual([]);
    expect(p.count).toBe(0);
    assertNoSecrets(res, kp.seed);
  });

  it("refuses to dial without a stored identity (fail-closed, not anonymous)", async () => {
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.roster, arguments: { listen_ms: 500 } });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toContain("vclaw_onboard_start");
    const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
    expect(connectViaNKey).not.toHaveBeenCalled();
    assertNoSecrets(res);
  });

  it("a bounded listen verifies a REAL signed announcement and reports it", async () => {
    const { creds } = await seedIdentity();
    const peer = await generateNkeyPair();
    const { wire } = await signedAnnouncement(peer);
    const { state } = await wireConnectWithDelivery("$SRV.INFO.agents.default.>", [
      { subject: `$SRV.INFO.agents.default.${peer.publicKey}`, data: enc.encode(wire) },
    ]);

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.roster, arguments: { listen_ms: 400 } });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.listened).toBe(true);
    expect(p.observed).toBe(1);
    expect(p.count).toBe(1);
    const entry = (p.entries as Array<Record<string, unknown>>)[0]!;
    expect(entry.nkey).toBe(peer.publicKey);
    expect(entry.name).toBe("peer-agent");
    expect(entry.online).toBe(true);
    expect(entry.v).toBe(1);
    // The watch subscribed to the segment wildcard and UNSUBSCRIBED after the window.
    expect(state.subs.map((s) => s.subject)).toEqual(["$SRV.INFO.agents.default.>"]);
    expect(state.subs[0]!.unsubscribed).toBe(true);
    expect(state.closed).toBe(true);
    assertNoSecrets(res, creds.seed);
  });

  it("an UNSIGNED announcement is dropped, never projected", async () => {
    await seedIdentity();
    const peer = await generateNkeyPair();
    const unsigned = JSON.stringify({
      ts: new Date().toISOString(),
      name: "faker",
      nkey: peer.publicKey,
      segment: "default",
      capabilities: [],
      online: true,
      model: "",
      sdk_version: "test",
    });
    const { state: _state } = await wireConnectWithDelivery("$SRV.INFO.agents.default.>", [
      { subject: `$SRV.INFO.agents.default.${peer.publicKey}`, data: enc.encode(unsigned) },
    ]);

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.roster, arguments: { listen_ms: 300 } });
    const p = payload(res as never);
    expect(p.observed).toBe(0);
    expect(p.entries).toEqual([]);
    assertNoSecrets(res);
  });

  it("cache survives to a later listen_ms=0 read (same process), then expires by TTL", async () => {
    await seedIdentity(); // the listen path needs stored credentials to dial
    const peer = await generateNkeyPair();
    const { wire } = await signedAnnouncement(peer);
    await wireConnectWithDelivery("$SRV.INFO.agents.default.>", [
      { subject: `$SRV.INFO.agents.default.${peer.publicKey}`, data: enc.encode(wire) },
    ]);

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.roster, arguments: { listen_ms: 400 } });
    expect(payload(res as never).count).toBe(1);

    const res2 = await client.callTool({ name: MCP_TOOLS.roster, arguments: {} });
    const p2 = payload(res2 as never);
    expect(p2.listened).toBe(false);
    expect(p2.count).toBe(1); // cached, no dial

    vi.useFakeTimers();
    try {
      vi.setSystemTime(new Date(Date.now() + 91_000)); // past the 90s TTL
      const res3 = await client.callTool({ name: MCP_TOOLS.roster, arguments: {} });
      expect(payload(res3 as never).count).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });
});

/* ── vclaw_announce_once ─────────────────────────────────────────────── */

describe("vclaw_announce_once", () => {
  it("refuses without a stored identity — never dials, points at onboarding", async () => {
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.announceOnce, arguments: { state: "online" } });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toContain("vclaw_onboard_start");
    const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
    expect(connectViaNKey).not.toHaveBeenCalled();
    assertNoSecrets(res);
  });

  it("publishes ONE signed announcement + ONE heartbeat, then closes", async () => {
    const { kp, creds } = await seedIdentity();
    const { nc, state } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.announceOnce, arguments: { state: "online" } });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.state).toBe("online");
    expect(p.announcement_subject).toBe(`$SRV.INFO.agents.default.${creds.public_key}`);
    expect(p.heartbeat_subject).toBe(`tenant.default.user.${creds.public_key}.agent.${creds.public_key}.hb`);

    expect(state.published).toHaveLength(2);
    expect(state.published[0]!.subject).toBe(`$SRV.INFO.agents.default.${creds.public_key}`);
    const ann = verifyPublishedAnnouncement(state.published[0]!, creds.public_key);
    expect(ann.online).toBe(true);
    expect(ann.nkey).toBe(creds.public_key);

    expect(state.published[1]!.subject).toBe(`tenant.default.user.${creds.public_key}.agent.${creds.public_key}.hb`);
    const hb = JSON.parse(state.published[1]!.data) as Record<string, unknown>;
    expect(hb.status).toBe("online");
    expect(hb.online).toBe(true);

    expect(state.closed).toBe(true); // one-shot: dial → publish ×2 → close
    assertNoSecrets(res, kp.seed);
  });

  it("offline declares online:false in the announcement and status:offline in the heartbeat", async () => {
    const { kp } = await seedIdentity();
    const { nc, state } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.announceOnce, arguments: { state: "offline" } });
    const p = payload(res as never);
    expect(p.state).toBe("offline");
    const ann = verifyPublishedAnnouncement(state.published[0]!, kp.publicKey);
    expect(ann.online).toBe(false);
    const hb = JSON.parse(state.published[1]!.data) as Record<string, unknown>;
    expect(hb.status).toBe("offline");
    expect(hb.online).toBe(false);
    assertNoSecrets(res, kp.seed);
  });

  it("records the declaration — vclaw_presence_status then reports it", async () => {
    const { kp } = await seedIdentity();
    const { nc } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    await client.callTool({ name: MCP_TOOLS.announceOnce, arguments: { state: "away" } });
    const res = await client.callTool({ name: MCP_TOOLS.presenceStatus, arguments: {} });
    const p = payload(res as never);
    expect(p.declared_state).toBe("away");
    const last = p.last_announcement as Record<string, unknown>;
    expect(last.subject).toBe(`$SRV.INFO.agents.default.${kp.publicKey}`);
    expect((last.announcement as Record<string, unknown>).online).toBe(false);
    assertNoSecrets(res, kp.seed);
  });

  it("surfaces a connect failure without leaking the seed", async () => {
    const { kp } = await seedIdentity();
    const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
    vi.mocked(connectViaNKey).mockRejectedValue(new Error(`dial refused leaked ${kp.seed}`));

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.announceOnce, arguments: {} });
    expect(res.isError).toBe(true);
    assertNoSecrets(res, kp.seed); // planted seed must NOT survive redaction
  });
});

/* ── vclaw_a2a_publish ───────────────────────────────────────────────── */

describe("vclaw_a2a_publish", () => {
  it("REFUSES subjects outside the agent namespace and never dials", async () => {
    const { kp } = await seedIdentity();
    const { client } = await harness();
    for (const subject of [
      "$SYS.PING",
      "$KV.vchat_roster.someone",
      "_INBOX.abc",
      "foo.bar",
      `$SRV.INFO.agents.default.${kp.publicKey}.extra`,
      `$SRV.INFO.agents.otherseg.${kp.publicKey}`,
      `tenant.default.a2a.${kp.publicKey}.>`,
      `tenant.eng.a2a.${kp.publicKey}.req`,
      `tenant.default.user.${kp.publicKey}.agent.${kp.publicKey}.>`,
    ]) {
      const res = await client.callTool({ name: MCP_TOOLS.a2aPublish, arguments: { subject, payload: "x" } });
      expect(res.isError, subject).toBe(true);
      // Both refusal texts: namespace violations and wildcard publishes.
      expect(JSON.stringify(res), subject).toMatch(/outside this agent's permitted subjects|wildcard publishes are not valid subjects/);
      assertNoSecrets(res, kp.seed);
    }
    const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
    expect(connectViaNKey).not.toHaveBeenCalled();
  });

  it("publishes to a permitted a2a peer subject with exact payload bytes", async () => {
    const { kp, creds } = await seedIdentity();
    const peer = await generateNkeyPair();
    const { nc, state } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    const subject = `tenant.default.a2a.${peer.publicKey}.req`;
    const res = await client.callTool({ name: MCP_TOOLS.a2aPublish, arguments: { subject, payload: '{"hello":"peer"}' } });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.subject).toBe(subject);
    expect(p.bytes).toBe(16);
    expect(state.published).toEqual([{ subject, data: '{"hello":"peer"}' }]);
    expect(state.closed).toBe(true);
    assertNoSecrets(res, kp.seed, creds.seed);
  });

  it("publishes to the agent's own announcement and heartbeat subjects", async () => {
    const { kp } = await seedIdentity();
    const { nc, state } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    let lastRes: Awaited<ReturnType<typeof client.callTool>> | undefined;
    for (const subject of [
      `$SRV.INFO.agents.default.${kp.publicKey}`,
      `tenant.default.user.${kp.publicKey}.agent.${kp.publicKey}.hb`,
      `tenant.default.user.${kp.publicKey}.agent.${kp.publicKey}.prompt`,
    ]) {
      state.published.length = 0;
      lastRes = await client.callTool({ name: MCP_TOOLS.a2aPublish, arguments: { subject, payload: "p" } });
      expect(lastRes.isError, subject).toBeFalsy();
      expect(state.published[0]!.subject, subject).toBe(subject);
    }
    assertNoSecrets(lastRes, kp.seed);
  });

  it("enforces the payload cap (schema-level)", async () => {
    const { kp } = await seedIdentity();
    const { client } = await harness();
    const res = await client.callTool({
      name: MCP_TOOLS.a2aPublish,
      arguments: { subject: `tenant.default.a2a.${kp.publicKey}`, payload: "x".repeat(262_145) },
    });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toMatch(/-32602|Input validation error/);
  });
});

/* ── vclaw_a2a_subscribe_poll ────────────────────────────────────────── */

describe("vclaw_a2a_subscribe_poll", () => {
  it("REFUSES subjects outside the agent namespace and never dials", async () => {
    const { kp } = await seedIdentity();
    const { client } = await harness();
    for (const subject of [
      "$SYS.>",
      "$JS.API.INFO.>",
      "foo.bar",
      "$SRV.INFO.agents.otherseg.>", // NOT this agent's segment
      `tenant.default.a2a.${"U".repeat(55)}.>`, // someone else's mailbox
    ]) {
      const res = await client.callTool({ name: MCP_TOOLS.a2aSubscribePoll, arguments: { subject, timeout_ms: 100 } });
      expect(res.isError, subject).toBe(true);
      expect(JSON.stringify(res), subject).toContain("outside this agent's permitted subjects");
    }
    const { connectViaNKey } = await import("../../src/agent/lifecycle.js");
    expect(connectViaNKey).not.toHaveBeenCalled();
  });

  it("bounded receive: collects messages on its own mailbox, unsubscribes, closes", async () => {
    const { kp } = await seedIdentity();
    const { nc, state } = fakeNc();
    await wireConnect(nc);
    const mailbox = `tenant.default.a2a.${kp.publicKey}.>`;

    const { client } = await harness();
    const callP = client.callTool({
      name: MCP_TOOLS.a2aSubscribePoll,
      arguments: { subject: mailbox, timeout_ms: 2_000, max_messages: 2 },
    });
    // Deliver after the subscribe lands (poll until the sub exists).
    await vi.waitFor(() => expect(state.subs.length).toBe(1));
    state.deliver({ subject: `tenant.default.a2a.${kp.publicKey}.req`, data: enc.encode('{"a":1}'), reply: "_INBOX.r1" });
    state.deliver({ subject: `tenant.default.a2a.${kp.publicKey}.req`, data: enc.encode('{"a":2}') });
    const res = await callP;

    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.count).toBe(2); // stopped EARLY at max_messages — did not wait the full 2s
    const msgs = p.messages as Array<Record<string, unknown>>;
    expect(msgs[0]!.data).toBe('{"a":1}');
    expect(msgs[0]!.reply).toBe("_INBOX.r1");
    expect(msgs[1]!.data).toBe('{"a":2}');
    expect(state.subs[0]!.unsubscribed).toBe(true);
    expect(state.closed).toBe(true);
    assertNoSecrets(res, kp.seed);
  });

  it("returns zero messages at window end (bounded, no standing sub)", async () => {
    const { kp } = await seedIdentity();
    const { nc, state } = fakeNc();
    await wireConnect(nc);

    const { client } = await harness();
    const t0 = Date.now();
    const res = await client.callTool({
      name: MCP_TOOLS.a2aSubscribePoll,
      arguments: { subject: `$SRV.INFO.agents.default.>`, timeout_ms: 150 },
    });
    expect(Date.now() - t0).toBeLessThan(2_000); // bounded by timeout_ms, not open-ended
    const p = payload(res as never);
    expect(p.count).toBe(0);
    expect(p.messages).toEqual([]);
    expect(state.subs[0]!.unsubscribed).toBe(true);
    expect(state.closed).toBe(true);
    assertNoSecrets(res, kp.seed);
  });

  it("timeout_ms above the 5000 cap is schema-rejected", async () => {
    const { kp } = await seedIdentity();
    const { client } = await harness();
    const res = await client.callTool({
      name: MCP_TOOLS.a2aSubscribePoll,
      arguments: { subject: `$SRV.INFO.agents.default.>`, timeout_ms: 5_001 },
    });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toMatch(/-32602|Input validation error/);
    expect(JSON.stringify(res)).toMatch(/5000/);
  });
});

/* ── subject validators (direct unit sweep — every shape, both scopes) ── */

describe("subject taxonomy validators (direct)", () => {
  const nkey = "U" + "A".repeat(55);

  it("publish scope: own namespace in, everything else out", () => {
    const ok = [
      `$SRV.INFO.agents.default.${nkey}`,
      `tenant.default.user.${nkey}.agent.${nkey}.hb`,
      `tenant.default.user.${nkey}.agent.${nkey}.prompt`,
      `tenant.default.a2a.${nkey}`,
      `tenant.default.a2a.${nkey}.req`,
      `tenant.default.a2a.reply.0192-uuid`,
    ];
    const bad = [
      `$SRV.INFO.agents.default.${nkey}.x`,
      `$SRV.INFO.agents.other.${nkey}`,
      "tenant.default.a2a..req",          // empty token
      `tenant.default.a2a.${nkey}.>`,     // wildcard publish
      `tenant.default.a2a.${nkey}.*`,
      `tenant.default.user.${nkey}.agent.${nkey}.>`,
      "$SYS.>",
      "_INBOX.x",
      "tenant.default.policy.bump",       // granted server-side but NOT in the SDK taxonomy
      `tenant.eng.user.${nkey}.agent.${nkey}.hb`, // wrong segment
    ];
    for (const s of ok) expect(checkPublishSubject(s, "default", nkey), s).toEqual({ ok: true });
    for (const s of bad) expect(checkPublishSubject(s, "default", nkey)?.ok, s).toBe(false);
  });

  it("subscribe scope: own namespace + segment wildcard in, everything else out", () => {
    const ok = [
      "$SRV.INFO.agents.default.>",
      `tenant.default.user.${nkey}.agent.${nkey}.hb`,
      `tenant.default.user.${nkey}.agent.${nkey}.>`,
      `tenant.default.a2a.${nkey}`,
      `tenant.default.a2a.${nkey}.>`,
      `tenant.default.claim.${nkey}`,
    ];
    const bad = [
      "$SRV.INFO.agents.otherseg.>",
      "$SRV.INFO.agents.>",
      `tenant.default.a2a.${nkey}.<bad token>`,
      `tenant.default.a2a.other${"U".repeat(54)}.>`,
      "$SYS.>",
      "$JS.API.INFO.>",
      "foo",
      `tenant.eng.user.${nkey}.agent.${nkey}.>`,
    ];
    for (const s of ok) expect(checkSubscribeSubject(s, "default", nkey), s).toEqual({ ok: true });
    for (const s of bad) expect(checkSubscribeSubject(s, "default", nkey)?.ok, s).toBe(false);
  });
});
