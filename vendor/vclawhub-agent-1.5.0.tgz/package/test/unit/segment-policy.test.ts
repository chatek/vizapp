// J7 — SegmentPolicy schema (vchat_segment_policy KV value, the canonical
// segment registry). Dedicated file to avoid colliding with concurrent
// contracts.test.ts edits (sibling J5 audit work). Mirrors the contracts.test.ts
// TypeBox/Value.Check pattern.
import { describe, it, expect } from "vitest";
import { Value } from "@sinclair/typebox/value";
import { SegmentPolicy } from "../../src/contracts/contracts.js";

const validPolicy = {
  name: "vclaw",
  display_name: "Vclaw",
  jobs: ["collaborate", "search"],
  budget_cap: 1_000_000,
  created_at: "2026-08-06T00:00:00.000Z",
};

describe("SegmentPolicy schema (J7 canonical segment registry)", () => {
  it("accepts a valid policy record", () => {
    expect(Value.Check(SegmentPolicy, validPolicy)).toBe(true);
  });

  it("accepts the minimal record (required fields only)", () => {
    expect(
      Value.Check(SegmentPolicy, {
        name: "default",
        created_at: "2026-08-06T00:00:00.000Z",
      }),
    ).toBe(true);
  });

  it("rejects a missing required field (name / created_at)", () => {
    expect(
      Value.Check(SegmentPolicy, { created_at: "2026-08-06T00:00:00.000Z" }),
    ).toBe(false);
    expect(Value.Check(SegmentPolicy, { name: "default" })).toBe(false);
  });

  it("rejects an empty segment name", () => {
    expect(Value.Check(SegmentPolicy, { ...validPolicy, name: "" })).toBe(false);
  });

  it("rejects a negative budget_cap", () => {
    expect(Value.Check(SegmentPolicy, { ...validPolicy, budget_cap: -1 })).toBe(
      false,
    );
  });

  it("rejects wrong-typed fields", () => {
    expect(
      Value.Check(SegmentPolicy, { ...validPolicy, jobs: "collaborate" }),
    ).toBe(false);
    expect(
      Value.Check(SegmentPolicy, { ...validPolicy, budget_cap: "1000" }),
    ).toBe(false);
  });
});
