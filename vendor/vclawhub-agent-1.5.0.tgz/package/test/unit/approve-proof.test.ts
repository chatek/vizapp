/**
 * I-17 CLIENT HALF — the key-holder proof: acceptance.
 *
 * WHAT THIS FILE IS EVIDENCE ABOUT (stated, so it is not over-read):
 *
 *  - The FROZEN INTEROP VECTOR is the strongest evidence here, and it is not
 *    mine: `TestApproveProofInteropVector` (vgate/internal/agentidp/
 *    i17_writeside_test.go) takes the literal string pinned below and passes it
 *    to the SERVER's `VerifyApproveProof` — against the NKey-pub form AND
 *    against the base64url raw form. When this test passes, the bytes this SDK
 *    mints are byte-identical to the bytes the server's own committed test
 *    asserts its verifier ACCEPTS. That is the server side of the wire.
 *
 *  - The SIGNATURE and the ISSUER FORM are additionally checked here with
 *    `@nats-io/nkeys` (`fromPublic(iss).verify(...)`), the same library family
 *    the Go server calls last (`nkeys.FromPublicKey` → `Verify`), so those two
 *    steps are cross-implementation rather than self-consistent.
 *
 *  - The CLAIM RULES (aud / jti / iss==sub / iat / exp / canonical key binding)
 *    exercised through `checkApproveProofLocally` are a TRANSCRIPTION of
 *    proof.go and therefore agree with the client BY CONSTRUCTION. They are
 *    covered authoritatively by the vector above and by the server's own
 *    negative tests; they are asserted here to distinguish the refusal REASONS,
 *    which nothing else in this repo can show.
 *
 *  - NOT exercised here, and not claimed: the HTTP layer. `403 proof_required`
 *    (approve.go) and the claim-link error page are handler mappings around
 *    `VerifyApproveProof`; this file never runs them. See §"failure modes" for
 *    the exact source lines each message comes from.
 */

import { describe, it, expect } from "vitest";
import { fromPublic, fromSeed } from "@nats-io/nkeys";
import {
  APPROVE_PROOF_AUDIENCE,
  buildApproveProof,
  buildApproveProofForKeypair,
  checkApproveProofLocally,
  claimUrlWithProof,
  decodeApproveProof,
} from "../../src/lib/approve-proof.js";
import { generateNkeyPair } from "../../src/lib/keygen.js";

/* ── the frozen interop vector (vgate/internal/agentidp/i17_writeside_test.go,
 *    TestApproveProofInteropVector — copied verbatim) ─────────────────────── */
const V = {
  // nkeys user seed over the RFC 8032 test seed
  seed: "SUAJ2YNRTXX72WTAXKCEV5ES5QWMIRCJYVUXWMTJDFYDXLADDSXH6YALCA",
  nkeyPub: "UDLVVGABQKYQVN6VJP7NHSLEA45A5YLS6PNKMIZFV4BBU2HXA5IRUVAL",
  // the base64url raw form of the SAME key — the pending record's `nkey` field
  b64raw: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
  nonce: "Jal1B0_JgE9ZBm6aaWFCNu4tNqYbEbfm2fT-nFGYu3Y",
  want:
    "eyJhbGciOiJlZDI1NTE5LW5rZXkiLCJ0eXAiOiJKV1QifQ." +
    "eyJhdWQiOiJ2Y2hhdC1jbGFpbS1hcHByb3ZlIiwiaXNzIjoiVURMVlZHQUJRS1lRVk42VkpQN05IU0xFQTQ1QTVZTFM2UE5LTUlaRlY0QkJVMkhYQTVJUlVWQUwiLCJqdGkiOiJKYWwxQjBfSmdFOVpCbTZhYVdGQ051NHROcVliRWJmbTJmVC1uRkdZdTNZIiwic3ViIjoiVURMVlZHQUJRS1lRVk42VkpQN05IU0xFQTQ1QTVZTFM2UE5LTUlaRlY0QkJVMkhYQTVJUlVWQUwifQ." +
    "L6dA0dcC5OaTr4yAC_t7eyxLBUqjgg5jRYBncGlY6DuZs5ECWfglNYHZ97LOQV59EfLPFKjitI63jLZfPKVkAQ",
};

/** The server's last step, re-run here against the real nkeys library. */
function serverStyleSignatureCheck(proof: string): boolean {
  const [h, p, s] = proof.split(".");
  return fromPublic(decodeApproveProof(proof).iss as string).verify(
    new TextEncoder().encode(`${h}.${p}`),
    Buffer.from(s, "base64url"),
  );
}

describe("I-17 client half — the frozen interop vector", () => {
  it("mints the pinned vector BYTE-FOR-BYTE (the server's own acceptance)", () => {
    const got = buildApproveProof({
      seed: V.seed,
      publicKey: V.nkeyPub,
      challenge: V.nonce,
    });
    expect(got).toBe(V.want);
  });

  it("the minted bytes verify under the nkeys library (independent of our builder)", () => {
    const proof = buildApproveProof({ seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce });
    expect(serverStyleSignatureCheck(proof)).toBe(true);
  });

  it("omits iat/exp by default — the nonce is the freshness control", () => {
    const payload = decodeApproveProof(
      buildApproveProof({ seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce }),
    );
    expect(payload.iat).toBeUndefined();
    expect(payload.exp).toBeUndefined();
    // and both optional claims still pass the rule set when present
    const withExp = buildApproveProof({
      seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce, now: 1_800_000_000, expiresInSeconds: 604_800,
    });
    expect(checkApproveProofLocally(withExp, V.nkeyPub, V.nonce, 1_800_000_001)).toBeNull();
  });
});

describe("I-17 — THE TWO FORMS: two legs in the same run, never one checkbox", () => {
  // THE TWO SHAPES ON THIS WIRE, and why they cannot be one checkbox:
  //   the record's `nkey` (what the client POSTed as `nkey_public`) is the
  //   SDK's base64url raw form — 43 chars, [A-Za-z0-9_-]; the assertion's
  //   issuer must be the U-form — 56 base32 chars. They share no identical
  //   input, they are parsed by DIFFERENT code, and a client that mints the
  //   proof from the value it posted is green on the binding check and DEAD on
  //   the issuer check. Both legs run here, in one run.
  const proof = buildApproveProof({ seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce });

  it("LEG A — record = the form this SDK introduces with (base64url) + iss = U-form: ACCEPTED", () => {
    // onboard.ts posts base64url(rawPublicKey), so THIS is the form live
    // pending records carry (introduce.go stores req.NkeyPublic verbatim).
    const bothSpellings = [V.nkeyPub, V.b64raw]; // what onboard.ts passes
    expect(checkApproveProofLocally(proof, bothSpellings, V.nonce)).toBeNull();
    expect(serverStyleSignatureCheck(proof)).toBe(true);
    // and the server's OWN test asserts the same pinned bytes against the
    // base64url record form: VerifyApproveProof(want, b64raw, nonce) — cited,
    // not re-run here (no vgate build in this lane).
  });

  it("LEG A′ — record = U-form (the other form seen in the wild): ACCEPTED", () => {
    // retire_forms_test.go records both forms existing in live buckets; the
    // proof must not care which one the record holds.
    expect(checkApproveProofLocally(proof, [V.nkeyPub], V.nonce)).toBeNull();
  });

  it("LEG B — iss = the value the client POSTED (the tempting bug): REFUSED, at the issuer step", () => {
    // This is the defect a one-form acceptance hides. Minting over the record's
    // spelling is the obvious thing to write, and it fails the LAST step of the
    // server's verifier even though the binding step passes.
    const wrong = buildApproveProofForTest({
      aud: APPROVE_PROOF_AUDIENCE, iss: V.b64raw, sub: V.b64raw, jti: V.nonce,
    });
    // (1) the library cannot parse it as an issuer — the server's last step
    expect(() => fromPublic(V.b64raw)).toThrow(/invalid encoded key/);
    // (2) so the refusal is the ISSUER one, not the binding one or a bad
    //     signature: the binding check passes for this same proof...
    expect(checkApproveProofLocally(wrong, [V.b64raw], V.nonce)).toMatch(
      /^invalid proof issuer NKey: /,
    );
    // (3) ...while the same payload signed over the U-form is accepted.
    expect(checkApproveProofLocally(proof, [V.b64raw, V.nkeyPub], V.nonce)).toBeNull();
  });

  it("the membership check is a conservative FALSE-REFUSAL, never a false accept (documented limit)", () => {
    // checkApproveProofLocally cannot canonicalize (no nkey codec in the SDK —
    // see its docstring), so ONE spelling is not enough: given only the record's
    // form it refuses a proof the server would accept. Fail-closed and stated,
    // which is why onboard.ts passes both spellings.
    expect(checkApproveProofLocally(proof, [V.b64raw], V.nonce)).toBe(
      "proof is for a different key than the pending record",
    );
  });
});

/** Mint an arbitrary payload (test-only) so a WRONG issuer can be produced. */
function buildApproveProofForTest(payload: Record<string, unknown>): string {
  const b64 = (d: string | Uint8Array) =>
    (typeof d === "string" ? Buffer.from(d, "utf8") : Buffer.from(d)).toString("base64url");
  const head = b64(JSON.stringify({ alg: "ed25519-nkey", typ: "JWT" }));
  const body = b64(JSON.stringify(payload));
  const sig = fromSeed(new TextEncoder().encode(V.seed)).sign(
    new TextEncoder().encode(`${head}.${body}`),
  );
  return `${head}.${body}.${b64(sig)}`;
}

describe("I-17 — the failure modes are DISTINGUISHED, never merged", () => {
  // Each expectation quotes the reason string the server produces (proof.go),
  // so a reason that drifts shows up here as a diff rather than as an
  // indistinguishable 403 at runtime.
  const proof = buildApproveProof({ seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce });

  it("no proof sent → 'proof is required' (the 403 proof_required path, approve.go:382)", () => {
    expect(checkApproveProofLocally("", V.nkeyPub, V.nonce)).toBe("proof is required");
  });

  it("a record with NO approve_nonce is UNPROVABLE and fails closed — before the proof is even parsed", () => {
    // proof.go checks expectedNonce == "" FIRST: an unprovable record refuses
    // even an EMPTY proof with the challenge message, not with 'proof is
    // required'. That ordering is the difference between 'you sent nothing' and
    // 'nobody can ever approve this record'.
    expect(checkApproveProofLocally("", V.nkeyPub, "")).toBe(
      "no approve challenge on the pending record",
    );
    expect(checkApproveProofLocally(proof, V.nkeyPub, "")).toBe(
      "no approve challenge on the pending record",
    );
    // and the builder refuses to mint against an empty challenge at all
    expect(() => buildApproveProof({ seed: V.seed, publicKey: V.nkeyPub, challenge: "" })).toThrow(
      /UNPROVABLE/,
    );
  });

  it("a REFUSED/malformed proof says which refusal it was", () => {
    expect(checkApproveProofLocally("not-a-jwt", V.nkeyPub, V.nonce)).toBe("malformed proof");
    expect(checkApproveProofLocally("a.b", V.nkeyPub, V.nonce)).toBe("malformed proof");
    expect(checkApproveProofLocally("a.!!!!.c", V.nkeyPub, V.nonce)).toMatch(
      /^malformed proof payload/,
    );

    const wrongAud = buildApproveProofForTest({
      aud: "client_assertion", iss: V.nkeyPub, jti: V.nonce, sub: V.nkeyPub,
    });
    expect(checkApproveProofLocally(wrongAud, V.nkeyPub, V.nonce)).toBe(
      `proof audience must be ${JSON.stringify(APPROVE_PROOF_AUDIENCE)}`,
    );

    const wrongJti = buildApproveProofForTest({
      aud: APPROVE_PROOF_AUDIENCE, iss: V.nkeyPub, jti: "another-records-challenge", sub: V.nkeyPub,
    });
    expect(checkApproveProofLocally(wrongJti, V.nkeyPub, V.nonce)).toBe(
      "proof challenge does not match this pending record",
    );

    const issNeSub = buildApproveProofForTest({
      aud: APPROVE_PROOF_AUDIENCE, iss: V.nkeyPub, jti: V.nonce, sub: "someone-else",
    });
    expect(checkApproveProofLocally(issNeSub, V.nkeyPub, V.nonce)).toBe(
      "proof iss/sub must both name the agent key",
    );

    // Flip a signature CHARACTER in the middle: the trailing base64url chars
    // only carry padding bits, so tampering at the end can decode unchanged.
    const parts = proof.split(".");
    const sigChars = parts[2].split("");
    sigChars[1] = sigChars[1] === "A" ? "B" : "A";
    const tampered = [parts[0], parts[1], sigChars.join("")].join(".");
    expect(tampered).not.toBe(proof);
    expect(checkApproveProofLocally(tampered, V.nkeyPub, V.nonce)).toBe(
      "proof signature verification failed",
    );

    const wrongKey = buildApproveProof({
      seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce,
    });
    expect(checkApproveProofLocally(wrongKey, ["U" + "A".repeat(55)], V.nonce)).toBe(
      "proof is for a different key than the pending record",
    );

    const past = buildApproveProof({
      seed: V.seed, publicKey: V.nkeyPub, challenge: V.nonce, now: 1_700_000_000, expiresInSeconds: 60,
    });
    expect(checkApproveProofLocally(past, V.nkeyPub, V.nonce, 1_800_000_000)).toBe("proof expired");
  });

  it("the key-holder proof is bound to ONE challenge — a second record refuses the first's proof", () => {
    const otherChallenge = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    expect(checkApproveProofLocally(proof, V.nkeyPub, otherChallenge)).toBe(
      "proof challenge does not match this pending record",
    );
  });
});

describe("I-17 — the claim URL", () => {
  it("carries the proof as ?proof=<jwt>, url-encoded ('claim.go:282' reads it)", () => {
    const url = claimUrlWithProof("https://login.vclawhub.com", "sess-1", V.want);
    expect(url.startsWith("https://login.vclawhub.com/a/sess-1?proof=")).toBe(true);
    const proofParam = new URL(url).searchParams.get("proof");
    expect(proofParam).toBe(V.want); // decodes back to the exact assertion
    expect(proofParam!.split(".")).toHaveLength(3);
  });

  it("with NO proof it stays a bare URL — the two cases are not the same link", () => {
    expect(claimUrlWithProof("https://login.vclawhub.com", "sess-1")).toBe(
      "https://login.vclawhub.com/a/sess-1",
    );
  });
});

describe("I-17 — a real SDK keypair round-trips (the live client path)", () => {
  it("generateNkeyPair → proof → accepted by the nkeys verifier against the base64url record form", async () => {
    const kp = await generateNkeyPair();
    const b64 = Buffer.from(kp.rawPublicKey).toString("base64url");
    const challenge = Buffer.from(new Uint8Array(32).map((_, i) => i * 7 + 1)).toString("base64url");
    expect(challenge).toHaveLength(43);

    const proof = buildApproveProofForKeypair(kp, challenge);
    expect(decodeApproveProof(proof).jti).toBe(challenge);
    expect(decodeApproveProof(proof).iss).toBe(kp.publicKey);
    expect(serverStyleSignatureCheck(proof)).toBe(true);
    // leg A (record = what this client introduces with, base64url) — the
    // spellings onboard.ts passes — and leg A′ (the U-form record)
    expect(checkApproveProofLocally(proof, [kp.publicKey, b64], challenge)).toBeNull();
    expect(checkApproveProofLocally(proof, [kp.publicKey], challenge)).toBeNull();
    expect(proof).not.toContain(b64); // the record form never appears in the assertion
  });
});
