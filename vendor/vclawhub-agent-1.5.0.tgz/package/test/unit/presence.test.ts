/**
 * presence.test.ts — J3b SDK 0.8.0 startPresence + watchDirectory verification.
 *
 * Covers the J3b VERIFY bar:
 *  - canonical-JSON stability (reuses J0.0 canonicalAnnouncementBytes — the
 *    announce wire's sig verifies against it).
 *  - announce→watch round-trip (a signed announce lands as a verified entry).
 *  - llm set/unset → re-announce (provider-fn model change propagates now).
 *  - online:false on stop (graceful offline).
 *  - drop-unverified (tampered sig never projects).
 */
import { describe, it, expect } from "vitest";
import { nkeys } from "@nats-io/nats-core";
import { startPresence } from "../../src/net/presence.js";
import { watchDirectory, verifyAnnouncement } from "../../src/net/directory.js";
import { canonicalAnnouncementBytes, signAnnouncement } from "../../src/contracts/contracts.js";

// ── mock NATS bus (publish + subscribe with > / * wildcard matching) ──────
function subjectMatches(filter: string, subject: string): boolean {
  const f = filter.split(".");
  const s = subject.split(".");
  let i = 0;
  for (; i < f.length; i++) {
    if (f[i] === ">") return i < s.length; // > = one-or-more trailing tokens
    if (i >= s.length) return false;
    if (f[i] !== "*" && f[i] !== s[i]) return false;
  }
  return i === s.length;
}

function mockBus() {
  const subs: Array<{ filter: string; cb: (subject: string, data: Uint8Array) => void }> = [];
  const published: Array<{ subject: string; data: Uint8Array }> = [];
  const nc = {
    publish(subject: string, data: Uint8Array) {
      published.push({ subject, data });
      for (const s of subs) {
        if (subjectMatches(s.filter, subject)) s.cb(subject, data);
      }
    },
    subscribe(filter: string, opts: { callback: (e: unknown, msg: { subject: string; data: Uint8Array }) => void }) {
      const cb = (subject: string, data: Uint8Array) => opts.callback(null, { subject, data });
      const entry = { filter, cb };
      subs.push(entry);
      return { unsubscribe: () => {
        const i = subs.indexOf(entry);
        if (i >= 0) subs.splice(i, 1);
      }};
    },
  };
  return { nc: nc as never, published };
}

const dec = new TextDecoder();
const decode = (d: Uint8Array) => JSON.parse(dec.decode(d)) as Record<string, unknown>;
// Flush the async announce chain (signAnnouncement dynamic-imports nkeys).
const flush = () => new Promise((r) => setTimeout(r, 15));

// Shared agent keypair (real ed25519 nkey — signs + verifies).
const kp = nkeys.createUser();
const seed = new TextDecoder().decode(kp.getSeed());
const pub = kp.getPublicKey();

describe("startPresence + watchDirectory (J3b)", () => {
  it("announce→watch round-trip: a signed announce lands as a verified directory entry", async () => {
    const bus = mockBus();
    const watch = watchDirectory(bus.nc, "default", {});
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "roundtrip-agent" }, {
      seed,
      segment: "default",
      capabilities: ["code", "search"],
      model: "gpt-4o",
      online: true,
      heartbeat: false, // isolate the announce plane
    });
    await flush();

    const entry = watch.directory.get(pub);
    expect(entry, "verified entry should be projected").toBeDefined();
    expect(entry!.nkey).toBe(pub);
    expect(entry!.segment).toBe("default");
    expect(entry!.name).toBe("roundtrip-agent");
    expect(entry!.capabilities).toEqual(["code", "search"]);
    expect(entry!.online).toBe(true);
    expect(entry!.model).toBe("gpt-4o");
    expect(watch.directory.accepted).toBe(1);
    expect(watch.directory.rejected).toBe(0);

    await presence.stop();
    watch.stop();
  });

  it("canonical-JSON stability: announce sig verifies against J0.0 canonicalAnnouncementBytes", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "canon-agent" }, {
      seed, segment: "default", capabilities: ["code"], model: "gpt-4o", online: true, heartbeat: false,
    });
    await flush();
    await presence.stop();

    const wire = decode(bus.published[0].data);
    const sig = wire.sig as string;
    const { sig: _drop, ...ann } = wire;
    // The sig must verify over the J0.0 canonical bytes (sig excluded).
    const canon = canonicalAnnouncementBytes(ann as never);
    const verifier = nkeys.fromPublic(pub);
    expect(verifier.verify(canon, new Uint8Array(Buffer.from(sig, "base64")))).toBe(true);
    // Canonical field order is the J0.0 contract order.
    expect(Object.keys(JSON.parse(dec.decode(canon)))).toEqual(
      ["ts", "name", "nkey", "segment", "capabilities", "online", "model", "sdk_version"],
    );
  });

  it("llm set/unset → reannounce() publishes the new model immediately (no 30s wait)", async () => {
    const bus = mockBus();
    let model = "gpt-4o";
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "llm-agent" }, {
      seed, segment: "default", model: () => model, heartbeat: false,
    });
    await flush();
    expect(decode(bus.published.at(-1)!.data).model).toBe("gpt-4o");

    model = "claude-sonnet-4"; // `llm set`
    await presence.reannounce();
    await flush();
    expect(decode(bus.published.at(-1)!.data).model).toBe("claude-sonnet-4");

    await presence.stop();
  });

  it("stop() publishes a final online:false announcement (graceful offline)", async () => {
    const bus = mockBus();
    const presence = startPresence(bus.nc, { nkey: pub, nonce: "stop-agent" }, {
      seed, segment: "default", online: true, heartbeat: false,
    });
    await flush();
    expect(decode(bus.published.at(-1)!.data).online).toBe(true);

    await presence.stop();
    await flush();
    expect(decode(bus.published.at(-1)!.data).online).toBe(false);
  });

  it("drops a tampered announcement (bad signature) — never projects", async () => {
    const bus = mockBus();
    const watch = watchDirectory(bus.nc, "default", {});

    // A second agent signs a well-formed announce, then we flip a sig byte.
    const evil = nkeys.createUser();
    const evilPub = evil.getPublicKey();
    const ann = {
      ts: new Date().toISOString(),
      name: "evil-twin",
      nkey: evilPub,
      segment: "default",
      capabilities: [] as string[],
      online: true,
      model: "x",
      sdk_version: "0.8.0",
    };
    const goodSig = await signAnnouncement(ann as never, new TextDecoder().decode(evil.getSeed()));
    const tampered = Buffer.from(goodSig);
    tampered[0] ^= 0xff;
    const wire = { ...ann, sig: tampered.toString("base64") };

    bus.nc.publish(`$SRV.INFO.agents.default.${evilPub}`, new TextEncoder().encode(JSON.stringify(wire)));
    await flush();

    expect(watch.directory.get(evilPub), "tampered announce must NOT project").toBeUndefined();
    expect(watch.directory.rejected).toBe(1);
    expect(watch.directory.stats().rejectCounts.bad_signature).toBe(1);

    watch.stop();
  });

  it("rejects a subject/payload nkey mismatch (anti-spoof, defense-in-depth)", () => {
    const dir = watchDirectory(mockBus().nc, "default", {}).directory;
    // payload says nkey=A, subject says nkey=B → reject without trusting.
    const a = nkeys.createUser().getPublicKey();
    const data = new TextEncoder().encode(JSON.stringify({
      ts: new Date().toISOString(), name: "x", nkey: a, segment: "default",
      capabilities: [], online: true, model: "x", sdk_version: "0.8.0", sig: "",
    }));
    const r = dir.ingest(`$SRV.INFO.agents.default.UB_OTHER`, data);
    expect(r.entry).toBeNull();
    expect(r.reason).toBe("subject_nkey_mismatch");
  });

  it("verifyAnnouncement accepts the startPresence wire format (cross-check)", async () => {
    const bus = mockBus();
    startPresence(bus.nc, { nkey: pub, nonce: "wire-agent" }, {
      seed, segment: "default", capabilities: ["trade"], model: "m", online: false, heartbeat: false,
    });
    await flush();
    const { subject, data } = bus.published[0];
    const r = verifyAnnouncement(subject, data, Date.now());
    expect(r.ok).toBe(true);
    expect(r.entry!.capabilities).toEqual(["trade"]);
    expect(r.entry!.online).toBe(false);
  });
});
