/**
 * p2p-artifacts.test.ts — the M3 artifact surface that needs NO sidecar:
 * the blobRef codec, the ANNOUNCEMENT gate (G3: metadata-only, a few hundred
 * bytes, zero artifact bytes), and the PLANE-OFF gate (G4: putArtifact /
 * getArtifact REFUSE with SidecarUnavailableError pointing at plan §5b.2 —
 * the verb never silently no-ops).
 */
import { describe, it, expect } from "vitest";
import { randomBytes } from "node:crypto";
import {
  putArtifact,
  getArtifact,
  announceArtifact,
  buildArtifactAnnouncement,
  encodeBlobRef,
  decodeBlobRef,
  ArtifactDigestMismatchError,
  ArtifactRefError,
  type ArtifactAnnouncement,
} from "../../src/net/p2p/artifacts.js";
import { SidecarClient, SidecarUnavailableError } from "../../src/net/p2p/client.js";
import type { AgentTransport, TransportMessage, TransportSubscription, TransportSubscribeOptions } from "../../src/net/transport.js";

/** The counting stub (G3): records EVERY byte published through the seam. */
function countingTransport() {
  const publishes: { subject: string; bytes: Uint8Array }[] = [];
  const transport: AgentTransport = {
    publish(subject: string, data: Uint8Array): void {
      publishes.push({ subject, bytes: data });
    },
    subscribe(_subject: string, _opts: TransportSubscribeOptions): TransportSubscription {
      return { unsubscribe(): void {} };
    },
  };
  return {
    transport,
    publishes,
    totalBytes(): number {
      return publishes.reduce((n, p) => n + p.bytes.length, 0);
    },
    payloadText(): string {
      return publishes.map((p) => Buffer.from(p.bytes).toString("utf8")).join("\n");
    },
  };
}

describe("blobRef codec", () => {
  it("round-trips a Hyperblobs-shaped ref byte-for-byte", () => {
    const ref = { blockOffset: 320, blockLength: 305, byteOffset: 20_971_520, byteLength: 20_000_003, sha256: "ab".repeat(32) };
    const encoded = encodeBlobRef(ref);
    expect(decodeBlobRef(encoded)).toEqual(ref);
  });

  it("refuses malformed refs with ArtifactRefError", () => {
    expect(() => decodeBlobRef("not-base64url!!")).toThrow(ArtifactRefError);
    expect(() => decodeBlobRef(Buffer.from(JSON.stringify({ v: 2 })).toString("base64url"))).toThrow(ArtifactRefError);
    const bad = { v: 1, blockOffset: -1, blockLength: 1, byteOffset: 0, byteLength: 10, sha256: "ab".repeat(32) };
    expect(() => decodeBlobRef(Buffer.from(JSON.stringify(bad)).toString("base64url"))).toThrow(ArtifactRefError);
    const noDigest = { v: 1, blockOffset: 0, blockLength: 1, byteOffset: 0, byteLength: 10, sha256: "xyz" };
    expect(() => decodeBlobRef(Buffer.from(JSON.stringify(noDigest)).toString("base64url"))).toThrow(ArtifactRefError);
  });
});

describe("G3 — the announcement is metadata-only (no artifact bytes cross the seam)", () => {
  it("publishes < 1 KB, exactly the five metadata fields, and zero artifact bytes", () => {
    const artifact = randomBytes(20_000_003); // the G1-sized wedge
    const artifactHead = artifact.subarray(0, 4096);
    const ann: ArtifactAnnouncement = {
      delegation: "dlg-artifacts-m3",
      baseKey: randomBytes(32).toString("base64"),
      blobRef: encodeBlobRef({ blockOffset: 0, blockLength: 306, byteOffset: 0, byteLength: artifact.length, sha256: "cd".repeat(32) }),
      size: artifact.length,
      sha256: "cd".repeat(32),
    };
    const hub = countingTransport();
    announceArtifact(hub.transport, "tenant.default.a2a.UAANNOUNCETARGET000000000000000000000000000000000000000000.req", ann);
    expect(hub.publishes).toHaveLength(1);
    const payload = Buffer.from(hub.publishes[0].bytes).toString("utf8");
    // metadata-only: the five fields + type, NOTHING else (no data/blob field)
    const parsed = JSON.parse(payload) as Record<string, unknown>;
    expect(Object.keys(parsed).sort()).toEqual(["baseKey", "blobRef", "delegation", "sha256", "size", "type"].sort());
    // the hub byte cap: the announcement is a few hundred bytes, hard-bound < 1 KB
    expect(hub.publishes[0].bytes.length).toBeLessThan(1024);
    expect(hub.totalBytes()).toBeLessThan(1024);
    // and NO artifact byte transits: the payload contains none of the
    // artifact's first 4 KiB (as raw bytes or base64) — it never could at
    // < 1 KB, but the assertion pins the intent, not the arithmetic.
    expect(payload).not.toContain(Buffer.from(artifactHead).toString("base64").slice(0, 64));
    expect(hub.payloadText()).not.toContain(Buffer.from(artifactHead.subarray(0, 32)).toString("utf8"));
  });

  it("three announcements of one artifact still total < 4 KB on the wire", () => {
    const ann: ArtifactAnnouncement = {
      delegation: "dlg-artifacts-m3",
      baseKey: randomBytes(32).toString("base64"),
      blobRef: encodeBlobRef({ blockOffset: 0, blockLength: 306, byteOffset: 0, byteLength: 20_000_003, sha256: "ee".repeat(32) }),
      size: 20_000_003,
      sha256: "ee".repeat(32),
    };
    const hub = countingTransport();
    for (let i = 0; i < 3; i++) announceArtifact(hub.transport, "tenant.default.a2a.x.req", ann);
    expect(hub.totalBytes()).toBeGreaterThan(0);
    expect(hub.totalBytes()).toBeLessThan(4096);
  });

  it("buildArtifactAnnouncement emits the frozen envelope shape", () => {
    const ann: ArtifactAnnouncement = { delegation: "d", baseKey: "b", blobRef: "r", size: 1, sha256: "a".repeat(32) };
    const parsed = JSON.parse(new TextDecoder().decode(buildArtifactAnnouncement(ann))) as Record<string, unknown>;
    expect(parsed.type).toBe("a2a_artifact");
    expect(parsed.delegation).toBe("d");
  });
});

describe("G4 — plane off: the artifact verbs REFUSE, never silently no-op", () => {
  it("putArtifact without a running sidecar throws SidecarUnavailableError naming plan 5b.2", async () => {
    const client = new SidecarClient(); // never started: the plane is OFF
    const err = await putArtifact(client, "dlg-x", new Uint8Array(10)).then(
      () => null,
      (e: unknown) => e as Error,
    );
    expect(err).toBeInstanceOf(SidecarUnavailableError);
    expect((err as SidecarUnavailableError).code).toBe("E_SIDECAR_UNAVAILABLE");
    expect(err?.message).toContain("5b.2"); // points at the Tier W degradation
    expect(err?.message).toContain("Tier W");
  });

  it("getArtifact without a running sidecar refuses the same way", async () => {
    const client = new SidecarClient();
    const blobRef = encodeBlobRef({ blockOffset: 0, blockLength: 1, byteOffset: 0, byteLength: 8, sha256: "ab".repeat(32) });
    const err = await getArtifact(client, "dlg-x", blobRef).then(
      () => null,
      (e: unknown) => e as Error,
    );
    expect(err).toBeInstanceOf(SidecarUnavailableError);
    expect(err?.message).toContain("5b.2");
  });

  it("a malformed blobRef refuses BEFORE any sidecar IO (ArtifactRefError)", async () => {
    const client = new SidecarClient();
    const err = await getArtifact(client, "dlg-x", "###").then(
      () => null,
      (e: unknown) => e as Error,
    );
    expect(err).toBeInstanceOf(ArtifactRefError);
  });
});

describe("digest refusal is client-side and unconditional (no sidecar needed for the shape)", () => {
  it("ArtifactDigestMismatchError carries the refuse-not-pass-up contract", () => {
    const e = new ArtifactDigestMismatchError("x");
    expect(e.code).toBe("E_ARTIFACT_DIGEST_MISMATCH");
    expect(e.name).toBe("ArtifactDigestMismatchError");
  });
});

// TransportMessage is re-asserted here so the stub above can never drift
// from the seam's frozen runtime shape.
const _shapeCheck: TransportMessage = { subject: "", data: new Uint8Array(0), reply: "" };
void _shapeCheck;
