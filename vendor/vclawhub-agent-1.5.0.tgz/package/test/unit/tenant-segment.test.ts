import { describe, it, expect } from "vitest";
import {
  setTenantSegment,
  SUBJECT_ROOT,
  V2HbSubject,
} from "../../src/contracts/contracts.js";

describe("setTenantSegment (L1 subject-root parameterization; EA-6: bare segment ids)", () => {
  it("defaults to tenant.default for unsegmented agents", () => {
    expect(SUBJECT_ROOT).toBe("tenant.default");
  });

  it("switches the live SUBJECT_ROOT onto tenant.<segment>.* (bare ids)", () => {
    setTenantSegment("vclaw");
    expect(SUBJECT_ROOT).toBe("tenant.vclaw");
    const hb = V2HbSubject.build({ nkey: "NKEY" });
    expect(hb).toBe("tenant.vclaw.user.NKEY.agent.NKEY.hb");
  });

  it("is idempotent: 'default' restores the initial value", () => {
    setTenantSegment("vclaw");
    setTenantSegment("default");
    expect(SUBJECT_ROOT).toBe("tenant.default");
  });

  it("falls back to tenant.default on empty input", () => {
    setTenantSegment("");
    expect(SUBJECT_ROOT).toBe("tenant.default");
    setTenantSegment("  ");
    expect(SUBJECT_ROOT).toBe("tenant.default");
  });

  it("strips whitespace but keeps legal subject-token chars", () => {
    setTenantSegment(" vclaw ");
    expect(SUBJECT_ROOT).toBe("tenant.vclaw");
  });
});
