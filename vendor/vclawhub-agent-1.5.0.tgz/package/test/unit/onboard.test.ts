/**
 * onboard command — claim-wait resume + resumed modeling tests (B11, L1-G4/G6).
 *
 * - pollClaimStatus: fake timers + a mocked VgateClient (status polling every
 *   5s, countdown + claim URL, resolves on claimed, throws past maxPollMs)
 * - waitForClaimWithPolling: falls back to polling when the NATS wait times out
 * - onboard(): resumed:true from introduce-idempotency (F1) is surfaced and
 *   the flow completes via status polling
 * - resumed?: boolean on IntroduceResponse (type modeling)
 */

import { describe, it, expect, vi, beforeEach } from "vitest";
import { fromPublic } from "@nats-io/nkeys";
import { captureConsole } from "../helpers/console.js";
import type { VgateClient as VgateClientType } from "../../src/lib/vgate.js";
import type { NkeyPair } from "../../src/types.js";

// ---------------------------------------------------------------------------
// Mocks — hoisted by vitest before any import
// ---------------------------------------------------------------------------

const mocks = vi.hoisted(() => ({
  // A REAL keypair is installed below (top-level await, via vi.importActual):
  // the I-17 proof cannot be minted with a placeholder seed, and a fake key
  // would make this file agree with itself about the one thing that matters
  // (the assertion's bytes).
  keypair: {
    seed: "SUDUMMYSEED00000000000000000000000000000000000000000000",
    publicKey: "UDUMMYPUBKEY000000000000000000000000000000000000",
    rawSeed: new Uint8Array(32).fill(7),
    rawPublicKey: new Uint8Array(32).fill(1),
    hexPublicKey: "0101010101010101010101010101010101010101010101010101010101010101",
  } as NkeyPair,
  claimTimeoutError: new Error("Claim timed out after 300s"),
}));

// The REAL keygen (bypassing the module mock below) — same code path onboard
// uses in production, so the seed/publicKey/rawPublicKey triple is consistent.
const realKeygen = await vi.importActual<typeof import("../../src/lib/keygen.js")>(
  "../../src/lib/keygen.js",
);
Object.assign(mocks.keypair, await realKeygen.generateNkeyPair());

/** The I-17 challenge the mocked introduce returns (43 base64url chars). */
const APPROVE_CHALLENGE = "Jal1B0_JgE9ZBm6aaWFCNu4tNqYbEbfm2fT-nFGYu3Y";

vi.mock("node:os", () => ({
  homedir: vi.fn(() => "/home/testuser"),
}));
vi.mock("node:fs", () => ({
  writeFileSync: vi.fn(),
  mkdirSync: vi.fn(),
  existsSync: vi.fn(() => false),
}));
vi.mock("../../src/lib/store.js", () => ({
  saveCredentials: vi.fn().mockResolvedValue(undefined),
  loadCredentials: vi.fn().mockResolvedValue(null),
  writePendingFlag: vi.fn().mockResolvedValue(undefined),
  clearPendingFlag: vi.fn().mockResolvedValue(undefined),
  hasPendingFlag: vi.fn().mockReturnValue(false),
  backupCredentials: vi.fn().mockResolvedValue(null),
  credentialDisplayPath: vi.fn(() => "/home/testuser/.pi/agent/credentials.json"),
}));
vi.mock("../../src/lib/keygen.js", () => ({
  generateNkeyPair: vi.fn().mockResolvedValue(mocks.keypair),
  keypairFromSeed: vi.fn().mockResolvedValue(mocks.keypair),
}));
vi.mock("../../src/lib/open-browser.js", () => ({
  openBrowser: vi.fn().mockResolvedValue(undefined),
}));
vi.mock("../../src/lib/vgate.js", () => ({
  VgateClient: vi.fn(),
}));
vi.mock("@nats-io/transport-node", () => ({
  connect: vi.fn().mockRejectedValue(mocks.claimTimeoutError),
}));

// ---------------------------------------------------------------------------
// Module under test (imported after mocks are hoisted)
// ---------------------------------------------------------------------------

import {
  onboard,
  pollClaimStatus,
  waitForClaimWithPolling,
  CLAIM_POLL_INTERVAL_MS,
} from "../../src/commands/onboard.js";
import { VgateClient } from "../../src/lib/vgate.js";
import type { IntroduceResponse } from "../../src/types.js";

const mockedLoadCredentials = vi.mocked((await import("../../src/lib/store.js")).loadCredentials);
const mockedHasPendingFlag = vi.mocked((await import("../../src/lib/store.js")).hasPendingFlag);
const mockedClearPendingFlag = vi.mocked((await import("../../src/lib/store.js")).clearPendingFlag);
const mockedVgateClient = vi.mocked(VgateClient);
const mockedGenerateNkeyPair = vi.mocked((await import("../../src/lib/keygen.js")).generateNkeyPair);

function statusClient(statuses: Array<{ claimed: boolean; steward?: string }>): VgateClientType {
  const getClaimStatus = vi
    .fn()
    .mockImplementation(() => Promise.resolve(statuses.shift() ?? { claimed: false }));
  return { getClaimStatus } as unknown as VgateClientType;
}

beforeEach(() => {
  vi.clearAllMocks();
});

describe("pollClaimStatus", () => {
  it("polls every 5s with a countdown + claim URL and resolves when claimed", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
    const { stdout, restore } = captureConsole();
    const client = statusClient([
      { claimed: false },
      { claimed: false },
      { claimed: true, steward: "boss@example.com" },
    ]);

    const promise = pollClaimStatus(client, "KEY", "https://login.vclawhub.com/a/abc", {
      pollIntervalMs: CLAIM_POLL_INTERVAL_MS,
      maxPollMs: 60_000,
    });

    await vi.advanceTimersByTimeAsync(1);
    expect(client.getClaimStatus).toHaveBeenCalledTimes(1);

    await vi.advanceTimersByTimeAsync(5_000);
    expect(client.getClaimStatus).toHaveBeenCalledTimes(2);

    await vi.advanceTimersByTimeAsync(5_000);
    const result = await promise;

    expect(result.email).toBe("boss@example.com");
    const out = stdout.join("\n");
    expect(out).toContain("https://login.vclawhub.com/a/abc");
    expect(out).toContain("left");
    restore();
    vi.useRealTimers();
  });

  it("throws after maxPollMs and points to the claim URL + resume", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
    const client = statusClient([{ claimed: false }]);

    const promise = pollClaimStatus(client, "KEY", "https://login.vclawhub.com/a/abc", {
      pollIntervalMs: 5_000,
      maxPollMs: 15_000,
    });
    // Attach the handler BEFORE advancing so the rejection is never unhandled.
    const rejection = expect(promise).rejects.toThrow(/re-run with --force/);
    await vi.advanceTimersByTimeAsync(20_000);
    await rejection;
    vi.useRealTimers();
  });
});

describe("waitForClaimWithPolling", () => {
  it("falls back to status polling when the NATS claim wait times out", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
    const client = statusClient([{ claimed: true, steward: "s@example.com" }]);

    const result = await waitForClaimWithPolling(
      "KEY",
      new Uint8Array(32),
      "https://login.vclawhub.com/a/abc",
      client,
    );

    expect(result.email).toBe("s@example.com");
    expect(client.getClaimStatus).toHaveBeenCalledTimes(1);
    vi.useRealTimers();
  });

  it("falls back to status polling on nkeys-class connect errors (1.0.3)", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
    const client = statusClient([{ claimed: true, steward: "nk@example.com" }]);
    const { connect } = await import("@nats-io/transport-node");
    vi.mocked(connect).mockRejectedValueOnce(new Error("nkeys: invalid encoded key"));

    const result = await waitForClaimWithPolling(
      "KEY",
      new Uint8Array(32),
      "https://login.vclawhub.com/a/abc",
      client,
    );

    expect(result.email).toBe("nk@example.com");
    expect(client.getClaimStatus).toHaveBeenCalledTimes(1);
    vi.useRealTimers();
  });

  it("keeps the HTTP poll lane alive when NATS errors are non-recoverable (G1 live 2026-09-07)", async () => {
    // The claim wait is now two concurrent lanes: a NATS error (even a fatal
    // connect error) must NOT kill the HTTP status poll — the poll is what
    // completes onboarding while the vgate daemon account cannot publish the
    // claim event. A claimed status resolves; an exhausted poll window throws
    // with the resume pointer.
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
    const client = statusClient([{ claimed: true, steward: "boss@example.com" }]);
    const { connect } = await import("@nats-io/transport-node");
    vi.mocked(connect).mockRejectedValueOnce(new Error("ECONNREFUSED 127.0.0.1:4223"));

    const promise = waitForClaimWithPolling(
      "KEY",
      new Uint8Array(32),
      "https://login.vclawhub.com/a/abc",
      client,
      { pollIntervalMs: 5_000, maxPollMs: 60_000 },
    );
    await vi.advanceTimersByTimeAsync(1);
    const result = await promise;
    expect(result.email).toBe("boss@example.com");
    expect(client.getClaimStatus).toHaveBeenCalled();
    vi.useRealTimers();
  });
});

describe("onboard() resumed flow (F1 idempotency)", () => {
  it("surfaces 'agent already introduced' and completes via status polling", async () => {
    const { stdout, restore } = captureConsole();
    mockedLoadCredentials.mockResolvedValue(null);
    mockedHasPendingFlag.mockReturnValue(false);
    mockedClearPendingFlag.mockResolvedValue(undefined);
    mockedGenerateNkeyPair.mockResolvedValue(mocks.keypair);

    const client = {
      introduceAgent: vi.fn().mockResolvedValue({
        agent_id: Buffer.from(mocks.keypair.rawPublicKey).toString("base64url"),
        status: "pending",
        session_id: "sess-1",
        resumed: true,
        approve_challenge: APPROVE_CHALLENGE,
      }),
      getClaimStatus: vi.fn().mockResolvedValue({ claimed: true, steward: "boss@example.com" }),
    };
    // Regular function (constructible) so `new VgateClient()` works.
    mockedVgateClient.mockImplementation(function (this: unknown) {
      return client as unknown as VgateClientType;
    });

    await onboard({ noOpen: true });

    const out = stdout.join("\n");
    expect(out).toContain("agent already introduced — waiting for approval (resumed)");
    expect(out).toContain("https://login.vclawhub.com/a/sess-1");
    expect(client.getClaimStatus).toHaveBeenCalled();
    expect(out).toContain("Agent claimed by boss@example.com");
    restore();
  });

  it("I-17 LEG A: the printed claim link carries a proof over the returned challenge", async () => {
    const { stdout, restore } = captureConsole();
    mockedLoadCredentials.mockResolvedValue(null);
    mockedHasPendingFlag.mockReturnValue(false);
    mockedGenerateNkeyPair.mockResolvedValue(mocks.keypair);

    const client = {
      introduceAgent: vi.fn().mockResolvedValue({
        agent_id: Buffer.from(mocks.keypair.rawPublicKey).toString("base64url"),
        status: "pending",
        session_id: "sess-1",
        approve_challenge: APPROVE_CHALLENGE,
      }),
      getClaimStatus: vi.fn().mockResolvedValue({ claimed: true, steward: "boss@example.com" }),
    };
    mockedVgateClient.mockImplementation(function (this: unknown) {
      return client as unknown as VgateClientType;
    });

    await onboard({ noOpen: true });

    const out = stdout.join("\n");
    expect(out).toContain("Key-holder proof minted");
    const line = out.split("\n").find((l) => l.includes("Claim URL: ")) as string;
    const claimUrl = line.slice(line.indexOf("https://"));
    expect(claimUrl.startsWith("https://login.vclawhub.com/a/sess-1?proof=")).toBe(true);

    // The proof is REAL: payload fields exact, signature verified with the
    // nkeys library over the ASCII segments (the server's last step).
    const proof = new URL(claimUrl).searchParams.get("proof") as string;
    const [head, body, sig] = proof.split(".");
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    expect(payload.aud).toBe("vchat-claim-approve");
    expect(payload.jti).toBe(APPROVE_CHALLENGE);
    expect(payload.iss).toBe(mocks.keypair.publicKey);
    expect(payload.sub).toBe(mocks.keypair.publicKey);
    expect(
      fromPublic(payload.iss).verify(
        new TextEncoder().encode(`${head}.${body}`),
        Buffer.from(sig, "base64url"),
      ),
    ).toBe(true);
    // the polling countdown reprints the SAME proof-bearing link (a bare link
    // is refused by claim.go, so a reprint without the proof would be a dead link)
    expect(out).toContain(`Still waiting for approval — ${claimUrl}`);
    restore();
  });

  it("I-17 LEG B: a record with NO challenge is reported UNPROVABLE, and the link carries no proof", async () => {
    const { stdout, stderr, restore } = captureConsole();
    mockedLoadCredentials.mockResolvedValue(null);
    mockedHasPendingFlag.mockReturnValue(false);
    mockedGenerateNkeyPair.mockResolvedValue(mocks.keypair);

    const client = {
      introduceAgent: vi.fn().mockResolvedValue({
        agent_id: Buffer.from(mocks.keypair.rawPublicKey).toString("base64url"),
        status: "pending",
        session_id: "sess-legacy",
      }),
      getClaimStatus: vi.fn().mockResolvedValue({ claimed: true, steward: "boss@example.com" }),
    };
    mockedVgateClient.mockImplementation(function (this: unknown) {
      return client as unknown as VgateClientType;
    });

    await onboard({ noOpen: true });

    const err = stderr.join("\n");
    expect(err).toContain("no approve_challenge");
    expect(err).toContain("UNPROVABLE");
    expect(err).toContain("--force");
    // Two distinct links are two distinct cases — never merged into one string.
    const line = stdout.join("\n").split("\n").find((l) => l.includes("Claim URL: ")) as string;
    const claimUrl = line.slice(line.indexOf("https://"));
    expect(claimUrl).toBe("https://login.vclawhub.com/a/sess-legacy");
    expect(claimUrl).not.toContain("proof=");
    expect(stdout.join("\n")).not.toContain("Key-holder proof minted");
    restore();
  });

  it("refuses to overwrite while a claim is pending without --force", async () => {
    mockedLoadCredentials.mockResolvedValue(null);
    mockedHasPendingFlag.mockReturnValue(true);
    // Make process.exit THROW so execution stops at the guard (a no-op spy
    // would let onboard continue past it).
    const exitSpy = vi
      .spyOn(process, "exit")
      .mockImplementation((() => {
        throw new Error("process.exit");
      }) as never);
    const { stderr, restore } = captureConsole();

    await expect(onboard({ noOpen: true, force: false })).rejects.toThrow("process.exit");

    const err = stderr.join("\n");
    expect(err).toContain("pending");
    expect(exitSpy).toHaveBeenCalledWith(1);
    expect(mockedGenerateNkeyPair).not.toHaveBeenCalled();
    exitSpy.mockRestore();
    restore();
  });
});

describe("onboard() --no-wait: the seed is NEVER printed", () => {
  it("prints claim URL + public key and never the seed (full or prefix); creds still saved", async () => {
    const { stdout, restore } = captureConsole();
    mockedLoadCredentials.mockResolvedValue(null);
    mockedHasPendingFlag.mockReturnValue(false);
    mockedGenerateNkeyPair.mockResolvedValue(mocks.keypair);
    mockedClearPendingFlag.mockResolvedValue(undefined);

    const client = {
      introduceAgent: vi.fn().mockResolvedValue({
        agent_id: Buffer.from(mocks.keypair.rawPublicKey).toString("base64url"),
        status: "pending",
        session_id: "sess-nw",
        approve_challenge: APPROVE_CHALLENGE,
      }),
    };
    mockedVgateClient.mockImplementation(function (this: unknown) {
      return client as unknown as VgateClientType;
    });

    await onboard({ noOpen: true, noWait: true });

    const out = stdout.join("\n");
    // The seed material must not appear — not the full seed, not even the old
    // 8-char prefix hint (stdout is captured in CI/terminal logs).
    expect(out).not.toContain(mocks.keypair.seed);
    expect(out).not.toContain(mocks.keypair.seed.slice(0, 8));
    // The useful bits still print: the proof-bearing claim URL + public key.
    expect(out).toContain("Claim URL: ");
    expect(out).toContain(mocks.keypair.publicKey);
    // The unclaimed credentials (carrying the seed on DISK, not stdout).
    const { saveCredentials } = await import("../../src/lib/store.js");
    expect(vi.mocked(saveCredentials)).toHaveBeenCalled();
    restore();
  });
});

describe("IntroduceResponse resumed typing", () => {
  it("models resumed?: boolean (server F1 idempotency)", () => {
    const resumed: IntroduceResponse = {
      agent_id: "K",
      status: "pending",
      session_id: "S",
      resumed: true,
    };
    expect(resumed.resumed).toBe(true);

    const fresh: IntroduceResponse = { agent_id: "K", status: "pending" };
    expect(fresh.resumed).toBeUndefined();
  });
});
