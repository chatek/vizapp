/**
 * keygen.test.ts — the SDK's NKey material, measured against the REAL codec.
 *
 * WHAT THIS FILE IS ABOUT. `generateNkeyPair()` delegates entirely to
 * `@nats-io/nkeys` — `keygen.ts`'s rule is "never reimplement nkey encoding",
 * after a HISTORY entry that records the exact cost of ignoring it: hand-rolled
 * prefix bytes (0xD0/0xD2), a Crockford alphabet and a wrong seed layout
 * produced non-standard `ST…` seeds that `fromSeed()` REJECTS ("invalid encoded
 * key"), which broke agent-start NATS auth. So the only thing worth asserting
 * here is that what this SDK EMITS is ACCEPTED by the same codec every
 * consumer uses — this file feeds the SDK's own seed/publicKey back into
 * `@nats-io/nkeys` and checks the round trip.
 *
 * WHAT THIS FILE USED TO BE (and why it is now a guard). It carried its own
 * Crockford `base32Encode` + `crc16` + `encodeNkey`, under a heading named
 * "Nkey format encoding", and asserted them against hand-written values. Those
 * blocks passed while measuring NOTHING in production — a private
 * reimplementation compared against its own expected output — and they
 * enshrined the very scheme the production fix exists to remove. A reader
 * seeing "Nkey format encoding: PASSING" would conclude the SDK emits standard
 * nkeys. The reimplementation is now DELETED, and the retired form is pinned as
 * a LITERAL that is asserted REJECTED: a regression that reintroduces it cannot
 * pass this file.
 */

import { describe, it, expect, beforeAll } from "vitest";
import { createPrivateKey, createPublicKey, sign as nodeSign } from "node:crypto";
import { fromSeed, fromPublic } from "@nats-io/nkeys";
import { generateNkeyPair } from "../../src/lib/keygen.js";
import type { NkeyPair } from "../../src/types.js";

const enc = (s: string): Uint8Array => new TextEncoder().encode(s);

/** PKCS#8 prefix for an Ed25519 private key (RFC 8410) — the 32 seed bytes follow. */
const PKCS8_ED25519_PREFIX = "302e020100300506032b657004220420";

/** Rebuild a node:crypto private key from RAW seed bytes (independent of noble/nkeys). */
function privateKeyFromRawSeed(rawSeed: Uint8Array) {
  return createPrivateKey({
    key: Buffer.concat([Buffer.from(PKCS8_ED25519_PREFIX, "hex"), Buffer.from(rawSeed)]),
    format: "der",
    type: "pkcs8",
  });
}

/** The raw 32-byte Ed25519 public key of a node:crypto private key. */
function rawPublicOf(privateKey: ReturnType<typeof createPrivateKey>): Buffer {
  const spki = Buffer.from(createPublicKey(privateKey).export({ type: "spki", format: "der" }));
  return spki.subarray(spki.length - 32);
}

/* ─────────────────────────────────────────────────────────────── *
 * The guard: the RETIRED hand-rolled form is rejected              *
 * ─────────────────────────────────────────────────────────────── */

describe("the RETIRED hand-rolled 'ST…' form is REJECTED by the real codec", () => {
  // Values the DELETED code (crc16 + Crockford base32 + prefix bytes
  // 0xD0/0xD2) produced for an all-zero 32-byte key. They are kept — not
  // because they are correct, but because they are WRONG in a way nothing
  // else in the suite can see. Delete these literals only with the guard.
  const LEGACY_SEED = "ST0000000000000000000000000000000000000000000000000001YEB";
  const LEGACY_PUB = "PT8000000000000000000000000000000000000000000000000001WJJ";

  it("fromSeed() REFUSES the retired 'ST…' seed (the defect keygen.ts's HISTORY records)", () => {
    expect(() => fromSeed(enc(LEGACY_SEED))).toThrow(/invalid encoded key/);
  });

  it("fromPublic() REFUSES the retired 'P…' public key (a user key is 'U…', not 'P…')", () => {
    expect(() => fromPublic(LEGACY_PUB)).toThrow(/invalid encoded key/);
  });

  it("the retired bodies fail the STANDARD base32 alphabet the live keys use (the alphabet guard bites)", () => {
    // The two alphabet assertions on the live keypair would be vacuous if any
    // string passed them. A Crockford body contains 0/1/8/9, which the real
    // alphabet (A-Z2-7) does not — so these two lines are what make those
    // assertions a guard rather than a formality.
    expect(LEGACY_SEED.slice(2)).not.toMatch(/^[A-Z2-7]+$/);
    expect(LEGACY_PUB.slice(1)).not.toMatch(/^[A-Z2-7]+$/);
  });

  it("the retired form is structurally wrong, not merely rejected: 57 chars, no 'SU'/'U' prefix", () => {
    // A real user seed is 58 chars ('SU' + 56); a real user public is 56 ('U' + 55).
    expect(LEGACY_SEED).toHaveLength(57);
    expect(LEGACY_PUB).toHaveLength(57);
    expect(LEGACY_SEED.startsWith("SU")).toBe(false);
    expect(LEGACY_PUB.startsWith("U")).toBe(false);
  });
});

/* ─────────────────────────────────────────────────────────────── *
 * generateNkeyPair() — what the SDK emits, accepted by the codec   *
 * ─────────────────────────────────────────────────────────────── */

describe("generateNkeyPair()", () => {
  let pair: NkeyPair;

  beforeAll(async () => {
    pair = await generateNkeyPair();
  });

  /* ── the round trip: the REAL codec accepts both halves ──── */

  describe("accepted by @nats-io/nkeys (what generateNkeyPair delegates to)", () => {
    it("fromSeed(seed) parses and yields the SAME publicKey (the keypair is coherent)", () => {
      const kp = fromSeed(enc(pair.seed));
      expect(kp.getPublicKey()).toBe(pair.publicKey);
    });

    it("fromSeed(seed) yields the SAME rawSeed bytes the SDK reports", () => {
      const kp = fromSeed(enc(pair.seed)) as unknown as { getRawSeed(): Uint8Array };
      expect(Buffer.from(kp.getRawSeed()).toString("hex")).toBe(
        Buffer.from(pair.rawSeed).toString("hex"),
      );
    });

    it("fromPublic(publicKey) parses (a user key: 'U' + 55 base32 chars)", () => {
      expect(fromPublic(pair.publicKey).getPublicKey()).toBe(pair.publicKey);
    });

    it("node:crypto — not the SDK's own code — derives the SAME raw public key from rawSeed", () => {
      // Independent derivation: build the Ed25519 key from the 32 raw seed bytes
      // with node:crypto and compare the public halves. This is what makes
      // "rawPublicKey belongs to rawSeed" a measurement rather than a tautology.
      const rawPub = rawPublicOf(privateKeyFromRawSeed(pair.rawSeed));
      expect(rawPub.toString("hex")).toBe(pair.hexPublicKey);
      expect(Buffer.from(pair.rawPublicKey).toString("hex")).toBe(pair.hexPublicKey);
    });

    it("a signature made from the SEED verifies under the PUBLIC key the SDK publishes", () => {
      // The property the I-17 key-holder proof depends on: the agent can prove
      // possession of the key it introduces. Checked with node:crypto signing and
      // the real nkeys verifier.
      const msg = enc("i17-keygen-roundtrip");
      const sig = nodeSign(null, Buffer.from(msg), privateKeyFromRawSeed(pair.rawSeed));
      expect(fromPublic(pair.publicKey).verify(msg, sig)).toBe(true);
    });
  });

  describe("return type shape", () => {
    it("returns an object with the correct keys", () => {
      expect(pair).toBeInstanceOf(Object);
      expect(pair).toHaveProperty("seed");
      expect(pair).toHaveProperty("publicKey");
      expect(pair).toHaveProperty("rawSeed");
      expect(pair).toHaveProperty("rawPublicKey");
      expect(pair).toHaveProperty("hexPublicKey");
    });
  });

  describe("seed", () => {
    it("starts with 'S'", () => {
      expect(pair.seed.startsWith("S")).toBe(true);
    });

    it("is 58 characters long (standard NATS user seed)", () => {
      expect(pair.seed.length).toBe(58);
    });

    it("uses the STANDARD nkeys base32 alphabet after 'SU' — no Crockford chars", () => {
      // The retired hand-rolled codec used Crockford base32 (0-9a-z minus
      // i/l/o/u), whose output contains 0/1/8/9. The real alphabet is A-Z2-7:
      // this assertion fails for ANY Crockford-encoded value.
      expect(pair.seed.slice(2)).toMatch(/^[A-Z2-7]+$/);
    });

    it("is a string", () => {
      expect(typeof pair.seed).toBe("string");
    });
  });

  describe("publicKey", () => {
    it("starts with 'U' (standard NATS user public)", () => {
      expect(pair.publicKey.startsWith("U")).toBe(true);
    });

    it("is 56 characters long", () => {
      expect(pair.publicKey.length).toBe(56);
    });

    it("uses the standard nkeys base32 alphabet after 'U' — no Crockford chars", () => {
      expect(pair.publicKey.slice(1)).toMatch(/^[A-Z2-7]+$/);
    });

    it("is a string", () => {
      expect(typeof pair.publicKey).toBe("string");
    });

    it("differs from the seed string", () => {
      expect(pair.publicKey).not.toBe(pair.seed);
    });
  });

  describe("rawSeed", () => {
    it("is a Uint8Array", () => {
      expect(pair.rawSeed).toBeInstanceOf(Uint8Array);
    });

    it("is exactly 32 bytes", () => {
      expect(pair.rawSeed.length).toBe(32);
    });

    it("contains non-zero bytes (cryptographically random)", () => {
      // It's astronomically unlikely that all 32 bytes are zero
      const allZero = pair.rawSeed.every((b) => b === 0);
      expect(allZero).toBe(false);
    });
  });

  describe("rawPublicKey", () => {
    it("is a Uint8Array", () => {
      expect(pair.rawPublicKey).toBeInstanceOf(Uint8Array);
    });

    it("is exactly 32 bytes", () => {
      expect(pair.rawPublicKey.length).toBe(32);
    });

    it("contains non-zero bytes", () => {
      const allZero = pair.rawPublicKey.every((b) => b === 0);
      expect(allZero).toBe(false);
    });

    it("is derived from rawSeed (ED25519 keypair consistency)", () => {
      // If we re-derive the public key from the seed, we should
      // get the same rawPublicKey bytes. We verify by checking
      // that the hex encodings match.
      expect(pair.hexPublicKey).toBe(
        Array.from(pair.rawPublicKey)
          .map((b) => b.toString(16).padStart(2, "0"))
          .join(""),
      );
    });
  });

  describe("hexPublicKey", () => {
    it("is a string", () => {
      expect(typeof pair.hexPublicKey).toBe("string");
    });

    it("is exactly 64 hex characters (32 bytes)", () => {
      expect(pair.hexPublicKey.length).toBe(64);
    });

    it("contains only valid lowercase hex characters", () => {
      expect(pair.hexPublicKey).toMatch(/^[0-9a-f]{64}$/);
    });

    it("matches the hex encoding of rawPublicKey", () => {
      const expected = Buffer.from(pair.rawPublicKey).toString("hex");
      expect(pair.hexPublicKey).toBe(expected);
    });
  });

  describe("Nkey format round-trip consistency", () => {
    it("seed and publicKey are correlated (same keypair)", () => {
      // Standard NATS user nkeys: seed = 58 chars ('SU' prefix), pub = 56 ('U').
      expect(pair.seed.length).toBe(58);
      expect(pair.publicKey.length).toBe(56);
    });
  });

  describe("determinism and uniqueness", () => {
    it("generates unique keypairs on successive calls", async () => {
      const pair2 = await generateNkeyPair();
      expect(pair2.seed).not.toBe(pair.seed);
      expect(pair2.publicKey).not.toBe(pair.publicKey);
      expect(pair2.hexPublicKey).not.toBe(pair.hexPublicKey);
    });

    it("generates three keypairs that are all distinct", async () => {
      const [a, b, c] = await Promise.all([
        generateNkeyPair(),
        generateNkeyPair(),
        generateNkeyPair(),
      ]);
      const seeds = [a.seed, b.seed, c.seed];
      const pubs = [a.publicKey, b.publicKey, c.publicKey];
      expect(new Set(seeds).size).toBe(3);
      expect(new Set(pubs).size).toBe(3);
    });

    it("every generated keypair round-trips through the real codec", async () => {
      const [a, b] = await Promise.all([generateNkeyPair(), generateNkeyPair()]);
      for (const p of [a, b]) {
        expect(fromSeed(enc(p.seed)).getPublicKey()).toBe(p.publicKey);
      }
    });
  });
});
