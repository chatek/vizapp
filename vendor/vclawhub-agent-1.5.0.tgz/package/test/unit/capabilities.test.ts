/**
 * capabilities.test.ts — OnlineGate (vchat_capabilities KV gate)
 *
 * Verifies: KV read → online state; 30s cache honored; env fallback when
 * the KV record is absent; isOnlineNow bypasses the cache.
 */

import { describe, expect, it, vi } from "vitest";
import { OnlineGate } from "../../src/net/capabilities.js";
import type { CapabilitiesEntry } from "../../src/contracts/contracts.js";

// ── Fake NATS + Kvm ───────────────────────────────────────────
// We don't want a real NATS server; OnlineGate only needs Kvm.open()
// + bucket.get(). Stub the @nats-io/kv Kvm class via a mock NatsConnection
// whose `new Kvm(nc)` returns our fake bucket.
const encoder = new TextEncoder();

function fakeBucket(records: Record<string, CapabilitiesEntry>) {
  return {
    get: vi.fn(async (key: string) => {
      const rec = records[key];
      if (!rec) return null;
      return { value: encoder.encode(JSON.stringify(rec)) };
    }),
  };
}

function makeGate(
  records: Record<string, CapabilitiesEntry>,
  nkey = "UAGENT123",
  opts: { cacheMs?: number; envFallback?: () => boolean } = {},
) {
  const bucket = fakeBucket(records);
  const fakeNc = {
    // Kvm(nc) ignores the connection for our stub; we inject via a custom
    // property the OnlineGate doesn't touch — but OnlineGate constructs
    // `new Kvm(this.nc)`. To keep the test hermetic we spy on the module
    // boundary instead: monkey-patch globalThis.Kvm? No — OnlineGate
    // imports Kvm directly. So we run against the REAL Kvm with a fake
    // connection that throws unless opened. Instead, we test the gate's
    // logic by stubbing its read() method via a subclass.
  };
  void fakeNc;
  void bucket;
  return opts;
}

// Since OnlineGate instantiates `new Kvm(nc)` internally, the cleanest
// hermetic test is to subclass and stub `read()` — the cache/fallback
// logic lives in isOnline/isOnlineNow, not in read().
class StubGate extends OnlineGate {
  constructor(
    private records: Record<string, CapabilitiesEntry | null>,
    opts: { cacheMs?: number; envFallback?: () => boolean } = {},
  ) {
    super({} as never, "UAGENT123", opts);
  }
  override async read(): Promise<CapabilitiesEntry | null> {
    return this.records["UAGENT123"] ?? null;
  }
}

describe("OnlineGate", () => {
  it("returns the KV online field when present", async () => {
    const g = new StubGate({ UAGENT123: { online: true } });
    expect(await g.isOnline()).toBe(true);
  });

  it("honors online:false from KV", async () => {
    const g = new StubGate({ UAGENT123: { online: false } });
    expect(await g.isOnline()).toBe(false);
  });

  it("falls back to the env gate when the KV record is absent", async () => {
    const g = new StubGate({ UAGENT123: null }, { envFallback: () => true });
    expect(await g.isOnline()).toBe(true);
  });

  it("caches within the TTL (read called once)", async () => {
    let reads = 0;
    class CountingGate extends OnlineGate {
      override async read(): Promise<CapabilitiesEntry | null> {
        reads += 1;
        return { online: false };
      }
    }
    const g = new CountingGate({} as never, "UAGENT123", { cacheMs: 30_000 });
    await g.isOnline();
    await g.isOnline();
    expect(reads).toBe(1);
  });

  it("re-reads after the cache TTL expires", async () => {
    let reads = 0;
    class CountingGate extends OnlineGate {
      override async read(): Promise<CapabilitiesEntry | null> {
        reads += 1;
        return { online: false };
      }
    }
    const g = new CountingGate({} as never, "UAGENT123", { cacheMs: 5 });
    await g.isOnline();
    // Fake the clock: wait past the 5ms TTL.
    await new Promise((r) => setTimeout(r, 10));
    await g.isOnline();
    expect(reads).toBe(2);
  });

  it("isOnlineNow forces a fresh read (bypasses cache)", async () => {
    let reads = 0;
    class FlipGate extends OnlineGate {
      override async read(): Promise<CapabilitiesEntry | null> {
        reads += 1;
        return { online: reads >= 2 };
      }
    }
    const g = new FlipGate({} as never, "UAGENT123", { cacheMs: 60_000 });
    expect(await g.isOnlineNow()).toBe(false); // read 1
    expect(await g.isOnlineNow()).toBe(true); // read 2 — fresh
    expect(reads).toBe(2);
  });
});
