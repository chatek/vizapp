/**
 * p2p-dht-options.test.ts — the M4 firewall-posture flags on the boot network
 * config (PROTOCOL.md §7, sidecar/src/dht.ts — imported directly: no sidecar
 * process, no live network. The unit under test is EXACTLY the options object
 * the boot hands to the DHT constructor, so asserting it pins the constructed
 * options without opening a socket).
 *
 * MEASURED ROOT CAUSE (dht-matrix lane, 2026-10-27 —
 * .prime/handoff/pears-assessment/dht-matrix/FINDINGS.md): against a CO-LOCATED
 * private seed, dht-rpc's NAT/firewall check never completes, so a default peer
 * stays ephemeral+firewalled — hollow dials (ETIMEDOUT ~13s) and cross-host 0/6.
 * A fleet sets ephemeral:false / firewalled:false to declare "reachable on
 * bindHost"; the default (absent) stays the upstream lifecycle.
 */
import { describe, it, expect } from "vitest";
import { resolveDhtOptions, seedDhtOptions } from "../../src/net/p2p/sidecar/src/dht.js";

const SEED = { host: "10.0.2.5", port: 47850 };
const BIND = "10.0.2.67";

describe("resolveDhtOptions (peer branch — new DHT)", () => {
  it("carries an explicit ephemeral:false / firewalled:false fleet declaration into the constructed options", () => {
    expect(resolveDhtOptions({ bootstrap: [SEED], ephemeral: false, firewalled: false }, BIND)).toEqual({
      bootstrap: [SEED],
      host: BIND,
      ephemeral: false,
      firewalled: false,
    });
  });

  it("defaults BOTH flags to true — upstream behavior preserved when the fleet says nothing", () => {
    expect(resolveDhtOptions({ bootstrap: [SEED] }, BIND)).toEqual({
      bootstrap: [SEED],
      host: BIND,
      ephemeral: true,
      firewalled: true,
    });
    expect(resolveDhtOptions({}, BIND)).toEqual({ bootstrap: [], host: BIND, ephemeral: true, firewalled: true });
  });

  it("normalizes an empty bootstrap list to [] — hyperdht would otherwise fall back to the PUBLIC bootstrap nodes", () => {
    expect(resolveDhtOptions({ bootstrap: [] }, BIND).bootstrap).toEqual([]);
  });

  it("passes an explicit true through too — the declaration works in both directions", () => {
    expect(resolveDhtOptions({ ephemeral: true, firewalled: true }, BIND)).toMatchObject({
      ephemeral: true,
      firewalled: true,
    });
  });
});

describe("seedDhtOptions (seed branch — DHT.bootstrapper)", () => {
  it("forwards an explicit fleet declaration to the bootstrapper options", () => {
    expect(seedDhtOptions({ ephemeral: false, firewalled: false }, BIND)).toEqual({
      host: BIND,
      ephemeral: false,
      firewalled: false,
    });
  });

  // dht-rpc bootstrapper() constructs the seed ephemeral:false/firewalled:false BEFORE
  // spreading caller opts — the resolved default true must never reach it.
  it("forwards NOTHING when the flags are absent — the bootstrapper keeps its upstream seed posture", () => {
    const opts = seedDhtOptions({}, BIND);
    expect(opts).toEqual({ host: BIND });
    expect("ephemeral" in opts).toBe(false);
    expect("firewalled" in opts).toBe(false);
  });
});
