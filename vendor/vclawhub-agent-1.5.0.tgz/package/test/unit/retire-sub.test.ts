/**
 * J16b — CLI retire control subscriber tests (src/net/retire.ts).
 *
 * Mirrors the W4 lane-B layer of ext-retire.test.ts but standalone: the
 * module under test only touches contracts (real import — setTenantSegment
 * pins the LIVE segment) + a capturing fake NatsConnection. The retire
 * subject mock uses the live-segment form "tenant.<seg>.agent.retired.<nkey>".
 *
 * Contract asserted (doc 19 B.2 / AGENT_RETIRE §4):
 *   - exact own-nkey subject on the LIVE switched segment
 *   - receipt is TERMINAL (one-shot): first delivery fires the handler once
 *     and unsubscribes; a duplicate delivery is ignored
 *   - malformed/empty payload does NOT suppress the terminal path (subject
 *     is authoritative) — handler gets {}
 *   - handler errors are isolated (never rethrown into the sub callback)
 */
import { describe, it, expect, beforeEach, vi } from "vitest";
import { setTenantSegment } from "../../src/contracts/contracts.js";
import {
  subRetired,
  retireSubjectV2,
  type RetiredNotice,
} from "../../src/net/retire.js";
import type { NatsConnection, Subscription } from "@nats-io/nats-core";

const NKEY = "UAARETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRETIREDRET";

interface Captured {
  subject: string;
  deliver: (data: Uint8Array) => void;
  sub: Subscription;
}

function fakeNc(): { nc: NatsConnection; captured: Captured[] } {
  const captured: Captured[] = [];
  const nc = {
    subscribe(subject: string, opts: { callback: (e: unknown, m: unknown) => void }) {
      const unsubscribe = vi.fn();
      const sub = { unsubscribe, closed: Promise.resolve(), drain: async () => {} } as unknown as Subscription;
      captured.push({
        subject,
        sub,
        deliver: (data: Uint8Array) =>
          opts.callback(null, { subject, data, reply: "" }),
      });
      return sub;
    },
  } as unknown as NatsConnection;
  return { nc, captured };
}

beforeEach(() => {
  setTenantSegment("vchat"); // pin the LIVE segment (prod runtime switches before subs)
});

describe("retireSubjectV2", () => {
  it("builds the exact own-nkey subject on the live segment", () => {
    expect(retireSubjectV2(NKEY)).toBe(`tenant.vchat.agent.retired.${NKEY}`);
  });

  it("follows setTenantSegment (live binding, not baked at import)", () => {
    setTenantSegment("seg42");
    expect(retireSubjectV2(NKEY)).toBe(`tenant.seg42.agent.retired.${NKEY}`);
  });
});

describe("subRetired", () => {
  it("subscribes the exact own-nkey subject", () => {
    const { nc, captured } = fakeNc();
    subRetired(nc, { nkey: NKEY }, () => {});
    expect(captured).toHaveLength(1);
    expect(captured[0].subject).toBe(`tenant.vchat.agent.retired.${NKEY}`);
  });

  it("first delivery fires the handler with the parsed notice, then unsubscribes", () => {
    const { nc, captured } = fakeNc();
    const onRetired = vi.fn<(n: RetiredNotice) => void>();
    subRetired(nc, { nkey: NKEY }, onRetired);
    captured[0].deliver(new TextEncoder().encode(
      JSON.stringify({ retired_at: "2026-09-16T00:00:00Z", reason: "ci validation", steward: "ops@vchat.email", chatto_user_id: "u1" }),
    ));
    expect(onRetired).toHaveBeenCalledTimes(1);
    expect(onRetired).toHaveBeenCalledWith({
      retired_at: "2026-09-16T00:00:00Z",
      reason: "ci validation",
      steward: "ops@vchat.email",
      chatto_user_id: "u1",
    });
    expect(captured[0].sub.unsubscribe).toHaveBeenCalledTimes(1);
  });

  it("is one-shot: a duplicate delivery does not re-fire the handler", () => {
    const { nc, captured } = fakeNc();
    const onRetired = vi.fn<(n: RetiredNotice) => void>();
    subRetired(nc, { nkey: NKEY }, onRetired);
    captured[0].deliver(new TextEncoder().encode(JSON.stringify({ reason: "first" })));
    captured[0].deliver(new TextEncoder().encode(JSON.stringify({ reason: "second" })));
    expect(onRetired).toHaveBeenCalledTimes(1);
    expect(onRetired.mock.calls[0][0].reason).toBe("first");
  });

  it("malformed payload still fires — handler gets {} (subject is authoritative)", () => {
    const { nc, captured } = fakeNc();
    const onRetired = vi.fn<(n: RetiredNotice) => void>();
    subRetired(nc, { nkey: NKEY }, onRetired);
    captured[0].deliver(new TextEncoder().encode("not-json{"));
    expect(onRetired).toHaveBeenCalledWith({});
  });

  it("empty payload still fires — handler gets {}", () => {
    const { nc, captured } = fakeNc();
    const onRetired = vi.fn<(n: RetiredNotice) => void>();
    subRetired(nc, { nkey: NKEY }, onRetired);
    captured[0].deliver(new Uint8Array(0));
    expect(onRetired).toHaveBeenCalledWith({});
  });

  it("handler throw is isolated — never rethrown into the sub callback", () => {
    const { nc, captured } = fakeNc();
    subRetired(nc, { nkey: NKEY }, () => { throw new Error("handler bug"); });
    expect(() => captured[0].deliver(new TextEncoder().encode("{}"))).not.toThrow();
  });

  it("async handler rejection is isolated too", async () => {
    const { nc, captured } = fakeNc();
    subRetired(nc, { nkey: NKEY }, async () => { throw new Error("async bug"); });
    expect(() => captured[0].deliver(new TextEncoder().encode("{}"))).not.toThrow();
    // let the microtask queue drain the rejection-catch before the test ends
    await new Promise((r) => setTimeout(r, 0));
  });
});
