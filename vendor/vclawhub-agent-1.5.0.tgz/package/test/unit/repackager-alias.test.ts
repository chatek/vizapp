/**
 * J15 — alias protocol legality (ADD → FLIP → SOAK → DROP).
 */
import { describe, it, expect } from "vitest";
import { applyAliasOp, type AliasState } from "../../skills/incus-repackager/src/alias.js";

const NOW = "2026-09-16T12:00:00.000Z";
const EARLIER = "2026-09-14T12:00:00.000Z";

const base: AliasState = {
  versions: ["0.9.3", "0.9.4"],
  stable: "0.9.3",
  stablePrev: "0.9.2",
  addedAt: { "0.9.2": EARLIER, "0.9.3": EARLIER, "0.9.4": EARLIER },
};

describe("alias state machine", () => {
  it("ADD: new version ok; duplicate refused", () => {
    expect(applyAliasOp(base, { op: "add", ver: "0.9.5", now: NOW }).ok).toBe(true);
    expect(applyAliasOp(base, { op: "add", ver: "0.9.4", now: NOW }).ok).toBe(false);
  });

  it("FLIP without --operator-go is REFUSED (operator-gated)", () => {
    const r = applyAliasOp(base, { op: "flip", ver: "0.9.4", operatorGo: false, now: NOW });
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/operator-gated/);
  });

  it("FLIP with go: :stable → new, :stable-prev → old stable (rollback target)", () => {
    const r = applyAliasOp(base, { op: "flip", ver: "0.9.4", operatorGo: true, now: NOW });
    expect(r.ok).toBe(true);
    expect(r.next?.stable).toBe("0.9.4");
    expect(r.next?.stablePrev).toBe("0.9.3");
  });

  it("DROP of :stable itself is refused", () => {
    expect(applyAliasOp(base, { op: "drop", ver: "0.9.3", operatorGo: true, now: NOW }).ok).toBe(false);
  });

  it("DROP of :stable-prev is REFUSED — rollback target, never dropped early", () => {
    const r = applyAliasOp(base, { op: "drop", ver: "0.9.2", operatorGo: true, now: NOW });
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/stable-prev/);
  });

  it("DROP before the soak window is refused; after it, allowed", () => {
    const freshAdded = { ...base, addedAt: { ...base.addedAt, "0.9.4": NOW } };
    const tooSoon = applyAliasOp(freshAdded, { op: "drop", ver: "0.9.4", operatorGo: true, now: NOW });
    expect(tooSoon.ok).toBe(false);
    expect(tooSoon.reason).toMatch(/soak/);
    const soaked = applyAliasOp(base, { op: "drop", ver: "0.9.4", operatorGo: true, now: NOW }); // added 2d ago
    expect(soaked.ok).toBe(true);
  });

  it("DROP without --operator-go is refused", () => {
    expect(applyAliasOp(base, { op: "drop", ver: "0.9.4", operatorGo: false, now: NOW }).ok).toBe(false);
  });
});
