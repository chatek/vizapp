/**
 * update.test.ts — the `update` command (L1: update was DETECT-ONLY).
 *
 * Network fake: a REAL local HTTP server (node:http on 127.0.0.1:0) serving a
 * fixture bundle + .sha256 sidecar, in the shape the CDN actually serves
 * ("<hex>  agent.js\n" — sha256sum format, trailing newline). This exercises
 * the actual fetch path (no stubbed globals), mirroring the network-fake
 * intent of token-refresh.test.ts but with real sockets, because update's
 * contract is byte transport, not retry policy.
 *
 * The refusal cases are the point: a WRONG digest must never write (a
 * pre-existing bundle must survive), and checkOnly must never write. The good
 * case must write ATOMICALLY (no tmp leftovers) with the executable bit the
 * join pipe installs.
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from "vitest";
import { createServer, type Server } from "node:http";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, readdir, writeFile } from "node:fs/promises";
import { existsSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { updateBundle, parseSha256Sidecar, resolveBundleUrl } from "../../src/commands/update.js";

const BUNDLE_FIXTURE = `#!/usr/bin/env bun\n// fixture agent.js — stands in for the single-file bundled CLI\nconsole.log("vfixture");\n`;
const BUNDLE_BYTES = new TextEncoder().encode(BUNDLE_FIXTURE);
const GOOD_SHA = createHash("sha256").update(BUNDLE_BYTES).digest("hex");
const WRONG_SHA = createHash("sha256").update("tampered").digest("hex");

let server: Server;
let base = "";
let hits: string[] = [];

beforeAll(async () => {
  server = createServer((req, res) => {
    const url = req.url ?? "";
    hits.push(url);
    if (url === "/agent.js" || url === "/refuse.js" || url === "/empty.js") {
      res.writeHead(200, { "Content-Type": "application/javascript" });
      res.end(BUNDLE_BYTES);
    } else if (url === "/agent.js.sha256") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end(`${GOOD_SHA}  agent.js\n`); // sha256sum format: digest, two spaces, filename, newline
    } else if (url === "/refuse.js.sha256") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end(`${WRONG_SHA.toUpperCase()}  agent.js\n`); // UPPERCASE hex — wrong AND uppercase
    } else if (url === "/empty.js.sha256") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end(""); // empty sidecar
    } else {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("not found");
    }
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const addr = server.address();
  if (typeof addr !== "object" || addr === null) throw new Error("no server address");
  base = `http://127.0.0.1:${addr.port}`;
});

afterAll(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
});

afterEach(() => {
  hits = [];
  delete process.env.VCLAW_AGENT_BUNDLE_URL;
  delete process.env.VCHAT_AGENT_BUNDLE_URL;
});

/** Fresh temp target dir per test — never the real ~/.vclaw. */
async function freshTarget(): Promise<{ dir: string; path: string }> {
  const dir = await mkdtemp(join(tmpdir(), "vclaw-update-test-"));
  return { dir, path: join(dir, "agent.js") };
}

function isExecutable(path: string): boolean {
  return ((statSync(path).mode & 0o111) !== 0);
}

describe("parseSha256Sidecar (join-script parsing parity)", () => {
  it("takes the first whitespace token, lowercased — tolerating newline, filename suffix, and case", () => {
    expect(parseSha256Sidecar(`${GOOD_SHA}  agent.js\n`)).toBe(GOOD_SHA);
    expect(parseSha256Sidecar(`${GOOD_SHA.toUpperCase()}  agent.js\n\n`)).toBe(GOOD_SHA);
    expect(parseSha256Sidecar(`${GOOD_SHA}\n`)).toBe(GOOD_SHA);
    expect(parseSha256Sidecar("")).toBe("");
    expect(parseSha256Sidecar("   \n")).toBe("");
  });
});

describe("resolveBundleUrl (option > VCLAW env > VCHAT env > default)", () => {
  it("defaults to the CDN bundle URL", () => {
    expect(resolveBundleUrl()).toBe("https://vclawhub.com/agent.js");
  });

  it("VCLAW_AGENT_BUNDLE_URL overrides the default; an explicit option overrides env", () => {
    process.env.VCLAW_AGENT_BUNDLE_URL = "https://example.com/a.js";
    expect(resolveBundleUrl()).toBe("https://example.com/a.js");
    expect(resolveBundleUrl("https://other.com/b.js")).toBe("https://other.com/b.js");
  });

  it("falls back to the legacy VCHAT_AGENT_BUNDLE_URL name", () => {
    process.env.VCHAT_AGENT_BUNDLE_URL = "https://legacy.com/c.js";
    expect(resolveBundleUrl()).toBe("https://legacy.com/c.js");
  });
});

describe("updateBundle — good path writes atomically", () => {
  it("fetches, verifies, and installs the bundle byte-exactly with the executable bit", async () => {
    const { dir, path } = await freshTarget();
    try {
      const res = await updateBundle({ bundleUrl: `${base}/agent.js`, agentJsPath: path });
      expect(res.verified).toBe(true);
      expect(res.written).toBe(true);
      expect(res.from).toBe("none");
      expect(res.to).toBe(GOOD_SHA.slice(0, 12));
      expect(res.sha256).toBe(GOOD_SHA);
      expect(res.next).toBe("");
      // byte-exact install
      expect(new Uint8Array(await readFile(path))).toEqual(BUNDLE_BYTES);
      // the join pipe chmods 755 — bun runs this file directly
      expect(isExecutable(path)).toBe(true);
      // ATOMIC: nothing left in the target dir but the installed file
      expect(await readdir(dir)).toEqual(["agent.js"]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("skips the write when the installed digest already matches (join-pipe 'already current')", async () => {
    const { dir, path } = await freshTarget();
    try {
      await updateBundle({ bundleUrl: `${base}/agent.js`, agentJsPath: path });
      const res = await updateBundle({ bundleUrl: `${base}/agent.js`, agentJsPath: path });
      expect(res.verified).toBe(true);
      expect(res.written).toBe(false);
      expect(res.from).toBe(GOOD_SHA.slice(0, 12));
      expect(res.to).toBe(GOOD_SHA.slice(0, 12));
      expect(await readdir(dir)).toEqual(["agent.js"]); // untouched
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("replaces an existing DIFFERENT bundle (from != to)", async () => {
    const { dir, path } = await freshTarget();
    try {
      await writeFile(path, "// old bundle", { mode: 0o755 });
      const res = await updateBundle({ bundleUrl: `${base}/agent.js`, agentJsPath: path });
      expect(res.written).toBe(true);
      expect(res.from).not.toBe(res.to);
      expect(new TextDecoder().decode(await readFile(path))).toBe(BUNDLE_FIXTURE);
      expect(await readdir(dir)).toEqual(["agent.js"]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("uses the dir of the given target — never a global temp dir (same-dir rename)", async () => {
    const { dir, path } = await freshTarget();
    try {
      await updateBundle({ bundleUrl: `${base}/agent.js`, agentJsPath: path });
      // rename was same-dir ATOMIC: the tmp file lived next to the target and
      // is gone; nothing leaked into os.tmpdir() under our prefix beyond dirs
      // this test manages (each freshTarget is its own dir and cleaned up).
      expect(await readdir(dir)).toEqual(["agent.js"]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("updateBundle — a WRONG digest REFUSES to write", () => {
  it("throws on sidecar mismatch and leaves a pre-existing OLD bundle intact", async () => {
    const { dir, path } = await freshTarget();
    try {
      await writeFile(path, "// old bundle — must survive a refused update", { mode: 0o755 });
      // /refuse.js serves the SAME bundle bytes, but its sidecar carries the
      // WRONG digest (uppercase hex — also proves case-insensitive parsing).
      await expect(
        updateBundle({ bundleUrl: `${base}/refuse.js`, agentJsPath: path }),
      ).rejects.toThrow(/sha256 mismatch/);
      expect(new TextDecoder().decode(await readFile(path))).toBe(
        "// old bundle — must survive a refused update",
      );
      expect(await readdir(dir)).toEqual(["agent.js"]); // no tmp leftovers
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("throws on sidecar mismatch with no pre-existing target — creates nothing", async () => {
    const { dir, path } = await freshTarget();
    try {
      await expect(
        updateBundle({ bundleUrl: `${base}/refuse.js`, agentJsPath: path }),
      ).rejects.toThrow(new RegExp(`sha256 mismatch \\(want ${WRONG_SHA.slice(0, 12)}`));
      expect(existsSync(path)).toBe(false);
      expect(await readdir(dir)).toEqual([]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("refuses on an EMPTY sidecar (no digest to compare)", async () => {
    const { dir, path } = await freshTarget();
    try {
      await expect(
        updateBundle({ bundleUrl: `${base}/empty.js`, agentJsPath: path }),
      ).rejects.toThrow(/sha256 mismatch/);
      expect(existsSync(path)).toBe(false);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("throws on a 404 bundle URL (missing artifact)", async () => {
    const { dir, path } = await freshTarget();
    try {
      await expect(
        updateBundle({ bundleUrl: `${base}/missing.js`, agentJsPath: path }),
      ).rejects.toThrow(/GET .* → 404/);
      expect(existsSync(path)).toBe(false);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("updateBundle — checkOnly never writes", () => {
  it("fetches, verifies, reports — and creates nothing (not even a tmp file)", async () => {
    const { dir, path } = await freshTarget();
    try {
      const res = await updateBundle({
        bundleUrl: `${base}/agent.js`,
        agentJsPath: path,
        checkOnly: true,
      });
      expect(res.verified).toBe(true);
      expect(res.written).toBe(false);
      expect(res.checkOnly).toBe(true);
      expect(res.checked).toBe(true);
      expect(res.next).toContain("--check");
      expect(existsSync(path)).toBe(false);
      expect(await readdir(dir)).toEqual([]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("checkOnly on a mismatch STILL refuses (verify path runs before the no-write branch)", async () => {
    const { dir, path } = await freshTarget();
    try {
      await expect(
        updateBundle({ bundleUrl: `${base}/refuse.js`, agentJsPath: path, checkOnly: true }),
      ).rejects.toThrow(/sha256 mismatch/);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("updateBundle — version pinning (no CDN scheme exists for agent.js)", () => {
  it("skips BEFORE fetching when --version has no exact --bundle-url, and says so", async () => {
    const { dir, path } = await freshTarget();
    try {
      const res = await updateBundle({ version: "9.9.9", agentJsPath: path });
      expect(res.checked).toBe(false);
      expect(res.written).toBe(false);
      expect(res.verified).toBe(false);
      expect(res.skipped).toContain("--version");
      expect(res.next).toContain("--bundle-url");
      expect(hits).toEqual([]); // nothing was fetched
      expect(existsSync(path)).toBe(false);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("proceeds with an explicit --bundle-url and carries versionNote (artifact NOT version-verified)", async () => {
    const { dir, path } = await freshTarget();
    try {
      const res = await updateBundle({
        version: "9.9.9",
        bundleUrl: `${base}/agent.js`,
        agentJsPath: path,
      });
      expect(res.written).toBe(true);
      expect(res.versionNote).toContain("pinning is unsupported");
      expect(res.versionNote).toContain("9.9.9");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("updateBundle — env override drives the default URL", () => {
  it("uses VCLAW_AGENT_BUNDLE_URL when no explicit option is passed", async () => {
    const { dir, path } = await freshTarget();
    process.env.VCLAW_AGENT_BUNDLE_URL = `${base}/agent.js`;
    try {
      const res = await updateBundle({ agentJsPath: path, checkOnly: true });
      expect(res.bundleUrl).toBe(`${base}/agent.js`);
      expect(res.verified).toBe(true);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
