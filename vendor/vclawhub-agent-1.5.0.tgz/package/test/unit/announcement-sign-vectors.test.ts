/**
 * announcement-sign-vectors.test.ts — the SIGN half of the golden gate (build item 1).
 *
 * announcement-fixtures.ts pins WHAT is signed (canonical JSON literals) and the v2 suite
 * checks canonicalization. This file pins the SIGNATURES, so the whole path
 * (field order -> canonical bytes -> ed25519 over those bytes -> base64) is frozen:
 * change the codec, the PRNG seam, or the sign input, and this fails loudly instead of
 * shipping announcements that peers silently reject pairwise.
 *
 * Ed25519 is deterministic (RFC 8032): the same seed over the same bytes gives the same
 * signature, so pinned literals are the correct form. The seed is TEST-ONLY (see fixtures).
 * Signatures are base64-std, matching the wire encoding.
 */
import { describe, it, expect } from "vitest";
import {
  canonicalAnnouncementBytes,
  canonicalAnnouncementV2Bytes,
  signAnnouncement,
  signAnnouncementV2,
} from "../../src/contracts/contracts.js";
import {
  V1_ANNOUNCEMENT,
  V1_CANONICAL_JSON,
  V2_ANNOUNCEMENT_WITH_CHILDREN,
  V2_ANNOUNCEMENT_NO_CHILDREN,
  V2_CANONICAL_JSON_WITH_CHILDREN,
  V2_CANONICAL_JSON_NO_CHILDREN,
  SIGN_VECTOR_SEED,
  SIGN_VECTOR_PUBLIC,
  V1_SIG,
  V2_SIG_WITH_CHILDREN,
  V2_SIG_NO_CHILDREN,
} from "../helpers/announcement-fixtures.js";

const b64 = (u: Uint8Array) => Buffer.from(u).toString("base64");

describe("golden sign vectors — the signing path is byte-pinned", () => {
  it("canonical bytes ARE the pinned JSON literals (encode side)", () => {
    expect(new TextDecoder().decode(canonicalAnnouncementBytes(V1_ANNOUNCEMENT as never))).toBe(V1_CANONICAL_JSON);
    expect(new TextDecoder().decode(canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_WITH_CHILDREN as never))).toBe(V2_CANONICAL_JSON_WITH_CHILDREN);
    expect(new TextDecoder().decode(canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_NO_CHILDREN as never))).toBe(V2_CANONICAL_JSON_NO_CHILDREN);
  });

  it("v1 signature matches the pinned vector", async () => {
    const sig = await signAnnouncement(V1_ANNOUNCEMENT as never, SIGN_VECTOR_SEED);
    expect(b64(sig as unknown as Uint8Array)).toBe(V1_SIG);
  });

  it("v2 signature WITH children matches the pinned vector", async () => {
    const sig = await signAnnouncementV2(V2_ANNOUNCEMENT_WITH_CHILDREN as never, SIGN_VECTOR_SEED);
    expect(b64(sig as unknown as Uint8Array)).toBe(V2_SIG_WITH_CHILDREN);
  });

  it("v2 signature WITHOUT children matches the pinned vector (undefined-skip)", async () => {
    const sig = await signAnnouncementV2(V2_ANNOUNCEMENT_NO_CHILDREN as never, SIGN_VECTOR_SEED);
    expect(b64(sig as unknown as Uint8Array)).toBe(V2_SIG_NO_CHILDREN);
  });

  it("the three vectors are DISTINCT (a copy-paste fixture would pass everything else)", async () => {
    const set = new Set([V1_SIG, V2_SIG_WITH_CHILDREN, V2_SIG_NO_CHILDREN]);
    expect(set.size).toBe(3);
    expect(SIGN_VECTOR_SEED.startsWith("SU")).toBe(true);   // valid user seed shape
    expect(SIGN_VECTOR_PUBLIC.startsWith("U")).toBe(true);  // valid user public shape
  });
});
