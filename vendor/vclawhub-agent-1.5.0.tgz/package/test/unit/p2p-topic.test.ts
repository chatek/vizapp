/**
 * p2p-topic.test.ts — delegation topic derivation (Pears Tier P, M2).
 *
 * The topic derivation is a STABILITY contract: every peer of a delegation
 * must derive the SAME 32 bytes forever, and two delegations must never share
 * a topic. The golden hex pins the algorithm — if this test fails after an
 * "innocent" change, every existing fleet just split.
 */
import { describe, it, expect } from "vitest";
import { delegationTopic, delegationTopicHex, TOPIC_DOMAIN } from "../../src/net/p2p/topic.js";
import { createHash } from "node:crypto";

const GOLDEN_TOPIC_HEX = "b245e9dd8bfad6606cdaaccd654503199fcb9d8ca6758c3c0923392c467ec54c";
const GOLDEN_TOPIC_OTHER_HEX = "3477218e71a20f40c31a24551e355f0c7f98b5049d9bce050ea319f2cfb08147";

describe("delegationTopic", () => {
  it("derives exactly 32 bytes", () => {
    const topic = delegationTopic("dlg-golden");
    expect(topic).toBeInstanceOf(Uint8Array);
    expect(topic.length).toBe(32);
  });

  it("matches the golden vector (algorithm stability)", () => {
    expect(Buffer.from(delegationTopic("dlg-golden")).toString("hex")).toBe(GOLDEN_TOPIC_HEX);
  });

  it("is deterministic across calls", () => {
    expect(delegationTopicHex("dlg-golden")).toBe(delegationTopicHex("dlg-golden"));
  });

  it("differs per delegation id", () => {
    expect(delegationTopicHex("dlg-golden")).not.toBe(delegationTopicHex("dlg-other"));
    expect(Buffer.from(delegationTopic("dlg-other")).toString("hex")).toBe(GOLDEN_TOPIC_OTHER_HEX);
  });

  it("is domain-separated (never equals a bare sha256 of the id)", () => {
    const bare = createHash("sha256").update("dlg-golden", "utf8").digest("hex");
    expect(delegationTopicHex("dlg-golden")).not.toBe(bare);
    expect(TOPIC_DOMAIN).toBe("vclaw/pears/topic/v1");
  });
});
