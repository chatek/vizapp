/**
 * MCP server tests (lane mcp-server, wave 1) — HERMETIC.
 *
 * Boundary discipline:
 *   - Transport: InMemoryTransport round-trips against buildMcpServer() —
 *     every assertion goes through a real MCP Client.callTool/listTools, so
 *     RENAMING A TOOL (or breaking registration) turns this suite RED.
 *   - Network: fetch is stubbed at the VgateClient boundary (global fetch);
 *     the API URL env points at a fake host — api.vclawhub.com is never
 *     touched. An env-target-less vclaw_onboard_start call is REFUSED before
 *     any fetch (the J16a-style guard is itself under test).
 *   - Disk: VCLAW_CREDS_DIR is set to a fresh temp dir INSIDE each test
 *     before any tool runs (store.ts resolves paths lazily at call time —
 *     the 2026-08-18 lesson), so no real ~/.config/vclaw is read or written.
 *   - Secrets: every result is JSON-serialised and swept for the REAL seed
 *     used by the test plus a config.json sentinel — on every code path,
 *     success and error alike.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { mkdtempSync, existsSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";

import { buildMcpServer, MCP_TOOLS } from "../../src/mcp/server.js";
import { redirectConsoleToStderr } from "../../src/mcp/index.js";
import { SEED_PATTERN } from "../../src/mcp/redact.js";
import { APPROVE_PROOF_AUDIENCE, decodeApproveProof } from "../../src/lib/approve-proof.js";
import { generateNkeyPair, keypairFromSeed } from "../../src/lib/keygen.js";
import { saveCredentials, writePendingFlag } from "../../src/lib/store.js";
import type { StoredCredentials } from "../../src/types.js";

/* ── env hygiene ─────────────────────────────────────────────────────── */

const ENV_KEYS = [
  "VCLAW_API_URL", "VCHAT_API_URL",
  "VCLAW_VGATE_URL", "VCHAT_VGATE_URL",
  "VCLAW_CREDS_DIR", "VCHAT_CREDS_DIR",
  "VCLAW_CLAIM_BASE_URL", "VCHAT_CLAIM_BASE_URL",
];

let credsDir: string;

beforeEach(() => {
  vi.unstubAllGlobals();
  for (const k of ENV_KEYS) delete process.env[k];
  credsDir = mkdtempSync(join(tmpdir(), "mcp-creds-"));
  // Set INSIDE the test, before any tool call — paths resolve lazily.
  process.env.VCLAW_CREDS_DIR = credsDir;
});

afterEach(() => {
  vi.unstubAllGlobals();
  for (const k of ENV_KEYS) delete process.env[k];
  rmSync(credsDir, { recursive: true, force: true });
});

/* ── harness ─────────────────────────────────────────────────────────── */

async function harness() {
  const server = buildMcpServer();
  const [serverTransport, clientTransport] = InMemoryTransport.createLinkedPair();
  await server.connect(serverTransport);
  const client = new Client({ name: "mcp-server-test", version: "0.0.0" });
  await client.connect(clientTransport);
  return { server, client };
}

type FetchCall = { url: string; method: string; body?: unknown };

interface StubbedResponse {
  status: number;
  body: unknown;
}

/** Fake fetch at the VgateClient boundary. `route` maps URL → response, or
 *  throws when the entry is an {throw}. Records every call. */
function stubFetch(route: Record<string, StubbedResponse | { throw: string }>) {
  const calls: FetchCall[] = [];
  const fn = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    calls.push({
      url,
      method: init?.method ?? "GET",
      body: init?.body ? JSON.parse(String(init.body)) : undefined,
    });
    const match = Object.entries(route).find(([prefix]) => url.startsWith(prefix));
    if (!match) throw new Error(`unexpected fetch in test: ${url}`);
    const planned = match[1];
    if ("throw" in planned) throw new Error(planned.throw);
    return new Response(JSON.stringify(planned.body), {
      status: planned.status,
      headers: { "content-type": "application/json" },
    });
  });
  vi.stubGlobal("fetch", fn);
  return { fn, calls };
}

/** A REAL keypair (official codec) + stored credentials in the temp dir. */
async function seedIdentity() {
  const kp = await generateNkeyPair();
  const creds: StoredCredentials = {
    seed: kp.seed,
    public_key: kp.publicKey,
    agent_nkey: kp.publicKey,
    name: "seeded-agent",
    steward: "unknown",
    created_at: "2026-01-01T00:00:00.000Z",
  };
  await saveCredentials(creds);
  return { kp, creds };
}

/** Write a config.json carrying a sentinel secret — proving the tool reports
 *  the file's PRESENCE without ever emitting its CONTENTS. */
function writeConfigWithSentinel() {
  const sentinel = "sk-llm-SENTINEL-a1b2c3d4e5";
  writeFileSync(
    join(credsDir, "config.json"),
    JSON.stringify({ segment: "vchat", api_key: sentinel }, null, 2),
  );
  return sentinel;
}

/** Serialize a full CallToolResult and sweep it for secrets. */
function assertNoSecrets(result: unknown, ...needles: string[]) {
  const text = JSON.stringify(result);
  expect(text.match(SEED_PATTERN), `seed-shaped leak in: ${text.slice(0, 200)}`).toBeNull();
  for (const n of needles) expect(text).not.toContain(n);
  return text;
}

function payload(result: { content: Array<{ type: string; text: string }> }) {
  expect(result.content[0]?.type).toBe("text");
  return JSON.parse(result.content[0]!.text) as Record<string, unknown>;
}

const BASE64URL_43 = /^[A-Za-z0-9_-]{43}$/;

/* ── tool surface (a rename anywhere → RED) ──────────────────────────── */

describe("mcp tool surface", () => {
  // Wave 2 (mcp-fabric-verbs): the surface grew from four identity tools to
  // nine — the five fabric verbs registered in server.ts. 0.3.0 (M3.5) adds
  // the three artifact verbs. This enumeration is the rename-detector; a
  // rename anywhere turns it RED by design.
  it("lists the four identity tools, the five fabric verbs and the three artifact verbs", async () => {
    const { client } = await harness();
    const tools = await client.listTools();
    expect(tools.tools.map((t) => t.name).sort()).toEqual(
      [
        MCP_TOOLS.identityStatus,
        MCP_TOOLS.onboardStart,
        MCP_TOOLS.onboardPoll,
        MCP_TOOLS.health,
        MCP_TOOLS.presenceStatus,
        MCP_TOOLS.roster,
        MCP_TOOLS.announceOnce,
        MCP_TOOLS.a2aPublish,
        MCP_TOOLS.a2aSubscribePoll,
        MCP_TOOLS.artifactPut,
        MCP_TOOLS.artifactGet,
        MCP_TOOLS.artifactList,
      ].sort(),
    );
  });
});

/* ── vclaw_identity_status ───────────────────────────────────────────── */

describe("vclaw_identity_status", () => {
  it("reports an empty host honestly (no creds, no files)", async () => {
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.identityStatus, arguments: {} });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.onboarded).toBe(false);
    expect(p.pending).toBe(false);
    expect(p.public_key).toBeNull();
    expect(p.files).toEqual({ credentials: false, config: false, pending: false });
    // creds_path reflects the override (lazy resolution — set in beforeEach)
    expect(p.creds_path).toBe(join(credsDir, "credentials.json"));
    assertNoSecrets(res);
  });

  it("reports public key forms + file presence; never the seed or config contents", async () => {
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    const sentinel = writeConfigWithSentinel();

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.identityStatus, arguments: {} });
    const p = payload(res as never);
    expect(p.onboarded).toBe(true);
    expect(p.pending).toBe(true);
    expect(p.name).toBe("seeded-agent");
    // U-form + base64url raw form — the PUBLIC identity only
    expect(p.public_key).toEqual({
      u_form: kp.publicKey,
      base64url: Buffer.from(kp.rawPublicKey).toString("base64url"),
    });
    expect((p.public_key as { base64url: string }).base64url).toMatch(BASE64URL_43);
    expect(p.files).toEqual({ credentials: true, config: true, pending: true });
    // Secret sweep: the real seed AND the config sentinel must be absent.
    assertNoSecrets(res, kp.seed, sentinel);
  });
});

/* ── vclaw_onboard_start ─────────────────────────────────────────────── */

describe("vclaw_onboard_start", () => {
  it("REFUSES without an explicit env target and never fetches", async () => {
    const { fn, calls } = stubFetch({});
    const { client } = await harness();
    const res = await client.callTool({
      name: MCP_TOOLS.onboardStart,
      arguments: { name: "host-agent" },
    });
    expect(res.isError).toBe(true);
    const text = JSON.stringify(res);
    expect(text).toContain("VCLAW_API_URL");
    expect(fn).not.toHaveBeenCalled();
    expect(calls).toHaveLength(0);
    // Fail-closed: no identity half-written to disk either.
    expect(existsSync(join(credsDir, "credentials.json"))).toBe(false);
    expect(existsSync(join(credsDir, ".pending"))).toBe(false);
    assertNoSecrets(res);
  });

  it("introduces, mints the I-17 proof (aud = APPROVE_PROOF_AUDIENCE), returns claim_url only", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    process.env.VCLAW_CLAIM_BASE_URL = "http://claim.test";
    const CHALLENGE = "cHJvb2YtY2hhbGxlbmdlLTQzLWNoYXJzLXBhZGluZw";
    const { calls } = stubFetch({
      "http://vgate.test/v1/agent/introduce": {
        status: 200,
        body: { agent_id: "ag-1", session_id: "sess-1", status: "pending", approve_challenge: CHALLENGE },
      },
    });

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardStart, arguments: {} });
    expect(res.isError).toBeFalsy();

    // Wire shape: POST /v1/agent/introduce with base64url raw pubkey + name.
    expect(calls).toHaveLength(1);
    expect(calls[0]!.url).toBe("http://vgate.test/v1/agent/introduce");
    expect(calls[0]!.method).toBe("POST");
    expect((calls[0]!.body as { nkey_public: string }).nkey_public).toMatch(BASE64URL_43);
    expect((calls[0]!.body as { name: string }).name).toMatch(/^agent-[0-9a-f]{8}$/);

    const p = payload(res as never);
    expect(p.session_id).toBe("sess-1");
    expect(p.proof_minted).toBe(true);
    expect(p.resumed).toBe(false);
    expect(typeof p.poll_hint).toBe("string");
    expect(p.poll_hint).toContain("vclaw_onboard_poll");

    // claim_url: the ONE sanctioned ?proof= emission.
    const claimUrl = p.claim_url as string;
    expect(claimUrl.startsWith("http://claim.test/a/sess-1?proof=")).toBe(true);
    const proof = claimUrl.split("?proof=")[1]!;
    const decoded = decodeApproveProof(decodeURIComponent(proof));
    expect(decoded.aud).toBe(APPROVE_PROOF_AUDIENCE); // imported constant, not a restated literal
    expect(decoded.jti).toBe(CHALLENGE);

    // Pending state persisted ON DISK (for poll) — seed never crosses the wire.
    expect(existsSync(join(credsDir, ".pending"))).toBe(true);
    const stored = JSON.parse(readFileSync(join(credsDir, "credentials.json"), "utf-8")) as StoredCredentials;
    expect(decoded.iss).toBe(stored.public_key);
    expect(decoded.sub).toBe(stored.public_key);
    // Secret sweep over the whole serialized result: no seed field, no raw
    // challenge field (it lives only inside the signed proof).
    assertNoSecrets(res, stored.seed, CHALLENGE, '"approve_challenge"');
  });

  it("resumes a pending identity: same nkey re-introduced, resumed surfaced", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    const CHALLENGE2 = "cmVzdW1lLWNoYWxsZW5nZS00My1jaGFycy1wYWQ";
    const { calls } = stubFetch({
      "http://vgate.test/v1/agent/introduce": {
        status: 200,
        body: { agent_id: "ag-1", session_id: "sess-2", status: "pending", resumed: true, approve_challenge: CHALLENGE2 },
      },
    });

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardStart, arguments: { name: "same-agent" } });
    const p = payload(res as never);
    expect(p.resumed).toBe(true);
    // SAME identity: the introduced nkey is the stored keypair's raw form.
    expect((calls[0]!.body as { nkey_public: string }).nkey_public).toBe(
      Buffer.from(kp.rawPublicKey).toString("base64url"),
    );
    expect(p.proof_minted).toBe(true);
    assertNoSecrets(res, kp.seed);
  });

  it("refuses when already onboarded (claimed identity) — no fetch", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity(); // creds, NO pending flag
    const { fn } = stubFetch({});
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardStart, arguments: {} });
    expect(res.isError).toBe(true);
    expect(fn).not.toHaveBeenCalled();
    assertNoSecrets(res, kp.seed);
  });

  it("surfaces introduce failure without leaking the seed from error paths", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    const { calls } = stubFetch({
      "http://vgate.test/v1/agent/introduce": { status: 500, body: { error: "boom" } },
    });
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardStart, arguments: {} });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toContain("500");
    expect(calls).toHaveLength(1);
    assertNoSecrets(res, kp.seed);
  });
});

/* ── vclaw_onboard_poll ──────────────────────────────────────────────── */

describe("vclaw_onboard_poll", () => {
  it("polls GET /v1/agent/status?nkey=<base64url> and completes the claim", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    const expectedNkey = Buffer.from(kp.rawPublicKey).toString("base64url");
    const { calls } = stubFetch({
      "http://vgate.test/v1/agent/status": {
        status: 200,
        body: { claimed: true, steward: "alice@example.com", name: "seeded-agent" },
      },
    });

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardPoll, arguments: { timeout_ms: 5_000 } });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.claimed).toBe(true);
    expect(p.steward).toBe("alice@example.com");

    // URL contract: base64url nkey form (NOT the U-form), 43 chars, encoded.
    expect(calls[0]!.url).toBe(`http://vgate.test/v1/agent/status?nkey=${expectedNkey}`);
    expect(expectedNkey).toMatch(BASE64URL_43);
    expect(expectedNkey).not.toBe(kp.publicKey);

    // Completion: pending flag cleared, steward recorded in credentials.
    expect(existsSync(join(credsDir, ".pending"))).toBe(false);
    const stored = JSON.parse(readFileSync(join(credsDir, "credentials.json"), "utf-8")) as StoredCredentials;
    expect(stored.steward).toBe("alice@example.com");
    assertNoSecrets(res, kp.seed);
  });

  it("returns claimed:false at window end; keeps polling state; boundary timeout 60000 accepted", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    const { calls } = stubFetch({
      "http://vgate.test/v1/agent/status": { status: 200, body: { claimed: false } },
    });

    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardPoll, arguments: { timeout_ms: 80 } });
    const p = payload(res as never);
    expect(p.claimed).toBe(false);
    expect("steward" in p).toBe(false);
    expect(calls.length).toBeGreaterThanOrEqual(2); // paced loop, not one shot
    expect(existsSync(join(credsDir, ".pending"))).toBe(true);
    assertNoSecrets(res, kp.seed);

    // Inclusive cap: 60000 is a valid window. Re-stub to claimed:true so the
    // boundary call resolves on its FIRST tick (no 60s live wait).
    vi.unstubAllGlobals();
    stubFetch({ "http://vgate.test/v1/agent/status": { status: 200, body: { claimed: true, steward: "s@x" } } });
    const { client: c2 } = await harness();
    const res2 = await c2.callTool({ name: MCP_TOOLS.onboardPoll, arguments: { timeout_ms: 60_000 } });
    expect(res2.isError).toBeFalsy();
    expect(payload(res2 as never).claimed).toBe(true);
  });

  it("rejects timeout_ms above the 60000 cap (schema-enforced)", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    await seedIdentity();
    stubFetch({});
    const { client } = await harness();
    // Schema violation surfaces as an isError tool result ("MCP error
    // -32602: Input validation error …"), not a thrown client error.
    const res = await client.callTool({ name: MCP_TOOLS.onboardPoll, arguments: { timeout_ms: 60_001 } });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toMatch(/-32602|Input validation error/);
    expect(JSON.stringify(res)).toMatch(/60000/);
    assertNoSecrets(res);
  });

  it("refuses without a stored identity — points at vclaw_onboard_start", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { fn } = stubFetch({});
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.onboardPoll, arguments: { timeout_ms: 1_000 } });
    expect(res.isError).toBe(true);
    expect(JSON.stringify(res)).toContain("vclaw_onboard_start");
    expect(fn).not.toHaveBeenCalled();
    assertNoSecrets(res);
  });
});

/* ── vclaw_health ────────────────────────────────────────────────────── */

describe("vclaw_health", () => {
  it("reports a healthy vgate with the resolved api_url", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { calls } = stubFetch({
      "http://vgate.test/health": { status: 200, body: { status: "ok", service: "vgate", version: "9.9.9" } },
    });
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.health, arguments: {} });
    expect(res.isError).toBeFalsy();
    const p = payload(res as never);
    expect(p.ok).toBe(true);
    expect(p.api_url).toBe("http://vgate.test");
    expect(p.detail).toMatchObject({ status: "ok", service: "vgate", version: "9.9.9" });
    expect(calls[0]!.url).toBe("http://vgate.test/health");
    assertNoSecrets(res);
  });

  it("reports ok:false with a REDACTED failure detail", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity(); // a real seed to plant in the error text
    stubFetch({ "http://vgate.test/health": { throw: `connect ECONNREFUSED leaked ${kp.seed}` } });
    const { client } = await harness();
    const res = await client.callTool({ name: MCP_TOOLS.health, arguments: {} });
    const p = payload(res as never);
    expect(p.ok).toBe(false);
    expect(p.api_url).toBe("http://vgate.test");
    assertNoSecrets(res, kp.seed); // the planted seed must NOT survive redaction
  });
});

/* ── stdio hygiene ───────────────────────────────────────────────────── */

describe("stdio hygiene", () => {
  it("redirectConsoleToStderr routes console.log away from the JSON-RPC channel", () => {
    const original = console.log;
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const outSpy = vi.spyOn(process.stdout, "write").mockImplementation(() => true);
    try {
      redirectConsoleToStderr();
      console.log("stray banner");
      expect(errSpy).toHaveBeenCalledWith("stray banner");
      expect(outSpy).not.toHaveBeenCalled();
    } finally {
      console.log = original;
      errSpy.mockRestore();
      outSpy.mockRestore();
    }
  });
});

/* ── direct-handler sweep (every code path serialized) ───────────────── */

describe("serialization sweep over direct handlers", () => {
  it("every identityStatus/onboardPoll/vgateHealth return serializes without secrets", async () => {
    process.env.VCLAW_API_URL = "http://vgate.test";
    const { kp } = await seedIdentity();
    await writePendingFlag(kp.publicKey);
    stubFetch({
      "http://vgate.test/v1/agent/status": { status: 200, body: { claimed: true, steward: "s@x" } },
      "http://vgate.test/health": { status: 200, body: { status: "ok", service: "vgate", version: "1" } },
    });
    const { identityStatus, onboardPoll, vgateHealth } = await import("../../src/mcp/tools.js");
    for (const r of [
      await identityStatus(),
      await onboardPoll({ timeout_ms: 500 }),
      await vgateHealth(),
    ]) {
      const text = JSON.stringify(r);
      expect(text).not.toContain(kp.seed);
      expect(text.match(SEED_PATTERN)).toBeNull();
    }
  });
});
