/**
 * J3 (a-cmd / b / c) — extension command-handler e2e + stale-creds error path.
 *
 * Drives the /vchat-* command handlers (src/pi-extension/index.ts) through a
 * capturing mock pi, with store/lifecycle/directory/contracts/subjects mocked
 * so no real I/O or NATS occurs. Covers:
 *   J3a-cmd : /vchat-connect writes config (saveConfig); session_start reads
 *             it (readConfig) and feeds it into startRuntime.
 *   J3b     : /vchat-claim-status state machine — NOT_ONBOARDED → PENDING →
 *             APPROVED, INCLUDING the ambiguous flag+creds case.
 *   J3c     : stale-creds error path — connect surfaces the proper nkeys error
 *             (E_CONNECT, no crash/hang); status/claim-status stay graceful
 *             (presence-based, documented); seed-level seam-gate (decodeNkeySeed).
 *
 * Test-only: no production code changed. Gaps flagged in the J3 report.
 */
import { describe, it, expect, beforeEach, vi } from "vitest";

// ── Stable mock instances (vi.hoisted so the vi.mock factories can reference
//    them AND they survive vi.resetModules — the extension re-evaluates fresh
//    each test but the mock fns are the same instances). ──────────────────────
const mocks = vi.hoisted(() => ({
  loadCredentials: vi.fn(),
  hasPendingFlag: vi.fn(),
  readConfig: vi.fn(),
  saveConfig: vi.fn(),
  fetchNatsUserJWT: vi.fn(),
  connectViaJWT: vi.fn(),
  startPresence: vi.fn(),
  subA2A: vi.fn(),
  watchDirectory: vi.fn(),
  setTenantSegment: vi.fn(),
}));

vi.mock("../../src/lib/store.js", () => ({
  loadCredentials: mocks.loadCredentials,
  hasPendingFlag: mocks.hasPendingFlag,
  readConfig: mocks.readConfig,
  saveConfig: mocks.saveConfig,
}));
vi.mock("../../src/agent/lifecycle.js", () => ({
  fetchNatsUserJWT: mocks.fetchNatsUserJWT,
  connectViaJWT: mocks.connectViaJWT,
  startPresence: mocks.startPresence,
  subA2A: mocks.subA2A,
}));
vi.mock("../../src/net/directory.js", () => ({
  watchDirectory: mocks.watchDirectory,
}));
vi.mock("../../src/contracts/contracts.js", () => ({
  setTenantSegment: mocks.setTenantSegment,
}));
vi.mock("../../src/agent/subjects.js", () => ({
  SubjectTree: {
    CLAIM: () => "tenant.vchat.claim.FAKE_NKEY",
    PROMPT: () => "tenant.vchat.user.FAKE_NKEY.agent.FAKE_NKEY.prompt.>", // BUILD-B: H2A wiring subscribes PROMPT
  },
}));

import { decodeNkeySeed, generateNkeyPair } from "../../src/lib/keygen.js";

const CREDS = {
  seed: "SUATESTSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEEDSEED",
  public_key: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  agent_nkey: "UAATESTPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLICPUBLIC",
  name: "test-agent",
  steward: "tester@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
} as const;

/** Minimal fake NatsConnection: subscribe yields nothing (claim loop exits). */
function fakeNc() {
  return {
    subscribe: vi.fn(() => ({
      unsubscribe() {},
      [Symbol.asyncIterator]() {
        return { next: async () => ({ done: true as const, value: undefined }) };
      },
    })),
    drain: vi.fn(async () => {}),
    close: vi.fn(() => {}),
    publish: vi.fn(),
  };
}

/** Start-runtime success wiring (connect / session_start happy path). */
function stubRuntimeSuccess() {
  mocks.fetchNatsUserJWT.mockResolvedValue("JWT-xxx");
  mocks.connectViaJWT.mockResolvedValue(fakeNc());
  mocks.startPresence.mockReturnValue({ stop: async () => {} });
  mocks.subA2A.mockReturnValue(undefined);
  mocks.watchDirectory.mockReturnValue({ directory: { snapshot: () => [] }, stop: () => {} });
}

let factory: (pi: unknown) => void;

beforeEach(async () => {
  vi.clearAllMocks();
  vi.resetModules();
  factory = (await import("../../src/pi-extension/index.ts")).default;
});

/** Install the factory against a capturing mock pi; return handlers. */
function harness() {
  const commands = new Map<string, (args: string, ctx: unknown) => Promise<void>>();
  const handlers = new Map<string, (...a: unknown[]) => unknown>();
  const pi = {
    on: vi.fn((name: string, fn: (...a: unknown[]) => unknown) => handlers.set(name, fn)),
    registerCommand: vi.fn((name: string, spec: { handler: (a: string, c: unknown) => Promise<void> }) =>
      commands.set(name, spec.handler),
    ),
    sendUserMessage: vi.fn(),
  };
  factory(pi);
  return { commands, handlers };
}

/** Invoke a command; collect notify frames (parsed) emitted via ctx.ui.notify. */
async function runCmd(
  commands: Map<string, (args: string, ctx: unknown) => Promise<void>>,
  name: string,
  args = "",
) {
  const frames: Array<{ p: Record<string, unknown>; t?: string }> = [];
  const ctx = {
    hasUI: true,
    ui: {
      notify: (m: string, t?: string) => {
        try { frames.push({ p: JSON.parse(m), t }); } catch { /* non-JSON notify */ }
      },
    },
  };
  await commands.get(name)!(args, ctx);
  return frames;
}

/** Filter notify frames to command_result payloads. */
const results = (frames: Array<{ p: Record<string, unknown> }>) =>
  frames.filter((f) => f.p.__vchat === true && f.p.kind === "command_result");

// ── J3a-cmd: config-persistence lifecycle ───────────────────────────────────
describe("J3a-cmd: /vchat-connect writes config; session_start reads it", () => {
  it("/vchat-connect on success calls saveConfig with the wizard's segment/server/vgateUrl", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    stubRuntimeSuccess();
    const { commands } = harness();

    await runCmd(commands, "vchat-connect", "--segment acme --server nats://n:4223 --vgate-url https://g");

    expect(mocks.saveConfig).toHaveBeenCalledWith({
      segment: "acme",
      server: "nats://n:4223",
      vgateUrl: "https://g",
    });
  });

  it("/vchat-connect does NOT saveConfig when not onboarded (no creds)", async () => {
    mocks.loadCredentials.mockResolvedValue(null);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-connect", "");

    expect(mocks.saveConfig).not.toHaveBeenCalled();
    expect(results(frames)[0].p).toMatchObject({ command: "connect", success: false, code: "E_NO_CREDS" });
  });

  it("session_start reads readConfig and feeds segment/server/vgateUrl into startRuntime", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    mocks.readConfig.mockResolvedValue({ segment: "s1", server: "srv1", vgateUrl: "vg1" });
    stubRuntimeSuccess();
    const { handlers } = harness();

    await handlers.get("session_start")!({ reason: "startup" }, { hasUI: false, ui: { notify() {} } });

    // readConfig was consulted, and its values flowed into the lifecycle calls:
    expect(mocks.readConfig).toHaveBeenCalled();
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("s1");
    expect(mocks.fetchNatsUserJWT).toHaveBeenCalledWith("vg1", expect.any(String), expect.any(String));
    expect(mocks.connectViaJWT).toHaveBeenCalledWith("srv1", expect.any(Function), expect.any(String), expect.any(String));
  });

  it("session_start without creds notifies 'not onboarded' and does not connect", async () => {
    mocks.loadCredentials.mockResolvedValue(null);
    const { handlers } = harness();
    const notes: string[] = [];
    await handlers.get("session_start")!({ reason: "startup" }, { hasUI: true, ui: { notify: (m: string) => notes.push(m) } });
    expect(mocks.connectViaJWT).not.toHaveBeenCalled();
    expect(notes.some((n) => /not onboarded/.test(n))).toBe(true);
  });
});

// ── J3b: claim-state transitions ────────────────────────────────────────────
describe("J3b: /vchat-claim-status state machine (local fs state)", () => {
  it("NOT_ONBOARDED — no creds, no pending flag", async () => {
    mocks.loadCredentials.mockResolvedValue(null);
    mocks.hasPendingFlag.mockReturnValue(false);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-claim-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "claim_status", success: false, code: "E_NO_CREDS" });
  });

  it("PENDING — pending flag set (introduced, awaiting approval)", async () => {
    mocks.loadCredentials.mockResolvedValue(null);
    mocks.hasPendingFlag.mockReturnValue(true);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-claim-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "claim_status", success: true, data: { state: "pending" } });
  });

  it("APPROVED — creds present, no pending flag", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    mocks.hasPendingFlag.mockReturnValue(false);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-claim-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "claim_status", success: true, data: { state: "approved" } });
  });

  // AMBIGUOUS: a pending flag AND creds both present. This should not normally
  // happen (pending = awaiting approval; creds = already approved), but the
  // command must not crash. Current precedence: PENDING FLAG WINS (checked
  // first) — conservative: never claims "approved" while a claim is still open.
  // GAP (flagged): onboard/claim-write should clear the pending flag when creds
  // are written, so this state is unreachable in production.
  it("AMBIGUOUS (flag + creds both present) — pending flag wins → reports 'pending'", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    mocks.hasPendingFlag.mockReturnValue(true);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-claim-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "claim_status", success: true, data: { state: "pending" } });
  });
});

// ── J3c: stale-creds error path ─────────────────────────────────────────────
describe("J3c: stale-creds error path (proper error, no crash/hang)", () => {
  // (i) seed-level seam-gate: the existing decodeNkeySeed (keygen.ts) rejects a
  // stale 'ST…' seed via nkeys.fromSeed. This is the actual validity gate.
  it("seam-gate: decodeNkeySeed accepts a real seed but rejects a stale 'ST…' seed", async () => {
    const kp = await generateNkeyPair(); // real, codec-correct 'SU…' seed
    expect(() => decodeNkeySeed(kp.seed)).not.toThrow();
    const stale = "ST11QFxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
    expect(() => decodeNkeySeed(stale)).toThrow(/invalid encoded key|InvalidEncoding|prefix/i);
  });

  // (ii) /vchat-connect surfaces the stale-seed rejection as a PROPER E_CONNECT
  // error (the seam fires inside fetchNatsUserJWT → nkeys.fromSeed), no crash.
  it("/vchat-connect with a stale seed → E_CONNECT 'nkeys: invalid encoded key' (caught, not thrown)", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    mocks.fetchNatsUserJWT.mockRejectedValue(new Error("nkeys: invalid encoded key"));
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-connect", "");

    const r = results(frames)[0].p;
    expect(r).toMatchObject({ command: "connect", success: false, code: "E_CONNECT" });
    expect(String(r.error)).toMatch(/nkeys/i);
    expect(mocks.saveConfig).not.toHaveBeenCalled(); // no config written on failure
  });

  // (iii) /vchat-status with stale creds stays graceful (presence-based: it
  // does NOT exercise the seed, so it can't detect staleness — documented).
  it("/vchat-status with stale creds → online:false result (no crash; presence-based, does not validate seed)", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS); // creds present (seed never used here)
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "status", success: true, data: { online: false } });
  });

  // (iv) /vchat-claim-status with stale creds → 'approved' by PRESENCE (creds
  // file exists). Staleness is only detectable at connect. Documented gap.
  it("/vchat-claim-status with stale creds → 'approved' by presence (staleness surfaces only at connect)", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS);
    mocks.hasPendingFlag.mockReturnValue(false);
    const { commands } = harness();

    const frames = await runCmd(commands, "vchat-claim-status", "");

    expect(results(frames)[0].p).toMatchObject({ command: "claim_status", success: true, data: { state: "approved" } });
  });
});

// ── ALSO: claim_received EVENT — locally simulatable? ────────────────────────
// The event fires when a message arrives on SubjectTree.CLAIM(nkey)
// (= tenant.<tenant>.claim.<nkey>); in production vgate publishes there on
// human approval. Answer for the coverage matrix: the PENDING *state* is
// locally simulatable via the ~/.vchat/.pending flag (hasPendingFlag — covered
// in J3b); the claim_received *event* is NOT simulated by the flag — it needs a
// CLAIM-subject message. It IS locally simulatable without the production vgate
// path: drive the nc.subscribe async-iterator with a synthetic message (below).
// No production-code change needed (the inline handler is reached via the mocked
// nc subscription); the event has no local side effect beyond emitEvent (notify).
describe("ALSO: claim_received event (locally simulatable via CLAIM-subject message)", () => {
  it("fires claim_received when a message arrives on the CLAIM subscription (no real vgate)", async () => {
    // PENDING agent: no steward yet — the claim subscription only exists
    // pre-claim (claimed-agent JWTs carry no claim grant; the runtime skips
    // the sub when a steward is recorded — vmaker claim-wait fix).
    mocks.loadCredentials.mockResolvedValue({ ...CREDS, steward: "" });
    const nc = fakeNc();
    // CLAIM subscription yields exactly one message, then completes:
    nc.subscribe.mockReturnValue({
      unsubscribe() {},
      [Symbol.asyncIterator]() {
        let yielded = false;
        return {
          next: async () => {
            if (!yielded) { yielded = true; return { value: {}, done: false as const }; }
            return { done: true as const, value: undefined };
          },
        };
      },
    });
    mocks.fetchNatsUserJWT.mockResolvedValue("JWT");
    mocks.connectViaJWT.mockResolvedValue(nc);
    mocks.startPresence.mockReturnValue({ stop: async () => {} });
    mocks.subA2A.mockReturnValue(undefined);
    mocks.watchDirectory.mockReturnValue({ directory: { snapshot: () => [] }, stop: () => {} });

    const { commands } = harness();
    const frames = await runCmd(commands, "vchat-connect", "");
    // the claim IIFE is async + fire-and-forget — flush a macrotask so it drains
    await new Promise((r) => setTimeout(r, 10));

    const evt = frames.find((f) => f.p.kind === "claim_received");
    expect(evt).toBeTruthy();
    expect(evt!.p).toMatchObject({ kind: "claim_received", nkey: CREDS.public_key });
  });
});

// ── DOGFOOD: static-creds mode (vmaker leaf / v3.1 site-fabrics) ────────────
describe("static-creds: embedded jwt skips vgate fetch + refresh timer", () => {
  it("session_start with creds.jwt connects WITHOUT fetchNatsUserJWT or refresh timer", async () => {
    mocks.loadCredentials.mockResolvedValue({ ...CREDS, jwt: "STATIC-JWT-abc" });
    mocks.readConfig.mockResolvedValue({ segment: "vmaker", server: "nats://leaf:14222", vgateUrl: "https://unused" });
    stubRuntimeSuccess();
    const { handlers } = harness();

    await handlers.get("session_start")!({ reason: "startup" }, { hasUI: false, ui: { notify() {} } });

    // vgate was NEVER touched — no fetch (the refresh timer only ever
    // refreshes THROUGH that fetch, so not-called covers the whole vgate path):
    expect(mocks.fetchNatsUserJWT).not.toHaveBeenCalled();
    // prod connect still used (SDK's own client, JWT+seed challenge-response):
    expect(mocks.connectViaJWT).toHaveBeenCalledWith("nats://leaf:14222", expect.any(Function), expect.any(String), expect.any(String));
    // the provider closure yields the STATIC jwt:
    const provider = mocks.connectViaJWT.mock.calls[0][1] as () => string;
    expect(provider()).toBe("STATIC-JWT-abc");
    // segment switched to the site's segment:
    expect(mocks.setTenantSegment).toHaveBeenCalledWith("vmaker");
  });

  it("creds WITHOUT jwt keep the vgate flow (no behavior change)", async () => {
    mocks.loadCredentials.mockResolvedValue(CREDS); // no jwt field
    mocks.readConfig.mockResolvedValue({ segment: "s1", server: "srv1", vgateUrl: "vg1" });
    stubRuntimeSuccess();
    const { handlers } = harness();

    await handlers.get("session_start")!({ reason: "startup" }, { hasUI: false, ui: { notify() {} } });

    expect(mocks.fetchNatsUserJWT).toHaveBeenCalledWith("vg1", expect.any(String), expect.any(String));
  });
});
