/**
 * contracts.test.ts — J0.0 contracts surface verification.
 *
 * Covers the four J0.0 deliverables:
 *  (1) AgentAnnouncement schema (additionalProperties:false) + canonical-JSON
 *      stability + nkeys kp.sign signing (NO new dep).
 *  (2) V3 subject templates (discovery / trade / app / audit) — build emits
 *      every param, shapes match docs/AGENT_NETWORK_SEGMENT_FABRIC.md §1.1.
 *  (3) PERMISSIONS deny-by-default typed const (compiled shape).
 *  (4) KV_BUCKETS == nats-init's 24-bucket list.
 */
import { describe, it, expect } from "vitest";
import { Value } from "@sinclair/typebox/value";
import { nkeys } from "@nats-io/nats-core";
import {
  AgentAnnouncement,
  ANNOUNCEMENT_FIELD_ORDER,
  canonicalAnnouncementBytes,
  signAnnouncement,
  TradeReceipt,
  TRADE_FIELD_ORDER,
  canonicalTradeBytes,
  tradeReceiptSubject,
  KV_BUCKETS,
  PERMISSIONS,
  SUBJECT_ROOT,
  V3DiscoverySubject,
  V3TradeSubject,
  V3AuditTradeSubject,
  V2ClaimSubject,
  V2PendingSubject,
  setTenantSegment,
  discoverySubWildcard,
} from "../../src/contracts/contracts.js";

const validAnnouncement = {
  ts: "2026-08-05T12:00:00.000Z",
  name: "worker-1",
  nkey: "UD3XYZ",
  segment: "vclaw",
  capabilities: ["code", "search"],
  online: true,
  model: "gpt-4o",
  sdk_version: "0.8.0",
};

// ── (1) AgentAnnouncement schema ───────────────────────────────
describe("AgentAnnouncement schema", () => {
  it("accepts a valid announcement", () => {
    expect(Value.Check(AgentAnnouncement, validAnnouncement)).toBe(true);
  });

  it("rejects unknown fields (additionalProperties:false)", () => {
    expect(Value.Check(AgentAnnouncement, { ...validAnnouncement, sig: "nope" })).toBe(false);
    expect(Value.Check(AgentAnnouncement, { ...validAnnouncement, extra: 1 })).toBe(false);
  });

  it("rejects a missing required field", () => {
    const { online, ...missing } = validAnnouncement;
    expect(Value.Check(AgentAnnouncement, missing)).toBe(false);
  });

  it("rejects wrong-typed fields", () => {
    expect(Value.Check(AgentAnnouncement, { ...validAnnouncement, online: "yes" })).toBe(false);
    expect(Value.Check(AgentAnnouncement, { ...validAnnouncement, capabilities: "code" })).toBe(false);
  });
});

// ── (1) canonical-JSON stability (byte-strict) ─────────────────
describe("canonicalAnnouncementBytes (byte-strict stability)", () => {
  it("emits keys in ANNOUNCEMENT_FIELD_ORDER", () => {
    const json = JSON.parse(new TextDecoder().decode(canonicalAnnouncementBytes(validAnnouncement)));
    expect(Object.keys(json)).toEqual([...ANNOUNCEMENT_FIELD_ORDER]);
  });

  it("same object → identical bytes across two serializations", () => {
    const a = canonicalAnnouncementBytes(validAnnouncement);
    const b = canonicalAnnouncementBytes(validAnnouncement);
    expect(Buffer.from(a).equals(Buffer.from(b))).toBe(true);
  });

  it("byte-identical to a pinned canonical string (catches field reorders)", () => {
    const bytes = canonicalAnnouncementBytes(validAnnouncement);
    const expected = '{"ts":"2026-08-05T12:00:00.000Z","name":"worker-1","nkey":"UD3XYZ","segment":"vclaw","capabilities":["code","search"],"online":true,"model":"gpt-4o","sdk_version":"0.8.0"}';
    expect(new TextDecoder().decode(bytes)).toBe(expected);
  });

  it("sig is excluded from the canonical input", () => {
    // a sig field attached to the object is dropped (not in FIELD_ORDER)
    const bytes = canonicalAnnouncementBytes({ ...validAnnouncement, sig: "DEADBEEF" } as never);
    const decoded = new TextDecoder().decode(bytes);
    expect(decoded).not.toContain("sig");
    expect(decoded).not.toContain("DEADBEEF");
  });
});

// ── (1) signAnnouncement (nkeys kp.sign, no new dep) ───────────
describe("signAnnouncement (nkeys kp.sign)", () => {
  const kp = nkeys.createUser();
  const seed = new TextDecoder().decode(kp.getSeed());
  const pub = kp.getPublicKey();

  it("produces a signature verifiable with the public nkey", async () => {
    const sig = await signAnnouncement(validAnnouncement, seed);
    const verifier = nkeys.fromPublic(pub);
    expect(verifier.verify(canonicalAnnouncementBytes(validAnnouncement), sig)).toBe(true);
  });

  it("is deterministic — same seed + object → identical sig bytes", async () => {
    const s1 = await signAnnouncement(validAnnouncement, seed);
    const s2 = await signAnnouncement(validAnnouncement, seed);
    expect(Buffer.from(s1).equals(Buffer.from(s2))).toBe(true);
  });

  it("fails to verify over tampered bytes", async () => {
    const sig = await signAnnouncement(validAnnouncement, seed);
    const verifier = nkeys.fromPublic(pub);
    const tampered = { ...validAnnouncement, online: false };
    expect(verifier.verify(canonicalAnnouncementBytes(tampered), sig)).toBe(false);
  });
});

// ── (2) V3 subject templates ───────────────────────────────────
describe("V3 subject templates", () => {
  it("discovery: pub pinned per-agent, sub segment-scoped", () => {
    expect(V3DiscoverySubject.build({ segment: "vclaw", nkey: "NKEY" }))
      .toBe("$SRV.INFO.agents.vclaw.NKEY");
    expect(discoverySubWildcard("vclaw"))
      .toBe("$SRV.INFO.agents.vclaw.>");
  });

  it("trade: emits verb + conv with .req for all three verbs (no swallowed param)", () => {
    for (const verb of ["offer", "commit", "settle"] as const) {
      expect(V3TradeSubject.build({ tenant: "default", verb, conv: "C1" }))
        .toBe(`${SUBJECT_ROOT}.trade.${verb}.C1.req`);
    }
  });

  it("audit: sub-only wildcard surface", () => {
    expect(V3AuditTradeSubject.build({ tenant: "default" })).toBe(`${SUBJECT_ROOT}.audit.trade.>`);
  });

  it("claim/pending: pre-claim subjects ignore segment mutation (base tenant always)", () => {
    // Regression (2026-08-18): setTenantSegment('vchat') used to re-scope
    // CLAIM/PENDING builds via SUBJECT_ROOT — subscribing tenant.vchat.claim.X
    // instead of the granted/published tenant.default.claim.X (server-side
    // PermissionViolation that killed pi). Pre-claim subjects must honor the
    // tenant param and never the mutable segment root.
    setTenantSegment("vchat");
    try {
      expect(V2ClaimSubject.build({ tenant: "default", nkey: "NK" })).toBe("tenant.default.claim.NK");
      expect(V2PendingSubject.build({ tenant: "default", nkey: "NK" })).toBe("tenant.default.pending.NK");
      expect(V2ClaimSubject.wildcard).toBe("tenant.default.claim.>");
    } finally {
      setTenantSegment("");
    }
  });
});

// ── (3) PERMISSIONS deny-by-default typed const ────────────────
describe("PERMISSIONS (deny-by-default typed const)", () => {
  it("exposes the expected roles", () => {
    expect(Object.keys(PERMISSIONS).sort()).toEqual(
      ["CLAIMED_AGENT", "HUMAN_DASHBOARD", "SITE_MESH", "UNCLAIMED_AGENT"].sort(),
    );
  });

  it("every role carries a deny list (deny-by-default posture)", () => {
    for (const role of Object.keys(PERMISSIONS) as Array<keyof typeof PERMISSIONS>) {
      expect(PERMISSIONS[role].deny.length).toBeGreaterThan(0);
    }
  });

  it("CLAIMED_AGENT carries V3 discovery grants and DENIES the commerce plane (V3 deny-by-default)", () => {
    const pub = PERMISSIONS.CLAIMED_AGENT.pub as readonly string[];
    const sub = PERMISSIONS.CLAIMED_AGENT.sub as readonly string[];
    // V3 discovery IS granted: own-nkey pinned pub + segment-scoped sub.
    expect(pub).toContain("$SRV.INFO.agents.<segment>.<nkey>");
    expect(sub).toContain("$SRV.INFO.agents.<segment>.>");
    // V3 commerce plane is DENY-BY-DEFAULT (vgate token.go explicit deny,
    // ~L332-340): NO tenant.<seg>.trade.> / app.> pub, NO audit.trade.> sub.
    // (Set-equality with token.go asserted by v3-grants-conformance.test.ts.)
    expect(pub).not.toContain(`${SUBJECT_ROOT}.trade.>`);
    expect(pub).not.toContain(`${SUBJECT_ROOT}.app.>`);
    expect(sub).not.toContain(`${SUBJECT_ROOT}.audit.trade.>`);
  });

  // J5 FABRIC_AUDIT: the audit stream is fleet-service-written ONLY. Agents have
  // NEITHER pub NOR sub on audit — a forged receipt from a compromised agent
  // would corrupt the settlement ledger. Deny-by-default covers this (audit is
  // in neither grant list), but assert it explicitly so a future grant edit
  // can't silently open the hole.
  it("agents have NO grant (pub or sub) to audit subjects (fleet-service-written ONLY)", () => {
    const pub = PERMISSIONS.CLAIMED_AGENT.pub as readonly string[];
    const sub = PERMISSIONS.CLAIMED_AGENT.sub as readonly string[];
    for (const p of pub) {
      expect(p, `agent pub must not reach audit: ${p}`).not.toMatch(/audit/);
    }
    for (const s of sub) {
      expect(s, `agent sub must not reach audit: ${s}`).not.toMatch(/audit/);
    }
  });
});

// ── (3) TradeReceipt schema + canonicalTradeBytes (J5 FABRIC_AUDIT) ──
describe("TradeReceipt schema + canonicalTradeBytes", () => {
  const validReceipt = {
    receipt_id: "r-1",
    conversation_id: "c-1",
    kind: "offer",
    offerer_nkey: "UA3OFFERER",
    amount: "10.00",       // canonical DECIMAL STRING
    budget_cap_ref: "cap-monthly-100",
    offer_sig: "base64sig",
    fleet_sig: "base64fleet",
  };

  it("accepts a valid receipt", () => {
    expect(Value.Check(TradeReceipt, validReceipt)).toBe(true);
  });

  it("rejects unknown fields (additionalProperties:false)", () => {
    expect(Value.Check(TradeReceipt, { ...validReceipt, extra: 1 })).toBe(false);
  });

  it("rejects an invalid kind", () => {
    expect(Value.Check(TradeReceipt, { ...validReceipt, kind: "refund" })).toBe(false);
  });

  it("accepts all four kinds (offer/commit/settle/settle_fail)", () => {
    for (const kind of ["offer", "commit", "settle", "settle_fail"] as const) {
      expect(Value.Check(TradeReceipt, { ...validReceipt, kind })).toBe(true);
    }
  });

  it("rejects a missing required field", () => {
    const { fleet_sig, ...missing } = validReceipt;
    expect(Value.Check(TradeReceipt, missing)).toBe(false);
  });

  it("rejects a numeric amount (must be a DECIMAL STRING)", () => {
    expect(Value.Check(TradeReceipt, { ...validReceipt, amount: 10 })).toBe(false);
  });

  it("canonicalTradeBytes emits TRADE_FIELD_ORDER keys", () => {
    const json = JSON.parse(new TextDecoder().decode(canonicalTradeBytes(validReceipt)));
    expect(Object.keys(json)).toEqual([...TRADE_FIELD_ORDER]);
  });

  it("byte-identical to a pinned canonical string (catches reorders)", () => {
    const bytes = canonicalTradeBytes(validReceipt);
    const expected = '{"receipt_id":"r-1","conversation_id":"c-1","kind":"offer","offerer_nkey":"UA3OFFERER","amount":"10.00","budget_cap_ref":"cap-monthly-100"}';
    expect(new TextDecoder().decode(bytes)).toBe(expected);
  });

  it("sig fields are EXCLUDED from the canonical input", () => {
    const decoded = new TextDecoder().decode(canonicalTradeBytes(validReceipt));
    expect(decoded).not.toContain("offer_sig");
    expect(decoded).not.toContain("fleet_sig");
  });

  it("tradeReceiptSubject builds tenant.<seg>.audit.trade.<kind>.<conv>.<id>", () => {
    expect(tradeReceiptSubject("default", validReceipt))
      .toBe("tenant.default.audit.trade.offer.c-1.r-1");
  });
});

// ── (4) KV_BUCKETS == nats-init's list ─────────────────────────
describe("KV_BUCKETS == nats-init's list (24 buckets)", () => {
  // Ground truth: the KV buckets declared in vgate/cmd/nats-init/main.go —
  // the `buckets` slice (22) PLUS the createKVMissing section (vizshow pair) = 24.
  // 2026-10-24: the census was widened from the old 18-name list to ALL of
  // nats-init (the 6 missing: invite_codes, npub_bindings, segment_members,
  // session_revoked, vizshow, vizshow_queue); A2A_NONCE_POOL was removed
  // (phantom — nats-init creates no such bucket/stream).
  const natsInitBuckets = [
    "vchat_ownership",
    "vchat_agent_pubkeys",
    "vchat_pending",
    "vchat_pending_hashes",
    "vchat_capabilities",
    "vchat_heartbeat",
    "vchat_fleet_status",
    "vchat_a2a_follows",
    "vchat_roster",
    "vchat_humans",
    "vchat_budgets",
    "vchat_myagents_room",
    "vchat_tenants",
    "vchat_segment_policy",
    "vchat_invites",
    "vchat_retired",
    "vchat_room_sessions",
    "vchat_delegations",
    "vchat_segment_members",
    "vchat_npub_bindings",
    "vchat_invite_codes",
    "vchat_session_revoked",
    "vchat_vizshow",
    "vchat_vizshow_queue",
  ];

  const declaredBuckets = (): string[] =>
    Object.values(KV_BUCKETS)
      .map((b) => (b as { bucket?: string }).bucket)
      .filter((n): n is string => typeof n === "string");

  it("every nats-init bucket is declared in KV_BUCKETS", () => {
    const declared = new Set(declaredBuckets());
    for (const name of natsInitBuckets) {
      expect(declared, `missing KV bucket: ${name}`).toContain(name);
    }
  });

  it("declared KV bucket count == nats-init (24)", () => {
    expect(declaredBuckets().length).toBe(natsInitBuckets.length);
  });

  it("no duplicate bucket names", () => {
    const names = declaredBuckets();
    expect(new Set(names).size).toBe(names.length);
  });
});
