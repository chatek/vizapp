/**
 * export/import round-trip tests (B12, L1-G7).
 *
 * Tests the pure encode/decode contract on the credentials bundle:
 *   export: credentials.json + identity seed → single-line base64
 *   import: base64 → validated credentials + identity seed
 * Uses a real generated NKey pair (keygen) so the seed validation in
 * decodeBundle is exercised against a genuine NATS NKey seed.
 */

import { describe, it, expect } from "vitest";
import { generateNkeyPair } from "../../src/lib/keygen.js";
import { encodeBundle, decodeBundle, BUNDLE_FORMAT, LEGACY_BUNDLE_FORMAT, BUNDLE_VERSION } from "../../src/commands/export.js";
import type { StoredCredentials } from "../../src/types.js";

/** Build a realistic StoredCredentials from a generated keypair. */
async function makeCreds(): Promise<StoredCredentials> {
  const kp = await generateNkeyPair();
  return {
    seed: kp.seed,
    public_key: kp.publicKey,
    agent_nkey: kp.publicKey,
    name: "test-agent",
    steward: "tester@vchat.email",
    created_at: new Date().toISOString(),
  };
}

describe("export/import bundle round-trip", () => {
  it("encodes a full bundle (credentials + identity seed) and decodes it back", async () => {
    const creds = await makeCreds();
    const serverSeed = creds.seed; // onboard writes the same seed to identity.seed

    const b64 = encodeBundle(creds, serverSeed);

    // Single line, base64 alphabet only (pipe-safe for `export | import`).
    expect(b64).toMatch(/^[A-Za-z0-9+/=]+$/);
    expect(b64).not.toContain("\n");

    const out = decodeBundle(b64);
    expect(out.format).toBe(BUNDLE_FORMAT);
    expect(out.version).toBe(BUNDLE_VERSION);
    expect(out.credentials).toEqual(creds);
    expect(out.server_seed).toBe(serverSeed);
    expect(out.exported_at).toBeTruthy();
  });

  it("tolerates a missing identity seed (server_seed null) on the source machine", async () => {
    const creds = await makeCreds();
    const out = decodeBundle(encodeBundle(creds, null));
    expect(out.server_seed).toBeNull();
    expect(out.credentials.seed).toBe(creds.seed);
  });

  it("import-side fallback: when server_seed is null, credentials.seed is used", async () => {
    const creds = await makeCreds();
    const out = decodeBundle(encodeBundle(creds, null));
    const effectiveSeed = out.server_seed ?? out.credentials.seed;
    expect(effectiveSeed).toBe(creds.seed);
  });

  it("rejects empty input", () => {
    expect(() => decodeBundle("")).toThrow(/empty bundle/);
    expect(() => decodeBundle("   ")).toThrow(/empty bundle/);
  });

  it("rejects non-bundle base64 (garbage JSON)", () => {
    const b64 = Buffer.from(JSON.stringify({ foo: "bar" })).toString("base64");
    expect(() => decodeBundle(b64)).toThrow(/not a vclaw-agent-bundle \(or legacy vchat-agent-bundle\)/);
  });

  it("rejects a wrong format marker", () => {
    const payload = JSON.stringify({ format: "other-bundle", version: 1, credentials: {} });
    expect(() => decodeBundle(Buffer.from(payload).toString("base64"))).toThrow(/not a vclaw-agent-bundle \(or legacy vchat-agent-bundle\)/);
  });

  it("rejects an unsupported version", () => {
    const payload = JSON.stringify({ format: BUNDLE_FORMAT, version: 99, credentials: {} });
    expect(() => decodeBundle(Buffer.from(payload).toString("base64"))).toThrow(/unsupported bundle version/);
  });

  it("rejects a bundle missing credentials.seed", () => {
    const payload = JSON.stringify({
      format: BUNDLE_FORMAT,
      version: BUNDLE_VERSION,
      credentials: { public_key: "UFAKE" },
    });
    expect(() => decodeBundle(Buffer.from(payload).toString("base64"))).toThrow(/missing credentials.seed/);
  });

  it("rejects a bundle with a corrupt NKey seed (decode fails)", async () => {
    const creds = await makeCreds();
    const bad = {
      format: BUNDLE_FORMAT,
      version: BUNDLE_VERSION,
      credentials: { ...creds, seed: "SNOTANKEY" },
      server_seed: null,
      exported_at: new Date().toISOString(),
    };
    expect(() => decodeBundle(Buffer.from(JSON.stringify(bad)).toString("base64"))).toThrow();
  });
});

describe("bundle format marker — Wave-1 dual-read", () => {
  it("encodes with the NEW vclaw magic and round-trips", async () => {
    const creds = await makeCreds();
    const b64 = encodeBundle(creds, null);
    const out = decodeBundle(b64);
    expect(out.format).toBe(BUNDLE_FORMAT);
    expect(out.format).toBe("vclaw-agent-bundle");
  });

  it("accepts a LEGACY vchat-magic bundle for import (pre-Wave-1 compat)", async () => {
    const creds = await makeCreds();
    const legacy = JSON.stringify({
      format: LEGACY_BUNDLE_FORMAT,
      version: BUNDLE_VERSION,
      credentials: creds,
      server_seed: null,
      exported_at: new Date().toISOString(),
    });
    const out = decodeBundle(Buffer.from(legacy).toString("base64"));
    expect(out.credentials.public_key).toBe(creds.public_key);
    expect(out.format).toBe("vchat-agent-bundle");
  });

  it("rejects an unknown magic listing both accepted markers", async () => {
    const bogus = JSON.stringify({ format: "someone-elses-bundle", version: 1 });
    expect(() => decodeBundle(Buffer.from(bogus).toString("base64"))).toThrow(
      /vclaw-agent-bundle \(or legacy vchat-agent-bundle\)/
    );
  });
});
