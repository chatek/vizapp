# agent-sdk Test Cases

> Test plan for `@vclawhub/agent` — E2E onboarding pipeline, NATS fabric integration,
> roster KV, and A2A messaging.
> Architecture: `a2a-net` + `nats-contracts` **inlined** into `agent-sdk/src/net/` and
> `agent-sdk/src/contracts/` (Option A — single publishable package, no internal deps).
> Last updated: 2026-07-28

---

## Phase 0 — E2E Test: Onboard pi Agent onto vchat IDP

**Goal:** End-to-end verification of the agent onboarding lifecycle against vchat3
production fabric. Covers onboard → connect → roster write → heartbeat → prompt/A2A
subscriptions → drain cleanup → offline recovery.

**Environment:**
```
Test machine:   this laptop (Mac, Tailscale → vchat3)
NATS server:    nats://vchat3:4223 (production, vgate auth callout enabled)
vgate API:      https://api.vclawhub.com  (healthy ✅ v0.7.0)
Agent under test: local checkout, run via `npx tsx src/cli.ts`
                 (compiled dist/ available at agent-sdk/dist/)
Existing creds: ~/.vchat/credentials.json (stale, unclaimed — needs --force)
```

### 0.1 Test script

```bash
#!/bin/bash -e
set -e
cd agent-sdk

# ── 1. Fresh onboard (force overwrite stale) ──────────────────────
echo "=== 1. Onboard agent ==="
npx tsx src/cli.ts onboard \
  --email "chance.jiang@outlook.com" \
  --name "e2e-test-agent" \
  --force
# → browser opens to agents.vclawhub.com/a/<session_id>
# → HUMAN: approve the claim in browser
# → creds saved to ~/.vchat/credentials.json
# → seed written to ~/.config/pi-a2a/identity.seed

echo "=== 2. Verify credentials ==="
cat ~/.vchat/credentials.json | python3 -m json.tool

echo "=== 3. Start agent (V2 lifecycle) ==="
# Blocks until SIGINT. In a second terminal: verify steps 4-6.
npx tsx src/cli.ts start --server nats://vchat3:4223

echo "=== 4. Verify roster entry ==="
# From second terminal, while agent is running:
#   ssh vchat3 "nats kv get vchat_roster <PUBKEY> --server nats://vchat3:4223"
# Expected: {"name":"e2e-test-agent","segment":"default","steward":"..."}

echo "=== 5. Verify heartbeat ==="
# From second terminal:
#   nats sub tenant.default.user.<PUBKEY>.agent.<PUBKEY>.hb \
#     --server nats://vchat3:4223 --timeout 35
# Expected: {"agent":"e2e-test-agent","status":"online","ts":"...","interval_s":30}

echo "=== 6. Ctrl+C → verify drain cleanup ==="
# Kill agent → verify:
#   ssh vchat3 "nats kv get vchat_roster <PUBKEY> --server nats://vchat3:4223"
# Expected: "not found"

echo "=== 7. Reconnect test ==="
# Restart agent, then Ctrl+C again:
#   nats kv get → first written, then deleted
```

### 0.2 Test cases

| # | Step | Command | Verifier | Human? | Status |
|---|------|---------|----------|--------|--------|
| T0.1 | Install pi.dev | `npm i -g @earendil-works/pi-coding-agent` | `which pi` | ❌ | ⬜ Needs run |
| T0.2 | Onboard agent | `npx tsx src/cli.ts onboard --force` | `~/.vchat/credentials.json` exists, NKey fields populated | 🟡 Browser approve | ⬜ Needs run |
| T0.3 | Credential integrity | After claim: inspect creds JSON | `steward`, `agent_nkey`, `seed` all populated | ❌ | ⬜ Needs run |
| T0.4 | Start agent | `npx tsx src/cli.ts start --server nats://vchat3:4223` | NATS connected, no errors, blocks cleanly | ❌ | ⬜ Needs run |
| T0.5 | Roster write | `nats kv get vchat_roster <nkey>` on vchat3 | Entry `{name, segment, steward}` matches agent | ❌ | ⬜ Needs run |
| T0.6 | Heartbeat | `nats sub tenant.default.user.<nkey>.agent.<nkey>.hb --timeout 35` | JSON with `status:"online"` received within 30s | ❌ | ⬜ Needs run |
| T0.7 | Prompt subscription | `nats pub "tenant.default.user.<nkey>.agent.<nkey>.prompt" '{"messages":[{"role":"user","content":"ping"}],"reply_to":"test"}'` | Agent logs "📨 Prompt from test" | ❌ | ⬜ Needs run |
| T0.8 | A2A subscription | `nats pub "tenant.default.a2a.<nkey>" '{"type":"a2a_request","id":"t1","prompt":"hello","from":{"nkey":"test"},"ts":"..."}'` | Agent logs "📨 A2A from test" | ❌ | ⬜ Needs run |
| T0.9 | SIGINT drain | Ctrl+C on running agent | Roster entry deleted, `nc.drain()` completes | ❌ | ⬜ Needs run |
| T0.10 | Reconnect | Restart agent after drain | Roster entry recreated | ❌ | ⬜ Needs run |
| T0.11 | Offline cleanup | `kill -9` agent → wait 120s → verify | Roster entry deleted via `nc.closed()` handler | ❌ | ⬜ Needs run |

### 0.3 Pass criteria

**MVP (4 of 11 pass = core pipeline works):**
```
T0.2  ✅ onboard generates creds
T0.5  ✅ roster entry written on start
T0.6  ✅ heartbeat received within 35s
T0.9  ✅ roster cleanup on SIGINT drain
```

**Full (11 of 11 = production ready):**
```
T0.1–T0.3  ✅ Install → onboard → claim
T0.4–T0.8  ✅ Start → roster → HB → prompt → A2A
T0.9–T0.11 ✅ SIGINT drain → reconnect → offline cleanup
```

### 0.4 Blockers and risks

| Risk | Impact | Mitigation |
|------|--------|------------|
| vgate `introduce` endpoint fails | T0.2 blocked | Check `curl https://api.vclawhub.com/.well-known/agent-idp` |
| No human to approve claim in browser | T0.2 stuck | Use `--no-wait` mode, print URL, approve later |
| NATS auth callout rejects NKey | T0.4 fails | Verify `tenant.default.claim.<nkey>` was published by approve flow |
| `vchat_roster` KV missing from vchat3 | T0.5 fails | Already verified exists (P3). Re-check: `nats kv ls` on vchat3 |
| Tailscale tunnel down | All NATS tests fail | `ssh vchat3` must work first |
| Server URL mismatch (`ws://` vs `nats://`) | T0.4 silent fail | start.ts defaults to `ws://vchat3:4224`. Test with `nats://vchat3:4223` explicitly |

---

## Phase 1 — Unit Tests (agent-sdk/src/net/)

### 1.1 roster.ts — CRUD operations

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T1.1 | `setRosterEntry` writes to KV | `nkey="test123"`, `{ name:"test", segment:"default", steward:"dev" }` | Entry exists in `vchat_roster` KV, fields match | ✅ `A2A/a2a-net/__tests__/smoke.test.ts` |
| T1.2 | `getRosterEntry` reads back | Same nkey | Returned entry matches written data | ✅ `smoke.test.ts` |
| T1.3 | `deleteRosterEntry` removes | Previously written nkey | Entry no longer exists | ✅ `smoke.test.ts` |
| T1.4 | `listRoster` returns all | 3 entries written | Array of 3 entries | ✅ `smoke.test.ts` |
| T1.5 | `getRosterEntry` on missing key | nkey that was never written | `null` (no throw) | ✅ `smoke.test.ts` |
| T1.6 | `deleteRosterEntry` on missing key | nkey already deleted | No error (best-effort) | ✅ `smoke.test.ts` |
| T1.7 | Roster write without NATS connection | No nc | Logs warning, no throw | ⬜ Needs test |

### 1.2 connect.ts — Fabric connection

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T1.8 | `connectToFabric` with valid token | Local NATS URL + server.seed token | Returns FabricConnection with nc, fabricId, identity | ✅ `smoke.test.ts` |
| T1.9 | `disconnectFromFabric` cleanup | Active FabricConnection | nc drained, subs unsubscribed | ⬜ Needs test |
| T1.10 | `connectToFabrics` multiple | Array of valid + invalid URLs | Returns only successful connections, logs failures | ⬜ Needs test |

### 1.3 reply.ts — Reply routing

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T1.11 | `replySubjectV2` format | owner="chance", name="worker3" | `tenant.default.a2a.reply.chance.worker3` | ✅ `smoke.test.ts` |
| T1.12 | `sendResponse` publishes chunks | Valid nc + replySubject | Two messages: response chunk + empty terminator | ⬜ Needs test |
| T1.13 | `setupReplySubscription` parses response | Published chunk with conversationId | pendingResponses resolved | ⬜ Needs test |

### 1.4 a2a.ts — A2A messaging

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T1.14 | `a2aSubjectV2` format | nkey="Uabc123" | `tenant.default.a2a.Uabc123` | ✅ `smoke.test.ts` |
| T1.15 | `a2aSend` publishes to correct subject | targetNkey, prompt, from, replySubject | Message received on `tenant.default.a2a.<targetNkey>` | ⬜ Needs test |
| T1.16 | `subA2A` catches messages | Published a2a_request | Handler called with parsed envelope | ⬜ Needs test |

### 1.5 heartbeat.ts — Heartbeat

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T1.17 | `hbSubjectV2` format | nkey="Uabc123" | `tenant.default.user.Uabc123.agent.Uabc123.hb` | ⬜ Needs test |
| T1.18 | `startHeartbeat` publishes periodically | Valid nc + identity | 2 heartbeats received within 2x interval | ⬜ Needs test |
| T1.19 | Stop function stops heartbeats | Call returned stopHb fn | No heartbeats after stop | ⬜ Needs test |

---

## Phase 2 — Integration Tests (agent-sdk)

### 2.1 start.ts — Full agent lifecycle

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T2.1 | Agent starts without credentials | No `~/.config/vchat/creds.json` | Error: "No credentials found" | ⬜ Needs test |
| T2.2 | Agent connects via NKey | Valid creds file with seed + nkey | NATS connected, client_id logged | ⬜ Needs test |
| T2.3 | Roster entry written on connect | Agent starts successfully | `vchat_roster.<nkey>` exists with {name, segment, steward} | ⬜ Needs test |
| T2.4 | Heartbeat starts | `--no-heartbeat` NOT set | Heartbeat received on `*.hb` subject within 30s | ⬜ Needs test |
| T2.5 | Heartbeat skipped when flagged | `--no-heartbeat` set | No heartbeats received | ⬜ Needs test |
| T2.6 | Prompt subscription active | `--no-prompt` NOT set | Subscription on `*.prompt.>` subject | ⬜ Needs test |
| T2.7 | A2A subscription active | `--no-a2a` NOT set | Subscription on `*.a2a.<nkey>.>` subject | ⬜ Needs test |
| T2.8 | Agent drains gracefully | Ctrl+C / SIGINT | Roster entry deleted, nc drained | ⬜ Needs test |
| T2.9 | Roster entry deleted on unexpected close | Kill agent process | `vchat_roster.<nkey>` deleted within 120s (closed() handler) | ⬜ Needs test |

### 2.2 lifecycle.ts — a2a-net re-exports

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T2.10 | All a2a-net exports available | Import from `../agent/lifecycle.js` | All 15 exports resolve at runtime | ⬜ Needs test |
| T2.11 | Backward compat aliases | `A2AHandler`, `A2AMessage` types | Resolve without compile error | ✅ `tsc --noEmit` |

---

## Phase 3 — E2E Tests (Full Pipeline)

### 3.1 Onboard → Connect → Roster → A2A

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T3.1 | Full agent lifecycle against vchat3 | `onboard --email test@vchat.email --name e2e-test` | Agent onboards, connects, writes roster, subscribes to prompts/A2A | ⬜ Manual |
| T3.2 | Cross-agent A2A works | Two agents on same segment | Agent A sends request → Agent B receives → Agent B responds | ⬜ Manual |
| T3.3 | Roster discovery works | Two agents on same segment | Agent A lists roster → finds Agent B's entry | ⬜ Manual |
| T3.4 | Agent drain cleans roster | Kill one of two agents | Roster entry deleted within 120s | ⬜ Manual |
| T3.5 | Reconnect restores roster | Restart the killed agent | Roster entry recreated on connect | ⬜ Manual |

### 3.2 Stress Tests (Bug Regression)

| # | Test | Scenario | Bug | Expected | Status |
|---|-------|----------|-----|----------|--------|
| T3.6 | Single-slot busy response | 3 parallel tasks to same agent | B1 | First processed, remaining get "busy" | ✅ Implemented |
| T3.7 | createInbox reply routing | a2a_sync single message to agent | B3 | Response received via ephemeral inbox, no timeout | ✅ Implemented |
| T3.8 | Per-target serialization | 3 tasks to agent A + 3 to agent B | B4 | A's tasks sequential, B's tasks sequential, cross-target concurrent | ✅ Implemented |
| T3.9 | TTL expiry on stale slot | Agent LLM hangs >30s | B1 | pendingReply auto-expires, next request gets slot | ✅ Implemented |
| T3.10 | pendingSyncReply priority | Sync message + chain active simultaneously | B2 | Sync response delivered before chain response | ✅ Implemented |

---

## Phase 4 — Compatibility Tests

### 4.1 Extension coexistence

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T4.1 | pi-a2a + a2a-net both symlinked | Both extensions in `~/.pi/agent/extensions/` | pi loads without error, a2a-net defers to pi-a2a | ✅ Verified |
| T4.2 | a2a-net standalone (no pi-a2a) | Remove pi-a2a symlink | a2a-net activates, connects to NATS, registers a2anet_send tool | ⬜ Needs test |

### 4.2 V1→V2 subject migration

| # | Test | Input | Expected | Status |
|---|------|-------|----------|--------|
| T4.3 | pi-a2a V1 subjects still work | Send to `agents.a2a.pi.*` | Message delivered (direct pub/sub still works) | ✅ 198/200 tests pass |
| T4.4 | a2a-net V2 subjects work | Send to `tenant.default.a2a.*` | Message delivered | ⬜ Needs test |

---

## Running Tests

```bash
# Unit tests (agent-sdk — includes inlined net/ + contracts/)
cd agent-sdk && npx vitest run

# pi-a2a test suite
cd A2A/pi-a2a && bun test

# Compilation checks (all 3 packages)
cd agent-sdk && npx tsc --noEmit
cd A2A/a2a-net && npx tsc --noEmit
cd A2A/pi-a2a && npx tsc --noEmit

# E2E test (requires access to vchat3 NATS)
# See Phase 0
```

## Current Test Status

| Suite | Tests | Pass | Fail | Date |
|-------|-------|------|------|------|
| pi-a2a | 200 | 198 | 2 (V1→V2 artifacts) | 2026-07-28 |
| agent-sdk | 63 | 63 | 0 | 2026-07-28 |
| a2a-net smoke | 9 | 9 | 0 | 2026-07-28 |

---

## Legend

| Symbol | Meaning |
|--------|---------|
| ✅ | Test exists and passes |
| ⬜ | Test not yet written |
| 🟡 | Manual test (requires vchat3 fabric) |
