/**
 * mint-nats-user-jwt.ts — G1 LIVE-JWT mint helper (v9 W0.5 scope 1).
 *
 * Two-step G1 live run:
 *   1) MINT:  bun test/helpers/mint-nats-user-jwt.ts [--creds <path>] [--vgate-url <url>] [--out <path>]
 *      → prints the NATS user JWT (or writes it to --out; mode 0600)
 *   2) PROBE: bun test/helpers/g1-perm-probe.ts --jwt <that-token-or-file> --segment <seg> --nkey <pub>
 *
 * Reads ~/.config/vclaw/credentials.json (canonical; the store's legacy tiers
 * + VCLAW_CREDS_DIR override are honored via store.loadCredentials) or
 * --creds <path>. Calls vgate /v1/agent/token through the EXACT production
 * path — src/agent/lifecycle.ts fetchNatsUserJWT (REUSED, not copied: the
 * NKey-signed client_assertion, 3x-backoff retry and error surfacing all live
 * there; the SDK's own start.ts and rpc/server.ts call the same function).
 *
 * Vgate URL resolution mirrors src/commands/start.ts:
 *   --vgate-url > VCLAW_API_URL/VCHAT_API_URL (env "API_URL") >
 *   VCLAW_VGATE_URL/VCHAT_VGATE_URL (env "VGATE_URL") > https://api.vclawhub.com
 */
import { fetchNatsUserJWT } from "../../src/agent/lifecycle.js";
import { loadCredentials } from "../../src/lib/store.js";
import { env } from "../../src/env.js";
import type { StoredCredentials } from "../../src/types.js";
import { readFile, writeFile } from "node:fs/promises";
import { fromSeed } from "@nats-io/nkeys";
import { homedir } from "node:os";
import { join } from "node:path";

export const DEFAULT_VGATE_URL = "https://api.vclawhub.com";

/** Canonical credentials path (informational — store.ts owns the real read order). */
export function defaultCredsHint(): string {
  return join(homedir(), ".config", "vclaw", "credentials.json");
}

/** Vgate URL precedence — mirrors src/commands/start.ts exactly. */
export function resolveVgateUrl(flag?: string): string {
  return flag || env("API_URL") || env("VGATE_URL") || DEFAULT_VGATE_URL;
}

function validateOrThrow(creds: StoredCredentials, src: string): StoredCredentials {
  if (!creds.seed || !creds.seed.startsWith("S") || creds.seed.length !== 58) {
    throw new Error(`invalid seed in ${src} — expected an encoded 58-char "SU…" nkey seed string`);
  }
  try {
    fromSeed(new TextEncoder().encode(creds.seed));
  } catch {
    throw new Error(`invalid seed in ${src} — nkeys.fromSeed rejected it`);
  }
  const nkey = creds.public_key || creds.agent_nkey;
  if (!nkey) {
    throw new Error(`credentials in ${src} carry no public key (public_key/agent_nkey both missing)`);
  }
  return creds;
}

/**
 * Load stored credentials: --creds <path> (validated: JSON + nkey-seed shape +
 * a public key present), else the canonical store tiers. Throws a clear error
 * when nothing is available.
 */
export async function readCredentials(credsPath?: string): Promise<StoredCredentials> {
  if (credsPath) {
    let raw: string;
    try {
      raw = await readFile(credsPath, "utf8");
    } catch (e) {
      throw new Error(`cannot read credentials file ${credsPath}: ${(e as Error).message}`);
    }
    let parsed: StoredCredentials;
    try {
      parsed = JSON.parse(raw) as StoredCredentials;
    } catch {
      throw new Error(`credentials file ${credsPath} is not valid JSON`);
    }
    return validateOrThrow(parsed, credsPath);
  }
  const creds = await loadCredentials();
  if (!creds) {
    throw new Error(
      `no credentials found — run 'vclaw-agent onboard' first or pass --creds ` +
        `(looked in ${defaultCredsHint()} + legacy tiers)`,
    );
  }
  return creds;
}

/**
 * Mint the NATS user JWT for stored credentials: delegate to the production
 * fetchNatsUserJWT (vgate /v1/agent/token with an NKey-signed
 * client_assertion). The assertion principal is the REAL public key
 * (public_key || agent_nkey) — vgate mints JWT perms for the pub; agent_nkey
 * is a legacy session id whose perms mismatch (runtime.ts identityFromCreds
 * comment, start.ts). Mirrors src/commands/start.ts + src/rpc/server.ts.
 */
export async function mintNatsUserJwt(creds: StoredCredentials, vgateUrl: string): Promise<string> {
  return fetchNatsUserJWT(vgateUrl, creds.public_key || creds.agent_nkey, creds.seed);
}

function argValue(name: string): string | undefined {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

if (import.meta.main) {
  try {
    const creds = await readCredentials(argValue("--creds"));
    const url = resolveVgateUrl(argValue("--vgate-url"));
    const out = argValue("--out");
    const jwt = await mintNatsUserJwt(creds, url);
    if (out) {
      await writeFile(out, jwt + "\n", { encoding: "utf8", mode: 0o600 });
      console.error(`[mint] NATS user JWT written → ${out}`);
    } else {
      console.log(jwt);
    }
  } catch (e) {
    console.error(`[mint] failed: ${(e as Error).message}`);
    process.exit(1);
  }
}
