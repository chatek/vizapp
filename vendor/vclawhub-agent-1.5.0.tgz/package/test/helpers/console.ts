/**
 * Console capture helper for testing CLI output.
 *
 * Intercepts stdout/stderr writes so tests can assert on
 * log output without polluting the test runner's terminal.
 */

type ConsoleFn = (typeof console)["log" | "error" | "warn"];

export interface CapturedConsole {
  stdout: string[];
  stderr: string[];
  warn: string[];
}

/**
 * Replace console.log / console.error / console.warn with capture functions.
 * Returns the capture buffer and a restore function.
 *
 * @example
 *   const { stdout, stderr, restore } = captureConsole();
 *   myFunction();
 *   expect(stdout).toContain("✅ Success");
 *   restore();
 */
export function captureConsole(): CapturedConsole & { restore: () => void } {
  const captured: CapturedConsole = { stdout: [], stderr: [], warn: [] };

  const origLog = console.log;
  const origError = console.error;
  const origWarn = console.warn;

  console.log = (...args: unknown[]) => {
    captured.stdout.push(args.map(String).join(" "));
  };

  console.error = (...args: unknown[]) => {
    captured.stderr.push(args.map(String).join(" "));
  };

  console.warn = (...args: unknown[]) => {
    captured.warn.push(args.map(String).join(" "));
  };

  return {
    ...captured,
    restore: () => {
      console.log = origLog;
      console.error = origError;
      console.warn = origWarn;
    },
  };
}
