import type { NkeyPair, StoredCredentials } from "../../src/types.js";

/** Sample generated Nkey pair for use in tests. */
export const SAMPLE_NKEY_PAIR: NkeyPair = {
  seed: "SAAN6C4WZ5C6O655VMRKRR2J2ZTO5W6FTGJGH7XW7RNZP5A7E7MOGFCI",
  publicKey: "PAAVS6Z7D3Z5GXJ5VZ6G5Z6G5Z6G5Z6G5Z6G5Z6G5Z6G5Z6G5Z6G5Z6GA",
  rawSeed: new Uint8Array(32).fill(1),
  rawPublicKey: new Uint8Array(32).fill(2),
  hexPublicKey: "aabb".repeat(8),
};

/** Sample stored credentials representing an onboarded agent. */
export const SAMPLE_CREDENTIALS: StoredCredentials = {
  seed: SAMPLE_NKEY_PAIR.seed,
  public_key: SAMPLE_NKEY_PAIR.publicKey,
  agent_nkey: "AAGENT1234567890",
  name: "test-agent",
  template: "researcher",
  steward: "test@vchat.email",
  created_at: "2026-01-01T00:00:00.000Z",
};
