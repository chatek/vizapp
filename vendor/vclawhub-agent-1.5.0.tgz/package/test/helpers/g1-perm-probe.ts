/**
 * g1-perm-probe.ts — v9 G1 grant-reach probe (UPGRADE.md §5 G1, W0 deliverable 5).
 *
 * QUESTION: is the v9 family lane
 *   tenant.<seg>.user.<nkey>.agent.<nkey>.family.>        (wildcard claim)
 *   tenant.<seg>.user.<nkey>.agent.<nkey>.family.<fid>.<name>.<verb>
 * inside the minted claimed-agent JWT allow-list — BOTH pub + sub?
 *
 * Two modes:
 *  1. STRUCTURAL (always available): probe the TS mirror of the grant source —
 *     contracts.ts PERMISSIONS.CLAIMED_AGENT (asserted set-equal to vgate
 *     token.go DeriveClaimedPermissions by test/unit/v3-grants-conformance.test.ts,
 *     the R2 collapse). This fills the probe table TODAY.
 *  2. LIVE JWT (needs a claimed-agent credential): `--jwt <file-or-JWT>` decodes
 *     the real nats JWT payload and probes its actual allow-list. Without it the
 *     JWT-verified column reads "PENDING — needs claimed-agent JWT".
 *
 * Matching semantics = nats-server token authorization:
 *   `*` matches exactly one token; `>` (grant side) matches one-or-more
 *   remaining tokens; a `>` on the PROBED subject matches only a `>` in the
 *   grant at the same depth (a wildcard subscription is authorized literally
 *   against the grant tokens, or is swallowed by a grant `>` covering it).
 *
 * CLI: bun test/helpers/g1-perm-probe.ts [--jwt <path|JWT>] [--segment s]
 *            [--nkey n] [--family-id id] [--name name] [--conversation-id c]
 *
 * TWO-STEP LIVE RUN (W0.5): mint the claimed-agent user JWT, then probe it.
 *   1) bun test/helpers/mint-nats-user-jwt.ts [--creds ~/.config/vclaw/credentials.json] [--out /tmp/agent.jwt]
 *   2) bun test/helpers/g1-perm-probe.ts --jwt /tmp/agent.jwt --segment <seg> --nkey <pub>
 * (mint reuses src/agent/lifecycle.ts fetchNatsUserJWT — the production vgate
 *  /v1/agent/token path; see mint-nats-user-jwt.ts for URL/creds resolution.)
 */
import { PERMISSIONS } from "../../src/contracts/contracts.js";
import {
  FAMILY_STATIC_VERBS,
  familyReplyVerb,
  sanitizeToken,
} from "../../src/contracts/contracts.js";

// ── NATS token matching ───────────────────────────────────────

/**
 * Does `grant` (a permission token string) authorize `subject` (a concrete
 * subject OR a wildcard subscription subject)? Mirrors nats-server auth
 * tokenization (see module doc): `*` = one token, `>` = 1+ remaining.
 */
export function matchGrant(grant: string, subject: string): boolean {
  if (grant === subject) return true;
  const g = grant.split(".");
  const s = subject.split(".");
  for (let i = 0; i < g.length; i++) {
    if (g[i] === ">") return i < s.length; // grant `>` swallows 1+ remaining
    if (i >= s.length) return false;
    if (g[i] === "*") continue; // grant `*` = exactly this one token
    if (g[i] !== s[i]) return false;
  }
  return g.length === s.length;
}

const firstMatch = (grants: string[], deny: string[], subject: string): string | null => {
  if (deny.some((d) => matchGrant(d, subject))) return null;
  return grants.find((g) => matchGrant(g, subject)) ?? null;
};

// ── Grant sources ─────────────────────────────────────────────

export interface JwtGrants {
  pubAllow: string[];
  pubDeny: string[];
  subAllow: string[];
  subDeny: string[];
}

/** Normalize <segment>/<nkey> placeholder grants to concrete subjects. */
export function substitutePlaceholders(grant: string, segment: string, nkey: string): string {
  return grant.replaceAll("<segment>", segment).replaceAll("<nkey>", nkey);
}

/**
 * STRUCTURAL grant source: PERMISSIONS.CLAIMED_AGENT instantiated for a
 * (segment, nkey). Valid AS the minted JWT's allow-list only because
 * v3-grants-conformance.test.ts pins this mirror to token.go — the R2 collapse.
 */
export function claimedAgentGrants(segment: string, nkey: string): JwtGrants {
  const s = (g: string) => substitutePlaceholders(g, segment, nkey);
  return {
    pubAllow: PERMISSIONS.CLAIMED_AGENT.pub.map(s),
    pubDeny: [...PERMISSIONS.CLAIMED_AGENT.deny],
    subAllow: PERMISSIONS.CLAIMED_AGENT.sub.map(s),
    subDeny: [...PERMISSIONS.CLAIMED_AGENT.deny],
  };
}

/** Decode a nats JWT (header.payload.sig, base64url) → its pub/sub grants. */
export function extractJwtGrants(jwt: string): JwtGrants | null {
  const parts = jwt.trim().split(".");
  if (parts.length !== 3) return null;
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8")) as Record<string, unknown>;
  } catch {
    return null;
  }
  const nats = (payload["nats"] ?? {}) as Record<string, unknown>;
  // Real vgate-minted JWTs (POST /v1/agent/token → token.go DeriveClaimedPermissions)
  // carry the NATS user-JWT schema: nats.{pub,sub} = { allow, deny }. The
  // structural mirror (contracts.ts) used nats.perms/permissions in early
  // drafts — accept both shapes (G1 live 2026-09-07).
  const perms = (nats["perms"] ?? nats["permissions"] ?? nats) as Record<string, unknown> | null;
  if (!perms || !("pub" in perms)) return null;
  const allow = (v: unknown): string[] =>
    Array.isArray(v) ? (v as string[]) : Array.isArray((v as { allow?: string[] })?.allow) ? (v as { allow: string[] }).allow : [];
  const deny = (v: unknown): string[] =>
    Array.isArray((v as { deny?: string[] })?.deny) ? (v as { deny: string[] }).deny : [];
  return {
    pubAllow: allow(perms["pub"]),
    pubDeny: deny(perms["pub"]),
    subAllow: allow(perms["sub"]),
    subDeny: deny(perms["sub"]),
  };
}

// ── The probe ─────────────────────────────────────────────────

export interface ProbeOptions {
  segment: string;
  nkey: string;
  familyId: string;
  name: string;
  conversationId?: string;
}

export interface ProbeRow {
  plane: "pub" | "sub";
  claim: string;
  allowed: boolean;
  matchedGrant: string | null;
}

/**
 * Every family-lane claim G1 must authorize, pub + sub.
 *
 * Subjects are built EXPLICITLY for opts.segment — a probe must NOT read the
 * probing process's runtime SUBJECT_ROOT global (this module may run under
 * tenant.default while probing a mint for any segment). Mirrors
 * FamilySubject.build token-for-token, with the segment taken from opts.
 */
export function familyProbeClaims(opts: ProbeOptions): Array<{ plane: "pub" | "sub"; subject: string }> {
  const conv = opts.conversationId ?? "conv-1";
  const verbs = [...FAMILY_STATIC_VERBS, familyReplyVerb(conv)];
  const prefix = `tenant.${opts.segment}.user.${opts.nkey}.agent.${opts.nkey}.family`;
  const rows: Array<{ plane: "pub" | "sub"; subject: string }> = [
    { plane: "sub", subject: `${prefix}.>` }, // the wildcard claim itself
  ];
  for (const verb of verbs) {
    const subject = `${prefix}.${sanitizeToken(opts.familyId)}.${sanitizeToken(opts.name)}.${verb}`;
    rows.push({ plane: "pub", subject });
    rows.push({ plane: "sub", subject });
  }
  return rows;
}

/** Probe one grant set over every family-lane claim. */
export function probeFamilyGrants(grants: JwtGrants, opts: ProbeOptions): ProbeRow[] {
  return familyProbeClaims(opts).map(({ plane, subject }) => {
    const matched =
      plane === "pub"
        ? firstMatch(grants.pubAllow, grants.pubDeny, subject)
        : firstMatch(grants.subAllow, grants.subDeny, subject);
    return { plane, claim: subject, allowed: matched !== null, matchedGrant: matched };
  });
}

export const G1_PENDING = "PENDING — needs claimed-agent JWT";

/** Fixed-width probe table (the W0 deliverable artifact). */
export function formatProbeTable(rows: ProbeRow[]): string {
  const w = (label: string, get: (r: ProbeRow) => string) =>
    Math.max(label.length, ...rows.map((r) => get(r).length));
  const wp = w("plane", (r) => r.plane);
  const wc = w("claim", (r) => r.claim);
  const wa = w("allow?", (r) => (r.allowed ? "allow" : "DENY"));
  const wm = w("matched grant", (r) => r.matchedGrant ?? "—");
  const line = (cells: string[]) => cells.map((c, i) => c.padEnd([wp, wc, wa, wm][i])).join(" | ");
  const head = line(["plane", "claim", "allow?", "matched grant"]);
  const sep = "-".repeat(head.length);
  const body = rows.map((r) => line([r.plane, r.claim, r.allowed ? "allow" : "DENY", r.matchedGrant ?? "—"]));
  return [head, sep, ...body].join("\n");
}

/** Overall G1 verdict for a probe result. */
export function g1Verdict(rows: ProbeRow[], source: "structural" | "jwt"): string {
  const allAllowed = rows.every((r) => r.allowed);
  if (source === "jwt") return allAllowed ? "G1 PASS (live JWT verified)" : "G1 FAIL (live JWT denies family lane)";
  return allAllowed
    ? "G1 PASS (structural — PERMISSIONS.CLAIMED_AGENT mirror of token.go; live JWT: " + G1_PENDING + ")"
    : "G1 FAIL (structural mirror denies family lane — token.go widening + ruling required)";
}

// ── CLI ───────────────────────────────────────────────────────

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

if (import.meta.main) {
  const segment = arg("--segment") ?? "default";
  const nkey = arg("--nkey") ?? "U_CLAIMED_AGENT_NKEY";
  const familyId = arg("--family-id") ?? "00000000-0000-4000-8000-000000000000";
  const name = arg("--name") ?? "worker-a";
  const conversationId = arg("--conversation-id");
  const jwtArg = arg("--jwt");

  let grants: JwtGrants;
  let source: "structural" | "jwt";
  if (jwtArg) {
    const raw = jwtArg.startsWith("eyJ")
      ? jwtArg
      : await import("node:fs").then((fs) => fs.readFileSync(jwtArg, "utf8"));
    const decoded = extractJwtGrants(raw);
    if (!decoded) {
      console.error("could not decode a nats JWT (expected header.payload.sig base64url) from: " + jwtArg);
      process.exit(1);
    }
    grants = decoded;
    source = "jwt";
  } else {
    grants = claimedAgentGrants(segment, nkey);
    source = "structural";
  }
  const rows = probeFamilyGrants(grants, { segment, nkey, familyId, name, conversationId });
  console.log("# G1 perm-probe — v9 family lane grant reach");
  console.log("# source: " + (source === "jwt" ? "live claimed-agent JWT" : "structural mirror (PERMISSIONS.CLAIMED_AGENT)"));
  console.log(formatProbeTable(rows));
  console.log(g1Verdict(rows, source));
}
