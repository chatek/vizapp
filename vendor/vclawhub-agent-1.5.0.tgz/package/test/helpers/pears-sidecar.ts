/**
 * pears-sidecar.ts — shared helpers for the Tier P integration suites.
 *
 * Owns three things the suites need identically:
 *   1. TOOLCHAIN PROBE: node presence/version + built sidecar bundle. Node
 *      absence is a valid environment (plan §5b.2 — Tier W agent), but it
 *      must be VISIBLE, never a silent skip: p2p-toolchain.test.ts fails
 *      unless PEARS_SIDECAR_OPTIONAL=1 explicitly says "skip is intended".
 *   2. BUILD GUARD: rebuilds the sidecar when sources are newer than
 *      dist/main.js (npm ci if node_modules is missing — network needed on a
 *      fresh clone; documented in PROTOCOL.md + M2-BUILD).
 *   3. FIXTURES: random 32B root seeds, free UDP ports, delegation bundles.
 */
import { spawnSync } from "node:child_process";
import { existsSync, statSync, readdirSync } from "node:fs";
import { createSocket } from "node:dgram";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes } from "node:crypto";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SIDECAR_DIR = path.resolve(HERE, "../../src/net/p2p/sidecar");
export const SIDECAR_MAIN = path.join(SIDECAR_DIR, "dist", "main.js");

export interface Toolchain {
  nodeBin: string | null;
  nodeVersion: string | null;
  built: boolean;
  ok: boolean;
}

/** Probe the sidecar toolchain (never throws — callers decide visibility). */
export function toolchain(): Toolchain {
  const nodeBin = process.env.PEARS_NODE_BIN ?? "node";
  const probe = spawnSync(nodeBin, ["--version"], { encoding: "utf8", timeout: 5000 });
  const nodeVersion = probe.status === 0 ? probe.stdout.trim() : null;
  return {
    nodeBin: nodeVersion === null ? null : nodeBin,
    nodeVersion,
    built: existsSync(SIDECAR_MAIN),
    ok: nodeVersion !== null && existsSync(SIDECAR_MAIN),
  };
}

function sourcesNewerThanBuild(): boolean {
  if (!existsSync(SIDECAR_MAIN)) return true;
  const builtAt = statSync(SIDECAR_MAIN).mtimeMs;
  const srcDir = path.join(SIDECAR_DIR, "src");
  const queue = [srcDir];
  while (queue.length > 0) {
    const dir = queue.pop() as string;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) queue.push(full);
      else if (entry.name.endsWith(".ts") && statSync(full).mtimeMs > builtAt) return true;
    }
  }
  return false;
}

/**
 * Ensure the sidecar bundle exists and is fresh. Returns true when usable.
 * Installs from the committed lockfile when node_modules is missing.
 */
export function ensureSidecarBuilt(tc: Toolchain): boolean {
  if (!tc.nodeBin) return false;
  const needsInstall = !existsSync(path.join(SIDECAR_DIR, "node_modules"));
  const needsBuild = needsInstall || sourcesNewerThanBuild();
  if (needsInstall) {
    // npm ci keeps us honest against the committed package-lock.json.
    const install = spawnSync("npm", ["ci", "--no-audit", "--no-fund"], { cwd: SIDECAR_DIR, encoding: "utf8" });
    if (install.status !== 0) {
      throw new Error("sidecar npm ci failed: " + String(install.stderr).slice(0, 400));
    }
  }
  if (needsBuild) {
    const build = spawnSync("npm", ["run", "build"], { cwd: SIDECAR_DIR, encoding: "utf8" });
    if (build.status !== 0) {
      throw new Error("sidecar build failed: " + String(build.stderr).slice(0, 400));
    }
  }
  return existsSync(SIDECAR_MAIN);
}

/** A free UDP port on 127.0.0.1 (for the private DHT seed). */
export async function freeUdpPort(): Promise<number> {
  const sock = createSocket("udp4");
  await new Promise<void>((resolve, reject) => {
    sock.once("error", reject);
    sock.bind(0, "127.0.0.1", () => {
      sock.off("error", reject);
      resolve();
    });
  });
  const port = sock.address().port;
  sock.close();
  return port;
}

/** Random 32B root seed — stands in for an agent's NKey raw seed. */
export function randomRootSeed(): Uint8Array {
  return new Uint8Array(randomBytes(32));
}

/** Random 32B content key — stands in for the console-minted encryptionKey. */
export function randomContentKey(): Uint8Array {
  return new Uint8Array(randomBytes(32));
}

/** Fresh per-test store dir (caller removes it; tests use their own tmp). */
export function storeDir(prefix: string): string {
  const dir = path.join("/tmp", "pears-m2-it", prefix + "-" + randomBytes(4).toString("hex"));
  return dir;
}

export const b64 = (u: Uint8Array): string => Buffer.from(u).toString("base64");
export const unb64 = (s: string): Uint8Array => new Uint8Array(Buffer.from(s, "base64"));
export const hex = (u: Uint8Array): string => Buffer.from(u).toString("hex");
