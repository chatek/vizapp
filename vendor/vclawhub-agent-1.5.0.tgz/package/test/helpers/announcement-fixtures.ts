/**
 * announcement-fixtures.ts — GOLDEN conformance fixtures for the agent
 * announcement schemas (v1 + v2), W0 deliverable 4 / gate G2.
 *
 * These are the byte-level contract between the TWO encoders:
 *   • TS  — agent-sdk src/contracts/contracts.ts
 *           (canonicalAnnouncementBytes / canonicalAnnouncementV2Bytes)
 *   • Go  — vgate/sidecar directory verifyAnnouncement mirror
 * The JSON strings below are PINNED LITERALS (not derived) — if an encoder
 * change makes a test fail against them, the encoder moved the bytes. Port
 * these strings to the Go golden test; do NOT re-derive them there.
 *
 * FIELD ORDER IS THE CANONICAL BYTE ORDER (see ANNOUNCEMENT_FIELD_ORDER /
 * ANNOUNCEMENT_V2_FIELD_ORDER). `sig` is never part of any canonical input.
 * Fixed `ts` values make the bytes deterministic.
 */

// ── v1 (pre-v9 wire — must stay byte-identical forever) ───────
export const V1_ANNOUNCEMENT = {
  ts: "2026-09-04T00:00:00.000Z",
  name: "lead-agent",
  nkey: "UBW1FIXTURENKEYPLACEHOLDER00",
  segment: "default",
  capabilities: ["code", "search"],
  online: true,
  model: "gpt-4o",
  sdk_version: "1.2.4",
} as const;

/** GOLDEN v1 canonical JSON (schema order, no extra whitespace). */
export const V1_CANONICAL_JSON =
  '{"ts":"2026-09-04T00:00:00.000Z","name":"lead-agent",'
  + '"nkey":"UBW1FIXTURENKEYPLACEHOLDER00","segment":"default",'
  + '"capabilities":["code","search"],"online":true,"model":"gpt-4o",'
  + '"sdk_version":"1.2.4"}';

// ── v2 (v9 families: `v`:2 discriminator + optional children[]) ──
export const V2_CHILDREN = [
  { name: "worker-a", role: "researcher", caps: ["code", "search"], state: "running" },
  { name: "worker-b", role: "reviewer", caps: [], state: "idle" },
] as const;

export const V2_ANNOUNCEMENT_WITH_CHILDREN = {
  v: 2,
  ts: "2026-09-04T00:00:00.000Z",
  name: "lead-agent",
  nkey: "UBW1FIXTURENKEYPLACEHOLDER00",
  segment: "default",
  capabilities: ["code", "search"],
  online: true,
  model: "gpt-4o",
  sdk_version: "1.2.4",
  children: V2_CHILDREN,
} as const;

/** GOLDEN v2 canonical JSON WITH children (children last, per child order name/role/caps/state). */
export const V2_CANONICAL_JSON_WITH_CHILDREN =
  '{"v":2,"ts":"2026-09-04T00:00:00.000Z","name":"lead-agent",'
  + '"nkey":"UBW1FIXTURENKEYPLACEHOLDER00","segment":"default",'
  + '"capabilities":["code","search"],"online":true,"model":"gpt-4o",'
  + '"sdk_version":"1.2.4",'
  + '"children":[{"name":"worker-a","role":"researcher","caps":["code","search"],"state":"running"},'
  + '{"name":"worker-b","role":"reviewer","caps":[],"state":"idle"}]}';

export const V2_ANNOUNCEMENT_NO_CHILDREN = {
  v: 2,
  ts: "2026-09-04T00:00:00.000Z",
  name: "lead-agent",
  nkey: "UBW1FIXTURENKEYPLACEHOLDER00",
  segment: "default",
  capabilities: ["code", "search"],
  online: true,
  model: "gpt-4o",
  sdk_version: "1.2.4",
} as const;

/** GOLDEN v2 canonical JSON WITHOUT children (undefined-skip: no children key). */
export const V2_CANONICAL_JSON_NO_CHILDREN =
  '{"v":2,"ts":"2026-09-04T00:00:00.000Z","name":"lead-agent",'
  + '"nkey":"UBW1FIXTURENKEYPLACEHOLDER00","segment":"default",'
  + '"capabilities":["code","search"],"online":true,"model":"gpt-4o",'
  + '"sdk_version":"1.2.4"}';

// ── SIGN VECTORS (gate: the SIGNING path is byte-pinned too, not just canonicalization) ──
//
// Why these exist: the canonical JSON literals above pin WHAT is signed; these pin the
// SIGNATURE, so a change to the nkeys codec, the ed25519 wiring, or the sign call's input
// fails here rather than silently producing announcements peers reject. Ed25519 (RFC 8032)
// is DETERMINISTIC, so a fixed seed + fixed bytes must always give these exact signatures —
// a mismatch means the signing path moved, never "randomness".
//
// ⚠ TEST-ONLY KEY. Generated for these vectors; it owns nothing, is registered nowhere, and
// must NEVER be used for a real identity. A review that finds it outside test/ is a defect.
export const SIGN_VECTOR_SEED = "SUAENCY455MSVODB5FLYIYUMEXO743XQ4YYATNEJKCDDI5M3VAXL23U5BU"; // TEST-ONLY
export const SIGN_VECTOR_PUBLIC = "UDWLHA46Z4ED24BMMZMJZ4XJYBYNCVBWP3PVOKRCW3UTEA6JTO6K2VK4";

/** base64-std signature (the wire encoding) of canonicalAnnouncementBytes(V1_ANNOUNCEMENT). */
export const V1_SIG =
  "XTXFgP3bhga0vW9rF/fy3A+LGYN9RJQHbkMyjoDsszN/Ovaj6nRS05U63q2RwoeE6LOH9MYDnrbWgeLrH/XOBw==";

/** base64-std signature of canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_WITH_CHILDREN). */
export const V2_SIG_WITH_CHILDREN =
  "atUQ1/IpNccWCngy+etDKU9zdrPcaHlivsmUpEPG4wmOtA29yoybD5hPdlROCnl7ShecdmpwY4uhoSefFboPDg==";

/** base64-std signature of canonicalAnnouncementV2Bytes(V2_ANNOUNCEMENT_NO_CHILDREN) — undefined-skip. */
export const V2_SIG_NO_CHILDREN =
  "BZsYoFRRjCqGeqTj81oDfip2SxaHkYInPHG0PHgYMgsqviJr3NBfj2P1Ezu+AC0uj2BeuRfPyi1khOG2CAo3AQ==";
