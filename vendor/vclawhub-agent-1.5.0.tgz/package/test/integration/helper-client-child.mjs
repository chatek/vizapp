/**
 * helper-client-child.mjs — one throwaway CLIENT process for
 * test/integration/p2p-helper-shared.test.ts.
 *
 * It exists to prove the 0.3.0 listen-mode property that cannot be shown
 * in-process: THREE SEPARATE OS PROCESSES share ONE sidecar helper (one
 * helper pid, one store lock) over the unix socket.
 *
 * argv[2] = path to an esbuild bundle of src/net/p2p/client.ts (the test
 * builds it; the sidecar's node deps are not needed for the client).
 * env: HELPER_SOCK, HELPER_STORE, HELPER_SEED_HEX, HELPER_LINGER_MS.
 *
 * Protocol (one JSON object per stdout line):
 *   {stage:"attached", pid, spawned, peer}      — after attachHelper resolves
 *   {stage:"stats", clients, rooms, pid}        — one reply per "stats" line
 *   {stage:"error", error, message}             — then exit 1
 * stdin: "stats" once per sample, "release" to detach and exit 0.
 */
import { createInterface } from "node:readline";

const bundlePath = process.argv[2];
if (bundlePath === undefined) {
  process.stdout.write(JSON.stringify({ stage: "error", error: "E_USAGE", message: "bundle path argv[2] required" }) + "\n");
  process.exit(2);
}

const print = (obj) => process.stdout.write(JSON.stringify(obj) + "\n");

const { attachHelper } = await import(bundlePath);

const seed = new Uint8Array(Buffer.from(process.env.HELPER_SEED_HEX ?? "", "hex"));
const socketPath = process.env.HELPER_SOCK;
const storeDir = process.env.HELPER_STORE;
const lingerMs = Number(process.env.HELPER_LINGER_MS ?? "30000");

let session;
try {
  session = await attachHelper({
    seed,
    socketPath,
    storeDir,
    lingerMs,
    bootTimeoutMs: Number(process.env.HELPER_BOOT_TIMEOUT_MS ?? "60000"),
    network: { bindHost: "127.0.0.1" },
  });
} catch (err) {
  print({ stage: "error", error: err?.code ?? "E_ATTACH", message: String(err?.message ?? err) });
  process.exit(1);
}

print({ stage: "attached", pid: session.helperPid, spawned: session.spawned, peer: session.peerPublicKey, client_pid: process.pid });

const rl = createInterface({ input: process.stdin });
rl.on("line", (line) => {
  const cmd = line.trim();
  if (cmd === "stats") {
    void session.client
      .stats()
      .then((s) => {
        print({ stage: "stats", clients: s.helperClients ?? null, rooms: s.rooms.length, pid: session.helperPid });
      })
      .catch((err) => print({ stage: "error", error: err?.code ?? "E_STATS", message: String(err?.message ?? err) }));
    return;
  }
  if (cmd === "release") {
    rl.close();
    void session.close().then(() => process.exit(0));
  }
});
rl.on("close", () => {
  void session.close().then(() => process.exit(0));
});
