/**
 * daemon-rehydrate.test.ts — INTEGRATION (v9 W1): daemon restart rehydrates
 * children from the family dir + session JSONL.
 *
 * Covers the W1 verify items: crash simulation (close WITHOUT cascade, then
 * workers killed) → restart on the same family dir → SAME roster (names/roles
 * survive), re-addressable by name (steer respawns the worker), transcript
 * continuity (both epochs in the session JSONL), family_id stable across
 * restarts; and the G6 graceful-close cascade (workers die with the daemon).
 */
import { describe, it, expect } from "vitest";
import { mkdtempSync, readFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServe, DaemonClient, pidAlive } from "../../src/daemon/index.js";

async function waitFor(pred: () => boolean | Promise<boolean>, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  const tick = async (): Promise<void> => {
    if (await pred()) return;
    if (Date.now() > deadline) throw new Error("waitFor timeout");
    await new Promise((r) => setTimeout(r, 50));
    return tick();
  };
  await tick();
}

describe("Tier L daemon restart + G6", () => {
  it("crash → restart: same roster, re-addressable by name, transcript continuity, stable family_id", async () => {
    const dir = mkdtempSync(join(tmpdir(), "vclaw-rehydrate-"));
    const serveA = await startServe({ familyDirOverride: dir, port: 0, replyDelayMs: 20 });
    const clientA = await DaemonClient.connect({ port: serveA.port });

    await clientA.spawn({ name: "w1", role: "researcher", prompt: "epoch one", conversationId: "c-rehyd-1" });
    const reply1 = await clientA.nextReply("c-rehyd-1");
    expect(reply1.text).toBe("done: epoch one");
    const pidA = (await clientA.panel()).workers.find((w) => w.name === "w1")?.pid!;
    expect(pidAlive(pidA)).toBe(true);

    // Crash simulation: the daemon dies WITHOUT its G6 cascade and WITHOUT
    // recording the child exits (hard crash — the exit handler never runs).
    // In-process limitation: serveA is alive, so first detach it, then kill the
    // orphaned children, then re-write w1.json as a stale Running record — the
    // exact disk state a hard-crashed daemon leaves behind (Running + pid gone).
    await clientA.close();
    await serveA.close({ cascade: false });
    await serveA.killWorkers("SIGKILL");
    await waitFor(() => !pidAlive(pidA), 3_000);
    const staleRec = {
      name: "w1",
      role: "researcher",
      state: "Running", // stale — the crashed daemon never recorded the exit
      pid: pidA,
      sessionFile: join(dir, "sessions", "w1.jsonl"),
      spawnedAt: new Date().toISOString(),
    };
    const { writeFileSync } = await import("node:fs");
    writeFileSync(join(dir, "workers", "w1.json"), JSON.stringify(staleRec, null, 2));

    // Restart on the same family dir — rehydration reads workers/*.json.
    const serveB = await startServe({ familyDirOverride: dir, port: 0, replyDelayMs: 20 });
    try {
      expect(serveB.familyId).toBe(serveA.familyId); // family_id persisted, not re-minted

      const clientB = await DaemonClient.connect({ port: serveB.port });
      try {
        // Same roster survives the restart; w1 was recovered Inactive (pid gone).
        const roster = (await clientB.panel()).workers;
        const w1 = roster.find((w) => w.name === "w1")!;
        expect(w1.name).toBe("w1");
        expect(w1.role).toBe("researcher");
        expect(w1.state).toBe("Inactive");
        expect(w1.note).toContain("recovered");

        // Re-address by name after restart — steer respawns and the reply
        // round-trips again (acceptance §7.3 shape).
        const steerAck = await clientB.steer({ name: "w1", prompt: "epoch two", conversationId: "c-rehyd-2" });
        expect(steerAck.receipt).toBe("delivered");
        expect(steerAck.message).toContain("respawned");
        const reply2 = await clientB.nextReply("c-rehyd-2");
        expect(reply2.text).toBe("[steered] epoch two");
        const pidB = (await clientB.panel()).workers.find((w) => w.name === "w1")?.pid!;
        expect(pidB).not.toBe(pidA); // fresh process, same identity
        await waitFor(() => !pidAlive(pidA), 1_000);

        // Transcript continuity: session JSONL holds BOTH epochs.
        const session = readFileSync(join(dir, "sessions", "w1.jsonl"), "utf8");
        expect(session).toContain("epoch one");
        expect(session).toContain("epoch two");
        expect(session).toContain('"type":"recover"');
      } finally {
        await clientB.close();
      }
    } finally {
      await serveB.close();
    }
  }, 25_000);

  it("graceful close cascades (G6): workers die with the daemon, daemon.json removed", async () => {
    const dir = mkdtempSync(join(tmpdir(), "vclaw-g6-"));
    const serve = await startServe({ familyDirOverride: dir, port: 0, replyDelayMs: 20 });
    const client = await DaemonClient.connect({ port: serve.port });
    await client.spawn({ name: "w1", prompt: "a", conversationId: "g6-1" });
    await client.spawn({ name: "w2", prompt: "b", conversationId: "g6-2" });
    const pids = (await client.panel()).workers.map((w) => w.pid!);
    expect(pids.length).toBe(2);
    expect(pids.every((p) => pidAlive(p))).toBe(true);
    await client.close();

    await serve.close(); // cascade default true

    // Both workers are gone with the daemon, and the liveness marker is cleaned.
    await waitFor(() => pids.every((p) => !pidAlive(p)), 3_000);
    await waitFor(() => !existsSync(join(dir, "daemon.json")), 2_000);
  }, 20_000);
});
