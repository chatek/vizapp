/**
 * daemon-roundtrip.test.ts — INTEGRATION (v9 W1): the Tier L daemon end to end
 * over a REAL loopback socket with a REAL stub-worker child process.
 *
 * Covers the W1 verify items: spawn → steer → reply round-trip; acks carrying
 * `receipt: delivered|queued`; conversation-scoped reply routing (G3 — replies
 * for different conversations never cross, no head-of-line FIFO); and the
 * Running/Idle/Inactive state transitions incl. re-address (steer of an
 * Inactive worker respawns it).
 *
 * No NATS involved: Tier L is a local socket (loopback TCP in these tests;
 * the daemon also serves a unix socket in production).
 */
import { describe, it, expect } from "vitest";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServe, DaemonClient, pidAlive } from "../../src/daemon/index.js";
import { Daemon } from "../../src/daemon/serve.js";

/** Poll a predicate until true or timeout (timing-tolerant; sync or async). */
async function waitFor(pred: () => boolean | Promise<boolean>, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  const tick = async (): Promise<void> => {
    if (await pred()) return;
    if (Date.now() > deadline) throw new Error("waitFor timeout");
    await new Promise((r) => setTimeout(r, 50));
    return tick();
  };
  await tick();
}

function tmpFamily(): string {
  return mkdtempSync(join(tmpdir(), "vclaw-daemon-"));
}

async function openDaemon(familyDir: string) {
  const serve = await startServe({ familyDirOverride: familyDir, port: 0, replyDelayMs: 20 });
  const client = await DaemonClient.connect({ port: serve.port });
  return { serve, client };
}

describe("Tier L daemon (socket + stub worker)", () => {
  it("spawn → ack(delivered) → reply → steer → reply round-trip; panel reflects states", async () => {
    const { serve, client } = await openDaemon(tmpFamily());
    try {
      const conv = "conv-roundtrip-1";
      const spawnAck = await client.spawn({ name: "w1", role: "coder", prompt: "first task", conversationId: conv });
      expect(spawnAck.receipt).toBe("delivered");
      expect(spawnAck.worker?.state).toBe("Running");
      expect(spawnAck.worker?.pid).toBeGreaterThan(0);
      expect(pidAlive(spawnAck.worker?.pid)).toBe(true);

      // Conversation-scoped reply routing: the reply comes back on conv.
      const reply1 = await client.nextReply(conv);
      expect(reply1.from).toBe("w1");
      expect(reply1.text).toBe("done: first task");
      expect(reply1.conversationId).toBe(conv);
      expect(reply1.receipt).toBe("delivered");

      // Worker finished its turn → Idle; steer re-runs it (mid-task follow-up).
      await waitFor(async () => (await client.panel()).workers.find((w) => w.name === "w1")?.state === "Idle", 3_000);
      const steerAck = await client.steer({ name: "w1", prompt: "turn left", conversationId: conv });
      expect(steerAck.receipt).toBe("delivered");
      expect(steerAck.worker?.state).toBe("Running");

      const reply2 = await client.nextReply(conv);
      expect(reply2.text).toBe("[steered] turn left");

      const panel = await client.panel();
      const w1 = panel.workers.find((w) => w.name === "w1")!;
      expect(w1.state).toBe("Idle"); // back on the rack after the steered turn
      expect(w1.role).toBe("coder");
      expect(w1.queuedReplies).toBe(0); // both replies were delivered, none queued
      expect(w1.lastReplyAt).toBeTruthy();
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);

  it("G3: two conversations on one worker never cross (client + router are conversation-scoped)", async () => {
    const { serve, client } = await openDaemon(tmpFamily());
    try {
      // One worker, two interleaved conversations. The stub answers in arrival
      // order, so convA\'s reply lands BEFORE convB\'s — but the convB waiter
      // must NOT consume it (no head-of-line FIFO).
      const convA = "conv-A";
      const convB = "conv-B";
      await client.spawn({ name: "w1", prompt: "alpha", conversationId: convA });
      await client.steer({ name: "w1", prompt: "beta", conversationId: convB });

      const gotB = await client.nextReply(convB); // asked for B while A\'s reply is in flight
      expect(gotB.conversationId).toBe(convB);
      expect(gotB.text).toBe("[steered] beta");

      const gotA = await client.nextReply(convA); // A\'s reply was buffered, never consumed by B
      expect(gotA.conversationId).toBe(convA);
      expect(gotA.text).toBe("done: alpha");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);

  it("state transitions: Running → Idle (task done) → stop → Inactive → steer respawns → kill", async () => {
    const { serve, client } = await openDaemon(tmpFamily());
    try {
      await client.spawn({ name: "w1", prompt: "work", conversationId: "conv-st" });
      await client.nextReply("conv-st");

      const state = async () => (await client.panel()).workers.find((w) => w.name === "w1")?.state;
      await waitFor(async () => (await state()) === "Idle", 3_000);

      // stop → Inactive (graceful; stub exits on {type:"stop"}).
      const stopAck = await client.stop("w1");
      expect(stopAck.receipt).toBe("delivered");
      await waitFor(async () => (await state()) === "Inactive", 3_000);

      // steer of an Inactive worker re-addresses it (respawn) — W1 reload-on-address.
      const steerAck = await client.steer({ name: "w1", prompt: "again", conversationId: "conv-st2" });
      expect(steerAck.receipt).toBe("delivered");
      expect(steerAck.message).toContain("respawned");
      const reply = await client.nextReply("conv-st2");
      expect(reply.text).toBe("[steered] again");
      await waitFor(async () => (await state()) === "Idle", 3_000);

      // kill → Inactive.
      await client.kill("w1");
      await waitFor(async () => (await state()) === "Inactive", 3_000);
      const panel = await client.panel();
      // Exact value, not `toContain("SIGTERM")`: the weaker form is satisfied by BOTH sides
      // of the race ("killed (SIGTERM)" from the kill path, "exited on SIGTERM" from the
      // child-exit handler), so it could not detect the second writer returning. The kill
      // path writes this note synchronously and alone, so it is the same string for every
      // observer at every time — that is the contract under test.
      expect(panel.workers.find((w) => w.name === "w1")?.note).toBe("killed (SIGTERM)");
      // Read once more: a still-present second writer would show up as a changed value
      // here (it runs when the child's exit event lands, which is after this point).
      const reread = await client.panel();
      expect(reread.workers.find((w) => w.name === "w1")?.note).toBe("killed (SIGTERM)");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);

  it("steering an unknown worker → E_NOT_FOUND; duplicate live spawn → E_DUPLICATE", async () => {
    const { serve, client } = await openDaemon(tmpFamily());
    try {
      await expect(client.steer({ name: "ghost", prompt: "hi" })).rejects.toThrow("E_NOT_FOUND");
      await expect(client.stop("ghost")).rejects.toThrow("E_NOT_FOUND");
      await client.spawn({ name: "w1", prompt: "x", conversationId: "c-dup" });
      await expect(client.spawn({ name: "w1", prompt: "y" })).rejects.toThrow("E_DUPLICATE");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);

  // Unit-level on purpose: the case below (a killed child whose `exit` event never fires)
  // cannot be produced through the stub driver — the stub installs no SIGTERM handler, so it
  // always exits. It IS reachable on the pi driver (pi.dev traps SIGTERM, and handleKill
  // never escalates to SIGKILL), so the guard has to drive onWorkerExit directly. Private
  // access is deliberate: this asserts the marker's INVARIANT, not serve.ts's internal shape.
  it("kill marker is generation-stamped: a never-drained marker cannot silence a later worker", () => {
    const dir = tmpFamily();
    const d = new Daemon(dir, "lead", {}) as unknown as {
      records: Map<string, { name: string; state: string; note?: string }>;
      generations: Map<string, number>;
      killedByRequest: Map<string, number>;
      onWorkerExit(n: string, gen: number, code: number | null, signal: string | null): void;
    };
    const record = (name: string, note: string) => ({
      name,
      state: "Running",
      sessionFile: join(tmpdir(), `${name}.jsonl`),
      note,
    });

    // Generation 1 was killed on request but its exit never arrived; the name was respawned
    // (generation 2), which then exits normally. The stale marker must not suppress it.
    d.records.set("w1", record("w1", "task turn complete"));
    d.generations.set("w1", 2);
    d.killedByRequest.set("w1", 1);
    d.onWorkerExit("w1", 2, 0, null);
    expect(d.records.get("w1")?.note).toBe("exited code 0");
    expect(d.records.get("w1")?.state).toBe("Inactive");

    // An exact-generation match still suppresses (the single-writer contract) and is drained
    // by its own exit, so the marker set stays bounded in the normal case.
    d.records.set("w2", record("w2", "killed (SIGTERM)"));
    d.generations.set("w2", 5);
    d.killedByRequest.set("w2", 5);
    d.onWorkerExit("w2", 5, null, "SIGTERM");
    expect(d.records.get("w2")?.note).toBe("killed (SIGTERM)");
    expect(d.killedByRequest.has("w2")).toBe(false);
  });
});
