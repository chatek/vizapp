/**
 * p2p-loopback.test.ts — THE M2 loopback gate (Pears Tier P).
 *
 * Two agents (in-process surfaces, each with its own node sidecar process),
 * ONE delegation, private offline DHT (no public network contact), roster
 * direct-dial (joinPeer), publish/subscribe round trip THROUGH THE SEAM
 * (AgentTransport — the same interface net/a2a.ts consumes via natsTransport).
 *
 * Proves:
 *   1. discovery+connection: agent B attaches with A's roster entry and
 *      connects (private DHT seed + joinPeer — never a public DHT);
 *   2. a2a-shaped subjects round-trip through p2pTransport: subscribe
 *      `tenant.default.a2a.<nkeyB>.>` on B, publish `...req` from A, receive
 *      {subject, data, reply:""} on B — byte-exact data;
 *   3. the reply leg (B -> A) also round-trips (bidirectional);
 *   4. unsubscribe stops delivery;
 *   5. THE Q5 PUBSUB ARM: a non-member (base key only, no content key) in the
 *      same room receives ZERO delivered messages and NO error — its frames
 *      are counted undecryptable and silently dropped (digest unverifiable);
 *   6. the digest header is present and correct on delivered messages.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { rmSync, mkdirSync } from "node:fs";
import path from "node:path";
import { SidecarClient, p2pTransport } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair, deriveWriterKeyPair } from "../../src/net/p2p/identity.js";
import { delegationTopic } from "../../src/net/p2p/topic.js";
import type { AgentTransport, TransportMessage } from "../../src/net/transport.js";
import { toolchain, ensureSidecarBuilt, freeUdpPort, randomRootSeed, randomContentKey, storeDir, b64, hex, unb64 } from "../helpers/pears-sidecar.js";

const tc = toolchain();
const delegationId = "dlg-loopback-m2";
const encKey = randomContentKey();

let clientA: SidecarClient | null = null;
let clientB: SidecarClient | null = null;
let clientC: SidecarClient | null = null; // the Q5 non-member
let transportA: AgentTransport | null = null;
let transportB: AgentTransport | null = null;
let dirA = "";
let dirB = "";
let dirC = "";
let baseKeyB64 = "";
let peerAPubHex = "";
let seedPort = 0;
let a2aSubjectB = "";

beforeAll(async () => {
  if (!tc.ok && !ensureSidecarBuilt(tc)) {
    throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
  }
  seedPort = await freeUdpPort();
  dirA = storeDir("loopA");
  dirB = storeDir("loopB");
  dirC = storeDir("loopC");
  for (const dir of [dirA, dirB, dirC]) mkdirSync(path.dirname(dir), { recursive: true });

  const seedA = randomRootSeed();
  const seedB = randomRootSeed();
  const seedC = randomRootSeed();
  const peerA = await derivePeerKeyPair(seedA);
  const peerB = await derivePeerKeyPair(seedB);
  const peerC = await derivePeerKeyPair(seedC);
  const writer = await deriveWriterKeyPair(seedA, delegationId);

  // Agent A: the delegation writer AND the private network seed.
  clientA = new SidecarClient();
  const helloA = await clientA.start({
    storeDir: dirA,
    peerKeyPair: peerA,
    network: { bindHost: "127.0.0.1", seedPort },
    bootTimeoutMs: 30000,
  });
  peerAPubHex = helloA.peer.publicKey;
  expect(helloA.dht.port).toBe(seedPort);

  const attachA = await clientA.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "writer",
    encryptionKey: b64(encKey),
    writerKeyPair: { publicKey: b64(writer.publicKey), secretKey: b64(writer.secretKey) },
  });
  baseKeyB64 = attachA.baseKey ?? "";

  // Agent B: reader-member, bootstrap at A's DHT, roster-dials A directly.
  clientB = new SidecarClient();
  await clientB.start({
    storeDir: dirB,
    peerKeyPair: peerB,
    network: { bindHost: "127.0.0.1", bootstrap: [{ host: "127.0.0.1", port: seedPort }] },
    bootTimeoutMs: 30000,
  });
  await clientB.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "reader",
    baseKey: baseKeyB64,
    encryptionKey: b64(encKey),
    peers: [{ publicKey: b64(unb64Hex(peerAPubHex)) }],
  });

  // Agent C: the Q5 non-member — base key ONLY, no content key, same room.
  clientC = new SidecarClient();
  await clientC.start({
    storeDir: dirC,
    peerKeyPair: peerC,
    network: { bindHost: "127.0.0.1", bootstrap: [{ host: "127.0.0.1", port: seedPort }] },
    bootTimeoutMs: 30000,
  });
  await clientC.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "reader",
    baseKey: baseKeyB64,
    peers: [{ publicKey: b64(unb64Hex(peerAPubHex)) }],
  });

  transportA = p2pTransport(clientA, delegationId);
  transportB = p2pTransport(clientB, delegationId);
}, 120000);

function unb64Hex(hexStr: string): Uint8Array {
  return new Uint8Array(Buffer.from(hexStr, "hex"));
}

afterAll(async () => {
  for (const client of [clientC, clientB, clientA]) {
    if (client) await client.stop().catch(() => undefined);
  }
  for (const dir of [dirA, dirB, dirC]) {
    if (dir) rmSync(dir, { recursive: true, force: true });
  }
});

describe("loopback two-agent delegation (seam round-trip)", () => {
  it(
    "agent B connects to agent A via roster joinPeer on the private net",
    async () => {
      expect(clientB).not.toBeNull();
      // Wait for at least one live channel to A from B.
      const deadline = Date.now() + 20000;
      let channels = 0;
      while (Date.now() < deadline) {
        const stats = await clientB!.stats();
        channels = stats.channels;
        if (channels >= 1) break;
        await new Promise((r) => setTimeout(r, 250));
      }
      expect(channels).toBeGreaterThanOrEqual(1);
    },
    30000,
  );

  it(
    "publish/subscribe round-trips through the SEAM with a2a-shaped subjects",
    async () => {
      const nkeyB = "UALOOPBACKAGENTB0000000000000000000000000000000000000000000000";
      a2aSubjectB = "tenant.default.a2a." + nkeyB;
      const received: TransportMessage[] = [];
      const sub = transportB!.subscribe(a2aSubjectB + ".>", {
        callback: (err, msg) => {
          expect(err).toBeNull();
          received.push(msg);
        },
      });

      // subscribe must be registered sidecar-side before the publish lands
      await new Promise((r) => setTimeout(r, 300));
      const payload = new TextEncoder().encode(JSON.stringify({ type: "a2a_request", id: "req-1", prompt: "loopback m2" }));
      transportA!.publish(a2aSubjectB + ".req", payload);

      const deadline = Date.now() + 15000;
      while (Date.now() < deadline && received.length === 0) {
        await new Promise((r) => setTimeout(r, 100));
      }
      expect(received).toHaveLength(1);
      expect(received[0].subject).toBe(a2aSubjectB + ".req");
      expect(Buffer.from(received[0].data)).toEqual(Buffer.from(payload)); // byte-exact
      expect(received[0].reply).toBe(""); // the seam's pinned runtime shape

      // unsubscribe stops delivery
      sub.unsubscribe();
      await new Promise((r) => setTimeout(r, 300));
      transportA!.publish(a2aSubjectB + ".req", payload);
      await new Promise((r) => setTimeout(r, 1200));
      expect(received).toHaveLength(1); // nothing new after unsubscribe
    },
    30000,
  );

  it(
    "the reply leg (B -> A) round-trips too (bidirectional)",
    async () => {
      const nkeyA = "UALOOPBACKAGENTA0000000000000000000000000000000000000000000000";
      const subjectA = "tenant.default.a2a." + nkeyA;
      const received: TransportMessage[] = [];
      transportA!.subscribe(subjectA + ".>", {
        callback: (err, msg) => {
          if (err === null) received.push(msg);
        },
      });
      await new Promise((r) => setTimeout(r, 300));
      const replyBytes = new TextEncoder().encode('{"type":"a2a_response","inReplyTo":"req-1"}');
      transportB!.publish(subjectA + ".ack", replyBytes);
      const deadline = Date.now() + 15000;
      while (Date.now() < deadline && received.length === 0) {
        await new Promise((r) => setTimeout(r, 100));
      }
      expect(received).toHaveLength(1);
      expect(received[0].subject).toBe(subjectA + ".ack");
      expect(Buffer.from(received[0].data)).toEqual(Buffer.from(replyBytes));
    },
    30000,
  );

  it(
    "Q5 pubsub arm: a non-member (base key only) receives ZERO messages, NO error",
    async () => {
      const deliveries: TransportMessage[] = [];
      let callbackError: Error | null = null;
      const transportC = p2pTransport(clientC!, delegationId);
      transportC.subscribe("tenant.default.a2a.>", {
        callback: (err, msg) => {
          if (err !== null) callbackError = err;
          else deliveries.push(msg);
        },
      });
      await new Promise((r) => setTimeout(r, 300));
      // C must actually be connected before the publish, else "received 0"
      // would prove nothing about silence.
      const connDeadline = Date.now() + 20000;
      while (Date.now() < connDeadline) {
        const stats = await clientC!.stats();
        if (stats.channels >= 1) break;
        await new Promise((r) => setTimeout(r, 250));
      }
      // A publishes into the room; C is connected and receives the FRAME but
      // cannot open it (no content key) — and must experience total silence.
      const payload = new TextEncoder().encode("member-only-payload");
      await clientA!.publish(delegationId, "tenant.default.a2a.anybody.req", "", payload);
      await new Promise((r) => setTimeout(r, 1500));
      expect(deliveries).toHaveLength(0); // zero plaintext deliveries
      expect(callbackError).toBeNull(); // no error — silent garbage is the mode
      const stats = await clientC!.stats();
      const room = stats.rooms.find((r) => r.delegationId === delegationId);
      expect(room).toBeDefined();
      expect(room!.received).toBeGreaterThanOrEqual(1); // the frame DID arrive
      expect(room!.undecryptable).toBeGreaterThanOrEqual(1); // and was dropped
      expect(room!.delivered).toBe(0);
    },
    30000,
  );

  it(
    "every delivered message carries a correct sha256 digest header",
    async () => {
      const { createHash } = await import("node:crypto");
      const digestSeen: string[] = [];
      const off = clientB!.onMessage((ev) => {
        if (ev.delegation === delegationId) digestSeen.push(ev.digest);
      });
      // B must hold a matching subscription for the delivery to happen.
      await clientB!.subscribe(delegationId, "tenant.default.a2a.dig.>");
      const payload = new TextEncoder().encode("digest-check");
      await clientA!.publish(delegationId, "tenant.default.a2a.dig.req", "", payload);
      await new Promise((r) => setTimeout(r, 1500));
      off();
      expect(digestSeen.length).toBeGreaterThanOrEqual(1);
      const envelope = JSON.stringify({ subject: "tenant.default.a2a.dig.req", reply: "", data: Buffer.from(payload).toString("base64") });
      const expected = createHash("sha256").update(envelope, "utf8").digest("hex");
      expect(digestSeen).toContain(expected);
    },
    30000,
  );
});
