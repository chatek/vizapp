/**
 * p2p-q5-negative.test.ts — the M0 Q5 gate, in M0's EXACT language (Pears M2).
 *
 * M0-SPIKE §Q5 measured: "a non-member peer that has the base key but NOT the
 * encryption key cannot read content" — with three nuances M2 must encode:
 *   (a) ZERO plaintext bytes at any position (the returned block contains no
 *       run of the known plaintext anywhere);
 *   (b) NO error thrown (silent garbage is the failure mode — download()
 *       resolves, get() returns bytes);
 *   (c) length metadata IS disclosed (remoteLen == 20 readable by key-holders
 *       without the encryptionKey).
 * And therefore: app-layer content digests are mandatory (the pubsub frame
 * layer carries them; this suite pins the CORE-side semantics).
 *
 * Method mirrors M0: writer core with 20 blocks of known plaintext
 * ("BLOCK-000-" + 80x"A"), fixed 32B encryptionKey; THREE readers in separate
 * sidecar processes, each given only its role would have:
 *   member {baseKey, encryptionKey} / non-member {baseKey} / wrongkey {baseKey, wrong 32B}.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { rmSync, mkdirSync } from "node:fs";
import path from "node:path";
import { SidecarClient } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair, deriveWriterKeyPair } from "../../src/net/p2p/identity.js";
import { delegationTopic } from "../../src/net/p2p/topic.js";
import { toolchain, ensureSidecarBuilt, freeUdpPort, randomRootSeed, randomContentKey, storeDir, b64 } from "../helpers/pears-sidecar.js";

const tc = toolchain();
const delegationId = "dlg-q5-m2";
const BLOCK_COUNT = 20;

function plaintextBlock(i: number): Uint8Array {
  const prefix = Buffer.from("BLOCK-" + String(i).padStart(3, "0") + "-", "utf8");
  return new Uint8Array(Buffer.concat([prefix, Buffer.alloc(80, "A".charCodeAt(0))]));
}

/** Start a writer sidecar (private-net seed) and append the known plaintext. */
async function startWriter(dir: string, seed: Uint8Array, encKey: Uint8Array, seedPort: number): Promise<{ client: SidecarClient; baseKey: string; peerPubHex: string }> {
  const client = new SidecarClient();
  const hello = await client.start({
    storeDir: dir,
    peerKeyPair: await derivePeerKeyPair(seed),
    network: { bindHost: "127.0.0.1", seedPort },
    bootTimeoutMs: 30000,
  });
  const writer = await deriveWriterKeyPair(seed, delegationId);
  const attach = await client.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "writer",
    encryptionKey: b64(encKey),
    writerKeyPair: { publicKey: b64(writer.publicKey), secretKey: b64(writer.secretKey) },
  });
  for (let i = 0; i < BLOCK_COUNT; i++) {
    await client.coreAppend(delegationId, plaintextBlock(i));
  }
  return { client, baseKey: attach.baseKey ?? "", peerPubHex: hello.peer.publicKey };
}

/** Start a reader sidecar with EXACTLY the inputs its role would have. */
async function startReader(dir: string, seed: Uint8Array, armPort: number, baseKey: string, encKeyB64: string | null, writerPubHex: string): Promise<SidecarClient> {
  const client = new SidecarClient();
  await client.start({
    storeDir: dir,
    peerKeyPair: await derivePeerKeyPair(seed),
    network: { bindHost: "127.0.0.1", bootstrap: [{ host: "127.0.0.1", port: armPort }] },
    bootTimeoutMs: 30000,
  });
  await client.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "reader",
    baseKey,
    encryptionKey: encKeyB64 ?? undefined,
    peers: [{ publicKey: b64(new Uint8Array(Buffer.from(writerPubHex, "hex"))) }],
  });
  return client;
}

const encKey = randomContentKey();
const wrongKey = new Uint8Array(32).fill(0x99);

describe("Q5 negative — encryptionKey is the read capability (M0 language)", () => {
  const dirs: string[] = [];
  const clients: SidecarClient[] = [];

  beforeAll(async () => {
    if (!tc.ok && !ensureSidecarBuilt(tc)) {
      throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
    }
    // per-arm ports are picked inside each test (see startWriter callers)
  }, 60000);

  afterAll(async () => {
    for (const client of clients.reverse()) await client.stop().catch(() => undefined);
    for (const dir of dirs) rmSync(dir, { recursive: true, force: true });
  });

  it(
    "member (baseKey + encryptionKey) reads byte-exact plaintext",
    async () => {
      const wDir = storeDir("q5w-member");
      const rDir = storeDir("q5r-member");
      dirs.push(wDir, rDir);
      mkdirSync(path.dirname(rDir), { recursive: true });
      const writerSeed = randomRootSeed();
      const armPort = await freeUdpPort();
      const writer = await startWriter(wDir, writerSeed, encKey, armPort);
      clients.push(writer.client);
      const reader = await startReader(rDir, randomRootSeed(), armPort, writer.baseKey, b64(encKey), writer.peerPubHex);
      clients.push(reader);
      const result = await reader.coreDownload(delegationId, BLOCK_COUNT, 30000);
      expect(result.reached).toBe(true);
      const block0 = await reader.coreGet(delegationId, 0);
      expect(block0).not.toBeNull();
      expect(Buffer.from(block0 as Uint8Array)).toEqual(Buffer.from(plaintextBlock(0))); // byte-exact
      await writer.client.stop().catch(() => undefined);
    },
    60000,
  );

  it(
    "NON-MEMBER (base key only): (a) zero plaintext at any position, (b) NO error, (c) length disclosed",
    async () => {
      const wDir = storeDir("q5w-non");
      const rDir = storeDir("q5r-non");
      dirs.push(wDir, rDir);
      mkdirSync(path.dirname(rDir), { recursive: true });
      const armPort = await freeUdpPort();
      const writer = await startWriter(wDir, randomRootSeed(), encKey, armPort);
      clients.push(writer.client);
      const reader = await startReader(rDir, randomRootSeed(), armPort, writer.baseKey, null, writer.peerPubHex);
      clients.push(reader);

      // (b) first: NOTHING throws — download resolves, len reads, get returns bytes
      const result = await reader.coreDownload(delegationId, BLOCK_COUNT, 30000);
      expect(result.reached).toBe(true); // the reader SAW the length and synced
      // (c) length metadata IS disclosed to a base-key holder
      const len = await reader.coreLen(delegationId);
      expect(len.len).toBe(BLOCK_COUNT);
      // (a) zero plaintext bytes at any position
      let checked = 0;
      for (let i = 0; i < BLOCK_COUNT; i++) {
        const block = await reader.coreGet(delegationId, i);
        expect(block).not.toBeNull();
        if (block === null) continue;
        const buf = Buffer.from(block);
        const expected = Buffer.from(plaintextBlock(i));
        expect(buf.equals(expected)).toBe(false); // not the plaintext
        for (let offset = 0; offset + 6 <= buf.length; offset++) {
          if (buf.subarray(offset, offset + 6).toString("utf8") === "BLOCK-") {
            throw new Error("plaintext leak: BLOCK- marker found in non-member block " + i + " at offset " + offset);
          }
        }
        if (buf.toString("utf8").includes("AAAA")) {
          throw new Error("plaintext leak: A-run found in non-member block " + i);
        }
        checked++;
      }
      expect(checked).toBe(BLOCK_COUNT);
      await writer.client.stop().catch(() => undefined);
    },
    90000,
  );

  it(
    "WRONG KEY (baseKey + wrong 32B): same silent-garbage semantics",
    async () => {
      const wDir = storeDir("q5w-wrong");
      const rDir = storeDir("q5r-wrong");
      dirs.push(wDir, rDir);
      mkdirSync(path.dirname(rDir), { recursive: true });
      const armPort = await freeUdpPort();
      const writer = await startWriter(wDir, randomRootSeed(), encKey, armPort);
      clients.push(writer.client);
      const reader = await startReader(rDir, randomRootSeed(), armPort, writer.baseKey, b64(wrongKey), writer.peerPubHex);
      clients.push(reader);
      const result = await reader.coreDownload(delegationId, BLOCK_COUNT, 30000);
      expect(result.reached).toBe(true);
      const block0 = await reader.coreGet(delegationId, 0);
      expect(block0).not.toBeNull();
      expect(Buffer.from(block0 as Uint8Array)).not.toEqual(Buffer.from(plaintextBlock(0)));
      expect(Buffer.from(block0 as Uint8Array).toString("utf8")).not.toContain("BLOCK-");
      await writer.client.stop().catch(() => undefined);
    },
    60000,
  );
});
