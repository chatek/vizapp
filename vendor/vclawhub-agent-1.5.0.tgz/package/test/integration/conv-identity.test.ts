/**
 * conv-identity.test.ts — PHASE 1 acceptance: conversation identity + ordering
 * (vclaw-lead ruling 2026-10-03, DESIGN-RECORD §5).
 *
 * WHAT IS PROVEN HERE (all evidence is read from the WIRE, not from mocks):
 *   A. an H2A request/response round trip carries a stable `conversationId` on
 *      BOTH legs and a valid UUIDv7 `messageId`; the reply names the request
 *      via `parentMessageId` and carries a per-conversation monotonic `seq`.
 *      The REQUEST frame is captured off the wire by a second subscriber, so
 *      neither leg is asserted from an in-process return value.
 *   B. NEGATIVE CONTROL: a reply frame WITHOUT `conversationId` is REJECTED
 *      loudly (error log with a REJECTED marker + onReject hook + counter),
 *      never silently dropped and never guessed onto the active conversation.
 *   C. NEGATIVE CONTROL: a malformed H2A prompt frame is rejected at the
 *      validator (handler not called; an on-wire error chunk goes back).
 *   D. NEGATIVE CONTROL: the producer refuses to publish a chunk without a
 *      conversationId at all.
 *   E. session ops: appended entries carry `seq` (monotonic) and a UUIDv7
 *      `uid`; the wire `head_id` is that uid — the 8-hex file-local id stays
 *      inside the JSONL.
 *
 * Requires a `nats-server` binary on PATH (homebrew: brew install nats-server).
 */
import { describe, it, expect, afterAll, beforeAll, vi } from "vitest";
import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import net from "node:net";
import { connect, type NatsConnection } from "@nats-io/transport-node";

import { subPrompt, promptSubjectV2, sendPrompt, buildPromptPayload } from "../../src/net/h2a.js";
import {
  setupReplySubscription,
  sendResponse,
  replySubjectV2,
  replyRejections,
  type ReplyRejection,
} from "../../src/net/reply.js";
import { subSession } from "../../src/net/session.js";
import { subA2A, a2aSend } from "../../src/net/a2a.js";
import { SessionStore } from "../../src/session/store.js";
import { sessionSubjectV2 } from "../../src/contracts/contracts.js";
import { isUuidV7 } from "../../src/lib/uuidv7.js";
import { resetConversationSeq } from "../../src/net/conversation.js";
import type { Chunk, PendingResponse, PromptMessage } from "../../src/net/types.js";

const PORT = 43600 + Math.floor(Math.random() * 300);
const dec = new TextDecoder();

let serverProc: ReturnType<typeof spawn> | null = null;
let nc: NatsConnection; // agent side
let client: NatsConnection; // client/publisher side

async function waitForPort(port: number, timeoutMs = 10_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const ok = await new Promise<boolean>((resolve) => {
      const s = net.connect(port, "127.0.0.1");
      s.once("connect", () => { s.destroy(); resolve(true); });
      s.once("error", () => resolve(false));
    });
    if (ok) return;
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error(`nats-server did not open port ${port}`);
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Capture every frame published to a subject on a dedicated connection. */
async function capture(subject: string): Promise<{ frames: Uint8Array[]; stop: () => void; conn: NatsConnection }> {
  const conn = await connect({ servers: `127.0.0.1:${PORT}` });
  const frames: Uint8Array[] = [];
  const sub = conn.subscribe(subject, { callback: (_e, m) => { if (m) frames.push(m.data); } });
  await conn.flush();
  return { frames, stop: () => { sub.unsubscribe(); void conn.close(); }, conn };
}

/** Wait until predicate holds (or fail). */
async function until(predicate: () => boolean, timeoutMs = 5_000, what = "condition"): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await sleep(25);
  }
  throw new Error(`timeout waiting for ${what}`);
}

const nonEmpty = (frames: Uint8Array[]) => frames.filter((f) => f.byteLength > 0);
const json = (frames: Uint8Array[]) => nonEmpty(frames).map((f) => JSON.parse(dec.decode(f)) as Chunk);

beforeAll(async () => {
  serverProc = spawn("nats-server", ["-p", String(PORT)], { stdio: "ignore" });
  await waitForPort(PORT);
  nc = await connect({ servers: `127.0.0.1:${PORT}` });
  client = await connect({ servers: `127.0.0.1:${PORT}` });
}, 20_000);

afterAll(async () => {
  await client?.close().catch(() => {});
  await nc?.close().catch(() => {});
  serverProc?.kill();
  serverProc = null;
});

// ── A. H2A round trip: identity on BOTH legs, from the wire ──────────────────
describe("A — H2A round trip carries conversation identity on both legs", () => {
  it("request frame (captured on the wire) + reply chunks share one conversationId", async () => {
    resetConversationSeq();
    const nkey = `UDCONVA${Date.now().toString(36).toUpperCase()}`;
    const inbox = `_INBOX.conv.a.${Date.now().toString(36)}`;

    let handled: PromptMessage | null = null;
    subPrompt(nc, { nkey }, async (msg) => {
      handled = msg;
      return "42 — the answer";
    });
    await nc.flush();

    // A second subscriber captures the REQUEST frame as it crosses the wire.
    const reqCap = await capture(promptSubjectV2(nkey));
    const replyCap = await capture(inbox);
    await sleep(150); // let the agent subscription attach

    const sent = sendPrompt(client, nkey, {
      messages: [{ role: "user", content: "what is the answer?" }],
      reply_to: inbox,
      model: nkey,
    });
    await client.flush();

    await until(() => replyCap.frames.some((f) => f.byteLength === 0), 5_000, "H2A EOF terminator");

    const reqFrames = json(reqCap.frames);
    const replyFrames = json(replyCap.frames);

    // ── raw evidence (reported verbatim in REPORT.md) ──
    console.log("RAW request frame  :", JSON.stringify(reqFrames[0]));
    console.log("RAW reply frames   :", replyFrames.map((c) => JSON.stringify(c)).join("\n                     "));
    console.log("RAW EOF frame      : byteLength=0 (protocol terminator, body-less by design)");

    expect(reqFrames).toHaveLength(1);
    expect(replyFrames.map((c) => c.type)).toEqual(["status", "response"]);
    expect(handled).not.toBeNull();
    expect(replyFrames[1].data).toContain("42 — the answer");

    // The REQUEST leg, read off the wire:
    const reqFrame = reqFrames[0];
    expect(isUuidV7(reqFrame.messageId)).toBe(true);
    expect(isUuidV7(reqFrame.conversationId)).toBe(true);
    expect(reqFrame.seq).toBe(1);
    expect(reqFrame.messageId).toBe(sent.messageId);
    expect(reqFrame.conversationId).toBe(sent.conversationId);

    // The REPLY leg, read off the wire: same conversation on every chunk.
    for (const chunk of replyFrames) {
      expect(chunk.conversationId).toBe(reqFrame.conversationId);
      expect(chunk.parentMessageId).toBe(reqFrame.messageId);
      expect(isUuidV7(chunk.messageId)).toBe(true);
    }
    // Per-conversation monotonic seq, shared by both legs.
    expect(replyFrames[0].seq).toBe(2);
    expect(replyFrames[1].seq).toBe(3);
    expect(replyFrames[0].seq!).toBeGreaterThan(reqFrame.seq!);
    expect(replyFrames[1].seq!).toBeGreaterThan(replyFrames[0].seq!);
    // Each frame has its own identity (a reply is not a copy of its parent).
    expect(replyFrames[0].messageId).not.toBe(reqFrame.messageId);
    expect(replyFrames[1].messageId).not.toBe(replyFrames[0].messageId);

    reqCap.stop();
    replyCap.stop();
  }, 20_000);

  it("a legacy prompt WITHOUT identity still gets a stable conversation on the reply", async () => {
    resetConversationSeq();
    const nkey = `UDCONVB${Date.now().toString(36).toUpperCase()}`;
    const inbox = `_INBOX.conv.b.${Date.now().toString(36)}`;

    subPrompt(nc, { nkey }, async () => "legacy answer");
    await nc.flush();
    const replyCap = await capture(inbox);
    await sleep(150);

    // Exactly what vgate publishes today: {model, messages, reply_to}.
    client.publish(promptSubjectV2(nkey), JSON.stringify({
      model: nkey,
      messages: [{ role: "user", content: "legacy" }],
      reply_to: inbox,
    }));
    await client.flush();
    await until(() => replyCap.frames.some((f) => f.byteLength === 0), 5_000, "legacy EOF");

    const chunks = json(replyCap.frames);
    console.log("RAW legacy reply   :", chunks.map((c) => JSON.stringify(c)).join("\n                     "));
    expect(chunks.map((c) => c.type)).toEqual(["status", "response"]);
    expect(isUuidV7(chunks[0].conversationId)).toBe(true);
    expect(chunks[0].conversationId).toBe(chunks[1].conversationId);
    expect(chunks[0].parentMessageId).toBeDefined();
    expect(isUuidV7(chunks[0].parentMessageId)).toBe(true);
    replyCap.stop();
  }, 20_000);
});

// ── B. NEGATIVE CONTROL: reply frame without conversationId ──────────────────
describe("B — a reply frame without conversationId is REJECTED LOUDLY", () => {
  it("is not routed, not guessed onto the active conversation, and logged REJECTED", async () => {
    // The reply inbox is the stable per-session subject the router listens on.
    const inbox = replySubjectV2("owner-neg", "name-neg");
    const pending = new Map<string, PendingResponse>();
    const active = { current: null as string | null };
    const seen: ReplyRejection[] = [];
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    const before = replyRejections.count;

    setupReplySubscription(nc, "owner-neg", "name-neg", pending, active, {
      onReject: (r) => seen.push(r),
    });
    await nc.flush();

    // A REAL pending conversation exists…
    const convId = "01930000-0000-7000-8000-000000000abc";
    let resolved: string | null = null;
    pending.set(convId, { resolve: (t) => { resolved = t; }, reject: () => {}, ts: Date.now() });

    // …and an orphan frame (no conversationId) arrives FIRST.
    const orphan = JSON.stringify({ type: "response", data: "ORPHAN — must not resolve anything" });
    client.publish(inbox, orphan);
    await client.flush();
    await until(() => seen.length > 0, 5_000, "rejection hook");

    // ── raw evidence ──
    console.log("RAW orphan frame   :", orphan);
    console.log("RAW rejection      :", JSON.stringify(seen[0]));
    console.log("RAW console.error  :", errSpy.mock.calls.map((c) => String(c[0])).join(" | "));

    // The orphan resolved NOTHING and did not become the active conversation.
    expect(resolved).toBeNull();
    expect(active.current).toBeNull();
    // The rejection is loud and observable.
    expect(seen.map((r) => r.reason)).toContain("missing_conversationId");
    expect(seen[0].subject).toBe(inbox);
    expect(seen[0].type).toBe("response");
    expect(replyRejections.count).toBe(before + 1);
    expect(errSpy.mock.calls.map((c) => String(c[0])).join(" ")).toMatch(/REJECTED/);
    expect(errSpy.mock.calls.map((c) => String(c[0])).join(" ")).toMatch(/no conversationId/);

    // The legitimate reply (same inbox, WITH conversationId) still resolves.
    client.publish(inbox, JSON.stringify({ type: "response", data: "REAL", conversationId: convId }));
    await client.flush();
    await until(() => resolved === "REAL", 5_000, "the legitimate reply");
    expect(resolved).toBe("REAL");

    errSpy.mockRestore();
    warnSpy.mockRestore();
  }, 20_000);
});

// ── C. NEGATIVE CONTROL: malformed H2A prompt ────────────────────────────────
describe("C — a malformed H2A prompt frame is rejected before the handler", () => {
  it("rejects a structurally invalid frame and answers with an error chunk", async () => {
    const nkey = `UDCONVC${Date.now().toString(36).toUpperCase()}`;
    const inbox = `_INBOX.conv.c.${Date.now().toString(36)}`;
    let called = 0;
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    subPrompt(nc, { nkey }, async () => { called += 1; return "should never happen"; });
    await nc.flush();
    const replyCap = await capture(inbox);
    await sleep(150);

    // `messages[].content` must be a string; this frame is JSON but malformed.
    const malformed = JSON.stringify({
      messages: [{ role: "user", content: { not: "a string" } }],
      reply_to: inbox,
      conversationId: "01930000-0000-7000-8000-0000000000ff",
      messageId: "01930000-0000-7000-8000-0000000000aa",
    });
    client.publish(promptSubjectV2(nkey), malformed);
    await client.flush();

    await until(() => nonEmpty(replyCap.frames).length > 0, 5_000, "rejection error chunk");
    await until(() => replyCap.frames.some((f) => f.byteLength === 0), 5_000, "rejection EOF");

    const chunks = json(replyCap.frames);
    console.log("RAW malformed frame:", malformed);
    console.log("RAW rejection chunk:", JSON.stringify(chunks[0]));
    console.log("RAW console.error  :", errSpy.mock.calls.map((c) => String(c[0])).join(" | "));

    expect(called).toBe(0); // the handler never saw it
    expect(chunks).toHaveLength(1);
    expect(chunks[0].type).toBe("error");
    expect(chunks[0].data).toMatch(/invalid h2a prompt frame/);
    // The rejection is itself routable: it echoes the frame's conversation.
    expect(chunks[0].conversationId).toBe("01930000-0000-7000-8000-0000000000ff");
    expect(chunks[0].parentMessageId).toBe("01930000-0000-7000-8000-0000000000aa");
    expect(errSpy.mock.calls.map((c) => String(c[0])).join(" ")).toMatch(/REJECTED prompt frame/);

    // An unroutable frame (no reply_to) cannot be answered — logged instead.
    const unroutable = JSON.stringify({ messages: "not-an-array" });
    client.publish(promptSubjectV2(nkey), unroutable);
    await client.flush();
    await until(() => errSpy.mock.calls.some((c) => String(c[0]).includes("no reply_to")), 5_000, "unroutable log");
    console.log("RAW unroutable     :", unroutable);
    expect(called).toBe(0);

    errSpy.mockRestore();
    replyCap.stop();
  }, 20_000);
});

// ── D. NEGATIVE CONTROL: the producer refuses an unroutable chunk ────────────
describe("D — the producer refuses to publish a chunk without conversationId", () => {
  it("sendResponse throws instead of publishing a frame the far side would reject", async () => {
    const inbox = `_INBOX.conv.d.${Date.now().toString(36)}`;
    const cap = await capture(inbox);

    expect(() => sendResponse(client, inbox, "text", "")).toThrow(/conversationId/);
    expect(() => sendResponse(client, inbox, "text", "   ")).toThrow(/conversationId/);
    await client.flush();
    expect(cap.frames).toHaveLength(0); // nothing crossed the wire

    const ok = sendResponse(client, inbox, "routable", "01930000-0000-7000-8000-0000000000cc", {
      parentMessageId: "01930000-0000-7000-8000-0000000000bb",
    });
    await client.flush();
    await until(() => cap.frames.length >= 2, 5_000, "published chunk + EOF");
    const chunks = json(cap.frames);
    console.log("RAW sendResponse   :", JSON.stringify(chunks[0]));
    expect(chunks[0].conversationId).toBe("01930000-0000-7000-8000-0000000000cc");
    expect(chunks[0].parentMessageId).toBe("01930000-0000-7000-8000-0000000000bb");
    expect(isUuidV7(chunks[0].messageId)).toBe(true);
    expect(ok).toBeUndefined();
    cap.stop();
  }, 20_000);

  it("buildPromptPayload refuses to build a frame its own validator would reject", () => {
    expect(() =>
      buildPromptPayload({ messages: [{ role: "user", content: 42 as unknown as string }], reply_to: "x" }),
    ).toThrow(/invalid prompt frame/);
  });
});

// ── F. A2A: inReplyTo + from.sessionId + same conversation on both legs ──────
describe("F — A2A request/response carries inReplyTo, sessionId and the conversation", () => {
  it("request frame and auto-reply frame are consistent (both read off the wire)", async () => {
    resetConversationSeq();
    const target = `UDCONVF${Date.now().toString(36).toUpperCase()}`;
    const sender = { nkey: "UDSENDERF", nonce: "sender-session" };
    const replyInbox = `_INBOX.conv.f.${Date.now().toString(36)}`;

    subA2A(nc, { nkey: target, nonce: "target-session" }); // default handling → auto-reply
    await nc.flush();
    const reqCap = await capture(`tenant.default.a2a.${target}.>`);
    const replyCap = await capture(replyInbox);
    await sleep(150);

    // A2A send that ANSWERS a known message: inReplyTo must be written (it had
    // zero writers before Phase 1), and intent defaults to "reply".
    const sent = a2aSend(client, target, "ping", sender, replyInbox, undefined, {
      inReplyTo: "01930000-0000-7000-8000-0000000000dd",
      sessionId: "session-x",
    });
    await client.flush();
    await until(() => replyCap.frames.some((f) => f.byteLength > 0), 5_000, "A2A auto-reply");

    const reqFrame = JSON.parse(dec.decode(nonEmpty(reqCap.frames)[0])) as {
      id: string;
      from: { nkey: string; name?: string; sessionId?: string };
      a2a: { intent: string; conversationId: string; inReplyTo?: string; parentMessageId?: string; seq?: number };
    };
    const respFrame = JSON.parse(dec.decode(nonEmpty(replyCap.frames)[0])) as {
      id: string;
      from: { nkey: string; sessionId?: string };
      text: string;
      conversationId?: string;
      inReplyTo?: string;
      parentMessageId?: string;
      seq?: number;
    };
    console.log("RAW a2a request    :", JSON.stringify(reqFrame));
    console.log("RAW a2a response   :", JSON.stringify(respFrame));

    // request leg
    expect(reqFrame.id).toBe(sent.id);
    expect(isUuidV7(reqFrame.id)).toBe(true);
    expect(reqFrame.from.sessionId).toBe("session-x");
    expect(reqFrame.a2a.inReplyTo).toBe("01930000-0000-7000-8000-0000000000dd");
    expect(reqFrame.a2a.parentMessageId).toBe("01930000-0000-7000-8000-0000000000dd");
    expect(reqFrame.a2a.intent).toBe("reply");
    expect(reqFrame.a2a.seq).toBe(1);

    // response leg — same conversation, names the request, carries sessionId
    expect(respFrame.text).toContain("auto-reply from target-session");
    expect(respFrame.from.sessionId).toBe("target-session");
    expect(respFrame.conversationId).toBe(reqFrame.a2a.conversationId);
    expect(respFrame.inReplyTo).toBe(reqFrame.id);
    expect(respFrame.parentMessageId).toBe(reqFrame.id);
    expect(respFrame.seq).toBeGreaterThan(reqFrame.a2a.seq as number);
    expect(isUuidV7(respFrame.conversationId)).toBe(true);

    reqCap.stop();
    replyCap.stop();
  }, 20_000);
});

// ── E. session ops: seq on entries + widened head_id ─────────────────────────
describe("E — session append/get: entry seq + globally-unique head_id", () => {
  it("head_id is the entry's UUIDv7 uid; the 8-hex file-local id stays in the file", async () => {
    const dir = mkdtempSync(join(tmpdir(), "vchat-conv-store-"));
    try {
      const nkey = `UDCONVE${Date.now().toString(36).toUpperCase()}`;
      const store = new SessionStore({ dataDir: dir, cwd: "/tmp/work" });
      subSession(nc, { nkey }, { store });
      await nc.flush();

      const call = async (op: "new" | "append" | "get", body: Record<string, unknown>) => {
        const inbox = `_INBOX.conv.e.${op}.${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
        const cap = await capture(inbox);
        nc.publish(sessionSubjectV2(nkey, op), JSON.stringify({ ...body, reply_to: inbox }));
        await nc.flush();
        await until(() => cap.frames.some((f) => f.byteLength === 0), 5_000, `session.${op} EOF`);
        const bodyFrames = nonEmpty(cap.frames).map((f) => JSON.parse(dec.decode(f)) as Record<string, unknown>);
        cap.stop();
        return bodyFrames;
      };

      const room = "room-conv-1";
      const created = await call("new", { room_id: room, mode: "per-room" });
      expect(created[0].ok).toBe(true);

      const first = await call("append", {
        chatto_room: room,
        text: "hi agent",
        chatto_msg_id: "msg-1",
        chatto_actor: "U1",
        conversation_id: "conv-session-1",
      });
      const second = await call("append", {
        chatto_room: room,
        text: "second message",
        chatto_msg_id: "msg-2",
        chatto_actor: "U1",
        conversation_id: "conv-session-1",
      });
      console.log("RAW append reply 1 :", JSON.stringify(first[0]));
      console.log("RAW append reply 2 :", JSON.stringify(second[0]));

      // head_id is globally unique (UUIDv7), NOT the 8-hex file-local entry id.
      expect(isUuidV7(first[0].head_id)).toBe(true);
      expect(isUuidV7(second[0].head_id)).toBe(true);
      expect(first[0].head_id).not.toBe(second[0].head_id);
      expect(String(first[0].head_id)).not.toMatch(/^[0-9a-f]{8}$/);
      expect(first[0].seq).toBe(1);
      expect(second[0].seq).toBeGreaterThan(first[0].seq as number);
      expect(String(first[0].session_id)).toMatch(/^agent-.*-room-room-conv-1$/);

      // max_pairs 0 = the RAW entry list (the default is the pruned context view).
      const got = await call("get", { room_id: room, conversation_id: "conv-session-1", max_pairs: 0 });
      const entries = got[0].entries as Array<Record<string, unknown>>;
      console.log("RAW session.get    :", JSON.stringify({ session_id: got[0].session_id, head_id: got[0].head_id, entries }));

      // Every appended entry carries uid (UUIDv7) + a strictly increasing seq…
      const stamped = entries.filter((e) => typeof e.uid === "string");
      expect(entries).toHaveLength(4); // attachment-less append = user entry + chatto_ref meta, x2
      expect(stamped).toHaveLength(4);
      const seqs = stamped.map((e) => e.seq as number);
      for (const e of stamped) expect(isUuidV7(e.uid)).toBe(true);
      for (let i = 1; i < seqs.length; i++) expect(seqs[i]).toBeGreaterThan(seqs[i - 1]);
      // …while the pi tree still walks the 8-hex file-local ids.
      for (const e of stamped) expect(String(e.id)).toMatch(/^[0-9a-f]{8}$/);

      // The wire head_id equals the conversational head entry's uid.
      expect(got[0].head_id).toBe(second[0].head_id);
      const head = stamped.find((e) => e.uid === got[0].head_id);
      expect(head).toBeDefined();

      // The PRUNED context view (session.get default) also carries uid + seq.
      const view = await call("get", { room_id: room, conversation_id: "conv-session-1" });
      const viewEntries = view[0].entries as Array<Record<string, unknown>>;
      console.log("RAW session.get view:", JSON.stringify(viewEntries));
      expect(viewEntries.map((e) => e.role)).toEqual(["user", "user"]);
      for (const e of viewEntries) {
        expect(isUuidV7(e.uid)).toBe(true);
        expect(typeof e.seq).toBe("number");
      }
      expect(viewEntries[0].seq as number).toBeLessThan(viewEntries[1].seq as number);
      // The uid/seq stamp is IN the file (durable), not only in the reply.
      const lines = readFileSync(store.get(room)!.path, "utf8").split("\n").filter((l) => l.trim() !== "");
      const rawEntry = JSON.parse(lines[lines.length - 1]) as { uid?: string; seq?: number };
      expect(isUuidV7(rawEntry.uid)).toBe(true);
      expect(rawEntry.seq).toBe(seqs[seqs.length - 1]);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  }, 25_000);
});
