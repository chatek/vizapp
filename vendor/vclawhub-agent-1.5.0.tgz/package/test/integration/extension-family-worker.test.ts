/**
 * extension-family-worker.test.ts — v9 cp3 (ruling A): family-WORKER mode.
 *
 * A pi session (mock pi harness) with VCLAW_FAMILY_WORKER=1 attaches to a
 * REAL local daemon as <VCLAW_WORKER_NAME> on session_start; a lead (real
 * DaemonClient) steers it; the task is surfaced into the session via
 * sendUserMessage; the session answers on turn_end via the daemon socket; the
 * lead receives the reply; session_shutdown detaches (worker → Inactive).
 *
 * Tier L only: no NATS/creds — VCLAW_CREDS_DIR points at an empty temp dir so
 * the extension's IDP path stays inert (no real credential lookups).
 */
import { describe, it, expect } from "vitest";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServe, DaemonClient } from "../../src/daemon/index.js";

async function waitFor(pred: () => boolean | Promise<boolean>, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  const tick = async (): Promise<void> => {
    if (await pred()) return;
    if (Date.now() > deadline) throw new Error("waitFor timeout");
    await new Promise((r) => setTimeout(r, 50));
    return tick();
  };
  await tick();
}

describe("cp3 family-worker mode (extension ↔ real daemon)", () => {
  it("session_start attach → lead steer → task in session → turn_end answer → reply → shutdown detach", async () => {
    const root = mkdtempSync(join(tmpdir(), "vclaw-ext-worker-"));
    const saved: Record<string, string | undefined> = {};
    for (const k of ["VCLAW_FAMILY_DIR", "VCLAW_LEAD", "VCLAW_FAMILY_WORKER", "VCLAW_WORKER_NAME", "VCLAW_CREDS_DIR", "VCLAW_AGENT_AUTOSTART"]) {
      saved[k] = process.env[k];
    }
    process.env.VCLAW_FAMILY_DIR = root;           // family ROOT (daemon + extension agree)
    process.env.VCLAW_LEAD = "lead";
    process.env.VCLAW_FAMILY_WORKER = "1";
    process.env.VCLAW_WORKER_NAME = "w-att";
    process.env.VCLAW_CREDS_DIR = mkdtempSync(join(tmpdir(), "vclaw-nocreds-")); // hermetic: no real creds
    process.env.VCLAW_AGENT_AUTOSTART = "0";        // skip the IDP connect half

    const serve = await startServe({ replyDelayMs: 10 }); // family dir = root/lead (production path)
    const lead = await DaemonClient.connect({ familyDir: join(root, "lead") });
    try {
      // Import the REAL extension factory; capture pi handlers + sendUserMessage.
      const handlers = new Map<string, (e: unknown, ctx: unknown) => unknown>();
      const sent: string[] = [];
      const pi = {
        on: (name: string, fn: (e: unknown, ctx: unknown) => unknown) => handlers.set(name, fn),
        registerCommand: () => {},
        sendUserMessage: (m: string) => { sent.push(m); },
      };
      const factory = (await import("../../src/pi-extension/index.js")).default;
      factory(pi);

      // session_start → worker attaches (poll the daemon for the record).
      const notes: string[] = [];
      await handlers.get("session_start")!({ reason: "startup" }, {
        hasUI: true,
        ui: { notify: (m: string) => notes.push(m) },
      });
      await waitFor(async () => (await lead.panel()).workers.some((w) => w.name === "w-att"), 4000);

      // Lead steers the attached worker → the session receives the task text.
      const conv = "conv-ext-worker-1";
      await lead.steer({ name: "w-att", prompt: "analyze the proposal", conversationId: conv });
      await waitFor(() => sent.some((m) => m.includes("analyze the proposal")), 4000);
      expect(sent.at(-1)).toContain("analyze the proposal");
      expect(sent.at(-1)).toContain(conv);

      // The session's turn completes → turn_end answers the family task.
      await handlers.get("turn_end")!({ message: { role: "assistant", content: "analysis: ship it" } }, {});
      const reply = await lead.nextReply(conv);
      expect(reply.from).toBe("w-att");
      expect(reply.text).toBe("analysis: ship it");

      // session_shutdown → detach → daemon marks the worker Inactive.
      await handlers.get("session_shutdown")!({}, {});
      await waitFor(async () => (await lead.panel()).workers.find((w) => w.name === "w-att")?.state === "Inactive", 4000);

      for (const [k, v] of Object.entries(saved)) {
        if (v === undefined) delete process.env[k];
        else process.env[k] = v;
      }
    } finally {
      await lead.close();
      await serve.close();
      for (const [k, v] of Object.entries(saved)) {
        if (v === undefined) delete process.env[k];
        else process.env[k] = v;
      }
    }
  }, 25_000);
});
