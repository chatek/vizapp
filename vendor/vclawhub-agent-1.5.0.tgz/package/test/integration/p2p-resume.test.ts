/**
 * p2p-resume.test.ts — restart/resume: sparse catch-up, not full replay (M2).
 *
 * M0 Q6 measured 0.057% wire-bytes on resume vs full sync (629 B vs 1.1 MB)
 * after kill -9 of BOTH processes, with RocksDB recovery clean on reopen.
 * Those wire bytes were read off raw TCP sockets; hyperswarm's UDX streams
 * expose no byte counters (measured at M2), so this suite asserts sparsity
 * with the sharper instrument at the hypercore layer: BLOCK DOWNLOAD EVENTS.
 * A resumed reader must fetch ONLY the new range — a full replay would fire
 * ~1100 downloads, a sparse resume exactly ~100.
 *
 * Shape: writer 1000 x 1 KiB blocks; reader full-syncs; kill -9 BOTH sidecar
 * processes (SIGKILL, not graceful); restart both on the same dirs with the
 * same identities; writer appends 100 more; reader catches up to 1100.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { rmSync, mkdirSync } from "node:fs";
import path from "node:path";
import { SidecarClient } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair, deriveWriterKeyPair } from "../../src/net/p2p/identity.js";
import { delegationTopic } from "../../src/net/p2p/topic.js";
import { toolchain, ensureSidecarBuilt, freeUdpPort, randomRootSeed, randomContentKey, storeDir, b64 } from "../helpers/pears-sidecar.js";

const tc = toolchain();
const delegationId = "dlg-resume-m2";
const FIRST_BATCH = 1000;
const SECOND_BATCH = 100;
const BLOCK = new Uint8Array(1024).fill(0x5a);

const writerSeed = randomRootSeed();
const readerSeed = randomRootSeed();
const encKey = randomContentKey();
const seedPort = await freeUdpPort();
const dirW = storeDir("resume-w");
const dirR = storeDir("resume-r");

async function startWriter(): Promise<{ client: SidecarClient; baseKey: string; peerPubHex: string }> {
  const client = new SidecarClient();
  const hello = await client.start({
    storeDir: dirW,
    peerKeyPair: await derivePeerKeyPair(writerSeed),
    network: { bindHost: "127.0.0.1", seedPort },
    bootTimeoutMs: 30000,
  });
  const writer = await deriveWriterKeyPair(writerSeed, delegationId);
  const attach = await client.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "writer",
    encryptionKey: b64(encKey),
    writerKeyPair: { publicKey: b64(writer.publicKey), secretKey: b64(writer.secretKey) },
  });
  return { client, baseKey: attach.baseKey ?? "", peerPubHex: hello.peer.publicKey };
}

async function startReader(baseKey: string, writerPubHex: string): Promise<SidecarClient> {
  const client = new SidecarClient();
  await client.start({
    storeDir: dirR,
    peerKeyPair: await derivePeerKeyPair(readerSeed),
    network: { bindHost: "127.0.0.1", bootstrap: [{ host: "127.0.0.1", port: seedPort }] },
    bootTimeoutMs: 30000,
  });
  await client.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "reader",
    baseKey,
    encryptionKey: b64(encKey),
    peers: [{ publicKey: b64(new Uint8Array(Buffer.from(writerPubHex, "hex"))) }],
  });
  return client;
}

/** SIGKILL exactly THIS sidecar process (M0 Q6's "kill -9 both"). */
async function kill9(client: SidecarClient): Promise<void> {
  const pid = client.sidecarPid;
  expect(pid, "sidecar pid must be known before kill -9").not.toBeNull();
  process.kill(pid as number, "SIGKILL");
  await new Promise((r) => setTimeout(r, 500));
}

describe("restart/resume (sparse catch-up)", () => {
  beforeAll(async () => {
    if (!tc.ok && !ensureSidecarBuilt(tc)) {
      throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
    }
    mkdirSync(path.dirname(dirR), { recursive: true });
  }, 60000);

  afterAll(() => {
    rmSync(dirW, { recursive: true, force: true });
    rmSync(dirR, { recursive: true, force: true });
  });

  it(
    "full sync -> kill -9 both -> restart -> sparse catch-up (downloads ~= new range only)",
    async () => {
      // Session 1: full sync
      const w1 = await startWriter();
      for (let i = 0; i < FIRST_BATCH; i++) await w1.client.coreAppend(delegationId, BLOCK);
      const r1 = await startReader(w1.baseKey, w1.peerPubHex);
      const full = await r1.coreDownload(delegationId, FIRST_BATCH, 120000);
      expect(full.reached).toBe(true);
      expect(full.contiguous).toBe(FIRST_BATCH); // every block is local
      const stats1 = await r1.stats();
      const downloads1 = stats1.rooms.find((r) => r.delegationId === delegationId)?.downloads ?? 0;
      expect(downloads1).toBeGreaterThanOrEqual(FIRST_BATCH - 50); // cold: ~everything downloaded

      // kill -9 BOTH sidecars (no graceful close — RocksDB WAL recovery path)
      await kill9(w1.client);
      await kill9(r1);

      // Session 2: same dirs, same identities, writer appends the new range
      const w2 = await startWriter();
      for (let i = 0; i < SECOND_BATCH; i++) await w2.client.coreAppend(delegationId, BLOCK);
      const r2 = await startReader(w2.baseKey, w2.peerPubHex);
      const resumed = await r2.coreDownload(delegationId, FIRST_BATCH + SECOND_BATCH, 120000);
      expect(resumed.reached).toBe(true); // caught up to 1100
      expect(resumed.len).toBe(FIRST_BATCH + SECOND_BATCH);

      const stats2 = await r2.stats();
      const downloads2 = stats2.rooms.find((r) => r.delegationId === delegationId)?.downloads ?? 0;
      // SPARSE resume: only the new range. A full replay would be ~1100.
      // Budget: new blocks + a small proof/header margin.
      expect(downloads2).toBeLessThanOrEqual(SECOND_BATCH + 20);
      expect(downloads2).toBeGreaterThanOrEqual(SECOND_BATCH);

      // Content integrity after the hard kill: last block readable, plaintext
      const tail = await r2.coreGet(delegationId, FIRST_BATCH + SECOND_BATCH - 1);
      expect(tail).not.toBeNull();
      expect(Buffer.from(tail as Uint8Array)).toEqual(Buffer.from(BLOCK));

      await w2.client.stop().catch(() => undefined);
      await r2.stop().catch(() => undefined);
    },
    240000,
  );
});
