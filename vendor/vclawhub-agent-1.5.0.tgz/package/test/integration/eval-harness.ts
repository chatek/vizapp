/**
 * eval-harness.ts — W4 fan-out eval harness (draft) for the Tier L daemon.
 *
 * Exercises the daemon END TO END over the loopback socket with the STUB
 * worker driver (hermetic — no live pi.dev host needed):
 *   1. spawn N workers (N configurable, default 3) through the client,
 *   2. steer each a distinct follow-up task prompt,
 *   3. collect replies (conversation-scoped routing) and measure round-trips,
 *   4. kill one worker and RE-ADDRESS it with the requester disconnected, so
 *      its reply is queued (receipts/), then pick it up from a fresh client,
 *   5. emit metrics + integrity verdicts.
 *
 * The same harness runs over REAL pi.dev workers later: `runEval({driver:"pi"})`
 * (operator: VCLAW_WORKER_DRIVER=pi / VCLAW_PI_BIN) — the driver is plumbed
 * straight into startServe, so nothing here changes.
 *
 * CLI-ish: `bun test/integration/eval-harness.ts --workers 5 --out /tmp/eval.json`
 * prints the metrics JSON (import.meta.main — Bun-only; vitest imports it as a
 * module and the guard stays inert).
 */
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { writeFileSync } from "node:fs";
import { startServe, DaemonClient, type ServeHandle } from "../../src/daemon/index.js";
import type { QueuedReceipt, WorkerDriverKind } from "../../src/daemon/index.js";
import { waitFor } from "./daemon-helpers.js";

export interface EvalOptions {
  /** Fan-out width. Default 3. */
  workers?: number;
  /** Stub reply delay (ms) — round-trip floor for measurements. Default 25. */
  replyDelayMs?: number;
  /** Driver: "stub" (hermetic tests) or "pi" (future live runs). Default "stub". */
  driver?: WorkerDriverKind;
  /** pi.dev binary override (future live runs; VCLAW_PI_BIN). */
  piBin?: string;
  /** Run the kill → re-address → queue → pickup segment. Default true. */
  killReaddress?: boolean;
  /** Override the family dir (tests). Default: fresh mkdtemp. */
  familyDirOverride?: string;
}

/** Per-conversation result: exactly one reply expected per delivered task. */
export interface EvalTaskResult {
  conversationId: string;
  prompt: string;
  kind: "spawn" | "steer";
  /** ms from request send to ack. */
  ackMs: number;
  /** ms from request send to the routed reply. */
  roundTripMs: number;
  /** How the reply arrived: "live" (socket) or "queued+pickup". */
  delivery: "live" | "queued";
  replyText: string;
}

export interface EvalWorkerMetrics {
  name: string;
  tasks: EvalTaskResult[];
  /** Integrity: every delivered task got exactly one reply for its conversation. */
  integrity: "ok" | string;
}

export interface KillReaddressMetrics {
  worker: string;
  conversationId: string;
  queuedAfterReaddress: number;
  pickedUp: number;
  contentMatch: boolean;
  pickupIntegrity: "ok" | string;
}

export interface EvalMetrics {
  harness: "tier-l-fanout-v1";
  config: { workers: number; replyDelayMs: number; driver: WorkerDriverKind; killReaddress: boolean };
  familyDir: string;
  familyId: string;
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  workers: EvalWorkerMetrics[];
  killReaddress: KillReaddressMetrics | null;
  totals: {
    deliveredTasks: number;
    liveReplies: number;
    queuedReplies: number;
    pickedUp: number;
    receiptIntegrity: "ok" | string;
    meanLiveRoundTripMs: number;
    maxLiveRoundTripMs: number;
  };
}

let familyCounter = 0;

function freshFamilyDir(): string {
  return mkdtempSync(join(tmpdir(), `vclaw-eval-${++familyCounter}-`));
}

async function connect(serve: ServeHandle): Promise<DaemonClient> {
  return DaemonClient.connect({ port: serve.port });
}

export async function runEval(opts: EvalOptions = {}): Promise<EvalMetrics> {
  const workers = opts.workers ?? 3;
  const replyDelayMs = opts.replyDelayMs ?? 25;
  const driver = opts.driver ?? "stub";
  const killReaddress = opts.killReaddress ?? true;
  if (!Number.isInteger(workers) || workers < 1) {
    throw new Error(`eval: workers must be a positive integer (got ${workers})`);
  }
  if (driver === "pi" && !opts.piBin && typeof process !== "undefined" && !process.env.VCLAW_PI_BIN) {
    throw new Error("eval: driver=pi requires piBin (or VCLAW_PI_BIN); live pi.dev hosts only");
  }

  const startedAt = new Date().toISOString();
  const tStart = Date.now();
  const familyDir = opts.familyDirOverride ?? freshFamilyDir();
  const serve = await startServe({
    familyDirOverride: familyDir,
    port: 0,
    workerDriver: driver,
    piBin: opts.piBin,
    replyDelayMs,
  });

  const metrics: EvalMetrics = {
    harness: "tier-l-fanout-v1",
    config: { workers, replyDelayMs, driver, killReaddress },
    familyDir,
    familyId: serve.familyId,
    startedAt,
    finishedAt: "",
    durationMs: 0,
    workers: [],
    killReaddress: null,
    totals: {
      deliveredTasks: 0,
      liveReplies: 0,
      queuedReplies: 0,
      pickedUp: 0,
      receiptIntegrity: "",
      meanLiveRoundTripMs: 0,
      maxLiveRoundTripMs: 0,
    },
  };

  const replyCountByConv = new Map<string, number>();

  try {
    const collector = await connect(serve);

    for (let i = 0; i < workers; i++) {
      const name = `eval-w${i}`;
      const tasks: EvalTaskResult[] = [];

      // 1) spawn with a distinct initial task.
      const convA = `eval-${i}-a-${Date.now().toString(36)}`;
      const promptA = `task for ${name}: report the color of the sky (variant ${i})`;
      const t0 = Date.now();
      await collector.spawn({ name, role: "eval-worker", prompt: promptA, conversationId: convA });
      const tAck = Date.now();
      const replyA = await collector.nextReply(convA);
      const tReply = Date.now();
      tasks.push({
        conversationId: convA,
        prompt: promptA,
        kind: "spawn",
        ackMs: tAck - t0,
        roundTripMs: tReply - t0,
        delivery: "live",
        replyText: replyA.text,
      });

      // 2) steer a distinct follow-up.
      const convB = `eval-${i}-b-${Date.now().toString(36)}`;
      const promptB = `follow-up for ${name}: now report the color of the sea (variant ${i})`;
      const s0 = Date.now();
      await collector.steer({ name, prompt: promptB, conversationId: convB });
      const replyB = await collector.nextReply(convB);
      const sReply = Date.now();
      tasks.push({
        conversationId: convB,
        prompt: promptB,
        kind: "steer",
        ackMs: 0, // steer ack measured implicitly; roundtrip below is the key metric
        roundTripMs: sReply - s0,
        delivery: "live",
        replyText: replyB.text,
      });

      // Integrity per worker: spawn task ⇒ its own conv reply; steer ⇒ its own.
      const integrity =
        tasks.length === 2 &&
        tasks[0].replyText === `done: ${promptA}` &&
        tasks[1].replyText === `[steered] ${promptB}`
          ? "ok"
          : `mismatch: ${JSON.stringify(tasks.map((t) => t.replyText))}`;
      metrics.workers.push({ name, tasks, integrity });
    }

    // Stray/duplicate sweep: every delivered task must have produced EXACTLY
    // one reply — all were consumed above by conversation, so any reply still
    // arriving now would be a duplicate (G3 double-route) and flags integrity.
    for (let i = 0; i < workers * 2 + 2; i++) {
      try {
        const stray = await collector.nextReply(undefined, 250);
        replyCountByConv.set(stray.conversationId, (replyCountByConv.get(stray.conversationId) ?? 0) + 1);
      } catch {
        break; // no more pending replies
      }
    }
    const dupConv = [...replyCountByConv].filter(([, n]) => n > 1).map(([c]) => c);
    if (dupConv.length) {
      metrics.totals.receiptIntegrity = `duplicate replies for conversations: ${dupConv.join(",")}`;
    }
    await collector.close();

    // ── kill → re-address → queue → pickup ─────────────────────────────
    if (killReaddress && workers >= 1) {
      const victim = `eval-w${0}`;
      const killClient = await connect(serve);
      await killClient.kill(victim);
      const stateOf = async (): Promise<string | undefined> =>
        (await (await connect(serve)).panel()).workers.find((w) => w.name === victim)?.state;
      await waitFor(async () => (await stateOf()) === "Inactive", 5_000);
      await killClient.close();

      // Re-address with NO live requester: the reply must queue (R4 floor).
      const convK = `eval-kill-${Date.now().toString(36)}`;
      const promptK = `post-kill task for ${victim}: confirm you are alive again`;
      const steerer = await connect(serve);
      await steerer.steer({ name: victim, prompt: promptK, conversationId: convK });
      await steerer.close(); // reply lands after we disconnect → queued

      await waitFor(async () => {
        const p = await connect(serve);
        try {
          const panel = await p.panel();
          return (panel.workers.find((w) => w.name === victim)?.queuedReplies ?? 0) >= 1;
        } finally {
          await p.close();
        }
      }, 6_000);

      const picker = await connect(serve);
      let picked: QueuedReceipt[] = [];
      try {
        picked = await picker.pickupReceipts(convK);
        const second = await picker.pickupReceipts(convK);
        if (second.length !== 0) {
          throw new Error("eval: second pickup not empty — drain is not idempotent-clear");
        }
      } finally {
        await picker.close();
      }

      const queuedCount = picked.length;
      const contentMatch = queuedCount === 1 && picked[0]?.text === `[steered] ${promptK}`;
      metrics.killReaddress = {
        worker: victim,
        conversationId: convK,
        queuedAfterReaddress: queuedCount,
        pickedUp: queuedCount,
        contentMatch,
        pickupIntegrity: queuedCount === 1 && contentMatch ? "ok" : `queued=${queuedCount} match=${contentMatch}`,
      };
      metrics.totals.queuedReplies += queuedCount;
      metrics.totals.pickedUp += queuedCount;
    }
  } finally {
    await serve.close();
  }

  // ── totals + integrity ────────────────────────────────────────────────
  let delivered = 0;
  let live = 0;
  const rt: number[] = [];
  let integrityIssue = "";
  for (const w of metrics.workers) {
    delivered += w.tasks.length;
    for (const t of w.tasks) {
      if (t.delivery === "live") {
        live++;
        rt.push(t.roundTripMs);
      }
    }
    if (w.integrity !== "ok" && integrityIssue === "") integrityIssue = w.integrity;
  }
  metrics.totals.deliveredTasks = delivered;
  metrics.totals.liveReplies = live;
  metrics.totals.receiptIntegrity =
    integrityIssue === "" && live === delivered ? "ok" : `live=${live} delivered=${delivered}: ${integrityIssue}`;
  metrics.totals.meanLiveRoundTripMs = rt.length ? Math.round(rt.reduce((a, b) => a + b, 0) / rt.length) : 0;
  metrics.totals.maxLiveRoundTripMs = rt.length ? Math.max(...rt) : 0;
  metrics.finishedAt = new Date().toISOString();
  metrics.durationMs = Date.now() - tStart;
  return metrics;
}

// ── CLI (Bun): bun test/integration/eval-harness.ts [--workers N] [--reply-delay MS]
//    [--driver stub|pi] [--pi-bin PATH] [--out PATH]
declare const import_meta: { main?: boolean };
if ((import.meta as unknown as { main?: boolean }).main) {
  const args = process.argv.slice(2);
  const val = (flag: string): string | undefined => {
    const i = args.indexOf(flag);
    return i >= 0 ? args[i + 1] : undefined;
  };
  const has = (flag: string): boolean => args.includes(flag);
  const opts: EvalOptions = {};
  if (val("--workers")) opts.workers = Number(val("--workers"));
  if (val("--reply-delay")) opts.replyDelayMs = Number(val("--reply-delay"));
  if (val("--driver")) opts.driver = val("--driver") as WorkerDriverKind;
  if (val("--pi-bin")) opts.piBin = val("--pi-bin");
  if (has("--no-kill-reevaluation")) opts.killReaddress = false;
  const metrics = await runEval(opts).catch((e) => {
    console.error("eval failed:", (e as Error).message);
    process.exit(1);
  });
  const json = JSON.stringify(metrics, null, 2);
  const out = val("--out");
  if (out) writeFileSync(out, json + "\n");
  console.log(json);
  if (metrics.totals.receiptIntegrity !== "ok" || metrics.killReaddress?.pickupIntegrity !== "ok") {
    console.error(`eval integrity FAILED: ${metrics.totals.receiptIntegrity} / ${metrics.killReaddress?.pickupIntegrity}`);
    process.exit(1);
  }
  process.exit(0);
}
