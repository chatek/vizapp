/**
 * daemon-receipt-pickup.test.ts — INTEGRATION (cp2 RECEIPT-PICKUP verb):
 * queued replies (R4 floor analogue) are collected by a RE-ATTACHED client.
 *
 * The one-shot CLI reality of cp1: a client that spawns/steers and closes
 * before the worker replies gets its answer persisted to receipts/<conv>.json
 * (receipt "queued"). cp2 adds `receipts` — a v1-additive verb that drains the
 * persisted receipts for a re-attached client (all conversations or one), and
 * the files are removed after the drain. Test: queue → pickup → empty again;
 * receipts survive a DAEMON RESTART (the durable-inbox property that makes it
 * the R4 floor analogue) and are then picked up from the restarted daemon.
 */
import { describe, it, expect } from "vitest";
import { startServe, DaemonClient } from "../../src/daemon/index.js";
import { tmpFamily, waitFor } from "./daemon-helpers.js";

async function openDaemon(dir: string, replyDelayMs = 60) {
  const serve = await startServe({ familyDirOverride: dir, port: 0, replyDelayMs });
  return serve;
}

async function connect(serve: { port?: number }) {
  return DaemonClient.connect({ port: serve.port });
}

describe("receipt pickup (queued replies → re-attached client)", () => {
  it("reply queued after requester disconnects → pickup drains it → panel queued 0", async () => {
    const dir = tmpFamily();
    const serve = await openDaemon(dir);
    const a = await connect(serve);
    try {
      await a.spawn({ name: "w1", prompt: "for pickup", conversationId: "pickup-1" });
    } finally {
      await a.close(); // reply (60ms out) finds no live sink → queued
    }

    await waitFor(async () => {
      const p = await connect(serve);
      try {
        const panel = await p.panel();
        return panel.workers.find((w) => w.name === "w1")?.queuedReplies === 1;
      } finally {
        await p.close();
      }
    }, 4_000);

    const b = await connect(serve);
    try {
      const drained = await b.pickupReceipts("pickup-1");
      expect(drained).toHaveLength(1);
      expect(drained[0].conversationId).toBe("pickup-1");
      expect(drained[0].from).toBe("w1");
      expect(drained[0].text).toBe("done: for pickup");
      expect(drained[0].status).toBe("queued");

      // Second pickup is empty (drain deletes the file).
      expect(await b.pickupReceipts("pickup-1")).toHaveLength(0);
      const panel = await b.panel();
      expect(panel.workers.find((w) => w.name === "w1")?.queuedReplies).toBe(0);
    } finally {
      await b.close();
      await serve.close();
    }
  }, 20_000);

  it("queued receipts SURVIVE a daemon restart and are picked up from the new daemon", async () => {
    const dir = tmpFamily();
    const serveA = await openDaemon(dir, 80);
    const a = await connect(serveA);
    try {
      await a.spawn({ name: "w1", prompt: "durable", conversationId: "pickup-restart" });
    } finally {
      await a.close(); // requester gone before the 80ms reply → queued
    }
    await new Promise((r) => setTimeout(r, 500)); // let the worker reply + queue
    await serveA.close(); // daemon down — receipts stay on disk (R4 floor)

    const serveB = await openDaemon(dir, 80);
    const b = await connect(serveB);
    try {
      const drained = await b.pickupReceipts("pickup-restart");
      expect(drained).toHaveLength(1);
      expect(drained[0].text).toBe("done: durable");
    } finally {
      await b.close();
      await serveB.close();
    }
  }, 25_000);
});
