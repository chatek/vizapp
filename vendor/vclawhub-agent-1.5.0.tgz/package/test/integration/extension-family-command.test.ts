/**
 * extension-family-command.test.ts — v9 cp3 lead-side: /vchat-family talks to
 * the LOCAL Tier L daemon socket from inside a pi session (extension handler).
 *
 * Real end-to-end: a real in-process daemon (startServe, unix socket in a temp
 * family dir) + the real extension command handler — list/spawn/steer/stop,
 * receipts, and the no-daemon error path. No NATS involved (Tier L local).
 */
import { describe, it, expect, afterEach } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServe } from "../../src/daemon/index.js";

let factory: (pi: unknown) => void;
let savedEnv: Record<string, string | undefined> = {};

function capture() {
  const commands = new Map<string, (args: string, ctx: unknown) => Promise<void>>();
  const pi = {
    on: () => {},
    registerCommand: (name: string, spec: { handler: (a: string, c: unknown) => Promise<void> }) =>
      commands.set(name, spec.handler),
    sendUserMessage: () => {},
  };
  factory(pi);
  return commands;
}

async function runCmd(
  commands: Map<string, (args: string, ctx: unknown) => Promise<void>>,
  name: string,
  args = "",
) {
  const frames: Array<{ p: Record<string, unknown> }> = [];
  const ctx = {
    hasUI: true,
    ui: { notify: (m: string) => { try { frames.push({ p: JSON.parse(m) }); } catch { /* non-JSON */ } } },
  };
  await commands.get(name)!(args, ctx);
  return frames.filter((f) => f.p.__vchat === true && f.p.kind === "command_result").map((f) => f.p);
}

describe("/vchat-family (extension, Tier L lead side)", () => {
  afterEach(() => {
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
    savedEnv = {};
  });

  it("list → spawn → steer → receipts → stop round-trip against a real daemon", async () => {
    const dir = mkdtempSync(join(tmpdir(), "vclaw-ext-family-"));
    savedEnv = { VCLAW_FAMILY_DIR: process.env.VCLAW_FAMILY_DIR, VCLAW_LEAD: process.env.VCLAW_LEAD };
    process.env.VCLAW_FAMILY_DIR = dir; // family ROOT override (production default: ~/.config/vclaw/family)
    process.env.VCLAW_LEAD = "lead";
    // No familyDirOverride: the daemon derives <root>/<lead> exactly like the
    // extension handler does (paths.familyDir) — same socket path both sides.
    const serve = await startServe({ replyDelayMs: 10 });
    try {
      factory = (await import("../../src/pi-extension/index.js")).default;
      const commands = capture();

      // list — empty family at first
      let res = await runCmd(commands, "vchat-family", "list");
      expect(res[0]).toMatchObject({ command: "family", success: true });
      expect((res[0].data as { workers: unknown[] }).workers).toEqual([]);

      // spawn w1 idle (on the rack)
      res = await runCmd(commands, "vchat-family", "spawn w1 --role coder");
      expect(res[0]).toMatchObject({ command: "family", success: true });
      expect((res[0].data as { verb: string; receipt: string }).verb).toBe("spawn");
      expect((res[0].data as { receipt: string }).receipt).toBe("delivered");

      // list shows w1
      res = await runCmd(commands, "vchat-family", "list");
      const workers = (res[0].data as { workers: Array<{ name: string; state: string }> }).workers;
      expect(workers.map((w) => w.name)).toEqual(["w1"]);
      expect(workers[0].state).toBe("Idle");

      // steer w1 with a task — ack delivered (reply routes on the socket)
      res = await runCmd(commands, "vchat-family", "steer w1 fix the lint error");
      expect(res[0]).toMatchObject({ command: "family", success: true });
      expect((res[0].data as { verb: string }).verb).toBe("steer");
      expect((res[0].data as { receipt: string }).receipt).toBe("delivered");

      // receipts: delivered (not queued) → nothing on disk to pick up
      res = await runCmd(commands, "vchat-family", "receipts");
      expect((res[0].data as { count: number }).count).toBe(0);

      // stop w1
      res = await runCmd(commands, "vchat-family", "stop w1");
      expect(res[0]).toMatchObject({ command: "family", success: true });
      // Worker exit is async (daemon reaps the process) — poll for Inactive.
      let afterStop: Array<{ name: string; state: string }> = [];
      const deadline = Date.now() + 4000;
      while (Date.now() < deadline) {
        res = await runCmd(commands, "vchat-family", "list");
        afterStop = (res[0].data as { workers: Array<{ name: string; state: string }> }).workers;
        if (afterStop.find((w) => w.name === "w1")?.state === "Inactive") break;
        await new Promise((r) => setTimeout(r, 60));
      }
      expect(afterStop.find((w) => w.name === "w1")?.state).toBe("Inactive");

      // usage + unknown worker errors stay graceful
      res = await runCmd(commands, "vchat-family", "bogus");
      expect(res[0]).toMatchObject({ command: "family", success: false, code: "E_USAGE" });
    } finally {
      await serve.close();
      rmSync(dir, { recursive: true, force: true });
    }
  }, 25_000);

  it("no daemon → E_NO_DAEMON with the socket hint (offline lead stays graceful)", async () => {
    const dir = mkdtempSync(join(tmpdir(), "vclaw-ext-family-"));
    savedEnv = { VCLAW_FAMILY_DIR: process.env.VCLAW_FAMILY_DIR, VCLAW_LEAD: process.env.VCLAW_LEAD };
    process.env.VCLAW_FAMILY_DIR = dir;
    process.env.VCLAW_LEAD = "lead";
    try {
      factory = (await import("../../src/pi-extension/index.js")).default;
      const commands = capture();
      const res = await runCmd(commands, "vchat-family", "list");
      expect(res[0]).toMatchObject({ command: "family", success: false, code: "E_NO_DAEMON" });
      expect((res[0].error as string)).toContain("vclaw-agent serve");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  }, 15_000);
});
