/**
 * p2p-corestore-lock.test.ts — the exclusive-ownership gate (Pears M2).
 *
 * The Corestore is owned by ONE process (the sidecar). hypercore-storage's
 * RocksDB layer takes an OS-level file lock on the directory; a second open —
 * measured in the M2 probe in BOTH the same process and across processes —
 * fails with "File descriptor could not be locked". This test pins that a
 * SECOND SIDECAR on the same dir fails LOUDLY: a fatal E_STORE_LOCKED frame
 * and a non-zero exit, never a silent second owner.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { rmSync, mkdirSync } from "node:fs";
import path from "node:path";
import { SidecarClient, SidecarOpError } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair } from "../../src/net/p2p/identity.js";
import { toolchain, ensureSidecarBuilt, randomRootSeed, storeDir } from "../helpers/pears-sidecar.js";

const tc = toolchain();
const dirs: string[] = [];
const clients: SidecarClient[] = [];

beforeAll(async () => {
  if (!tc.ok && !ensureSidecarBuilt(tc)) {
    throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
  }
}, 60000);

afterAll(async () => {
  for (const client of clients.reverse()) await client.stop().catch(() => undefined);
  for (const dir of dirs) rmSync(dir, { recursive: true, force: true });
});

describe("Corestore exclusive lock", () => {
  it(
    "a second sidecar on the same store dir fails LOUDLY (E_STORE_LOCKED, exit 1)",
    async () => {
      const dir = storeDir("lock");
      dirs.push(dir);
      mkdirSync(path.dirname(dir), { recursive: true });

      const first = new SidecarClient();
      clients.push(first);
      await first.start({ storeDir: dir, peerKeyPair: await derivePeerKeyPair(randomRootSeed()), network: { bindHost: "127.0.0.1" }, bootTimeoutMs: 30000 });

      const second = new SidecarClient();
      // The boot op must reject with the lock error (the sidecar emits a
      // fatal frame AND exits nonzero — the client surfaces the former; the
      // exit is asserted via the closed state right after).
      await expect(
        second.start({ storeDir: dir, peerKeyPair: await derivePeerKeyPair(randomRootSeed()), network: { bindHost: "127.0.0.1" }, bootTimeoutMs: 30000 }),
      ).rejects.toThrow(/lock/i);
      // the fatal path must EXIT (nonzero), not linger — poll for it
      const exitDeadline = Date.now() + 5000;
      while (!second.exited && Date.now() < exitDeadline) {
        await new Promise((r) => setTimeout(r, 100));
      }
      expect(second.exited).toBe(true); // it did NOT linger as a zombie owner

      // The FIRST owner is unaffected and still answers ops.
      const stats = await first.stats();
      expect(stats.connections).toBe(0);
    },
    60000,
  );
});
