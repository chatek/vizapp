#!/usr/bin/env node
// fake pi.dev CLI for daemon integration tests (cp2 worker seam).
// Speaks the pi.dev RPC subset the daemon driver uses:
//   prompt / steer -> {response success} + agent_settled; the driver then
//   queries get_last_assistant_text -> {response success, data.text}.
// The final text is derived deterministically per task and remembered in
// pendingText until the query arrives (agent_settled precedes the query).
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const args = process.argv.slice(2);
const argOf = (flag) => { const i = args.indexOf(flag); return i >= 0 ? args[i + 1] : undefined; };
const sessionDir = argOf("--session-dir") || process.cwd();
const sessionId = argOf("--session-id") || "fake";
const sessionFile = path.join(sessionDir, sessionId + ".jsonl");
const send = (obj) => process.stdout.write(JSON.stringify(obj) + "\n");
const logTurn = (kind, text) => {
  fs.mkdirSync(sessionDir, { recursive: true });
  fs.appendFileSync(sessionFile, JSON.stringify({ ts: new Date().toISOString(), type: kind, text }) + "\n");
};
let pendingText = "";
let buf = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buf += chunk;
  let nl;
  while ((nl = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, nl).trim();
    buf = buf.slice(nl + 1);
    if (line) handle(line);
  }
});
process.stdin.on("end", () => process.exit(0));
function handle(line) {
  let msg;
  try { msg = JSON.parse(line); } catch { return; }
  if (msg.type === "prompt" || msg.type === "steer") {
    const text = msg.type === "steer"
      ? "[steered] " + String(msg.message || "")
      : "done: " + String(msg.message || "");
    pendingText = text;
    logTurn("user", msg.message || "");
    logTurn("assistant", text);
    send({ id: msg.id, type: "response", command: msg.type, success: true });
    send({ type: "agent_start" });
    send({ type: "agent_settled" });
    return;
  }
  if (msg.type === "get_last_assistant_text") {
    const text = pendingText;
    pendingText = "";
    send({ id: msg.id, type: "response", command: "get_last_assistant_text", success: true, data: { text } });
    return;
  }
  if (msg.type === "get_state") {
    send({ id: msg.id, type: "response", command: "get_state", success: true, data: { isStreaming: false, sessionId } });
    return;
  }
  send({ id: msg.id, type: "response", command: msg.type, success: true });
}
