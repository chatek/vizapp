/**
 * eval-harness.test.ts — INTEGRATION (W4): runs the hermetic fan-out eval
 * harness (eval-harness.ts) against the daemon with the STUB driver and
 * asserts the metrics contract + integrity verdicts. No live pi.dev needed.
 */
import { describe, it, expect } from "vitest";
import { runEval, type EvalMetrics } from "./eval-harness.js";

function expectOkShape(m: EvalMetrics): void {
  expect(m.harness).toBe("tier-l-fanout-v1");
  expect(m.familyId).toBeTruthy();
  expect(m.durationMs).toBeGreaterThan(0);
  expect(m.startedAt).toBeTruthy();
  expect(m.finishedAt).toBeTruthy();
  // metrics key presence (the shape the operator will consume for real runs)
  expect(typeof m.totals.deliveredTasks).toBe("number");
  expect(typeof m.totals.liveReplies).toBe("number");
  expect(typeof m.totals.queuedReplies).toBe("number");
  expect(typeof m.totals.pickedUp).toBe("number");
  expect(typeof m.totals.meanLiveRoundTripMs).toBe("number");
  expect(typeof m.totals.maxLiveRoundTripMs).toBe("number");
  expect(typeof m.totals.receiptIntegrity).toBe("string");
  for (const w of m.workers) {
    expect(w.name).toMatch(/^eval-w/);
    expect(w.tasks.length).toBeGreaterThanOrEqual(2);
    for (const t of w.tasks) {
      expect(["spawn", "steer"]).toContain(t.kind);
      expect(t.roundTripMs).toBeGreaterThan(0);
      expect(t.replyText).toBeTruthy();
      expect(t.delivery).toBe("live");
    }
  }
}

describe("W4 fan-out eval harness (stub driver, hermetic)", () => {
  it("defaults to N=3 workers and reports full integrity (live + kill→pickup)", async () => {
    const m = await runEval({ replyDelayMs: 15 });
    expectOkShape(m);
    expect(m.config.workers).toBe(3);
    expect(m.workers).toHaveLength(3);
    expect(m.workers.every((w) => w.integrity === "ok")).toBe(true);
    // 2 live tasks per worker (spawn + steer) = 6 delivered; the kill-re-address
    // steer is a SEPARATE segment (counted in killReaddress/queued/pickedUp).
    expect(m.totals.deliveredTasks).toBe(6);
    expect(m.totals.liveReplies).toBe(6);
    expect(m.totals.queuedReplies).toBe(1);
    expect(m.totals.pickedUp).toBe(1);
    expect(m.totals.receiptIntegrity).toBe("ok");
    expect(m.killReaddress).not.toBeNull();
    expect(m.killReaddress!.pickupIntegrity).toBe("ok");
    expect(m.killReaddress!.contentMatch).toBe(true);
    expect(m.killReaddress!.queuedAfterReaddress).toBe(1);
    expect(m.totals.meanLiveRoundTripMs).toBeGreaterThanOrEqual(15);
  }, 60_000);

  it("honors the configurable fan-out width (N=1)", async () => {
    const m = await runEval({ workers: 1, replyDelayMs: 10, killReaddress: false });
    expectOkShape(m);
    expect(m.workers).toHaveLength(1);
    expect(m.totals.deliveredTasks).toBe(2);
    expect(m.totals.liveReplies).toBe(2);
    expect(m.totals.receiptIntegrity).toBe("ok");
    expect(m.killReaddress).toBeNull(); // disabled segment
  }, 30_000);

  it("rejects invalid widths", async () => {
    await expect(runEval({ workers: 0 })).rejects.toThrow(/positive integer/);
    await expect(runEval({ workers: -1 })).rejects.toThrow(/positive integer/);
  });
});
