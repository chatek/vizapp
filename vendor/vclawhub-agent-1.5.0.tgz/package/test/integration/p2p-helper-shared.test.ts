/**
 * p2p-helper-shared.test.ts — 0.3.0 listen mode, PROVEN AT PROCESS SCALE.
 *
 * The property the MCP fleet needs (PROTOCOL.md §9): 22 idle MCP processes
 * must NOT each reach for the Corestore lock; ONE helper per user-host serves
 * all of them over `helper.sock`. This suite proves it with three SEPARATE
 * node processes (real `child_process` spawns from this test), each running
 * the SDK's real `attachHelper()`:
 *
 *   G1 ONE HELPER — all three clients report the SAME helper pid, and that pid
 *      is the lockfile's recorded holder. The three connections are
 *      simultaneous: every process samples `stats.helperClients` while all
 *      three are attached and must see 3.
 *   G2 LINGER — after the last client detaches the helper exits (exit 0) once
 *      the linger window elapses, and the socket + lockfile are gone.
 *   G3 CRASH + RESPAWN — SIGKILL the helper: the debris (socket, lockfile)
 *      stays, the next client's ECONNREFUSED arm clears it and a NEW helper
 *      pid serves the call (the §9 respawn rule).
 *
 * The client side is an esbuild bundle of src/net/p2p/client.ts (the same
 * bundler the repo already depends on) — no network, no install, and the
 * sidecar's own node_modules are untouched.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import { toolchain, ensureSidecarBuilt, SIDECAR_DIR } from "../helpers/pears-sidecar.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(HERE, "../..");
const CHILD_SCRIPT = path.join(HERE, "helper-client-child.mjs");

const tc = toolchain();
const LINGER_MS = 500;

let root = "";
let sockPath = "";
let storeDirPath = "";
let bundlePath = "";
const seed = new Uint8Array(randomBytes(32));
const liveChildren: ChildProcessWithoutNullStreams[] = [];

interface Child {
  proc: ChildProcessWithoutNullStreams;
  lines: Record<string, unknown>[];
  next(stage: string, timeoutMs?: number): Promise<Record<string, unknown>>;
  send(cmd: string): void;
  exit(): Promise<number | null>;
}

/** Spawn one client process and expose its JSON line protocol. */
function startClient(): Child {
  const proc = spawn(process.execPath, [CHILD_SCRIPT, bundlePath], {
    env: {
      ...process.env,
      HELPER_SOCK: sockPath,
      HELPER_STORE: storeDirPath,
      HELPER_SEED_HEX: Buffer.from(seed).toString("hex"),
      HELPER_LINGER_MS: String(LINGER_MS),
      // resolveSidecarDir() searches relative to the IMPORTING module, and the
      // client here is an esbuild bundle outside the src tree — the documented
      // override is the way to name the bundle (PROTOCOL.md §5b / resolveSidecarDir).
      PEARS_SIDECAR_DIR: SIDECAR_DIR,
    },
    stdio: ["pipe", "pipe", "pipe"],
  }) as ChildProcessWithoutNullStreams;
  liveChildren.push(proc);

  const lines: Record<string, unknown>[] = [];
  const waiters: { stage: string; resolve: (v: Record<string, unknown>) => void; reject: (e: Error) => void; timer: NodeJS.Timeout }[] = [];
  let buffer = "";
  let stderr = "";
  proc.stderr.setEncoding("utf8");
  proc.stderr.on("data", (chunk: string) => {
    stderr += chunk;
  });
  proc.stdout.setEncoding("utf8");
  proc.stdout.on("data", (chunk: string) => {
    buffer += chunk;
    let nl = buffer.indexOf("\n");
    while (nl !== -1) {
      const line = buffer.slice(0, nl).trim();
      buffer = buffer.slice(nl + 1);
      nl = buffer.indexOf("\n");
      if (line === "") continue;
      let parsed: Record<string, unknown>;
      try {
        parsed = JSON.parse(line) as Record<string, unknown>;
      } catch {
        continue;
      }
      lines.push(parsed);
      for (let i = waiters.length - 1; i >= 0; i--) {
        if (waiters[i]!.stage !== parsed.stage) continue;
        const w = waiters.splice(i, 1)[0]!;
        clearTimeout(w.timer);
        w.resolve(parsed);
      }
    }
  });

  return {
    proc,
    lines,
    next(stage: string, timeoutMs = 90_000): Promise<Record<string, unknown>> {
      const existing = lines.find((l) => l.stage === stage && !(l as { _taken?: boolean })._taken);
      if (existing) {
        (existing as { _taken?: boolean })._taken = true;
        return Promise.resolve(existing);
      }
      return new Promise((resolve, reject) => {
        const timer = setTimeout(
          () =>
            reject(
              new Error(
                "child never reported stage " + stage + " (lines: " + JSON.stringify(lines) + " stderr: " + stderr.slice(-800) + ")",
              ),
            ),
          timeoutMs,
        );
        waiters.push({ stage, resolve, reject, timer });
      });
    },
    send(cmd: string): void {
      proc.stdin.write(cmd + "\n");
    },
    exit(): Promise<number | null> {
      if (proc.exitCode !== null) return Promise.resolve(proc.exitCode);
      return new Promise((resolve) => proc.once("exit", (code) => resolve(code)));
    },
  };
}

/** Bounded wait for a filesystem predicate (never a bare sleep loop). */
async function waitFor(predicate: () => boolean, timeoutMs: number, what: string): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error("timed out after " + timeoutMs + "ms waiting for " + what);
}

function helperPidFromLock(): number | null {
  try {
    const parsed = JSON.parse(readFileSync(sockPath + ".lock", "utf8")) as { pid?: unknown };
    return typeof parsed.pid === "number" ? parsed.pid : null;
  } catch {
    return null;
  }
}

function alive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return (e as NodeJS.ErrnoException).code === "EPERM";
  }
}

beforeAll(async () => {
  if (!tc.ok && !ensureSidecarBuilt(tc)) {
    throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
  }
  root = mkdtempSync(path.join(tmpdir(), "pears-helper-shared-"));
  sockPath = path.join(root, "helper.sock");
  storeDirPath = path.join(root, "store");
  mkdirSync(storeDirPath, { recursive: true, mode: 0o700 });

  // The bundle MUST live under the repo's node_modules tree: @nats-io/nkeys
  // pulls the `sodium-native` addon, which cannot be bundled (and must stay a
  // runtime resolve), so it is left external (`--packages=external`) and
  // resolved by walking up from this file.
  const bundleDir = path.join(REPO, "node_modules", ".cache", "m35-helper-shared-" + randomBytes(4).toString("hex"));
  mkdirSync(bundleDir, { recursive: true });
  bundlePath = path.join(bundleDir, "sdk-client.mjs");
  const build = spawn(
    path.join(REPO, "node_modules", ".bin", "esbuild"),
    [
      path.join(REPO, "src/net/p2p/client.ts"),
      "--bundle",
      "--platform=node",
      "--format=esm",
      "--packages=external",
      "--outfile=" + bundlePath,
      "--log-level=warning",
    ],
    { cwd: REPO, stdio: ["ignore", "pipe", "pipe"] },
  );
  let buildErr = "";
  build.stderr.setEncoding("utf8");
  build.stderr.on("data", (c: string) => {
    buildErr += c;
  });
  const buildCode = await new Promise<number | null>((resolve) => build.once("exit", resolve));
  expect(buildCode, "esbuild failed: " + buildErr).toBe(0);
  expect(existsSync(bundlePath)).toBe(true);
}, 180_000);

afterAll(async () => {
  for (const proc of liveChildren) {
    if (proc.exitCode === null && proc.signalCode === null) proc.kill("SIGKILL");
  }
  const helperPid = helperPidFromLock();
  if (helperPid !== null && alive(helperPid)) {
    try {
      process.kill(helperPid, "SIGKILL"); // SIGTERM would exercise the clean path; afterAll just cleans up
    } catch {
      /* raced its own exit */
    }
  }
  rmSync(root, { recursive: true, force: true });
  if (bundlePath !== "") rmSync(path.dirname(bundlePath), { recursive: true, force: true });
});

describe("G1 — three client PROCESSES, one sidecar pid", () => {
  it(
    "all three attach to the same helper and each sees helperClients == 3",
    async () => {
      // Start together: this is the spawn RACE the §9 retry arm exists for.
      const clients = [startClient(), startClient(), startClient()];
      const attached = await Promise.all(clients.map((c) => c.next("attached")));

      const pids = new Set(attached.map((a) => a.pid as number));
      expect(pids.size, "three clients must share ONE helper pid, got " + JSON.stringify(attached)).toBe(1);
      const pid = [...pids][0]!;
      expect(pid).toBeGreaterThan(0);
      expect(pid).not.toBe(process.pid); // a real separate process, not this one
      expect(alive(pid)).toBe(true);

      // The pid that SERVES is the pid that HOLDS the lock (§9 flock posture).
      expect(helperPidFromLock()).toBe(pid);

      // Three DIFFERENT client processes…
      const clientPids = new Set(attached.map((a) => a.client_pid as number));
      expect(clientPids.size).toBe(3);
      for (const cp of clientPids) expect(cp).not.toBe(pid);

      // …all attached at once, sampled from the helper itself.
      for (const c of clients) c.send("stats");
      const stats = await Promise.all(clients.map((c) => c.next("stats")));
      for (const s of stats) {
        expect(s.pid).toBe(pid);
        expect(s.clients, "the helper must report all three live connections").toBe(3);
      }

      // Exactly one listen-mode helper exists on this socket.
      const listing = await new Promise<string>((resolve) => {
        const ps = spawn("ps", ["-A", "-o", "pid=,command="], { stdio: ["ignore", "pipe", "ignore"] });
        let out = "";
        ps.stdout.setEncoding("utf8");
        ps.stdout.on("data", (c: string) => (out += c));
        ps.once("exit", () => resolve(out));
      });
      const serving = listing
        .split("\n")
        .filter((l) => l.includes("--listen") && l.includes(sockPath))
        .map((l) => Number(l.trim().split(/\s+/)[0]));
      expect(serving).toEqual([pid]);

      // G2 — detach all three; the linger window then ends the helper.
      for (const c of clients) c.send("release");
      const codes = await Promise.all(clients.map((c) => c.exit()));
      expect(codes).toEqual([0, 0, 0]);

      // A detach NEVER shuts the helper down synchronously: it lingers.
      await waitFor(() => !alive(pid), LINGER_MS + 15_000, "the helper to exit after the linger window");
      await waitFor(() => !existsSync(sockPath + ".lock"), 10_000, "the lockfile to be released");
    },
    180_000,
  );
});

describe("G3 — crash ⇒ debris ⇒ respawn (the §9 rule)", () => {
  it(
    "SIGKILL the helper, then the next client clears the debris and a NEW helper pid serves it",
    async () => {
      // A first client claims the socket again (the helper from G1 is gone).
      const first = startClient();
      const firstAttached = await first.next("attached");
      const crashedPid = firstAttached.pid as number;
      expect(alive(crashedPid)).toBe(true);

      // Kill it while the client is attached — the crash the rule is written for.
      process.kill(crashedPid, "SIGKILL");
      await waitFor(() => !alive(crashedPid), 10_000, "the helper process to die");
      // The dead owner left its socket behind (nothing unlinks on SIGKILL),
      // so the next client MUST take the ECONNREFUSED arm.
      expect(existsSync(sockPath)).toBe(true);

      const second = startClient();
      const secondAttached = await second.next("attached");
      const respawnedPid = secondAttached.pid as number;
      expect(respawnedPid).not.toBe(crashedPid);
      expect(alive(respawnedPid)).toBe(true);
      expect(helperPidFromLock()).toBe(respawnedPid);
      // and it is a real, booted helper: stats answers
      second.send("stats");
      const stats = await second.next("stats");
      expect(stats.pid).toBe(respawnedPid);

      second.send("release");
      await second.exit();
      first.proc.kill("SIGKILL"); // its helper died under it; nothing to release
      await waitFor(() => !alive(respawnedPid), LINGER_MS + 15_000, "the respawned helper to exit");
    },
    180_000,
  );
});
