/**
 * h2a-roundtrip.test.ts — INTEGRATION: a real NATS server, subPrompt →
 * handler → §6 chunk reply roundtrip (closes the wire-layer test hole:
 * the 149 unit tests prove the pieces; this proves they compose).
 *
 * Requires a `nats-server` binary on PATH (homebrew: `brew install nats-server`).
 */
import { describe, it, expect, afterAll } from "vitest";
import { spawn } from "node:child_process";
import net from "node:net";
import { connect } from "@nats-io/transport-node";
import { subPrompt } from "../../src/net/h2a.js";

const PORT = 43231 + Math.floor(Math.random() * 200);

async function waitForPort(port: number, timeoutMs = 10_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const ok = await new Promise<boolean>((resolve) => {
      const s = net.connect(port, "127.0.0.1");
      s.once("connect", () => { s.destroy(); resolve(true); });
      s.once("error", () => resolve(false));
    });
    if (ok) return;
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error(`nats-server did not open port ${port}`);
}

let serverProc: ReturnType<typeof spawn> | null = null;

describe("H2A prompt roundtrip (real NATS)", () => {
  afterAll(() => {
    serverProc?.kill();
    serverProc = null;
  });

  it("subPrompt → handler → ack/response/EOF chunks on reply_to", async () => {
    serverProc = spawn("nats-server", ["-p", String(PORT), "--jetstream"], {
      stdio: "ignore",
    });
    await waitForPort(PORT);

    const nc = await connect({ servers: `127.0.0.1:${PORT}` });
    const client = await connect({ servers: `127.0.0.1:${PORT}` });
    try {
      const nkey = "UDTESTROUNDTRIP";
      // Agent side: subscribe + answer.
      subPrompt(nc, { nkey }, async (msg) => {
        expect(msg.messages[0].content).toBe("hello integration");
        return "real reply from the handler";
      });

      // Client side: request with a reply_to inbox, collect §6 chunks.
      const inbox = `_INBOX.roundtrip.${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
      const chunks: Array<{ type?: string; data?: string } | null> = [];
      const done = new Promise<void>((resolve) => {
        const sub = client.subscribe(inbox, {
          callback: (_err, msg) => {
            const raw = msg.data;
            if (raw.byteLength === 0) {
              sub.unsubscribe();
              resolve();
              return;
            }
            const parsed = JSON.parse(new TextDecoder().decode(raw)) as { type?: string; data?: string };
            chunks.push(parsed);
          },
        });
      });

      // Give the agent sub a beat to attach.
      await new Promise((r) => setTimeout(r, 300));
      client.publish(
        `tenant.default.user.${nkey}.agent.${nkey}.prompt.req`,
        JSON.stringify({
          messages: [{ role: "user", content: "hello integration" }],
          reply_to: inbox,
        }),
      );

      await Promise.race([done, new Promise((_, rej) => setTimeout(() => rej(new Error("timeout waiting for §6 chunks")), 5_000))]);

      expect(chunks.length).toBe(2); // status:ack + response
      expect(chunks[0]?.type).toBe("status");
      expect(chunks[0]?.data).toBe("ack");
      expect(chunks[1]?.type).toBe("response");
      expect(chunks[1]?.data).toContain("real reply from the handler");
    } finally {
      await client.close();
      await nc.close();
    }
  });
});
