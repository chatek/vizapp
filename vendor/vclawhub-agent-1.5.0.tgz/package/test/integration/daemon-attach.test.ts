/**
 * daemon-attach.test.ts — INTEGRATION (v9 cp3, ruling A): the worker-register
 * seam — a LIVE session attaches to the daemon socket as a family worker, the
 * lead steers it, and the task is routed to the session's socket (not a child
 * process); the session answers and the lead receives the reply.
 *
 * Covers the ruling's commitments: attach-by-name registration; spawned ⇄
 * attached mutual exclusion (E_DUPLICATE); steer-to-attached dispatch (task
 * event + ack delivered); answer routing conversation-scoped (reply event to
 * the lead, receipt delivered); detach on disconnect/stop → Inactive; queued
 * answer when no live conversation sink.
 */
import { describe, it, expect } from "vitest";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServe, DaemonClient } from "../../src/daemon/index.js";

async function waitFor(pred: () => boolean | Promise<boolean>, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  const tick = async (): Promise<void> => {
    if (await pred()) return;
    if (Date.now() > deadline) throw new Error("waitFor timeout");
    await new Promise((r) => setTimeout(r, 50));
    return tick();
  };
  await tick();
}

function tmpFamily(): string {
  return mkdtempSync(join(tmpdir(), "vclaw-attach-"));
}

async function openDaemon(familyDir: string) {
  const serve = await startServe({ familyDirOverride: familyDir, port: 0 });
  const client = await DaemonClient.connect({ port: serve.port });
  return { serve, client };
}

describe("cp3 attach seam (Tier L socket)", () => {
  it("attach → lead steer → task to the session → answer → reply, then detach on close", async () => {
    const { serve, client: lead } = await openDaemon(tmpFamily());
    const worker = await DaemonClient.connect({ port: serve.port });
    try {
      // 1. the live session registers as worker-a
      const ack = await worker.attach({ name: "worker-a", role: "coder" });
      expect(ack.receipt).toBe("delivered");
      expect(ack.worker?.state).toBe("Running");
      expect(ack.worker?.driver).toBe("attach");

      // panel shows the attached worker (no pid — daemon does not own it)
      const panel = await lead.panel();
      const wa = panel.workers.find((w) => w.name === "worker-a")!;
      expect(wa.driver).toBe("attach");
      expect(wa.state).toBe("Running");
      expect(wa.pid).toBeUndefined();

      // 2. lead steers → ack delivered + task event on the WORKER's socket
      const steerAck = await lead.steer({ name: "worker-a", prompt: "summarize X", conversationId: "conv-attach-1" });
      expect(steerAck.receipt).toBe("delivered");
      const task = await worker.nextTask();
      expect(task.conversationId).toBe("conv-attach-1");
      expect(task.prompt).toBe("summarize X");
      expect(task.steer).toBe(true);

      // 3. the session answers → reply arrives on the LEAD's conversation
      const ans = await worker.answer("conv-attach-1", "done: summarize X");
      expect(ans.receipt).toBe("delivered");
      const reply = await lead.nextReply("conv-attach-1");
      expect(reply.from).toBe("worker-a");
      expect(reply.text).toBe("done: summarize X");
      expect(reply.receipt).toBe("delivered");

      // task turn complete → back to Idle on the rack
      await waitFor(async () => (await lead.panel()).workers.find((w) => w.name === "worker-a")?.state === "Idle", 3000);

      // 4. worker session closes → detach → Inactive
      await worker.close();
      await waitFor(async () => (await lead.panel()).workers.find((w) => w.name === "worker-a")?.state === "Inactive", 3000);
    } finally {
      await lead.close();
      await worker.close();
      await serve.close();
    }
  }, 20_000);

  it("spawned ⇄ attached mutual exclusion (E_DUPLICATE both ways)", async () => {
    const { serve, client: lead } = await openDaemon(tmpFamily());
    const w1 = await DaemonClient.connect({ port: serve.port });
    const w2 = await DaemonClient.connect({ port: serve.port });
    try {
      await w1.attach({ name: "busy" });
      // second session attaching the same name → duplicate
      await expect(w2.attach({ name: "busy" })).rejects.toThrow(/already attached/);
      // daemon spawn of the same name while attached → duplicate
      await expect(lead.spawn({ name: "busy" })).rejects.toThrow(/already exists|daemon-spawned/);

      // after detach, spawn succeeds
      await lead.kill("busy"); // detaches the attached session
      const spawnAck = await lead.spawn({ name: "busy", role: "coder" });
      expect(spawnAck.receipt).toBe("delivered");
      // and attach of that name now fails (spawned live)
      await expect(w1.attach({ name: "busy" })).rejects.toThrow(/daemon-spawned|already exists/);
    } finally {
      await w1.close(); await w2.close();
      await lead.close();
      await serve.close();
    }
  }, 15_000);

  it("queued answer: no live conversation sink → receipt on disk, pickup drains it", async () => {
    const { serve, client: lead } = await openDaemon(tmpFamily());
    const worker = await DaemonClient.connect({ port: serve.port });
    try {
      await worker.attach({ name: "orphan" });
      const ans = await worker.answer("conv-nobody-owns", "late reply");
      expect(ans.receipt).toBe("queued");
      const receipts = await lead.pickupReceipts("conv-nobody-owns");
      expect(receipts).toHaveLength(1);
      expect(receipts[0]).toMatchObject({ conversationId: "conv-nobody-owns", from: "orphan", text: "late reply", status: "queued" });
    } finally {
      await worker.close(); await lead.close();
      await serve.close();
    }
  }, 15_000);
});
