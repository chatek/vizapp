/**
 * daemon-pi-worker.test.ts — INTEGRATION (cp2 WORKER SEAM): the REAL pi.dev
 * worker driver (worker-pi.ts) driven end to end over the Tier L socket.
 *
 * The driver spawns `pi --mode rpc` and translates daemon tasks to pi.dev\'s
 * JSONL RPC protocol. NO live pi.dev host is required here: VCLAW_PI_BIN points
 * at test/integration/fake-pi.cjs, a fake `pi` binary that speaks the same RPC
 * subset (prompt/steer → response + agent_settled → get_last_assistant_text)
 * and writes its session transcript to <session-dir>/<session-id>.jsonl — the
 * same contract the real pi.dev keeps. What still needs a LIVE pi.dev host to
 * verify (marked in worker-pi.ts): exact argv composition, real session-file
 * placement, and the extension_ui_request auto-cancel policy.
 *
 * Covers: spawn→reply over the pi RPC path; steer; state transitions; session
 * transcript under sessions/pi/; daemon restart reuses the session-id so the
 * transcript keeps BOTH epochs (reload without losing history, acceptance #4).
 */
import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { tmpFamily, openDaemon, fakePiBin, waitFor } from "./daemon-helpers.js";
import { pidAlive } from "../../src/daemon/index.js";

const piBin = fakePiBin();

describe("Tier L daemon with pi.dev RPC worker driver (fake pi)", () => {
  it("spawn → pi prompt → reply → Idle; steer → pi steer → reply → Idle", async () => {
    const dir = tmpFamily();
    const { serve, client } = await openDaemon({ dir, driver: "pi", piBin });
    try {
      const conv = "pi-1";
      const ack = await client.spawn({ name: "w1", role: "coder", prompt: "task one", conversationId: conv });
      expect(ack.receipt).toBe("delivered");
      expect(ack.worker?.driver).toBe("pi");
      expect(ack.worker?.state).toBe("Running");
      expect(ack.worker?.pid).toBeGreaterThan(0);
      expect(pidAlive(ack.worker?.pid)).toBe(true);

      const reply1 = await client.nextReply(conv);
      expect(reply1.text).toBe("done: task one");
      expect(reply1.from).toBe("w1");

      await waitFor(async () => (await client.panel()).workers.find((w) => w.name === "w1")?.state === "Idle", 3_000);

      const steerAck = await client.steer({ name: "w1", prompt: "turn", conversationId: "pi-1b" });
      expect(steerAck.receipt).toBe("delivered");
      const reply2 = await client.nextReply("pi-1b");
      expect(reply2.text).toBe("[steered] turn");

      // The pi.dev session transcript lives under sessions/pi/ (fake layout).
      const transcript = join(dir, "sessions", "pi", "w1.jsonl");
      expect(existsSync(transcript)).toBe(true);
      const content = readFileSync(transcript, "utf8");
      expect(content).toContain("task one");
      expect(content).toContain("turn");

      const panel = await client.panel();
      const w1 = panel.workers.find((w) => w.name === "w1")!;
      expect(w1.state).toBe("Idle");
      expect(w1.driver).toBe("pi");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 25_000);

  it("daemon restart: same roster, pi session-id reused → transcript keeps both epochs (no history loss)", async () => {
    const dir = tmpFamily();
    const serveA = await openDaemon({ dir, driver: "pi", piBin });
    await serveA.client.spawn({ name: "w1", prompt: "epoch one", conversationId: "pi-r1" });
    expect((await serveA.client.nextReply("pi-r1")).text).toBe("done: epoch one");
    const pidA = (await serveA.client.panel()).workers.find((w) => w.name === "w1")?.pid!;
    await serveA.client.close();
    await serveA.serve.close(); // graceful G6 cascade → record Inactive

    const serveB = await openDaemon({ dir, driver: "pi", piBin });
    try {
      expect(serveB.serve.familyId).toBe(serveA.serve.familyId);
      // Same roster, worker recovered Inactive, same pi session id reserved.
      const roster = await serveB.client.panel();
      const w1 = roster.workers.find((w) => w.name === "w1")!;
      expect(w1.name).toBe("w1");
      expect(w1.driver).toBe("pi");
      expect(w1.state).toBe("Inactive");

      // Re-address: reload keeps the SAME session-id → pi.dev (fake) appends.
      const steerAck = await serveB.client.steer({ name: "w1", prompt: "epoch two", conversationId: "pi-r2" });
      expect(steerAck.message).toContain("respawned");
      expect((await serveB.client.nextReply("pi-r2")).text).toBe("[steered] epoch two");
      await waitFor(() => !pidAlive(pidA), 2_000);

      const transcript = join(dir, "sessions", "pi", "w1.jsonl");
      const content = readFileSync(transcript, "utf8");
      expect(content).toContain("epoch one"); // history BEFORE the restart
      expect(content).toContain("epoch two"); // appended AFTER the restart
    } finally {
      await serveB.client.close();
      await serveB.serve.close();
    }
  }, 30_000);

  it("stop and kill map pi worker state to Inactive; unknown worker errors", async () => {
    const dir = tmpFamily();
    const { serve, client } = await openDaemon({ dir, driver: "pi", piBin });
    try {
      await client.spawn({ name: "w1", prompt: "x", conversationId: "pi-s1" });
      await client.nextReply("pi-s1");
      const state = async () => (await client.panel()).workers.find((w) => w.name === "w1")?.state;
      await waitFor(async () => (await state()) === "Idle", 3_000);

      await client.stop("w1");
      await waitFor(async () => (await state()) === "Inactive", 4_000);

      // Reload after stop, then kill.
      await client.steer({ name: "w1", prompt: "again", conversationId: "pi-s2" });
      await client.nextReply("pi-s2");
      await client.kill("w1");
      await waitFor(async () => (await state()) === "Inactive", 4_000);
      expect((await client.panel()).workers.find((w) => w.name === "w1")?.note).toContain("SIGTERM");

      await expect(client.steer({ name: "ghost", prompt: "hi" })).rejects.toThrow("E_NOT_FOUND");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 25_000);
});
