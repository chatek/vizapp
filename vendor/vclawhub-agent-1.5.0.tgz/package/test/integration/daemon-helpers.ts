/**
 * daemon-helpers.ts — shared helpers for the sprint2 daemon integration tests.
 * Owned by sprint2 (cp2); existing helpers in test/helpers/ belong to sprint1.
 */
import { mkdtempSync, chmodSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { startServe, DaemonClient } from "../../src/daemon/index.js";

export async function waitFor(pred: () => boolean | Promise<boolean>, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  const tick = async (): Promise<void> => {
    if (await pred()) return;
    if (Date.now() > deadline) throw new Error("waitFor timeout");
    await new Promise((r) => setTimeout(r, 50));
    return tick();
  };
  await tick();
}

export function tmpFamily(): string {
  return mkdtempSync(join(tmpdir(), "vclaw-daemon-"));
}

/** Canonical fake pi.dev binary path (test/integration/fake-pi.cjs). */
export function fakePiBin(): string {
  const bin = fileURLToPath(new URL("./fake-pi.cjs", import.meta.url));
  chmodSync(bin, 0o755); // idempotent — spawn() needs the exec bit
  return bin;
}

export async function openDaemon(opts: { dir: string; driver?: "stub" | "pi"; piBin?: string; replyDelayMs?: number; idleUnloadMs?: number }) {
  const serve = await startServe({
    familyDirOverride: opts.dir,
    port: 0,
    workerDriver: opts.driver,
    piBin: opts.piBin,
    replyDelayMs: opts.replyDelayMs ?? 20,
    idleUnloadMs: opts.idleUnloadMs,
  });
  const client = await DaemonClient.connect({ port: serve.port });
  return { serve, client };
}
