/**
 * p2p-artifacts.test.ts — THE M3 WEDGE GATE (Pears Tier P, artifacts plane).
 *
 * Two agents (each with its own node sidecar), ONE delegation, private
 * offline DHT + roster direct-dial (the M2 loopback harness shape). The
 * capability that did not exist before: a >= 20 MB artifact crossing hosts
 * BY REF while the hub-visible announcement stays metadata-only.
 *
 * Proves:
 *   G1 THE WEDGE — writer putArtifact of a >= 20 MB artifact (deliberately
 *      NOT block-aligned); reader (a second sidecar, attached from the
 *      ANNOUNCEMENT's artifacts baseKey) fetches by blobRef through the
 *      swarm; receiver sha256 == sender sha256, byte-exact.
 *   G2 RANGE READS — byte ranges return exactly the requested bytes; a
 *      seek-style pattern (head / mid crossing a 1 MiB chunk boundary /
 *      tail) over one artifact works.
 *   DIGEST REFUSAL — a tampered ref (wrong sha256) REFUSES with
 *      ArtifactDigestMismatchError; garbage never passes up (the Q5
 *      consequence enforced at the client edge).
 *   ROLE REFUSAL — a reader's sidecar refuses blobPut (artifacts core is
 *      read-only for non-writers).
 *   ANNOUNCEMENT SIZE — the live announcement envelope (built from the real
 *      attach/put results) is < 1 KB of metadata.
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { rmSync, mkdirSync } from "node:fs";
import { randomBytes, createHash } from "node:crypto";
import path from "node:path";
import { SidecarClient } from "../../src/net/p2p/client.js";
import { derivePeerKeyPair, deriveWriterKeyPair, deriveArtifactsWriterKeyPair } from "../../src/net/p2p/identity.js";
import { delegationTopic } from "../../src/net/p2p/topic.js";
import { putArtifact, getArtifact, buildArtifactAnnouncement, encodeBlobRef, decodeBlobRef, ArtifactDigestMismatchError, type ArtifactAnnouncement } from "../../src/net/p2p/artifacts.js";
import { toolchain, ensureSidecarBuilt, freeUdpPort, randomRootSeed, randomContentKey, storeDir, b64 } from "../helpers/pears-sidecar.js";

const tc = toolchain();
const delegationId = "dlg-artifacts-m3";
const encKey = randomContentKey();
/** >= 20 MB gate, deliberately not block- or chunk-aligned (offset math must earn its keep). */
const ARTIFACT_SIZE = 20_000_003;

let writer: SidecarClient | null = null;
let reader: SidecarClient | null = null;
let dirW = "";
let dirR = "";
let seedPort = 0;
let peerWPubHex = "";

const artifact = randomBytes(ARTIFACT_SIZE);
const artifactSha = createHash("sha256").update(artifact).digest("hex");

let put: { blobRef: string; size: number; sha256: string } | null = null;
let announcement: ArtifactAnnouncement | null = null;
let announcementBytes = 0;

beforeAll(async () => {
  if (!tc.ok && !ensureSidecarBuilt(tc)) {
    throw new Error("sidecar toolchain unavailable — set PEARS_SIDECAR_OPTIONAL=1 to skip intentionally");
  }
  seedPort = await freeUdpPort();
  dirW = storeDir("art-w");
  dirR = storeDir("art-r");
  for (const dir of [dirW, dirR]) mkdirSync(path.dirname(dir), { recursive: true });

  const seedW = randomRootSeed();
  const seedR = randomRootSeed();
  const logWriter = await deriveWriterKeyPair(seedW, delegationId);
  const artifactsWriter = await deriveArtifactsWriterKeyPair(seedW, delegationId);

  // Writer: the delegation writer AND the private-net seed, with the
  // artifacts base opened from its own fabric-derived keypair.
  writer = new SidecarClient();
  const helloW = await writer.start({
    storeDir: dirW,
    peerKeyPair: await derivePeerKeyPair(seedW),
    network: { bindHost: "127.0.0.1", seedPort },
    bootTimeoutMs: 30000,
  });
  peerWPubHex = helloW.peer.publicKey;
  const attachW = await writer.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "writer",
    encryptionKey: b64(encKey),
    writerKeyPair: { publicKey: b64(logWriter.publicKey), secretKey: b64(logWriter.secretKey) },
    artifacts: { writerKeyPair: { publicKey: b64(artifactsWriter.publicKey), secretKey: b64(artifactsWriter.secretKey) } },
  });
  expect(attachW.artifactsBaseKey).toBeTruthy();

  // THE WEDGE: >= 20 MB through the chunked IPC put.
  put = await putArtifact(writer, delegationId, artifact);
  expect(put.size).toBe(ARTIFACT_SIZE);
  expect(put.sha256).toBe(artifactSha);

  // The announcement the hub would carry — metadata only.
  announcement = {
    delegation: delegationId,
    baseKey: attachW.artifactsBaseKey ?? "",
    blobRef: put.blobRef,
    size: put.size,
    sha256: put.sha256,
  };
  announcementBytes = buildArtifactAnnouncement(announcement).length;

  // Reader: attaches FROM THE ANNOUNCEMENT (artifacts baseKey + the log base
  // key), dials the writer by roster — the bytes flow peer-to-peer.
  reader = new SidecarClient();
  await reader.start({
    storeDir: dirR,
    peerKeyPair: await derivePeerKeyPair(seedR),
    network: { bindHost: "127.0.0.1", bootstrap: [{ host: "127.0.0.1", port: seedPort }] },
    bootTimeoutMs: 30000,
  });
  const attachR = await reader.attach({
    delegationId,
    topic: b64(delegationTopic(delegationId)),
    role: "reader",
    baseKey: attachW.baseKey,
    encryptionKey: b64(encKey),
    artifacts: { baseKey: announcement.baseKey },
    peers: [{ publicKey: b64(new Uint8Array(Buffer.from(peerWPubHex, "hex"))) }],
  });
  expect(attachR.artifactsBaseKey).toBe(announcement.baseKey);
}, 180000);

afterAll(async () => {
  for (const client of [reader, writer]) await client?.stop().catch(() => undefined);
  for (const dir of [dirR, dirW]) rmSync(dir, { recursive: true, force: true });
});

describe("G1 — the wedge: >= 20 MB artifact across two sidecars, one delegation", () => {
  it(
    "reader fetches by blobRef: sha256 matches, bytes exact, size asserted",
    async () => {
      expect(put).not.toBeNull();
      expect(announcement).not.toBeNull();
      expect(put!.size).toBeGreaterThanOrEqual(20_000_000); // THE GATE SIZE
      const got = await getArtifact(reader!, delegationId, put!.blobRef, { timeoutMs: 120000 });
      expect(got.length).toBe(ARTIFACT_SIZE);
      const gotSha = createHash("sha256").update(Buffer.from(got)).digest("hex");
      expect(gotSha).toBe(artifactSha); // receiver digest == sender digest
      expect(Buffer.compare(Buffer.from(got), Buffer.from(artifact.subarray(0, got.length)))).toBe(0); // byte-exact
    },
    180000,
  );

  it("the announcement of that artifact is metadata-only (< 1 KB)", () => {
    expect(announcementBytes).toBeGreaterThan(100); // real baseKey+ref+digest
    expect(announcementBytes).toBeLessThan(1024);
  });

  it("room stats count the artifact plane", async () => {
    const stats = await writer!.stats();
    const room = stats.rooms.find((r) => r.delegationId === delegationId);
    expect(room?.artifactsPuts).toBeGreaterThanOrEqual(1);
  });
});

describe("G2 — range reads (video-style seeking)", () => {
  it(
    "a mid-artifact range crossing a 1 MiB chunk boundary returns exactly those bytes",
    async () => {
      const offset = 1024 * 1024 - 7; // deliberately spans two blobPut chunk spans
      const length = 300_000;
      const got = await getArtifact(reader!, delegationId, put!.blobRef, { range: { offset, length }, timeoutMs: 120000 });
      expect(got.length).toBe(length);
      expect(Buffer.from(got)).toEqual(Buffer.from(artifact.subarray(offset, offset + length)));
    },
    120000,
  );

  it(
    "a seek pattern — head, then far tail, then re-read the same head — is exact every time",
    async () => {
      const ranges = [
        { offset: 0, length: 65536 },
        { offset: ARTIFACT_SIZE - 4096, length: 4096 },
        { offset: 0, length: 65536 }, // seek back: same bytes again
      ];
      for (const range of ranges) {
        const got = await getArtifact(reader!, delegationId, put!.blobRef, { range, timeoutMs: 120000 });
        expect(Buffer.from(got)).toEqual(Buffer.from(artifact.subarray(range.offset, range.offset + range.length)));
      }
    },
    120000,
  );

  it("a range past the artifact's end refuses", async () => {
    await expect(
      getArtifact(reader!, delegationId, put!.blobRef, { range: { offset: ARTIFACT_SIZE - 4, length: 8 } }),
    ).rejects.toThrow(/exceeds the artifact/);
  });
});

describe("digest + role refusals (the Q5 consequence at the artifact edge)", () => {
  it(
    "a tampered ref (wrong sha256) REFUSES with ArtifactDigestMismatchError — garbage never passes up",
    async () => {
      const ref = decodeBlobRef(put!.blobRef);
      const tampered = (parseInt(ref.sha256.slice(0, 2), 16) ^ 0xff).toString(16).padStart(2, "0") + ref.sha256.slice(2);
      const tamperedRef = encodeBlobRef({ ...ref, sha256: tampered });
      await expect(getArtifact(reader!, delegationId, tamperedRef, { timeoutMs: 120000 })).rejects.toBeInstanceOf(ArtifactDigestMismatchError);
    },
    120000,
  );

  it("a reader's sidecar refuses blobPut (artifacts core is read-only)", async () => {
    await expect(
      reader!.blobPut(delegationId, new Uint8Array([1, 2, 3]), createHash("sha256").update(new Uint8Array([1, 2, 3])).digest("hex")),
    ).rejects.toThrow(/read-only/);
  });
});
