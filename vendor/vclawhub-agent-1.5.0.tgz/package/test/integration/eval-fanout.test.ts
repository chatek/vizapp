/**
 * eval-fanout.test.ts — INTEGRATION (v9 W4): the fan-out eval harness end to
 * end with REAL daemon + REAL stub-worker child processes.
 *
 * Verify (UPGRADE.md §6 W4 + acceptance #1's hermetic half): ONE daemon
 * spawns N workers under one family dir; results come back by reply (each
 * worker's own conversation) AND file (per-worker session transcript in the
 * family dir); the report aggregates ok/failed; a worker that never answers
 * fails per-worker without hanging the run; daemon close cascades (G6).
 */
import { describe, it, expect } from "vitest";
import { existsSync, readFileSync } from "node:fs";
import { runFanoutEval, renderEvalReport } from "../../src/daemon/eval.js";

describe("fan-out eval harness (v9 W4)", () => {
  it("one task over 3 stub workers: 3 replies by conversation AND transcripts on disk", async () => {
    const report = await runFanoutEval({
      task: "review: does the design hold?",
      workers: ["w1", "w2", "w3"],
      role: "reviewer",
      replyDelayMs: 10,
      perWorkerTimeoutMs: 5000,
    });

    expect(report.kind).toBe("fanout_eval");
    expect(report.ok).toBe(3);
    expect(report.failed).toBe(0);
    expect(report.workers).toHaveLength(3);
    expect(report.familyId.length).toBeGreaterThan(0);

    for (const w of report.workers) {
      expect(w.error).toBeUndefined();
      // reply half: the worker answered its own copy of the task
      expect(w.replyText).toBe("done: review: does the design hold?");
      // file half: the per-worker transcript exists with the worker's turns
      expect(existsSync(w.transcriptFile)).toBe(true);
      expect(w.transcriptLines).toBeGreaterThanOrEqual(3); // worker_start + in + out
      const transcript = readFileSync(w.transcriptFile, "utf8");
      expect(transcript).toContain("worker_start");
      expect(transcript).toContain(`"dir":"out"`);
    }

    // Renderable + deterministic-ish summary line.
    const text = renderEvalReport(report);
    expect(text).toContain("3 ok / 0 failed");
    expect(text).toContain("review: does the design hold?");
  }, 20_000);

  it("a worker that never answers fails per-worker; the run still completes and cascades", async () => {
    const report = await runFanoutEval({
      task: "fast path",
      workers: ["fast", "slow"],
      role: "coder",
      // The stub replies after replyDelayMs (~20 default). A 1ms timeout makes
      // every worker fail — assert the per-worker failure path + report shape.
      perWorkerTimeoutMs: 1,
    });

    expect(report.ok).toBe(0);
    expect(report.failed).toBe(2);
    for (const w of report.workers) {
      expect(w.error).toMatch(/no reply within|timed out/);
      expect(existsSync(w.transcriptFile)).toBe(true); // workers did start
    }
  }, 20_000);
});
