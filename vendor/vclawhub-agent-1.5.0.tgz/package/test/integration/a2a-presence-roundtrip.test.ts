/**
 * a2a-presence-roundtrip.test.ts — INTEGRATION (J1b): a REAL NATS server
 * drives the full agent-sdk wire layer — startPresence (presence_update
 * online/offline), watchDirectory (peer_discovered + peer_evicted TTL sweep),
 * and the a2a roundtrip (a2aSend → subA2A handler → a2a_response reply).
 *
 * Why this exists: the unit tests use an in-memory mock bus (presence.test.ts)
 * which can't catch NATS wildcard semantics. This test caught a latent wire
 * bug — a2aSend published to the bare `tenant.default.a2a.{nkey}` subject while
 * subA2A subscribes to `tenant.default.a2a.{nkey}.>` (NATS `>` needs a trailing
 * token), so a2aSend never reached subA2A. Fixed in a2aTargetSubject (.req
 * suffix); this test is the regression guard.
 *
 * Requires a `nats-server` binary on PATH (homebrew: `brew install nats-server`).
 */
import { describe, it, expect, afterAll } from "vitest";
import { spawn } from "node:child_process";
import net from "node:net";
import { connect } from "@nats-io/transport-node";
import { nkeys } from "@nats-io/nats-core";
import { startPresence } from "../../src/net/presence.js";
import { watchDirectory } from "../../src/net/directory.js";
import { subA2A, a2aSend } from "../../src/net/a2a.js";

const PORT = 43231 + Math.floor(Math.random() * 200);

async function waitForPort(port: number, timeoutMs = 10_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const ok = await new Promise<boolean>((resolve) => {
      const s = net.connect(port, "127.0.0.1");
      s.once("connect", () => { s.destroy(); resolve(true); });
      s.once("error", () => resolve(false));
    });
    if (ok) return;
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error(`nats-server did not open port ${port}`);
}

/** Poll a predicate until true or timeout (timing-tolerant assertions). */
function waitFor<T>(pred: () => T, timeoutMs: number): Promise<T> {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve, reject) => {
    const tick = () => {
      let v: T;
      try { v = pred(); } catch (e) { return reject(e); }
      if (v) return resolve(v);
      if (Date.now() > deadline) return reject(new Error("waitFor timeout"));
      setTimeout(tick, 50);
    };
    tick();
  });
}

let serverProc: ReturnType<typeof spawn> | null = null;

describe("A2A wire layer (real NATS): presence + directory + a2a roundtrip", () => {
  afterAll(() => {
    serverProc?.kill();
    serverProc = null;
  });

  it("presence_update online → peer_discovered → a2a roundtrip → peer_evicted → presence_update offline", async () => {
    serverProc = spawn("nats-server", ["-p", String(PORT), "--jetstream"], {
      stdio: "ignore",
    });
    await waitForPort(PORT);

    // Two agents with real ed25519 nkeys (sign announces + verify directory).
    const kpA = nkeys.createUser();
    const kpB = nkeys.createUser();
    const seedA = new TextDecoder().decode(kpA.getSeed());
    const pubA = kpA.getPublicKey();
    const seedB = new TextDecoder().decode(kpB.getSeed());
    const pubB = kpB.getPublicKey();
    const enc = new TextEncoder();
    const dec = new TextDecoder();

    const ncA = await connect({ servers: `127.0.0.1:${PORT}` });
    const ncB = await connect({ servers: `127.0.0.1:${PORT}` });
    type Ev = { kind: string; nkey?: string; online?: boolean; prompt?: string };
    const events: Ev[] = [];
    const note = (e: Ev) => events.push(e);

    try {
      // ── Agent A: presence + directory watch (short TTL → peer_evicted) + a2a sub ──
      const presenceA = startPresence(ncA, { nkey: pubA, nonce: "agentA" }, {
        seed: seedA, segment: "default", capabilities: ["collaborate"], model: "test",
        online: true, heartbeat: false,
        onOnline: () => note({ kind: "presence_update", nkey: pubA, online: true }),
        onOffline: () => note({ kind: "presence_update", nkey: pubA, online: false }),
      });
      const watchA = watchDirectory(ncA, "default", {
        ttlMs: 600, sweepMs: 150,
        onEntry: (e) => note({ kind: "peer_discovered", nkey: e.nkey }),
        onEvict: (e) => note({ kind: "peer_evicted", nkey: e.nkey }),
      });
      subA2A(ncA, { nkey: pubA, nonce: "agentA" }, (msg) => {
        const env = msg.envelope as { a2a?: { replySubject?: string }; prompt?: string } | undefined;
        const replyTo = env?.a2a?.replySubject || msg.reply;
        note({ kind: "a2a_received", prompt: env?.prompt });
        // Simulate the extension's reply shape: a2a_response on the reply subject.
        if (replyTo) {
          ncA.publish(replyTo, enc.encode(JSON.stringify({
            type: "a2a_response", id: "resp1",
            from: { nkey: pubA, name: "agentA" },
            text: "hello from A", ts: new Date().toISOString(),
          })));
        }
      });

      // ── Agent B: announce once (intervalMs high so its entry expires under A's TTL) ──
      const presenceB = startPresence(ncB, { nkey: pubB, nonce: "agentB" }, {
        seed: seedB, segment: "default", capabilities: ["collaborate"], model: "test",
        online: true, heartbeat: false, intervalMs: 10_000,
      });

      // 1. presence_update online (A's first announce) + peer_discovered (B).
      await waitFor(
        () => events.some((e) => e.kind === "presence_update" && e.online && e.nkey === pubA),
        4_000,
      );
      await waitFor(
        () => events.some((e) => e.kind === "peer_discovered" && e.nkey === pubB),
        4_000,
      );
      expect(events.some((e) => e.kind === "presence_update" && e.online && e.nkey === pubA)).toBe(true);
      expect(events.some((e) => e.kind === "peer_discovered" && e.nkey === pubB)).toBe(true);

      // 2. a2a roundtrip: B a2aSend → A's subA2A → a2a_response → B receives.
      const replyInbox = `_INBOX.a2atest.${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
      let a2aReply: { type?: string; text?: string } | null = null;
      const replyDone = new Promise<void>((resolve) => {
        ncB.subscribe(replyInbox, {
          max: 1,
          callback: (_e, m) => {
            a2aReply = JSON.parse(dec.decode(m.data)) as { type?: string; text?: string };
            resolve();
          },
        });
      });
      await new Promise((r) => setTimeout(r, 200)); // let A's subA2A attach
      a2aSend(ncB, pubA, "hello A", { nkey: pubB, nonce: "agentB" }, replyInbox);
      await Promise.race([
        replyDone,
        new Promise((_, rej) => setTimeout(() => rej(new Error("a2a reply timeout")), 5_000)),
      ]);
      expect(events.some((e) => e.kind === "a2a_received" && e.prompt === "hello A")).toBe(true);
      expect(a2aReply?.type).toBe("a2a_response");
      expect(a2aReply?.text).toBe("hello from A");

      // 3. peer_evicted: B's single announce expires under A's short TTL.
      await waitFor(
        () => events.some((e) => e.kind === "peer_evicted" && e.nkey === pubB),
        4_000,
      );
      expect(events.some((e) => e.kind === "peer_evicted" && e.nkey === pubB)).toBe(true);

      // 4. presence_update offline (A stops → publishes online:false → onOffline).
      await presenceA.stop();
      await waitFor(
        () => events.some((e) => e.kind === "presence_update" && e.online === false && e.nkey === pubA),
        2_000,
      );
      expect(events.some((e) => e.kind === "presence_update" && e.online === false && e.nkey === pubA)).toBe(true);

      watchA.stop();
      await presenceB.stop();
    } finally {
      await ncA.drain();
      await ncB.drain();
    }
  }, 30_000);
});
