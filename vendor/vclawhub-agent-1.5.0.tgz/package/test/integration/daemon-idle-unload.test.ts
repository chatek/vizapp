/**
 * daemon-idle-unload.test.ts — INTEGRATION (cp2 IDLE UNLOAD/RELOAD, acceptance
 * #4): Idle workers unload from memory (process dropped) and reload on demand
 * WITHOUT losing history (transcripts persist; the worker record keeps its
 * session file). Covers the explicit `unload` verb, the Running-refusal, the
 * timer sweep (VCLAW/opt idleUnloadMs), and history retention across unload →
 * re-address (session JSONL holds both epochs).
 */
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { tmpFamily, openDaemon, waitFor } from "./daemon-helpers.js";
import { pidAlive } from "../../src/daemon/index.js";

describe("idle unload / reload (acceptance #4)", () => {
  it("unload verb drops an Idle worker; re-address reloads it WITH history", async () => {
    const dir = tmpFamily();
    const { serve, client } = await openDaemon({ dir });
    try {
      await client.spawn({ name: "w1", prompt: "epoch pre-unload", conversationId: "u-1" });
      expect((await client.nextReply("u-1")).text).toBe("done: epoch pre-unload");
      const state = async () => (await client.panel()).workers.find((w) => w.name === "w1");
      await waitFor(async () => (await state())?.state === "Idle", 3_000);
      const pid = (await state())?.pid!;
      expect(pidAlive(pid)).toBe(true);

      const unloadAck = await client.unload("w1");
      expect(unloadAck.receipt).toBe("delivered");
      await waitFor(async () => (await state())?.state === "Inactive", 4_000);
      expect((await state())?.note).toBe("unloaded (idle)");
      await waitFor(() => !pidAlive(pid), 3_000); // process actually dropped

      // Reload on demand: same name, same session file (history retained).
      const steerAck = await client.steer({ name: "w1", prompt: "epoch post-unload", conversationId: "u-2" });
      expect(steerAck.receipt).toBe("delivered");
      expect(steerAck.message).toContain("respawned");
      expect((await client.nextReply("u-2")).text).toBe("[steered] epoch post-unload");

      const session = readFileSync(join(dir, "sessions", "w1.jsonl"), "utf8");
      expect(session).toContain("epoch pre-unload");
      expect(session).toContain("epoch post-unload");
      expect(session).toContain('"type":"daemon_unload"');
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);

  it("unload refuses a Running worker; unknown worker → E_NOT_FOUND", async () => {
    const dir = tmpFamily();
    const { serve, client } = await openDaemon({ dir, replyDelayMs: 400 });
    try {
      await client.spawn({ name: "w1", prompt: "busy", conversationId: "u-busy" });
      // w1 is Running (reply not awaited); unload must refuse.
      await expect(client.unload("w1")).rejects.toThrow("E_BAD_REQUEST");
      await client.nextReply("u-busy"); // drain so close() is clean
      await expect(client.unload("ghost")).rejects.toThrow("E_NOT_FOUND");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 15_000);

  it("idle sweep (idleUnloadMs) unloads workers whose last activity is stale", async () => {
    const dir = tmpFamily();
    const { serve, client } = await openDaemon({ dir, idleUnloadMs: 250 });
    try {
      await client.spawn({ name: "w1", prompt: "sweep me", conversationId: "u-sw" });
      await client.nextReply("u-sw"); // task done → Idle; lastReplyAt now
      const state = async () => (await client.panel()).workers.find((w) => w.name === "w1");
      await waitFor(async () => (await state())?.state === "Idle", 3_000);

      // Sweep fires after idleUnloadMs of no activity → unloaded (idle).
      await waitFor(async () => (await state())?.state === "Inactive", 5_000);
      expect((await state())?.note).toBe("unloaded (idle)");
    } finally {
      await client.close();
      await serve.close();
    }
  }, 20_000);
});
