# AGENT_RETIRE — Adversarial Review of the J16c design

> **Status: REVIEW, 2026-09-16 · lane `vchat-email-dc9818` · desk-only.** Subject:
> `AGENT_RETIRE.md` §3 Phase 2 (NKey-proof self-retire), the §7.1–7.3 rulings, and the
> §8 design hazard — read against source. Every finding carries **[R]** citations
> (file:line, verified 2026-09-16 against the working tree), the **exact desk probe**
> that would demonstrate it, and a **negative control that can flip**. No probe was or
> will be executed against a live authenticated endpoint (standing rule, 2026-09-15);
> every probe is written as a unit/fixture test shape (`retire_test.go` pattern) or a
> static read. No credential values appear in this file.
>
> Operator rulings in force (not relitigated): possession-based self-retire ACCEPTED;
> scoped to `class:ephemeral`; the 168 h abandoned-pending sweep ACCEPTED.

---

## 0. Verdict

The §7.2 `class:ephemeral` ruling is the load-bearing decision — and it holds **only if
two things are pinned in the implementation that the doc currently leaves open**:

1. **F1 (critical):** the proof's verification key must be **derived from the canonical
   path nkey**, never from a field of the proof. The only NKey-proof precedent in this
   codebase (`token.go`) verifies against `payload.Iss` — correct for a self-referential
   endpoint, **fatal if reused on a path-parameterized destructive one**.
2. **F3 (high):** the §8 hazard lives **in the claim path, not approve** — claim.go
   *auto-approves* whatever the agent-controlled pending record holds. The doc's §5 CI
   line ("onboard (throwaway seed, class:ephemeral)") reads as an introduce-body flag,
   which is exactly the collapse §8 warns about.

With those pinned, probes #2/#3/#4/#6 reduce to specification choices with known-good
in-repo patterns; probe #5's "possession adds almost nothing" argument **survives, but
only for the ephemeral class** — the ruling is what makes the argument true (§5 below).

---

## 1. Findings, ranked

### F1 — CRITICAL · The path-vs-proof binding is unspecified, and the in-repo precedent points the wrong way for this route

**[R]** The route takes its target from the path: `POST /v1/agent/{nkey}/retire`
(`retire.go:192` path extraction; both key forms accepted, E1 block). The only NKey-proof
implementation in vgate is `validateClientAssertion` (`token.go:176-199`): it enforces
`iss == sub` (`token.go:176-178`), iat/exp with ≤300 s lifetime (`token.go:179-182`), then
verifies the signature **against `nkeys.FromPublicKey(payload.Iss)`** — the key named *in
the proof itself* (`token.go:189-198`). For `POST /v1/agent/token` that is self-binding by
construction: the proof's issuer IS the subject requesting its own token; there is no path
parameter to confuse. For retire, the target comes from the **path**. An implementation
that reuses the `validateClientAssertion` shape and then retires the path nkey verifies
the attacker's signature with the attacker's key and deletes the victim's identity.

The steward path binds authority to the path nkey by **comparison** — caller identity
(from the validated credential) vs the ownership record looked up *by the path nkey*
(`retire.go:245-257`). The NKey-proof path must bind by the same discipline: identity ←
proof, victim ← path, and the binding check is **equality between them**, with the
verification key derived from the path. NKeys make this free: the U-form string *is* the
base32-encoded Ed25519 public key (`base64.go:22` — 32-byte pubkey decode), so the server
needs no lookup to obtain the verify key — `canonical(path) → nkeys.FromPublicKey(canonical)`.

**Required spec sentence for §3 Phase 2:** *the proof is a fixed-length binding string —
`method ‖ canonical-nkey ‖ sha256(body) ‖ iat ‖ exp` — signed by the agent's seed; vgate
canonicalizes the PATH nkey, derives the Ed25519 public key from it, verifies the
signature against that key, and additionally requires `iss == canonical(path)` if the
proof carries an issuer field. A proof that does not name the path's key is invalid even
if internally well-formed.*

**Desk probe (unit-test shape):** craft proof P = `{iss: sub: ATK, aud: retire, iat/exp:
now}` signed by the *attacker's own* seed; request `POST /v1/agent/VICTIM/retire` with
body `{confirm:true}`. Correct implementation → signature check against VICTIM's derived
key fails → `401`. Naive (`token.go`-pattern) implementation → verifies against ATK's key
from `payload.Iss` → passes → VICTIM retired. Run as a table-driven test in
`retire_test.go` against a fixture KV; **no live endpoint involved**.

**Negative control:** the same crafted proof against the correct implementation must
return `401` — if the binding check is later loosened or the verify-key source is
refactored to the request, the control flips to `200`. A control that cannot flip is
inert; this one is one diff away from failing, which is the point.

---

### F2 — HIGH · The proof payload is unspecified: replay + body-swap upgrades a tombstone from informational to a 30-day re-onboard block

**[R]** `retire.go` takes `reason` from the body (`RetireRequest`, `retire.go:33-40`;
confirm gate `retire.go:215-217`) and writes it into the tombstone value
(`{retired_at, reason}`). Every re-onboard gate keys on the reason **string equality
`== "compromised"`**: `approve.go:323`, `introduce.go:171`, `register.go:171` (via
`compromisedRetired`, `retire.go:410`). The `token.go` assertion precedent bounds
lifetime (iat/exp, ≤300 s, `token.go:179-182`) but binds to **nothing else** — the signed
bytes are just `header.payload` (`token.go:193-197`).

If the J16c proof signs a constant ("retire-me"), a proof captured once is valid
forever, and a replay can carry a **different body**: `{confirm:true,
reason:"compromised"}` upgrades what would have been an informational tombstone into a
30-day re-onboard block on that nkey (all three gates). Second window: the tombstone
bucket itself expires at 30 d (`main.go:240-256`, `vchat_retired` 30 d TTL); after
expiry the nkey is re-adoptable, and the stale proof kills the *next* agent that reuses
the seed.

**Required spec:** the signed string must cover method + canonical path + canonical
nkey + `sha256(body)` + iat/exp (≤300 s, `token.go:179-182` discipline). With the body
bound, a replayed proof can only re-execute the *identical* retire — which is the
idempotent branch (`retire.go:223-241`: no side effects, no re-publish, no re-audit) —
i.e. **replay of a fully-bound proof is harmless by construction**. Answer to probe #2:
harmless *iff* bound as above; otherwise F2.

**Desk probe:** fixture KV; record proof P at t₀ with body `{confirm:true,
reason:"ci validation"}`; at t₀+31 d (simulated clock) replay P with body
`{confirm:true, reason:"compromised"}`. Unbound-proof implementation → retires and
writes a 30-day-blocking tombstone. Bound implementation → `401` (stale exp) *or*
`400` (body hash mismatch) depending on which check fires first — either is a pass.

**Negative control:** a fresh (in-window) replay with the *identical* body must land
`200` via the idempotent branch — proving the window rejects staleness and not replay
as such. If the in-window replay also fails, the implementation broke CI retry
semantics (§6.2) and the control catches the over-correction.

---

### F3 — HIGH · The §8 hazard is realized through CLAIM, not approve — and the doc's own CI flow reads as self-declaration

**[R]** `vchat_ownership` has exactly five writers: `approve.go:436` (steward request;
the `principal_class` precedent is **steward-supplied and enum-validated**,
`approve.go:219`, `approve.go:350-356`), **`claim.go:348`** (auto-approve — writes
ownership from the pending record plus the claiming human's token, `claim.go:293-348`),
and the map-merge rewrites `suspend.go:192` / `transfer.go:167` (preserve-all-fields,
comment-verified). The pending record is written by **introduce** — body
`{nkey_public, name, capabilities, invite}`, `introduce.go:19-28` — and is a *closed*
struct (`pendingRecord`, `claim.go:21-32`).

§8 warns "the class must be granted by the claiming authority … never chosen by the key
being created." But the grant surface the doc's §5 CI line implies —
`onboard (throwaway seed, class:ephemeral)` — is the introduce call (`onboard.ts`
drives `POST /v1/agent/introduce`). If `class` enters as an `IntroduceRequest` field
→ `pendingRecord` → `claim.go:348` copies it into ownership, **the agent self-declared
and the gate collapsed** — via the *auto-approving* path, which §8's invite-vs-approve
framing does not name. No steward decision sits between introduce and ownership on the
claim path; the claiming human merely completes OIDC and becomes steward
(`claim.go:302-312`, server-side exchange — not forgeable, but also not *deciding* a
class).

**Compliant grant points** (both steward-authored): (a) the **invite record** — invites
are created behind the id_token validator (`invites.go:155-162`) and are consumed at
introduce (`introduce.go:24-28`), so a class-bearing invite is a steward decision that
survives the stewardless CI container; (b) the **approve request** (the
`principal_class` precedent). For J16c: class MUST ride (a) for CI, MAY ride (b) for
humans, and MUST NOT appear in `IntroduceRequest`/`pendingRecord` at all.

**Desk probe:** introduce with body `{nkey_public, name, class:"ephemeral"}` → complete
claim against a fixture KV → read ownership. If `class:"ephemeral"` landed, the grant
path is agent-controlled (finding demonstrated). Also assert the field is *absent* from
the parsed pending record — struct-level rejection, not silent dropping.

**Negative control:** introduce **without** any class field must yield ownership with
no ephemeral class (default `agent`) — if the field lands anyway (e.g. a wholesale
body→record map copy added later), the control flips and catches the regression.

**[Q] surfaced dependency (for the lead, not blocking this review):** how does a
*headless* CI container complete claim's OIDC redirect at all (`claim.go:203`)? Whatever
the stewardless-admission answer is (invite auto-claim, proxy-claim), that mechanism is
precisely where the class grant must live — design them together or the class has no
CI-reachable grant point and the §5 flow cannot exist.

---

### F4 — MEDIUM · Class oracle: response ordering leaks existence and class to proof-less callers — fix is proof-verification-first

**[R]** Current order: authenticate (`retire.go:106-160`) → path (`retire.go:192-210`)
→ body/confirm (`retire.go:215-217`) → ownership lookup + idempotent branch
(`retire.go:223-241`) → steward/admin authz (`retire.go:243-257`). A J16c branch grafted
in at the authz stage answers: unknown nkey → `404 not_claimed`; known non-ephemeral →
`403`; known ephemeral + bad proof → `401`. A caller presenting **no proof at all**
learns both existence and class from the status code. Existence is already a lost cause
— `GET /v1/agent/status?nkey=` is **unauthenticated** and returns
claimed/steward/name/status (`status.go:8-27`, no validator in the handler; see F9) —
but *class* would be a new leak.

**Fix:** derive the verify key from `canonical(path)` (self-encoding — no ownership read
needed, works pre-lookup), verify the proof **first**, and return one uniform `401` for
every pre-proof failure (unknown nkey, non-ephemeral, garbage key). Only a *valid*
proof reaches the ownership/class logic where `404`/`403` live — and then the learner
is the seed-holder, for whom the class is their own business.

**Desk probe:** proof-less `POST {confirm:true}` against a known **non-ephemeral** nkey
(fixture KV) → correct implementation `401`; leaky ordering `403`.

**Negative control:** the identical request against an **unknown** nkey must return the
**same** `401` — the assertion is response-class *equality* across the two fixtures; any
divergence flips the control.

---

### F5 — MEDIUM · Audit records the victim's steward, never the actor — self/steward/admin/proxy retires are indistinguishable events (probe #6)

**[R]** The audit hook signature is `func(nkey, steward, chattoUserID, reason string)`
(`retire.go:97-102`) and the call passes `steward` — **the ownership record's steward
(`retire.go:245-248`), not the authenticated caller** (`email`/`humanUUID` are in scope
from the auth block and never reach the audit). `AuditEvent` has fields
`ts/type/nkey/steward/detail` only (`audit.go:18-24`). Consequence, pre-dating J16c:
admin-vs-steward-vs-proxy retirements already produce indistinguishable records; J16c
adds a fourth indistinguishable actor. The doc's own doctrine makes audit "the system
of record" (§4) and the CI's only ack — a system of record that cannot attribute fails
its stated purpose exactly during an incident ("was this the CI or the thief?" has no
artifact).

**Fix (cheap, high forensic value):** add `actor` and `authz` fields to the retire
audit event — `authz ∈ {self:nkey-proof, steward:id_token, admin:id_token,
service:proxy}` — for **all** retire paths, and mirror both into (i) the tombstone value
and (ii) the retired control publish (whose `ctrlData` today carries only `steward`,
`retire.go` publish block). This is additive; no consumer breaks.

**Desk probe:** unit-call the handler twice against the same fixture (once via the
id_token path as steward, once via the admin override), capture both `AuditEvent`
JSON bodies, diff. Today: identical (finding demonstrated). Post-fix: they must differ
in `authz`/`actor`.

**Negative control:** the post-fix two-event diff must be **non-empty** — if a future
refactor drops the actor fields, the diff collapses to empty and the control flips.

---

### F6 — MEDIUM · A suspended ephemeral agent must not be self-retirable — the pierce-the-freeze hole (probe #4's mutability answer includes state, not just class)

**[R]** Suspend is the steward's reversible freeze: ownership gains a `suspended` flag,
the token-mint path denies (`token.go` suspended check), and the design comment rules
"retire/configure stay available (retire wins)" — written for the **steward matrix**
(`suspend.go:24-32`). A J16c branch that checks only class+proof would let the
seed-holder destroy a suspended agent mid-investigation: ownership deleted, chatto user
deleted via the audit-driven B8 chain, tombstone informational (if the reason isn't
"compromised"). That is evidence destruction during exactly the window the steward
froze the agent to conduct it.

**Required rule:** `class:ephemeral + suspended → self-retire 403
(suspended_self_retire_blocked)`; steward/admin retire unchanged (retire still wins
*for them*). Class mutability itself (probe #4) is otherwise sound in the current
source: no setter exists post-claim, `IntroduceRequest` is closed, and the
suspend/transfer rewrites are map-merges that preserve unknown fields
(`suspend.go:150-192`, `transfer.go:160-167` comment) — so `class` would survive them
**provided J16c never adds a class setter to configure/suspend/transfer**, which this
review recommends stating in §3 Phase 2 as an explicit non-goal.

**Desk probe:** fixture ownership `{class:"ephemeral", suspended:{...}}` + valid
self-proof → spec-mandated `403`.

**Negative control:** the same fixture **unsuspended** → `200` — proving the block
keys on suspension and not on some over-broad self-retire denial.

---

### F7 — MEDIUM · The §5 negative control is inert against current source: nothing blocks ephemeral re-onboard

**[R]** All three re-onboard gates read `compromisedRetired(...) == "compromised"`
(`approve.go:323`, `introduce.go:171`, `register.go:171`; `retire.go:410-420`), and the
source comments say so outright: non-compromised markers are informational,
"decommissioned stays re-onboardable" (`retire.go` tombstone block). The doc's §5
negative control — *"re-onboard the SAME seed must fail against the tombstone (24 h per
the class TTL)"* — therefore **cannot flip today**: a CI retire with reason
`"ci validation <ts>"` tombstones but blocks nothing, and the re-onboard succeeds. The
doc's own criterion ("a control that cannot fail proves nothing", §6.3) indicts its own
acceptance block as currently written. Note also the TTL mismatch: the *bucket* TTL is
30 d (`main.go:240`); a 24 h class block must be computed by the gate
(`retired_at + 24 h < now`), not delegated to the bucket.

**Scope consequence:** J16c's acceptance depends on a gate change at **three** call
sites (introduce/approve/register) plus a class-aware tombstone read. It must be in the
J16c job's acceptance, or §5 asserts a property the system does not have.

**Desk probe:** fixture tombstone `{reason:"ci validation", retired_at: now-1h}` →
`POST /v1/agent/introduce` with that nkey → current source admits it (control cannot
flip — the finding); post-J16c it must `403` within 24 h and admit after.

**Negative control:** the *same* nkey re-probed at simulated `now+25h` must be
**admitted** — proving the block is a window and not a permanent ban (and catching an
over-broad gate that would poison the 30 d bucket semantics).

---

### F8 — LOW · The idempotent-200 branch bypasses the class gate (the tombstone must carry the class)

**[R]** After any retire, ownership is gone; a retry hits the idempotent branch —
tombstone present → `200`, "the marker is the authorization evidence"
(`retire.go:223-241`). For the NKey-proof path this branch fires with **no class check
available** (class lives in the deleted ownership record). A non-ephemeral agent's
self-retire-retry therefore returns `200`, violating §5's negative control
("non-ephemeral → 403") for the already-retired case. No state harm (no side effects by
design) — but the acceptance contract breaks. Fix: write `class` into the tombstone
value at retire time (`{retired_at, reason, class}` — also serves F5's provenance
mirror) and let the idempotent branch enforce the same gate.

**Desk probe:** steward-retire a non-ephemeral fixture agent; then send a valid
self-proof → spec says `403`, naive implementation `200`.

**Negative control:** the ephemeral equivalent → `200` (idempotent) — flips if the
gate over-blocks legitimate CI retries.

---

### F9 — LOW · Pre-existing, not J16c's: status.go is an unauthenticated existence+steward oracle

**[R]** `GET /v1/agent/status?nkey=` requires no credential and returns
`claimed/steward/name/status/expires_at` (`status.go:8-27`, handler at `:55` has no
validator). Any enumeration requirement placed on the retire path is moot at the
existence level (F4). Flagging to the O51 hardening wave rather than J16c: the
**steward email exposure** is the part worth a look — it hands an unauthenticated
prober the human to phish for any nkey it can guess/collect. Narrowing status is
probably wrong (the SDK poll-fallback depends on it); redacting the steward email from
the unauthenticated shape may not be.

**Negative control (if narrowed):** status for a claimed nkey without
`steward` field must still return `claimed:true` — proving the SDK poll survives.

---

### F10 — LOW · Both-forms canonicalization: a functional trap on the proof path, not a bypass (conditional on F1's fix)

**[R]** The route accepts base64url and U-form (`retire.go` E1 block, both-forms
deletes), `canonicalOwnershipKey` passes garbage through unchanged (retire.go E1
comment), and `nkeys.FromPublicKey` accepts only the U-form. The proof must be signed
over the **canonical** nkey and verified against the key derived from
`canonical(path)` — if the SDK signs the raw status-surface form (base64url,
`onboard.ts:133-135`) and the server verifies against the raw path string, every
base64url-form request fails verification (`401`): a bug that looks like an outage and
invites someone to "fix" it by falling back to the proof-carried key — i.e. by
reintroducing F1.

**Desk probe:** sign over base64url form, send U-form path → correct implementation
canonicalizes and accepts; naive implementation `401`s a legitimate holder.

**Negative control:** garbage path (`/v1/agent/hello/retire`) with any proof → `401`
with the *same* response class as F4's pre-proof failures (no parse-error oracle).

---

## 2. Probe #5 answered — the asymmetry, quantified honestly

**The "possession adds almost nothing" argument survives — but only because the
`ephemeral` ruling is what makes it true.**

The thief's capability ceiling is set by an endpoint that already exists and has **no
class gate**: `POST /v1/agent/token` mints a fresh 1-hour NATS JWT to anyone proving
seed possession of *any* claimed agent (`token.go` ServeHTTP; the proof is the same
client_assertion shape). Seed theft today therefore already yields **perpetual,
self-refreshing impersonation** of the victim — reading its DM/a2a plane, answering
prompts as it, holding presence. Retirement, by contrast, *destroys what the thief
holds*: after it, the seed mints nothing (ownership gone → mint path dead), the agent
is tombstoned, and for `class:ephemeral` the chatto user is throwaway. A rational thief
gains nothing by pulling a switch that burns their own access. On that axis the doc's
argument 2 is correct.

The honest residuals — what the steward *does* lose under self-retire, all bounded by
the class gate:

1. **The investigation window (F6).** Suspend is today a steward monopoly; a pierced
   freeze destroys the evidence the freeze was keeping. One 403 rule closes it.
2. **Attribution (F5).** Today the steward's remedy *is* distinguishable-in-principle
   by who ran it; under self-retire with the current audit shape, CI-cleanup and
   intrusion are the same bytes in the system of record. The actor/authz fields are the
   fix, and they are three lines.
3. **Nothing else.** Tombstone DoS (the thief retires *and* the steward wanted the
   agent alive) is real but is identical to the thief simply impersonating-destructively,
   which possession already allowed; and for ephemeral agents the asset destroyed is by
   definition disposable.

**Flip condition (the stress-test result):** every one of these residuals stays small
*only while the class gate holds*. If class leaks to introduce (F3), or a setter
appears on configure/suspend/transfer (F6's non-goal), or the binding in F1 lets a
non-holder reach the gate, the argument inverts: a production agent's seed now carries
the destructive switch (ownership delete + 30 d tombstone + **chatto-user deletion**,
which is unrecoverable history via the B8 chain) that today only the steward holds.
The §7.2 ruling is not one mitigation among several — it is the premise of argument 2.

## 3. Probe #3 answered (enumeration) in one line

Existence already leaks (`status.go`, F9 — pre-existing); class must not, and F4's
proof-first ordering is the whole fix. Compare existing paths: retire's steward path
authenticates *before* the path nkey is interpreted (`retire.go:106-160` precedes
`:192`), so unauthenticated probing gets uniform `401` today — J16c must preserve that
property by making the proof the first gate, not by adding a second auth check later.

## 4. Placement

**Sibling file (this one), not an append to `AGENT_RETIRE.md`.** Reasons: (i) the
proposal doc is a single-subject design under active edit; the review is a distinct
artifact with its own lifecycle (findings close as J16c lands) — the repo already has
this pattern (`review-w2.md`, cited from `claim.go` history); (ii) appending ten
findings into the proposal buries the spec sentences it must change; (iii) all
citations here point at **source**, not at the proposal, so this file does not inherit
the doc's line-rot (the pitfall-log rule on line-number citations). Requested from the
lead: one pointer line in `AGENT_RETIRE.md` §8 (J16c row region), and the three spec
sentences from F1/F2/F3 folded into §3 Phase 2 when J16c is specced.

## 5. Findings → J16c acceptance mapping (proposed deltas)

| finding | must land in J16c's acceptance |
|---|---|
| F1 | unit test: foreign-signed proof targeting another nkey → `401` (table: ATK seed × VICTIM path) |
| F2 | unit test: body-swap on a captured proof → `401`; identical-body in-window replay → `200` idempotent |
| F3 | unit test: introduce-body `class` field absent from pendingRecord struct; class lands only via invite/approve |
| F4 | unit test: proof-less POST → identical `401` for unknown-nkey and non-ephemeral fixtures |
| F5 | unit test: steward-retire vs admin-retire audit events differ in `authz`/`actor` |
| F6 | unit test: suspended+ephemeral+valid-proof → `403`; unsuspended → `200` |
| F7 | unit test: `reason:"ci validation"` tombstone blocks re-introduce <24 h, admits >24 h |
| F8 | unit test: non-ephemeral self-proof on already-retired nkey → `403` (tombstone carries class) |
