# Release flow — agent-sdk → jsr.io (private repo: CI gates + CLI publish)

> One repo (`chatek/agent-sdk`, **PRIVATE**), three publishable packages:
> `@vclawhub/agent` (root), `@vclawhub/protocol-core` + `@vclawhub/ext-synadia`
> (`packages/*` — bun workspace members of THIS repo, not submodules).

## Why CLI publishing (the constraint)

jsr.io OIDC trusted publishing **requires a public linked repository**
(operator ruling: this repo stays private — the Link on jsr.io rejects it
with "Make sure the repository exists and is public"). So:

- **CI = gates only** (`ci.yml` on every push/PR; `jsr-publish.yml` on the
  release tag re-runs everything a release must pass).
- **Publish = CLI from an authed terminal.** The one-time browser login
  caches to `~/.deno` for the whole machine — after it, publishes are
  non-interactive and promptless (any terminal on the box, including
  automated ones).

## One-time setup (per machine, ~1 min)

```bash
cd agent-sdk
npx jsr publish        # or: bunx jsr publish
# → browser opens → sign in with the GitHub account that owns @vclawhub
# → publish completes (credential goes to the macOS keychain — there is
#   NO ~/.deno; later pty-wrapped runs authenticate silently)
```

Members (`packages/protocol-core`, `packages/ext-synadia`) use the same
command from their directories; the CLI **skips versions already on jsr.io**
(never re-publishes, no bump-to-publish needed).

## Release flow

1. **Every push/PR** — `ci.yml`: frozen install · `tsc --noEmit` · vitest
   (integration included — CI provisions a pinned, digest-verified
   nats-server) · 3× `jsr publish --dry-run` · bundled-CLI build + smoke.
2. **Release**: bump `jsr.json` (+ `package.json`) — and any member whose
   source changed — add the `## [X.Y.Z]` CHANGELOG section, commit, push,
   `git tag agent-sdk-vX.Y.Z && git push origin agent-sdk-vX.Y.Z`.
   The tag run = full release gates. **A green tag run means: publish now.**
3. **Publish** — automated, no terminal needed. The CLI demands a TTY for
   its auth flow; a pty wrapper satisfies that, and the credential from the
   first one-time interactive login lives in the macOS keychain, so the
   publish authenticates SILENTLY (verified 2026-10-02: authorized + no-op
   published in 6s, zero clicks). From any automation shell:
   ```bash
   cd agent-sdk && script -q /dev/null npx -y jsr publish
   cd packages/protocol-core && script -q /dev/null npx -y jsr publish  # no-op if current
   cd ../ext-synadia && script -q /dev/null npx -y jsr publish          # no-op if current
   ```
   Fallback (keychain entry expired/absent): the CLI prints
   `Visit https://jsr.io/auth?code=XXXX …` and waits — relay that URL to
   the operator for ONE browser click; the waiting process then completes
   on its own. A truly headless run (no pty) always fails with
   "No means to authenticate" — never run it without the wrapper.
4. **Bundled CLI** (separate distribution surface): copy
   `dist/agent.js` + `.sha256` → `landing/public/`, push —
   vclawhub.com is git-connected (Cloudflare Pages builds from the push;
   verify by content probe, not by any deploy command's exit code).

## Version truth

`jsr.json` is root version truth (the bundle stamps from it; package.json
kept in lockstep). Members version independently (0.2.x today). JSR enforces
strict per-package version increase; the CLI no-ops unchanged members.

## Escape hatch (if CI publishing is ever wanted)

Add a publish step to `jsr-publish.yml` gated on the `JSR_PUBLISH_TOKEN`
repo secret (`--token $JSR_PUBLISH_TOKEN`); a JSR personal access token from
jsr.io account settings. Not enabled by default — a long-lived credential.
OIDC remains unavailable while the repo is private.
