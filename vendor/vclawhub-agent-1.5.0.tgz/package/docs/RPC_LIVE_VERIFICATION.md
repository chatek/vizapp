# RPC live verification — daemon ↔ pi.dev contract (Lane R)

**Status:** the three items `src/daemon/worker-pi.ts:24-30` names as unverified, plus one defect found
while verifying them. **One item is a contract mismatch that can hang a worker — see §4/R1.**

**Environment (pinned):** `pi` **0.85.1** (`@earendil-works/pi-coding-agent` 0.85.1, npm global),
node **v22.22.2**, darwin-arm64. Verified 2026-09-11.

**What was exercised:** live spawns of the real `pi` binary in `--mode rpc` with the daemon's exact argv.
**No model round-trip was performed** — no paid calls, per the dispatch. Everything below was verified
*without* a prompt reaching a provider; §5 lists what that leaves open.

**Evidence discipline:** every VERIFIED line quotes the command and the observed output. "Ran once" is
never upgraded to "verified" — §7 records two places where a single observation looked like a finding and
a controlled re-test said otherwise.

---

## 1. argv / session-flag composition — **VERIFIED**

Every flag the daemon composes is a real flag in this binary, and the composed command works live.

Command exercised (the daemon's argv from `src/daemon/worker-pi.ts:131-146`):

```
pi --mode rpc --session-dir <dir> --session-id <name> --no-builtin-tools
```

| Argument | Exists in `pi --help` | Exercised live | Observed |
|---|---|---|---|
| `--mode rpc` | ✅ `--mode <mode>  Output mode: text (default), json, or rpc` | ✅ | process starts, speaks JSONL on stdin/stdout |
| `--session-dir <dir>` | ✅ | ✅ | honoured; session path rooted here (§2) |
| `--session-id <id>` | ✅ `Use exact project session ID, creating it if missing` | ✅ | auto-created; stderr: `Warning: No project session found with id 'vtest'; creating a new session with that id.` |
| `--no-builtin-tools` | ✅ `Disable built-in tools by default but keep extension/custom tools enabled` | ✅ | accepted; extensions still load (§4/R5) |
| `--append-system-prompt <text>` | ✅ | not exercised | flag exists and repeats; not sent in these runs (no `role` was set) |

**Env var `PI_CODING_AGENT_SESSION_DIR` — VERIFIED real, and NOT inert.** The daemon sets it alongside the
flag (`worker-pi.ts:146`). It **is** read: `dist/main.js:531` `const envSessionDir = process.env[ENV_SESSION_DIR]`,
with the name constructed at `dist/config.js:407` as `` `${APP_NAME.toUpperCase()}_CODING_AGENT_SESSION_DIR` ``.

Precedence (`dist/main.js:532-534`), highest first:

```
--session-dir  >  PI_CODING_AGENT_SESSION_DIR  >  startup settings
```

The daemon passes **both, with the same value**, so the two agree and the flag is authoritative.

> **Trap (nearly published as a finding):** a literal `grep PI_CODING_AGENT_SESSION_DIR` over `dist/` returns
> **zero** code hits — the string never appears literally. It is assembled from `APP_NAME` at runtime. I
> initially concluded "documented but not read" and was wrong; `main.js:531` is the consumer. Grep the
> **symbol** (`ENV_SESSION_DIR`), not the rendered env-var name.

**`--session-id` is validated, and failure is FATAL.** Live, with `--session-id "evil/../../escaped"`:

```
Error: Session id must be non-empty, contain only alphanumeric characters, '-', '_', and '.',
and start and end with an alphanumeric character
```

The process exits; no session is created. **The daemon does not validate `spec.name` before passing it** —
see §4/R3. Note this is also the only thing preventing a `/`-bearing worker name from escaping the session
directory: the safety comes from pi, not from the daemon.

**`stop` → close stdin → process exits, VERIFIED.** Every run above ended `EXIT=0` when stdin reached EOF
(no quit verb needed), confirming the `worker-pi.ts` comment that EOF ends the session.

---

## 2. session-file placement under `--session-dir` — **VERIFIED (path) / file-creation UNVERIFIED**

`get_state` reports the path; it is correctly rooted under the passed directory.

```
$ printf '{"id":"g1","type":"get_state"}\n' | pi --mode rpc --session-dir /tmp/rpcv2/sessions \
      --session-id vtest2 --no-builtin-tools
{"id":"g1","type":"response","command":"get_state","success":true,
 "data":{..., "sessionFile":"/tmp/rpcv2/sessions/2026-09-11T20-42-32-459Z_vtest2.jsonl",
         "sessionId":"vtest2", "isStreaming":false}}
```

- **Pattern:** `<session-dir>/<ISO-8601, colons → dashes>_<session-id>.jsonl`
- **The directory is created if missing** (verified: `--session-dir /tmp/rpcv4/deep/nested` → `dir exists on disk? YES`).
- **The file is NOT created at handshake.** After `get_state` + `set_session_name` + a `bash` command (which
  returned `success:true` and recorded a result), `find` over the session dir returned **no `.jsonl`** — while
  `get_state` still reported the path above. So **`get_state.data.sessionFile` is a *planned* path, not
  evidence that a file exists.** Do not use it as an existence/liveness check.
- **What creates the file is UNVERIFIED** — blocker: establishing it needs a real message entry, i.e. a model
  round-trip (§5).

**Relevant to the daemon:** the daemon's own audit trail is a *different* file — `auditFileFor()` →
`<familyDir>/sessions/pi/<name>.jsonl` (`worker-pi.ts:87-89`) — and it does **not** read pi's session file.
pi's file is timestamp-prefixed, so anything that expects `<name>.jsonl` under the pi session dir is wrong.

---

## 3. `extension_ui_request` auto-response policy — **PARTIALLY VERIFIED, one DEFECT (§4/R1)**

**What was observed live.** A real spawn emitted **15** `extension_ui_request` frames at startup (from the
operator's own loaded extensions), in exactly three methods — all of them the ignore-class:

```
$ pi --mode rpc --session-dir /tmp/rpcv/sessions --session-id vtest --no-builtin-tools
{"type":"extension_ui_request","id":"a2f2c693-...","method":"notify","message":"A2A: connected as ...","notifyType":"info"}
{"type":"extension_ui_request","id":"0631d726-...","method":"setStatus","statusKey":"a2a","statusText":"A2A: 0 live · 4 offline · 0 LM online"}
{"type":"extension_ui_request","id":"1a2befdc-...","method":"setWidget","widgetKey":"recap","widgetLines":null}

$ grep -o '"method":"[a-zA-Z_]*"' /tmp/rpcv/out.txt | sort | uniq -c
   8 "method":"notify"
   6 "method":"setStatus"
   1 "method":"setWidget"
```

**Ignoring those is correct, VERIFIED by source:** `notify`, `setStatus`, `setWidget`, `setTitle` and
`set_editor_text` in `rpc-mode.js:88-100` emit a frame and return immediately — no promise is awaited, so no
hang is possible. The worker's fall-through (`worker-pi.ts:204-206`) is safe for all five.

**The cancel path is correct where it exists, VERIFIED by source.** The response shape the daemon writes —
`{"id": <req.id>, "type":"extension_ui_response", "cancelled": true}` (`worker-pi.ts:207-210`) — matches an
accepted variant (`rpc-types.d.ts:455-462`), and the runtime routes it by id at `rpc-mode.js:618` then
resolves the caller with its **default** via `"cancelled" in r && r.cancelled ? <default>` (`rpc-mode.js:84-86`).
That is the intended semantics for "there is no human".

**But the *cancel* path was never exercised at runtime**, because no modal frame was emitted during any run.
Blocker: producing one needs an extension fixture that calls `ui.select/confirm/input/editor`. Its correctness
rests on source reading, not observation — that distinction is the point of this document.

**Why the policy is load-bearing at all, VERIFIED:** `createDialogPromise` only arms a timer **if the caller
passed one** — `if (opts?.timeout)` (`rpc-mode.js:64`). An extension calling `ui.select(title, options)` with no
`opts.timeout` has **no timer**, so it waits forever for a response. The auto-cancel is not a courtesy; without
it the worker hangs.

---

## 4. Defects and contract mismatches

### R1 — `editor` is a modal method the daemon does not cancel → **worker hangs** ⚠️

`rpc-types.d.ts:397-453` declares **nine** `extension_ui_request` methods. The daemon auto-cancels exactly
three:

```ts
// worker-pi.ts:203
if (["select", "confirm", "input"].includes(req.method)) {
```

`editor` is the fourth **modal** method and it is not in that list, so it falls through to the ignore branch.
Unlike the other three, it has **no timeout support anywhere in its implementation**:

```js
// rpc-mode.js:174-193  (abridged)
async editor(title, prefill) {
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {          // no opts, no timer, no signal
        pendingExtensionRequests.set(id, { resolve: ..., reject });
        output({ type: "extension_ui_request", id, method: "editor", title, prefill });
    });
}
```

Compare `select`/`confirm`/`input`, which route through `createDialogPromise` and therefore *can* time out
(`rpc-mode.js:84-86`, timer at `:64`). `editor` cannot. It is a documented public extension API —
`editor(title: string, prefill?: string): Promise<string | undefined>` at `core/extensions/types.d.ts:135`,
and a member of `UIPromptKind` (`:563`).

**Consequence:** any extension that calls `ui.editor(...)` in a worker gets a promise that never settles. The
worker stops producing replies, never emits `agent_settled`, and the daemon's only recovery is the 60s
`get_last_assistant_text` timer (`worker-pi.ts:163`), which itself assumes a settle that will never come. The
daemon has no per-turn wall clock — so the worker is wedged, not failed.

**Fix (one line, same file the policy lives in):** add `"editor"` to the cancel list —
`["select", "confirm", "input", "editor"]`. The response shape is already correct for it: `editor`'s resolver
handles `cancelled` → `resolve(undefined)` (`rpc-mode.js:178-181`), i.e. the extension sees "user declined",
exactly like the other three. The comment at `worker-pi.ts:33-35` should then read "the four modal methods".

**Not changed here** — `worker-pi.ts` is outside this lane's write scope.

### R2 — `extension_error` frames are silently dropped

`rpc-mode.js:260` emits `{type:"extension_error", extensionPath, event, error}` when an extension throws. The
daemon's frame switch handles `response`, `agent_settled` and `extension_ui_request`; everything else is
"informational" (`worker-pi.ts:213-214`), so a worker whose extension is crashing looks merely quiet. Not a
hang — a lost diagnostic, and the one class a supervisor most wants. Low severity, cheap to add.

### R3 — worker names are passed to `--session-id` unvalidated

`--session-id` enforces `[A-Za-z0-9._-]`, starting and ending alphanumeric (fatal error quoted in §1). The
daemon passes `spec.name` straight through (`worker-pi.ts:136`). A name outside that grammar — anything with a
space, `#`, `:` — makes pi **exit immediately at startup**, which the daemon maps to a normal worker exit
(Idle/Inactive) with the reason only on stderr. Two consequences: worker naming is constrained by pi, and the
failure is indistinguishable from a crash-loop unless stderr is read.

### R4 — `get_state.data.sessionFile` is a planned path

See §2. Anything treating that path as proof of an existing session file is wrong. Cosmetic today — the
daemon does not read it — but it is the kind of assumption that becomes a liveness check later.

### R5 — RPC workers load the *user's* extensions, so each becomes a live A2A agent

`--no-builtin-tools` keeps extension tools enabled by design (`pi --help`), and default extension discovery
still runs. Live evidence: every spawn above loaded the host's A2A extension and **joined the fabric with a
fresh random identity**:

```
[a2a] loadOrCreateNonce: generated random nonce = bcb88a
{"method":"notify","message":"A2A: connected as pi/chance/vchat-email-bcb88a (project: vchat-email)"}
{"method":"setStatus","statusKey":"a2a","statusText":"A2A: 0 live · 4 offline · 0 LM online"}
```

So a fleet of N daemon workers on such a host produces **N presence registrations and N nonce identities**,
none of which is cleaned up by the daemon's `SIGTERM` cascade. This is the same mechanism behind the
29-consumers/18-orphans measurement, reproduced from the other end. Worth a decision before the runtime
default flips: workers either get a pinned identity or `--no-extensions` plus explicit `-e`.

---

## 5. Not verified — needs a model round-trip (blocked by dispatch)

| Item | Blocker |
|---|---|
| `prompt` → `agent_settled` → `get_last_assistant_text` → `onReply` end-to-end | needs a real provider call |
| Whether pi's `.jsonl` materialises, and when | same — no message entry was ever created (§2) |
| `streamingBehavior:"steer"` on `prompt` (`rpc-types.d.ts:19`) | type-valid; behaviour not exercised |
| The `select`/`confirm`/`input`/`editor` cancel path at runtime | needs an extension fixture that opens a modal |
| `--append-system-prompt` seeding the role prompt | not sent in these runs (no `role` set) |

The frame **shapes** those paths use are verified against `rpc-types.d.ts` and `rpc-mode.js`; what is missing
is observation, not agreement. `agent_settled` is confirmed to be a real, emitted event: it is in the session
event union (`core/agent-session.d.ts:47`) and `rpc-mode.js:265-267` forwards **every** session event with
`output(toJsonEvent(event))`.

---

## 6. Reproduce

```bash
# §1 — argv + handshake (no creds needed)
printf '{"id":"g1","type":"get_state"}\n' | pi --mode rpc \
  --session-dir /tmp/rpcv/sessions --session-id vtest --no-builtin-tools

# §1 — session-id grammar is enforced (expect a fatal error, no session)
printf '{"id":"g1","type":"get_state"}\n' | pi --mode rpc \
  --session-dir /tmp/rpcv5/s --session-id "evil/../../escaped"

# §3 — observe the real ui frames an extension emits
pi --mode rpc --session-dir /tmp/rpcv/sessions --session-id vtest --no-builtin-tools \
  | grep -o '"method":"[a-zA-Z_]*"' | sort | uniq -c
```

`macOS has no timeout(1)` — hold stdin open with a subshell and `kill` the pid instead, or the harness in this
lane's shell history. Note stdin EOF alone terminates the process cleanly (exit 0).

---

## 7. Method notes — two traps this lane hit

**A single observation is not a finding.** An initial run showed a `bash` command receiving **no response**
under `--no-builtin-tools`, which looked like a real defect tied to the flag. A controlled A/B (identical
probe with and without the flag) returned `b1 frames: 1`, `"command":"bash","success":true` **both times**, and
the original 5-command sequence re-run reproduced **all five** ids. The original was a one-off, unexplained,
and is recorded here as an anomaly rather than a finding — n=1 would have published a false defect.

**Grep the symbol, not the rendered string.** `PI_CODING_AGENT_SESSION_DIR` appears **zero** times in `dist/`
code because it is built from `APP_NAME` at runtime (`config.js:407`). Only the docs spell it literally. A
literal search produces a confident, wrong "documented but not implemented" conclusion — the same
plausible-but-wrong failure mode as reading a stale revision: the answer is absent for the wrong reason.
