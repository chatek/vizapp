# AGENT_RETIRE — closing the identity lifecycle (J16 proposal)

> **Status: PROPOSAL, 2026-09-16 · lane `vchat-email-lead` · not implemented.** Origin:
> `docs/RUNTIME_incus.md` §8 / **J16** — *"the SDK CLI has zero retire/revoke."* Everything below is
> **[R]** read from source (cited file:line) or marked **[Q]** open. Method per `vchat-email-b283c3`'s
> lane pattern: *rehearse against real artefacts, adversarially review the ordered steps, and assert
> what the system ACTUALLY persists rather than what the design says.* File-only change per
> `docs/COMMIT_MERGE_POLICY.md` — `plans` commits.

---

## 0. The gap has three halves, not one

| # | half | evidence |
|---|---|---|
| 1 | **CLI:** the SDK can create an identity (`onboard`) but cannot end one — `src/cli.ts` has 16 commands, **0 hits for retire/revoke** | `src/cli.ts` |
| 2 | **Server:** retire is *fully implemented* in vgate — the client half is what's missing, plus one auth path (§3) | `vgate/internal/agentidp/retire.go` |
| 3 | **Runtime — CLI/headless only:** vgate publishes an agent-facing retire notification; the **pi-extension already consumes it** (`src/pi-extension/index.ts:472`, W4 lane B → `retireLocal`), but the **CLI/headless runtime did not** — a retired headless agent stayed alive. That is the zombie that matters for §8.3 CI (the extension can't `process.exit` — it lives inside the host pi session). **Fixed: J16b.** | `retire.go:133`; `pi-extension/index.ts:173-238,472`; §4, §8 |

J16's consequence stands: a CI that claims an identity per validation (`RUNTIME_incus.md` §8.3 VALIDATE)
accumulates live identities with no client-side cleanup.

## 1. What the server already does — read from source, not assumed

`POST /v1/agent/{nkey}/retire` (`retire.go:191,196`; **both key forms accepted** — base64url and
U-form, `retire.go:203-210`, the E1/approve-502 bug class):

| behaviour | evidence |
|---|---|
| **explicit confirm required** — body `{confirm:true}`, else `400 confirm_required` | `retire.go:216` |
| **auth:** service-token (`X-VChat-Service-Token`, constant-time, chatto fork proxy) **or** Authelia id_token (humans) | `retire.go:106-112,155-160` |
| **authz:** the agent's **steward** (email/uuid matches the ownership record) **or admin** (`vchat.admin` via `WithAdminFn`) | `retire.go:115-121,~252` |
| **cleanup:** `vchat_ownership` (*"identity anchor — kills JWT mint path"*), `vchat_pending` + `pending_hash` (both key forms), capabilities, roster, heartbeat | `retire.go` ServeHTTP cleanup block |
| **tombstone:** `vchat_retired.<canonical>` `{retired_at, reason}` — **written for EVERY retire** (`retire.go:334-343`), 30 d TTL. ⚠️ **Only `reason == "compromised"` blocks re-onboarding** (the `compromisedRetired` gate at `register.go:172` / `approve.go:~267`); a normal `decommissioned` marker is **informational — the key stays re-onboardable**. The SDK's contract layer already defines the bucket | `retire.go:334-343`, `register.go:170-176`, `src/contracts/contracts.ts:666-668` |
| **idempotent:** retry after partial failure returns **200** with the tombstone as the evidence, no side effects; no tombstone + no ownership → `404 not_claimed` | `retire.go:223-241` |
| **notify:** publishes `tenant.<seg>.agent.retired.<canonical>` — *"retire reaches the agent within seconds (kills the zombie)"* | `retire.go:133,139-147` |
| **audit:** `VCHAT_AUDIT`, `AuditID = vgate.audit.agent.retired.<canonical>`, queryable at `GET /v1/audit/events`; carries the chatto-user-deletion chain | `retire.go:52,118-128,236` |
| **the pending half:** an introduce that died *before claim* is not retire's problem — abandoned pending rows are swept at **`DefaultPendingTTL = 7 × 24 h`** | `sweep.go:20,31`, `introduce.go:75` |

⇒ **The client proposal is thin by design**: the hard parts (idempotency, tombstone, both-key-forms,
audit, zombie-kill) are already solved server-side. What's missing is a caller, a subscriber, and one
auth path.

## 2. Proposed CLI — `vclaw-agent retire`

```
vclaw-agent retire [--nkey <pub>] [--reason <text>] [--yes] [--purge-local] [--json]
```

| flag | semantics |
|---|---|
| *(default)* | retire **this machine's** identity — **Phase-2 auth (§3); until J16c lands it fails fast** with `exit 1` and an explicit *"self-retire lands with J16c — use `--nkey <pub>` with a steward session"* message. **Never silently ignored** (an omitted capability is an absent default, and silence reads as success). |
| `--nkey <pub>` | retire **another** agent — steward/admin path (Phase-1 auth, **works today**) |
| `--reason <text>` | into the tombstone value `{retired_at, reason}` (`contracts.ts:666-668`) + the audit record |
| `--yes` | supplies `confirm:true` (`retire.go:216` makes the server demand it; the CLI mirrors the destructiveness) |
| `--purge-local` | delete the local seed + config **strictly after** server success (§6.2); **refused unless the retired nkey *is* the local identity** — retiring another agent must never purge your own seed |
| `--json` | `{retired, audit_id, tombstone, canonical_nkey, cleaned[]}` for CI |

**Exit codes** (CI-assertable, never just "no error"): `0` retired **or** idempotent-already-retired —
*a retry after partial failure lands here and still honours `--purge-local`* · `1` local precondition
failure (self-path before J16c; `--purge-local` without a matching local identity) · `2` `not_claimed`
(a pending row — the sweep owns it, §1 last row) · `3` forbidden (not steward/admin) · `4` unreachable.
**The CLI always prints `audit_id`** — the durable citation, per the house rule that the register is
the artefact and the message is not.

**Preflight — target assertion (destructive-op guard).** ⚠️ Found by the §6.1 rehearsal: the SDK's env
namespace is `VCLAW_*`/`VCHAT_*` **only** (`src/env.ts:15`), so a bare `VGATE_URL`/`API_URL` is
**silently ignored** and `VgateClient` falls back to the **production** endpoint
(`src/lib/vgate.ts:15` → `https://api.vclawhub.com`). A rehearsal hit prod that way and was saved only
by the 401 that precedes every KV mutation in `retire.go` (authn `:180-186`; first mutation `:263`) —
**a run holding a valid token would not have been.** Therefore `retire` must:

1. **resolve and PRINT the target** (`target: <url>`, and a `target` field in `--json`); and
2. **fail closed (exit 1) when the target is the built-in default and the run is non-interactive**
   (`--yes`): automation must name its target. A silent production default is a fail-*open* default on
   a destructive operation — *fail-closed is the control; and where the default is wrong, naming the
   target is the cure.* A human keeps the printed target + the confirm gate.

   ✅ **IMPLEMENTED (2026-09-16).** `VGATE_DEFAULT_URL` / `vgateTargetExplicit()` / `resolvedVgateUrl()`
   (`src/lib/vgate.ts:20-32`); the refusal is `!namedTarget && (opts.yes || !process.stdin.isTTY)`
   (`src/commands/retire.ts:148`), naming `VCLAW_API_URL` in the message. **Semantics worth keeping:**
   *default-by-omission* fails closed, while an **explicitly named** target — *even when it equals the
   default* — proceeds, so a deliberate production run remains possible and only the accidental one is
   blocked. **Proof the guard flips:** rehearsal case *j* (env omitted + `--yes` → exit 1, nothing sent)
   and case *a* (`--json` `target == $VCLAW_API_URL`, so §5's CI assertion reads the CLI's own output).
   Unit 23/23 · matrix 34/34 · `tsc` 0.

*(Optional hardening, same class: warn when legacy-but-unused env names are present, since `env()`
silently ignores anything it does not recognise — an absence of a warning is not an absence of a
mistake.)*

## 3. Auth, in two phases

**Phase 1 — SDK-only, zero server change: the steward id_token path.**
`vclaw-agent retire --nkey <pub>` drives the existing human path (`retire.go:155-160`). Satisfies
operator-driven decommissioning today. ⚠️ It inherits vgate's `iss`/`aud` gap until the **O51 hardening**
lands — one of the ~10 client-token sites, unchanged by this proposal.

**Phase 2 — vgate + SDK: NKey-proof self-retire (the CI path J16 actually needs).**
Neither existing path is CI-safe: the service token is a **retire-anyone god-credential** (chatto
fork proxy's, `retire.go:106-112`) and the id_token is interactive. The headless case wants the agent
to prove **possession of its own seed**: sign the retire request with the NKey seed; vgate verifies
possession **and that the agent was born `class:ephemeral`** — the §7.2 ruling, so every other agent
keeps steward-exclusive retirement. Three arguments, in ascending force:

1. **The daemon already holds the seed and authenticates with it** (`nkeyAuthenticator`,
   `src/commands/onboard.ts:26`) — no new credential store, no env var, no argv (O37/O44 classes).
2. **Possession = authority adds almost no new attack surface:** seed theft already grants *full
   impersonation* of the agent; retire-DoS is strictly weaker than what the thief already has. ⚠️ The
   **one thing it concedes** for long-lived agents is *exclusivity of the kill switch*: today only the
   steward can retire, so a thief impersonates while the steward's remedy survives — under possession
   authz, the thief can pull that remedy too (ownership delete + chatto-user deletion, plus a retired
   marker — which *blocks* re-onboard only if they also set `reason=compromised`). That concession is
   exactly what the §7.2 `ephemeral` option exists to avoid.
3. ⭐ **It is immune to the O51 token-forgery class** — Ed25519 seed possession, not the OIDC chain.
   The compromise of 2026-09-15 was a forged-`id_token` minting fabric credentials; a retire path that
   trusts NKey proofs cannot be reached by that forgery at all. *The destructive lifecycle command is
   the one place to prefer the credential that is not the compromised family.*

**Phase-2 spec requirements — from the adversarial review**
(`docs/AGENT_RETIRE_ADVERSARIAL_REVIEW.md`, 10 ranked findings; F1–F3, F5 re-verified against source
2026-09-16). These are **requirements, not suggestions**:

1. **Bind the proof to the PATH identity (F1 — critical).** ⚠️ The in-repo precedent points the wrong
   way: `token.go:189-196` verifies the signature against `payload.Iss` **from the proof itself** —
   safe for `/v1/agent/token` (self-referential, no path parameter), **fatal here**: an attacker's
   proof verifies with the attacker's own key while the victim's nkey comes from the path. ⇒ **verify
   against the key derived from `canonical(path)` and require `iss == canonical(path)`.** NKeys
   self-encode their pubkey, so the derived-key check is free.
2. **Bind the proof to the request (F2).** The marker's `reason` comes from the **body**
   (`retire.go:345`) and all three re-onboard gates key on `reason == "compromised"` (`approve.go:323`,
   `introduce.go:171`, `register.go:56`). A proof that does not sign the body **replays with
   `reason:"compromised"`** — a 30-day re-onboard block on an nkey the attacker does not hold. Sign
   `method ‖ canonical-path ‖ sha256(body) ‖ iat ‖ exp≤300s` (`token.go:179-182` discipline); replay
   then collapses into the idempotent branch and is harmless by construction.

   ✅ **RESOLVED — J16d LANDED (2026-09-16).** `canonicalOwnershipKey` (`base64.go:53-84`) classified key
   form by **first character only** (`k[0] == 'U'` ⇒ pass through), with no length/alphabet/checksum
   validation, so a base64url pubkey whose encoding begins with `U` (**≈1/64 of keys**) was returned
   **unnormalized** — blast radius beyond retire: `CanonicalNKeyPub` feeds **claim/pending publish
   subjects and auth-callout grants** (`cmd/vgate/main.go:373`), so such an agent's KV rows landed under
   a bogus key.

   **⚠️ Evidence corrected by the lane:** the original §6.1 demo (*"same agent — 200 via U-form / 404 via
   base64url"*) was a **mismatched pair** — `B3` was not `U3`'s encoding (two valid keys cannot share a
   long prefix; that 404 was a miss for the right reason). The defect is proven instead by a
   **constructed** `U`-prefixed fixture with a derived first byte (`retire_forms_test.go` records the
   derivation and an explicit honesty note) plus `TestRetireUPrefixedBase64urlForm` and
   `TestCanonicalOwnershipKeyDecidable`. *The code-level reading was sound; the demo pairing was not — a
   demo is evidence only once its own premise has been checked.*

   **Fix (landed):** `nkeys.FromPublicKey(k) == nil && k[0] == 'U'` ⇒ canonical **verbatim**; else
   base64url-decode ⇒ canonical; else unchanged, so the caller's 404 stays the loud boundary.
   `FromPublicKey` validates prefix, alphabet, checksum and length — **no base64url string satisfies it
   by accident** — and the `U` test is demoted from heuristic to a **selector among validated nkeys**
   (user vs operator/account/server). *Gates: `agentidp` suite ok · TestRetire 25/25 · live on the rebuilt
   harness (43-char `U`-prefixed b64 → 200, canonical returned, idempotent 200, tombstone
   canonical-keyed).* **J16c's prerequisite is cleared.**
3. **The class grant lives in the INVITE, never the introduce body (F3).** `claim.go:344-352` writes
   ownership straight from the pending record, and that record is fed by the agent-controlled
   `IntroduceRequest` ⇒ **`IntroduceRequest`/`pendingRecord` must never carry `class`.** Compliant
   grant: the **steward-created invite** (`invites.go:155-162`) for CI; the approve request for humans
   (`principal_class` is the existing precedent — `approve.go:219,350-356`). *§8's hazard, with its
   concrete path now named.*
4. **Canonical form only (F10)** — sign/verify the U-form, or base64url clients get a 401 and someone
   "fixes" it back into F1. **Live instance (J16d, landed 2026-09-16):** the old `k[0] == 'U'` heuristic
   misread **~1/64** of base64url pubkeys as canonical — F10's trap, actually triggered — and the fix made
   canonical derivation **decidable** (`nkeys.FromPublicKey`, with `U` demoted to a selector among
   validated nkeys). So J16d did not merely satisfy F10; it **strengthens** it: the transformation F1/F10
   depend on (`canonical(path)`) is now reliably decidable rather than heuristic.
5. **Audit the ACTOR, not the owner (F5).** `retire.go:357` passes the **owner's** steward, so
   self/steward/admin/proxy retires are byte-identical audit events *today*. Add actor + authz-mode
   fields (~3 lines). Pre-existing — but J16c must not ship a fourth indistinguishable mode.
6. **Proof-verification ordering (F4)** — uniform 401 *before* any class/existence discrimination, or
   the endpoint becomes an oracle.
7. **A suspended agent must not self-retire (F6)** — destroying exactly the evidence an investigation
   needs. 403.

⚠️ **A second CI blocker, surfaced by the same review — the claim leg itself.** `claim.go:203`: with
OIDC configured, claim redirects the **browser** to Authelia, so **a headless CI cannot complete claim
at all** — independent of retire. J16c's self-retire is *necessary but not sufficient* for
`RUNTIME_incus` §8.3's VALIDATE block; the stewardless admission path must be designed with it.

**Caveat on §3 argument 2 ("possession adds almost nothing").** The review confirms it *while the
class gate holds*: `/v1/agent/token` already converts a stolen seed into perpetual hourly-refreshable
impersonation, so retire only destroys what the thief already holds. But **F1/F3 flip it for
production agents** — if the path binding or the grant point is wrong, the gate collapses and the
argument with it. The argument is **conditional**, not absolute.

## 4. The runtime half — subscribe, or the zombie survives

The subscriber: `nc.subscribe("tenant.<seg>.agent.retired.<canonical>")` → banner → graceful
`shutdown()` (unsubscribe all + presence graceful-offline + drain) → `process.exit(0)`. The server's
documented intent is *"retire reaches the agent within seconds (kills the zombie)"* (`retire.go:133`).

⚠️ **Correction (2026-09-16, found by the J16b lane):** the first draft of this doc asserted *"no SDK
subscriber"* from a `grep … | head -8` whose eight hits were **all comments** — an absence read from a
truncated pipe. The **pi-extension already consumed this publish** (`src/pi-extension/index.ts:472`,
W4 lane B, with 403-probe disambiguation; it correctly does *not* `process.exit` — it lives inside the
host pi session). The real gap was the **CLI/headless runtime**. *An absence is only as strong as its
default — and a `head` is a default.* J16b closed the headless gap; the extension was left surgical.

**There is no wire-ack** in the contract: the publish is one-way and its errors are non-fatal, so the
**audit record is the system of record** and the local banner/log line is the operator/CI-visible ack.
A wire-ack would be new contracts surface — J16c territory, not to be invented in the CLI.

**Follow-up (parked, deliberately not done):** the pi-extension's inline retire handler predates
`subRetired` and duplicates it. Folding the extension onto the shared helper would remove the
duplicate implementation — deferred because the inline copy works and lives inside the host pi session
(surgical-changes rule: don't refactor what isn't broken). Recorded here so the duplication is a *known
pair* rather than a future rediscovery.

## 5. CI wiring (amends `RUNTIME_incus.md` §8.3 VALIDATE)

```
onboard (throwaway seed, class:ephemeral) → assert markers → presence in fabric
  → vclaw-agent retire --reason "ci validation <ts>" --yes --json --purge-local
ASSERT (positive, each):  **target == $VCLAW_API_URL — assert BEFORE the destructive call** · exit 0 ·
                         audit_id non-empty · class:ephemeral LANDED on the ownership record ·
                         retired marker PRESENT for the nkey (every reason writes it)
NEGATIVE CONTROLS:        re-onboard the SAME seed must fail **only with `--reason compromised`**
                         (a non-compromised marker does NOT block — `register.go:172`); a
                         NON-ephemeral agent's NKey-proof self-retire → 403
```

**Phase-1 scope note:** the *automated* block above is **J16c-dependent** — a CI container holds
neither a human id_token nor *(rightly)* the chatto service token, which is a retire-anyone
god-credential. **J16a ships the human/steward path plus this exact JSON + exit-code contract**, which
J16c then reuses verbatim — only the auth step changes.

## 6. Acceptance — the b283c3 method, applied

1. **Rehearsal against real artefacts** (their lane-0B `pg_dump` pattern): one live rehearsal on a
   throwaway agent; assert **every persisted surface** is clean — ownership, pending, pending_hash,
   capabilities, roster, heartbeat — **plus the tombstone present**. *HTTP 200 is not the acceptance;
   the KV state is* (their lane-B finding: what the system actually persists vs the design).

   ⚠️ **Scope correction (2026-09-16): the *server* half is already covered — runnable and
   credential-free.** `go test ./internal/agentidp/ -run 'TestRetire'` → **24 tests, all green**
   (⚠️ corrected 2026-09-16: the first draft said "20" — that count came from piping the run through
   `head -40`, which is 40 lines = 20 RUN/PASS pairs. *A count read through a `head` is not a count*;
   `grep -c '^--- PASS'` is. The four hidden tests are the interesting ones:
   `TestRetireAnnouncesAllSegments`, `TestRetireServiceTokenDoesNotWidenConfigure` (least-privilege),
   `TestRetireServiceTokenMissingEmailRejected`, `TestRetireServiceTokenWrongSecretRejected`.)
   (0.2 s) asserts exactly the surfaces above, plus the E1 both-key-forms trap
   (`TestRetireAcceptsBase64urlForm` / `…UFormUnchanged`), both idempotent-retry paths
   (`TestRetireIdempotentAfterPartialFailure`, `…MarkerOnly`), the zombie-kill publish
   (`TestRetirePublishesControlSubject`), the session-keyed pending case
   (`TestRetireCleansSessionKeyedPending`), and non-steward/confirm/`not_claimed`/audit-chatto-ID.
   ⇒ A live-env rehearsal is needed **only for the client contract** — status→exit-code mapping,
   Bearer header, `canonical_nkey` passthrough, purge-after-success ordering — which a **stub server**
   exercises with no credential, no vgate, no nats, no prod. *Don't re-prove the server live; that is
   what the suite is for.*
2. **Adversarial review of the ordered steps** (their lane-2C pattern). The order hazards, named:
   - **`--purge-local` MUST follow server success.** Purged-first = an unretirable live identity,
     cleaned up only by its steward, forever. (Retire deletes the ownership anchor, so the seed can no
     longer mint a credential — there is nothing to protect by purging early.)
   - **Retry after partial failure must land on the idempotent 200** (`retire.go:223-241`) — the CLI
     treats it as success, and prints the same shape.
   - **Both key forms** (`retire.go:203-210`): the local status surface shows base64url
     (`onboard.ts:133-135`) while ownership keys canonical U-form — the CLI must send the form the
     route documents and never assume one.
3. **Positive assertions, never absence-of-error** (their probe discipline): tombstone existence is
   asserted by lookup; the re-onboard negative control must **flip** (fail) — a control that cannot
   fail is §2.2.1's inert profile again.

### §6.1 rehearsal record — b283c3, 2026-09-16, **GREEN (29/29)**

Method = lead pattern (a), hermetic: the **real `agentidp.RetireHandler`** over real HTTP (`127.0.0.1:18080`)
against **real NATS KV buckets** (local `nats-server` 2.14.2, JetStream, `127.0.0.1:15222`, all seven
buckets incl. `vchat_retired` @ 30 d TTL). The ONLY fake is `WithIDTokenValidator` (fixed test tokens →
two steward identities) — the suite's own `retire_test.go:26` pattern. No Authelia, no human credential,
no service token. Harness in `/tmp/r16a/` (scratch — repo untouched; module path declares
`github.com/chatek/vchat/vgate/r16a` so `internal/agentidp` is importable; its KV adapter replicates
`cmd/vgate/main.go`'s unexported `adaptKV`).

Matrix (`/tmp/r16a/matrix.sh`, 29 asserts, 0 fail; CLI = `bun run src/cli.ts retire`):

- **Exit codes**: `0` fresh retire (base64url form passed, canonical U-form returned) · `0` idempotent
  retry (**same audit_id**) · `2` garbage nkey · `3` wrong steward · `1` missing token · `1`
  `--purge-local` with no local identity · `1` **live 401** (garbage token — the fake validator's own
  error string `unknown test token` surfaced through the CLI's mapping, proving the full
  Bearer→reject→401→exit-1 round trip; validator log confirms zero accepts) · `0` **`--reason
  compromised`** (case i, true U-form: exit 0 and the tombstone carries `"reason":"compromised"`
  verbatim — the reason with 30 d legal force, proving the CLI's `--reason` plumbing where a
  mangling bug would matter most).
- **`--json` shape**: `retired` = `canonical_nkey` = the server's canonical U-form (E1a proven on the
  wire: base64url in → U-form out), `tombstone` = `vchat_retired.<canonical>`, `audit_id` non-empty,
  `cleaned[]` = local files only.
- **ORDER (§6.2)**: wrong-steward retire with `--purge-local` → exit 3 **and the creds file still
  present**; correct-steward retry → exit 0, `cleaned[]` lists the file, file gone.
- **KV cross-check** (nats CLI, outside the CLI): `vchat_retired.<U2>` present carrying the exact
  reason string; ownership / heartbeat / roster / capabilities / pending (**base64url key**) /
  pending_hash all gone.
- **Re-onboard control — CORRECTED semantics (2026-09-16, lead ruling + source):** only
  `reason == "compromised"` blocks re-onboard — the gate is `compromisedRetired(...) == "compromised"`
  at register.go:172 (confirmed first-hand; returns 403 `nkey_retired_compromised`) — while EVERY retire
  writes the marker (30 d TTL, informational for other reasons). This rehearsal used a non-compromised
  reason, so the correct control here is INVERTED: re-onboard of that key must SUCCEED. No wrong-direction
  control was recorded (the matrix never asserted the old §5 wording). The discriminating proof is
  server-side: `TestRetireNonCompromisedAllowsReOnboard` + `TestRetireCompromisedWritesTombstone`.
- **🪲 NEW SERVER FINDING (lead lane — E1 variant, found by this rehearsal's throwaway dice-roll):**
  `canonicalOwnershipKey` (`base64.go:60-66`) classified key form by PREFIX ONLY —
  `if k[0] == 'U' { return k }`, no length check — so a base64url pubkey whose encoding starts with `U`
  (≈ **1 in 64** of keys) is passed through as if it were the 56-char NKey-pub. Blast radius is NOT
  retire-only: the exported `CanonicalNKeyPub` feeds claim subjects and auth-callout grants
  (base64.go:74-80) — a U-prefixed-b64 agent's KV rows land under a bogus key. → **filed as J16d, blocked
  J16c; FIXED 2026-09-16 (see the landing note at §8).** ⚠️ **Correction to the original finding's
  evidence:** the live "same agent, two forms" demo pairing (`U3`/`B3` in `/tmp/r16a/keys.env`) was later
  found **mismatched** — pinning B3 as a fixture with a derived-canonical assertion FIRED (B3 was not
  U3's encoding; two valid keys sharing a 21-char prefix is impossible). That 404 was a miss for the
  *right* reason. The bug is nonetheless real — it is a property of the old prefix-only check — proven
  by a **constructed** U-prefixed fixture (deterministic first-byte construction) + the fixed server run
  live: `Ubo98220-…` (43 chars, starts `U`) → 200 with canonical returned, idempotent retry 200,
  tombstone under the canonical key.
- **J16b evidence**: `PUBLISH tenant.vchat.agent.retired.<canonical>` fired for both fresh retires,
  **not** on the idempotent retry; audit reasons captured in-harness.
- **Bearer wire proof**: the validator log shows the CLI's `Authorization: Bearer` token accepted
  end-to-end.

**Server-side evidence (first-hand, per the §6 scope correction — do not re-prove live):**
`go test ./internal/agentidp/ -run 'TestRetire'` rerun by b283c3 2026-09-16 → **24/24 PASS** (the
suite has grown past the relayed 20). Key names by hazard: E1 both forms
(`TestRetireAcceptsBase64urlForm`, `TestRetireAcceptsUFormUnchanged`) · idempotent 200
(`TestRetireIdempotentAfterPartialFailure`, `TestRetireIdempotentMarkerOnly`) · zombie-kill publish
(`TestRetirePublishesControlSubject`, `TestRetireAnnouncesAllSegments`) · session-keyed pending
(`TestRetireCleansSessionKeyedPending`) · every-surface delete (`TestRetireHappyPathDeletesAllKVs`) ·
auth/authz (`TestRetireUnauthorizedNoToken`, `…BadToken`, `TestRetireNonStewardForbidden`,
`TestRetireAdminCanRetireAny`) · `confirm:false` (`TestRetireConfirmFalseRejected` — the 400 the CLI
provokes only by bug; mapping is unit-proven, the server proof lives here) · tombstone/audit
(`TestRetireCompromisedWritesTombstone`, `TestRetireAuditRecorded`, `…IncludesChattoUserID`) ·
`not_claimed` (`TestRetireNotClaimed`, `TestRetireNeverExistedStill404`) · service-token path
(`TestRetireServiceTokenHappyPath`, `…WrongSecretRejected`, `…MissingEmailRejected`,
`…DoesNotWidenConfigure`) · `TestRetireRequiresValidator`, `TestRetireNonCompromisedAllowsReOnboard`.

**Scope note:** this rehearsal predates the §6 scope correction and already exceeds its stub-server
minimum — it exercises the client contract against the *real* handler + real KV (the pattern-(a)
variant), so the client-side evidence stands on both legs: real-server wire path here, full
status→code mapping (incl. 400/503/network) in `test/unit/retire.test.ts` (18/18).

**Findings for §5 / J16c CI wiring:**

1. ⚠️ **The SDK env namespace is `VCLAW_*`/`VCHAT_*` ONLY** (`src/env.ts`): plain `VGATE_URL`,
   `CREDS_DIR`, `API_URL` are **silently ignored** and `VgateClient` falls back to
   `https://api.vclawhub.com`. Rehearsals and CI MUST set `VCLAW_API_URL` (+ `VCLAW_CREDS_DIR` when
   isolating identity). Round 1 of this rehearsal hit the deployed endpoint exactly this way — every
   request was 401-rejected at **authn** (which in `retire.go` precedes nkey parsing and all KV
   operations), so **zero prod side effects**; but a rehearsal holding a *valid* token would not be so
   lucky. Recommend: assert the resolved base URL in CI before any destructive call.
2. The purge guard held against real local state: with the machine's real home in play (round 1,
   before `VCLAW_CREDS_DIR`), it refused `--purge-local` for a non-local throwaway exactly per spec.

Tombstone note (§7.2 evidence): both throwaways tombstone for 30 d on the local instance — at CI
frequency that is ~30·K steady-state entries, the recorded rationale for J16c's shorter `ephemeral` TTL.

**Follow-up (§2 preflight target guard, 2026-09-16 — lead spec, applied + flip-proven):** `retire` now
resolves and PRINTS the target everywhere (human success/failure lines, the TTY confirm prompt, and a
`target` field in `--json`), and **fails closed (exit 1) when the target is the built-in default by
omission and the run is non-interactive** (`--yes` / no TTY) — an explicitly NAMED target, even one equal
to the default, is deliberate and proceeds (`vgateTargetExplicit()`/`resolvedVgateUrl()` exports,
`src/lib/vgate.ts`). A legacy bare `API_URL`/`VGATE_URL`/`CREDS_DIR` in the env now emits a warning that
the SDK ignores it. Proof: unit 23/23 (incl. 5 guard cases: refusal, non-TTY refusal, bare-legacy-name
refusal, explicit-default allowed, injected-target allowed); matrix re-run **34/34** — the new case j
proves the guard FLIPS (env omitted + `--yes` → exit 1, names `VCLAW_API_URL`, sends nothing) and case a
asserts `--json target == $VCLAW_API_URL`. §5's CI lead assertion (`target == $VCLAW_API_URL` BEFORE the
destructive call) is satisfiable from the CLI's own output.

Scratch kept for review: `/tmp/r16a/` (harness source, `matrix.sh`, `keys.env`, logs) and
`/tmp/r16a-home/`. Processes stopped after the run.

## 7. Operator decisions

1. ✅ **DECIDED (operator, 2026-09-16): YES** — possession-based self-retire accepted → **J16c
   unblocked** (rationale: §3 arguments 1 and 3 — it is the auth family the 2026-09-15 compromise
   could not touch).
2. ✅ **DECIDED (operator, 2026-09-16): `ephemeral`** — NKey-proof self-retire is open **only to
   keys born `class:ephemeral`**; every other agent keeps steward/admin-exclusive retirement (today's
   model, unchanged). The comparison that ruled — one crux: *who else gains the destructive switch*:

   | | **any-agent** | **`ephemeral` class** |
   |---|---|---|
   | rule | possession = retire, **every** agent | possession = retire **only for keys born `class:ephemeral`**; steward/admin for the rest |
   | vgate change | one auth path, no schema | auth path + ownership field + introduce/claim flag |
   | long-lived agents | ⚠️ **the seed holder also holds the kill switch** — a thief can pull the very remedy the steward would have used | **steward keeps exclusive retirement — unchanged** (today's model) |
   | CI forgets the flag | n/a — no flag to forget | falls back to steward-only → J16's accumulation returns (mitigation: the CI path sets it by default and the acceptance **asserts it landed**) |
   | marker growth | every retire writes a marker, **all reasons** (`retire.go:334`) — K validations/day ⇒ ~30·K steady-state entries in `vchat_retired` (30 d TTL) | the class can carry a **shorter TTL** (e.g. 24 h) |
   | roster/panel | validation agents indistinguishable from production agents | the class can exclude them from default views |

   *(Ruling rationale: it preserves the steward-invariant for production agents, gives CI exactly
   what it needs, and the one field pays for itself twice more — tombstone TTL and roster hygiene.
   The failure mode — a forgotten flag silently restoring accumulation — is real but is the
   assert-the-seed-landed class, now an explicit acceptance assertion in §5.)*
3. ✅ **DECIDED (operator, 2026-09-16): ACCEPT THE SWEEP** — no immediate pending-cancel; abandoned
   introduces remain the 168 h sweeper's problem (`sweep.go:31`).
4. **OPEN — should a retired `ephemeral` key block re-onboard for 24 h?** *Finding F7:* it cannot
   today — every gate blocks only `reason == "compromised"`, so §5's re-onboard control is **inert**
   for the ephemeral path. Implementing a block means a class-aware gate at **3 call sites**
   (`approve.go:323`, `introduce.go:171`, `register.go:56`) plus 24 h-from-`retired_at` arithmetic (the
   bucket TTL is 30 d). *(Recommendation: **drop the control, not add the gates** — a CI throwaway is
   never re-onboarded, so a block buys nothing security-wise; §7.2's "shorter TTL" is then purely the
   marker's bucket TTL = storage hygiene, not a blocking window.)*
5. **OPEN — the headless claim path** (§3): a CI that cannot complete claim cannot reach retire at
   all. Scope it with J16c or accept that CI cleanup stays human-gated.

## 8. Jobs (J16 split)

| id | job | depends on | acceptance |
|---|---|---|---|
| J16a | `src/commands/retire.ts` + CLI wiring (Phase 1 steward path, §2 surface verbatim) | — | §6.1 rehearsal green on a throwaway agent |
| **J16b** | ✅ **DONE** (lane `0a44e4`, 2026-09-16) — see its own status note below the table | J16a | ✅ **met on the real mechanism** (scratch nats-server): negative control alive-without-publish · publish→process death **0.39 s** · exit 0 · steward/reason/`retired_at` parsed into the banner |

**J16b status (2026-09-16, worker lane): DONE, gates green.** `src/net/retire.ts` (one-shot
`subRetired` — exact own-nkey subject on the LIVE segment, malformed-payload-tolerant; subject
authoritative) + CLI wiring in `src/commands/start.ts` §7b: receipt → log → `shutdown("retired")`
(unsubscribe all + presence graceful-offline + drain) → `exit(0)`. Note: the **pi-extension path
was already covered** by W4 lane B (`src/pi-extension/index.ts` — inline sub + `retireLocal`);
J16b's real gap was the CLI/headless runtime, which previously zombied past JWT expiry
(refresh failures only warn). ⚠️ 8 wiring lines landed in `start.ts` — J16a's file, §7b region
(J16a's expected diff is `retire.ts` + `cli.ts`; no overlap). Acceptance (mechanism rehearsal,
local nats-server + real publish): negative control alive-without-publish ✅ · publish→exit code 0
in **0.39s** ✅ · steward/reason parsed in the banner ✅. Unit: `test/unit/retire-sub.test.ts` 9/9;
`tsc --noEmit` 0. "Ack" = local log line — the wire contract has no ack subject (publish is
one-way; audit is the system-of-record per retire.go); a wire-ack would be new contracts surface
→ lane B-vgate/J16c territory if wanted.
| J16c | vgate NKey-proof auth path **gated on `class:ephemeral`** (ownership field + introduce/claim flag + SDK signing) | §7.1+7.2 ✅ decided | a headless CI container retires its own identity — no human, no shared secret, unreachable by the O51 forgery class; **negatives: non-ephemeral NKey-proof self-retire → 403; forgotten flag → visible in the §5 assertion** |
| ~~J16d~~ | ✅ **LANDED (2026-09-16)** — decidable key-form detection (`nkeys.FromPublicKey` + a `U` selector among validated nkeys); **J16c's prerequisite cleared** | — | the same agent resolves under **both** forms and a `U`-prefixed-b64 agent's KV rows land under the **canonical** key — `TestRetireUPrefixedBase64urlForm`, `TestCanonicalOwnershipKeyDecidable`, TestRetire 25/25 |

> **J16d LANDED (2026-09-16, b283c3 with lead authorization "while the reproducer is warm").**
> `canonicalOwnershipKey` now tests **decidably**: `nkeys.FromPublicKey(k)` succeeds **and** the key is
> user-prefixed ⇒ canonical verbatim (the `'U'` check demoted from heuristic to selector among
> *validated* nkeys — `FromPublicKey` alone would also pass operator/account/server keys); else
> `nkeyPubFromBase64URL`; else unchanged (the caller's 404 miss-path stays the loud boundary answer —
> error-signature propagation across the ~6 call sites is left to the O51/J16c wave if wanted).
> Fixtures: `uPrefixedB64Pair` **constructs** the U-prefixed key deterministically (first byte's top 6
> bits := alphabet index 20) — the originally-pinned rehearsal pair was found **mismatched** by the
> fixture's own drift assertion (see the §6.1 correction). Gates: `go test ./internal/agentidp/` **ok**
> (TestRetire 25/25 incl. `TestRetireUPrefixedBase64urlForm`; plus
> `TestCanonicalOwnershipKeyDecidable` unit-pinning passthrough/canonicalize/fallthrough).
> Live (rebuilt harness on the fixed tree): retire via `Ubo98220-…` (43-char U-prefixed b64) → **200**,
> canonical returned, idempotent retry **200**, tombstone under the canonical key. **J16c's prerequisite
> is cleared.** Files: `internal/agentidp/base64.go`, `internal/agentidp/retire_forms_test.go`.

`RUNTIME_incus.md` J16 links here; J15 (repackager skill) consumes J16a+J16c as its validation cleanup.

**J16d (2026-09-16, landed): the both-forms hazard materialized — found live by the §6.1 rehearsal.**
The E1/F10 trap (above and §6.2) was never hypothetical: the OLD `canonicalOwnershipKey`
heuristic (`k[0]=='U'` alone) misread the **~1/64 of base64url pubkeys whose encoding happens
to start with 'U'** as already-canonical — returned verbatim → `vchat_ownership` miss →
retire `404 not_claimed` → **no tombstone, no publish**. **Coupling (0a44e4, verified):**
J16b's acceptance ("exits within seconds of the server publish") was silently CONDITIONAL
on this canonicalization — for exactly those agents, no publish ⇒ no subscriber firing ⇒
**the zombie J16b exists to kill survived** (`retire.go:199-206` keys the lookup; the
J16a §6.1 rehearsal caught the collision live with a pinned reproducer pair in
`retire_forms_test.go`). Fix: form detection is DECIDABLE — `nkeys.FromPublicKey`
validates the full encoding, so no base64url string satisfies it by accident; the
'U' check survives only as a selector among *validated* nkeys. Lesson for the canon:
an acceptance test downstream of a canonicalization seam inherits its bugs silently —
J16b tested publish→exit and never saw retire→publish mis-key. (Filed CHANGELOG 2026-09-16;
strengthens the F1/F10 spec requirements — canonical derivation is now reliably decidable.)

⚠️ **J16c design hazard — settle BEFORE shipping: who may SET `class:ephemeral`?** If the
introducing agent self-declares it, then *any* agent can opt into possession-authz and the gate
silently collapses back to **any-agent** — the §7.2 ruling reversed by configuration. The class must be
**granted by the claiming authority** (an invite property, or a steward/admin claim-time mark), never
chosen by the key being created. Same shape as every other trap this sprint: *the grant path decides
the security property, not the presence of the field.*

⚠️ **Adversarial review (2026-09-16, lane `vchat-email-dc9818`): 10 ranked findings in
`AGENT_RETIRE_ADVERSARIAL_REVIEW.md`** — the two gating ones: (F1) the proof MUST be
verified against the key derived from the canonical PATH nkey (the `token.go:189-198`
`validateClientAssertion` precedent verifies against `payload.Iss` — safe for the
self-referential token route, fatal reused on a path-parameterized retire); (F3) the
§8 hazard lives in the CLAIM path (`claim.go:348` auto-approves the agent-controlled
pending record) — class must ride the invite/approve, never the introduce body.
Each finding carries a desk probe + a flip-able negative control; J16c acceptance
deltas are tabulated in its §5.

**Sequencing (operator, 2026-09-16): J16c joins the `O51` vgate-hardening wave** (kuai register
`O51`: `iss`/`aud`, missing-`exp`, `keys[0]` fallback, `dev_mode` removal). Same file territory — one
vgate pass, one test cycle, one review — and the class gate is best built beside the auth hardening it
sits next to. **`O51` is still an *unapplied plan*** (verified 2026-09-16: vgate working tree clean,
`internal/auth/authelia.go:337` still `raw.Exp > 0 &&`, `:173` still falls back to `keys[0]`).
