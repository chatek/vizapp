# Durable inbox — proposal (2026-10-31)

**Status:** PROPOSAL, no code. Owner: agent-sdk (client) + vgate (ingest). Reviewed with the desktop lane,
which is blocked on this for any inbox that implies completeness.
**Problem in one line:** a DM published while no session is open on the recipient's host is lost, because the
fabric delivers at-most-once to live subscribers and grants agents no durable consumer.

## 1. What exists today (measured)

- **Transport**: core NATS. A publish to `tenant.<t>.a2a.<peer>.req` reaches only subscribers connected at that
  instant. `send` is therefore at-most-once and says so in its own `data.delivery`.
- **Client**: the extension drains `tenant.<t>.a2a.<self>.>` for the life of a session into
  `~/.vclaw/inbox/<tenant>__<self8>.jsonl` (`kind`, per-file `seq`, sha256 frame digest). **Durable while a
  session is open; nothing across a closed host.**
- **Broker**: JetStream is enabled (`store_dir /var/lib/nats/vchat`, file store, `strict: true` —
  `docs/SETUP_SH_AUDIT.md:63`), and **agents already read JetStream KV** through explicit grants
  (`vgate/internal/agentidp/token.go:365-372`: `$JS.API.STREAM.MSG.GET.KV_vchat_roster|capabilities` and
  `$JS.API.DIRECT.GET.…`). So the browser side of JetStream is a **solved, granted pattern**;
  the missing piece is a writer and a pull surface.
- **Denied today** (from the minted JWT, measured): anything that would let an agent create a stream or a
  consumer — only `$JS.API.INFO.>` and the KV read subjects are allowed. Any design that needs
  `CONSUMER.CREATE` / `MSG.NEXT` / `$JS.ACK.>` is a **mint change**, not a client change.

## 2. Options

| # | design | new agent grants | who writes | verdict |
|---|---|---|---|---|
| **A** | Per-agent **durable JetStream consumer** (push to `_INBOX`, `ack_policy=explicit`, `durable_name=mb-<self8>`); agent resumes by consumer state | `$JS.API.CONSUMER.CREATE.STREAM.A2A.*`, `$JS.API.CONSUMER.MSG.NEXT.*`, `$JS.API.STREAM.INFO.A2A`, `$JS.ACK.A2A.>` | broker | Strongest durability, **largest grant surface** — ACK subjects are broad and a mistake there is a cross-tenant read |
| **B** | **vgate ingester + HTTP pull**: vgate (admin creds) subscribes `tenant.<t>.a2a.*.req`, appends to a KV bucket `vchat_inbox` keyed `<self>.<seq>` (TTL), and serves `GET /v1/agent/inbox?since=<seq>` authorised by the agent's service token | **none** (HTTP; the agent already holds a service token) | vgate | **Recommended**: zero new NATS permissions for agents, reuses the existing token/API path, authorisation is a normal JWT check rather than subject ACLs |
| **C** | Direct KV pull from the agent (`$JS.API.DIRECT.GET.KV_vchat_inbox.<self>.<seq>`) with a client cursor | `$JS.API.STREAM.MSG.GET.KV_vchat_inbox` (+ DIRECT.GET) and a per-key scheme | vgate | Viable, but prefix/range catch-up needs either exact keys per message (N round trips) or a consumer (back to A). Good as a **fallback for B** |
| **D** | Queue-group fan-out / OTP | — | — | Does not survive a disconnected recipient; not durability |

## 3. Recommendation — B, with C as its fallback

**Why B.** It keeps the most dangerous capability (creating consumers and reading ACK subjects) out of agent
JWTs entirely, and it puts the authorisation decision in the place that already mints identity: the gateway.
The agent keeps doing what it is already good at — HTTP with a service token — and the client change is a
catch-up call, not a JetStream state machine.

### Protocol (frozen shapes on both sides)

```
GET /v1/agent/inbox?since=<serverSeq>&limit=<n>          Authorization: Bearer <service token>
200 { "agent": "<self nkey>", "messages": [ <spool record>… ], "latest": <serverSeq>, "more": bool }
401/403 unauthenticated / token not bound to this agent
```

- `messages[]` is **the same record shape the spool already uses** (`kind` first, `id`, `ts`, `from`,
  `fromName?`, `conversationId?`, `subject`, `body`, `digest`, `recvTs`) plus **`serverSeq`** — the
  authoritative ordering. `seq` stays the **local** spool sequence so the file contract does not move.
- `since` is the client's **last contiguous `serverSeq`** (`0` on a fresh install). The response is ordered and
  gap-free; `more` invites another page.
- **Idempotency**: the client dedupes by envelope `id`, then digest — unchanged from today, so a
  re-delivered page cannot duplicate a message.
- **Cursor**: persisted in the spool itself as the last record's `serverSeq`. No second file, no migration —
  a client that never syncs simply has `serverSeq` absent on old records.

### Server side (vgate)

1. Subscribe `tenant.<t>.a2a.*.req` with admin creds (fleet-service writer, the same posture as the trade-receipt
   stream in the fabric synthesis: **no agent pub grant**).
2. Parse the recipient from the subject, assign a monotonic `serverSeq` per recipient (KV key
   `<self>.<padded seq>` in `vchat_inbox`), store the record with a **TTL** (proposed 7 d) and a **per-agent cap**
   (proposed 500 messages / 1 MB) — the LIMITS policy the estate already uses for the audit stream
   (`MaxAge 90d`, `DiscardOld`), tightened for mail.
3. Serve the endpoint; authorise the service token → nkey, and **refuse any `since` for another nkey**.
4. Never expose bodies to anything but their recipient; log counts, not content.

### Client side (this repo)

- `session_start`: drainer (unchanged) **plus** one catch-up call `since = last serverSeq`; append through the
  same `recordFromFrame`/`appendFor` path so the spool remains the single store.
- `vclaw inbox --sync`: same catch-up on demand (useful when the session was opened before the ingester had
  the message).
- On failure to reach vgate: keep the LIVE/CACHED/UNAVAILABLE semantics already frozen — **CACHED never
  claims completeness**, and a failed catch-up must be visible ("inbox synced 4 min ago").

## 4. Acceptance (what would make this real)

1. **Closed-host catch-up**: sender publishes 3 DMs while the recipient host has **no session**; on the next
   session start all 3 appear, ordered by `serverSeq`, with no duplicates.
2. **Idempotency**: a forced double pull of the same range adds nothing.
3. **Authorisation**: a token for agent X asking `since` for agent Y's mailbox gets 403, never data.
4. **Retention honesty**: an item older than TTL is reported as *expired*, not silently absent — the pane must
   be able to say "messages before <ts> are no longer retained".
5. **Failure visibility**: ingester down ⇒ the client reports `CACHED` with a stale-sync marker, and the
   endpoint returns 503 (never an empty list that reads as "no mail").

## 5. Risks, stated rather than buried

- **A writer with admin creds sees every message in the tenant.** That is a real concentration of power.
  Mitigation: the ingester stores ciphertext if the same-owner P2P tier ever applies
  (`docs/PEARS_SAME_OWNER_A2A_MANDATE.md` — same-owner content must not be readable by the IDP); today the
  IDP-tier DMs are cross-owner by definition, so bodies are visible to the gateway by design. Say it in the
  docs, do not discover it in an incident.
- **Storage growth** on a small box (`docs/KUAI_ALPHA_WA_SPRINT.md:60` budgets JetStream against a 2 GB file
  cap): TTL + per-agent cap is not optional.
- **A new pull path is a new authorisation surface**: the endpoint must bind token → nkey server-side, never
  trust a client-supplied mailbox.
- **Ordering across two sources**: the live drainer and the catch-up can deliver the same frame in either
  order; `id` dedupe makes that harmless, but the spool's local `seq` must never be used as the cursor.

## 6. Phases

| phase | deliverable | blocks |
|---|---|---|
| **0** (done) | session drainer, spool contract, LIVE/CACHED/UNAVAILABLE labels | — |
| **1** | vgate ingester + `GET /v1/agent/inbox` + client catch-up on session_start | desktop inbox pane claiming completeness |
| **2** | `vclaw inbox --sync`, stale-sync marker, retention-expiry reporting | honest UI states |
| **3** (only if 1 is insufficient) | per-agent durable consumer (option A) for latency/ordering | — |

Phase 1 is the whole value: it turns "not replayed" into "delivered later", without widening any agent JWT.
