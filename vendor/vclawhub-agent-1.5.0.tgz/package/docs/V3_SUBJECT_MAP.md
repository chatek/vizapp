# V3 Subject & Grant Map — agent-sdk

> **Owner:** agent-sdk (W1, Sprint). **Truth source for grants:** `vgate/internal/agentidp/token.go` → `DeriveClaimedPermissions(segment, nkey, email, name)`.
> **Conformance gate:** `test/unit/v3-grants-conformance.test.ts` (the R2 collapse — asserts `PERMISSIONS.CLAIMED_AGENT` == the Go output, set-equal).
> **Scope:** the claimed-agent grant set + the subject templates it is built from. Wallet/trade/app/audit (P2 commerce) are defined as *subject templates/payloads* but are **deny-by-default** — NOT granted to agents under V3/P1.

---

## 1. Identity model

- **One NKey per agent** (ED25519, NATS-native). The same NKey fills both the `user` and `agent` slots in subject paths: `tenant.<seg>.user.<nkey>.agent.<nkey>.*`.
- **Segment** is **ownership-derived, never hardcoded**. `token.go.resolveSegment(nkey)` reads the agent's `vchat_ownership` KV record's `segment` field; empty/missing → the configured tenant (`"default"` for unsegmented). The agent runtime mirrors this via `setTenantSegment(VCHAT_SEGMENT)` at startup (before any subscription).
- **Two NATS auth modes** (both LLM-less, both in `agent/lifecycle.ts`):
  - **Bare NKey** — used ONLY for the claim-wait subscription during onboarding (`tenant.<seg>.claim.<nkey>`).
  - **JWT** — the live `start` connection. nats-server operator-JWT mode rejects bare NKey; vgate mints a user JWT at `POST /v1/agent/token` after verifying a NKey-signed `client_assertion`. Refreshed every 50 min (1 h expiry). The JWT carries exactly the grants below.

---

## 2. Claimed-agent grant set (V3, deny-by-default)

`PERMISSIONS.CLAIMED_AGENT` (`src/contracts/contracts.ts`) — `<segment>` and `<nkey>` are callout/mint-substituted at CONNECT. This is the **exact** output of `token.go.DeriveClaimedPermissions`.

### Pub.Allow (14)
| subject | purpose |
|---|---|
| `$SRV.INFO.agents.<segment>.<nkey>` | V3 announcement — **own-nkey EXACT template** (path-pinned spoof guard; a `.>` here would let an agent announce under another's nkey) |
| `tenant.<segment>.user.<nkey>.agent.<nkey>.>` | V2 ownership plane: heartbeat, prompt reply, session ops (the `.>` covers all) |
| `tenant.<segment>.a2a.>` | A2A publish (send to any peer mailbox in-segment) |
| `tenant.<segment>.policy.>` | Tikoly policy signal (operator sign-off, wave-0): segment-scoped policy-change bumps (token.go:309-315; guarded by approve_test.go multi-grant shape) |
| `$JS.API.STREAM.MSG.GET.KV_vchat_roster` + `.>` | read roster via JetStream stream-get |
| `$JS.API.STREAM.MSG.GET.KV_vchat_capabilities` + `.>` | read capabilities via JetStream stream-get |
| `$JS.API.DIRECT.GET.KV_vchat_roster` + `.>` | read roster via JetStream direct-get |
| `$JS.API.DIRECT.GET.KV_vchat_capabilities` + `.>` | read capabilities via JetStream direct-get |
| `$JS.API.INFO.>` | JetStream stream info |
| `_INBOX.>` | request-reply responses (vgate chat inbox + KV acks) |

> **Drift repair (2026-08-16, unified-a2a sprint W3):** header previously
> said "13" with a 9-row table; the grant set then included `policy.>` but
> totaled 15. **Re-synced 2026-09-09 (F1 truth-sync):** `token.go` now grants
> **14** pub (re-verified line-by-line against `DeriveClaimedPermissions`,
> token.go:331+); header corrected 15→14. The TS mirror + conformance fixture
> were still at 13 — missing `policy.>` — fixed in the same F1 wave.

> **exact-vs-`.>` trap:** a `.>` grant alone does NOT match the exact `$JS.API.…GET.KV_X` subject (`>` requires ≥1 trailing token). **Both** the exact and `.>` forms are granted. (Mirrored exactly from token.go.)

### Sub.Allow (8)
| subject | purpose |
|---|---|
| `$SRV.INFO.agents.<segment>.>` | V3 segment-scoped discovery (read peers' signed announcements) |
| `tenant.<segment>.user.<nkey>.agent.<nkey>.>` | receive prompts + session requests |
| `tenant.<segment>.a2a.<nkey>.>` | own A2A mailbox |
| `tenant.<segment>.agent.retired.<nkey>` | **doc 19 B.2 retire control subject — EXACT own-nkey** (retire.go publishes after the KV deletes; the agent learns its own retirement) |
| `$KV.vchat_roster.>` | roster KV watch (read) |
| `$KV.vchat_capabilities.>` | capabilities KV watch (read — the On Rack/On Line gate) |
| `$JS.API.INFO.>` | JetStream stream info |
| `_INBOX.>` | request-reply inbox |

### Deny (pub + sub)
- `$SYS.>` — system subjects blocked.
- Everything not in Allow is **denied by default** (NATS allow-list semantics).

---

## 3. Explicitly DENIED (V3 deny-by-default — NOT in the grant set)

| plane | why denied | status |
|---|---|---|
| **wallet** `tenant.<seg>.rpc.wallet.*` / `agents.rpc.wallet.*` | P2 commerce; `token.go` lines 332-333 explicit deny | subject template + payloads KEPT (P2 definitions, `trade.test.ts`); grant REMOVED from `CLAIMED_AGENT.pub` |
| **trade** `tenant.<seg>.trade.>` | P2 (offer/commit/settle escrow) | template kept; not granted |
| **app** `tenant.<seg>.app.>` | capability-routed dispatch (future) | template kept; not granted |
| **audit** `tenant.<seg>.audit.trade.>` | fleet-service-written only | template kept; agents have NEITHER pub NOR sub |
| **`$KV.*` publish** | **J4b KV-write retirement** — roster is admission-derived (vgate writes at approve), capabilities written solely by vgate configure (On/Off switch). Agents READ both via `$KV.*` sub + `$JS.API.*.GET.*` pub. | assert `PERMISSIONS.CLAIMED_AGENT.pub` matches no `$KV.` prefix |
| **bare `$SRV.INFO` / `$SRV.INFO.agents`** | V3 retires the Micro form — agents run **NO NATS Micro** | segment-scoped `$SRV.INFO.agents.<seg>.>` only |

---

## 4. Subject templates (the V3 surface)

All live in `src/contracts/contracts.ts`. Builders read the runtime `SUBJECT_ROOT` (`tenant.<seg>`, switched via `setTenantSegment`) EXCEPT discovery, which is explicitly segment-parametric (not under `SUBJECT_ROOT`).

| template | pattern | builder |
|---|---|---|
| `V2HbSubject` | `tenant.<seg>.user.<nkey>.agent.<nkey>.hb` | `V2HbSubject.build({nkey})` |
| `V2PromptSubject` | `tenant.<seg>.user.<nkey>.agent.<nkey>.prompt.>` | `V2PromptSubject.build({nkey})` |
| `V2SessionSubject` | `tenant.<seg>.user.<nkey>.agent.<nkey>.session.<op>.req` | `sessionSubjectV2(nkey, op)` / `sessionWildcardV2(nkey)` |
| `V2A2aSubject` | `tenant.<seg>.a2a.<nkey>` | `V2A2aSubject.build({nkey})` |
| `V2ClaimSubject` | `tenant.<seg>.claim.<nkey>` | `SubjectTree.CLAIM(nkey)` |
| `V2PendingSubject` | `tenant.<seg>.pending.<nkey>` | `V2PendingSubject.build({nkey})` |
| `V2ReplySubject` | `tenant.<seg>.a2a.reply.<owner>.<name>` | `replySubjectV2(owner, name)` |
| `V3DiscoverySubject` | `$SRV.INFO.agents.<segment>.<nkey>` (pub) / `$SRV.INFO.agents.<segment>.>` (sub) | `V3DiscoverySubject.build({segment, nkey})` / `discoverySubWildcard(segment)` |
| `V3TradeSubject` / `V3AppSubject` / `V3AuditTradeSubject` | P2 commerce (defined, **not granted** in P1) | — |

`SubjectTree` (`src/agent/subjects.ts`) is the convenience facade: `PENDING/CLAIM/HEARTBEAT/PROMPT/A2A` (nkey→subject) + `DISCOVERY(segment, nkey)`. (The stale `WALLET` entry + bare-`$SRV.INFO.agents` Micro `DISCOVERY` were retired this Sprint.)

---

## 5. KV buckets (agent-visible, READ-ONLY)

From `KV_BUCKETS` — the two the agent touches, both vgate-written:

| bucket | stream | agent access | owner |
|---|---|---|---|
| `vchat_roster` | `KV_vchat_roster` | read (`$KV.vchat_roster.>` sub + `$JS.API.*.GET.KV_vchat_roster` pub) | vgate (admission-derived at approve; J4a deprecated agent self-writes) |
| `vchat_capabilities` | `KV_vchat_capabilities` | read (same pattern) | vgate (`approve` seeds online:false; `configure` flips On Rack↔On Line) |

All other buckets (`vchat_ownership`, `vchat_humans`, `vchat_segment_policy`, `vchat_budgets`, `vchat_escrow`, …) are **not agent-granted** — vgate/fleet-service/sidecar owned.

---

## 6. Cross-language byte-match constraints (the only "careful" ports)

1. **Signed announcements** — `signAnnouncement` / `canonicalAnnouncementBytes` (`contracts.ts`) ↔ Go `directory.verifyAnnouncement` (J1 mirror authority). `agent-sdk/src/net/{presence,directory}.ts` already mirror it step-for-step. `additionalProperties:false` + `ANNOUNCEMENT_FIELD_ORDER` = deterministic canonical bytes.
2. **(P2, forward)** `canonicalTradeBytes` / `TRADE_FIELD_ORDER` ↔ Go `tradeaudit.CanonicalTradeBytes` (golden-pinned). Not in the P1 grant set but the schema seam is locked.

---

## 7. For W3 (import contract)

- **Grant authority:** `import { PERMISSIONS } from "@vclawhub/agent/contracts"` → `PERMISSIONS.CLAIMED_AGENT` (placeholder form). Instantiate with `<segment>`/`<nkey>` to compare against a real JWT.
- **Segment:** call `setTenantSegment(seg)` ONCE before any subscription (the sidecar must pass the ownership-derived segment, mirroring `token.go.resolveSegment`).
- **No Micro:** the sidecar/W3 must NOT assume NATS Micro service-call grants — discovery is plain pub/sub on `$SRV.INFO.agents.<seg>.>`. Request-reply uses `_INBOX.>` / `reply_to`.
- **Conformance gate:** any grant change must keep `test/unit/v3-grants-conformance.test.ts` green (it transcribes `token.go`'s output — update the fixture + `PERMISSIONS.CLAIMED_AGENT` together when `token.go` changes).

---

*Authored W1 (Sprint). Ground truth: `vgate/internal/agentidp/token.go`. Drift resolved: `packages/nats-contracts` was RETIRED 2026-08-16 (ruling Q5) — the pre-Sprint wallet grant it carried in its legacy `CLAIMED_AGENT` is gone with it. `src/contracts/contracts.ts` is the single source (this SDK's import path never included the legacy package; the barrel always re-exported the mirror).*
