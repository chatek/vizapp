# E2E: does the daemon spawn the RESOLVED runtime?

**Lane:** E2E Lane 1 · **Driver:** committed source · measured at `agent-sdk@9e770e6`,
**re-verified at `2a50c98`** (the only delta in the spawn path between them is a doc comment in
`runtime.ts` and two `console.log` lines in `cli.ts` — provably non-functional, and re-run anyway.
**Verdict:** the resolver's four layers all reach `spawn()`, and the argv it composes is
accepted by a real pi **0.85.1**. The only thing left unverified is the modal
extension-UI policy, which needs a real turn.

`worker-pi.ts:24-30` said a live spawn had **never** been run; the integration test drove the
same code path against a fake `pi` via `VCLAW_PI_BIN`. This closes that gap for every claim
below except the one marked BLOCKED.

---

## 1. What was driven, and why

| | |
|---|---|
| Command | `bun src/cli.ts eval "<task>" --driver pi --workers 1 --timeout 8000` |
| Runtime | `eval` starts an in-process daemon (`startServe`) and spawns real workers — no pre-running `serve`, no NATS |
| Why source, not `dist/` | `bin/agent.js` prefers `dist/`, but `dist/` is **gitignored** (only 2 bundled extension files are tracked) and is a local build. The committed evidence is `src/`. Verified equivalent anyway: **0** `src/*.ts` files were newer than `dist/cli.js` at test time. |
| Env | `HOME` → a scratch home; `PATH` → instrument dir first; `VCLAW_PI_BIN` explicitly unset except in claim 3 |
| Credentials | none needed — the spawn is observable whether or not the turn completes |

## 2. The instrument

Three wrappers, each **appending its argv to a distinct log, then `exec`ing the real pi**.
Making every candidate observable is the point: a null result is then informative, not ambiguous.

```
/tmp/e2e-runtime/stubbin/pi          → path-pi.log        (the PATH layer, "pi")
/tmp/e2e-runtime/wrapper-config.sh   → config-runtime.log (the config layer)
/tmp/e2e-runtime/wrapper-env.sh      → env-runtime.log    (the VCLAW_PI_BIN layer)
/tmp/e2e-runtime/wrapper-flag.sh     → flag-runtime.log   (the --pi-bin layer)
```

**The instrument was verified by hand before use** — each wrapper was invoked once directly and
its log confirmed to carry the right `layer=` marker and argv. (It also immediately showed that
real pi rejects an unknown flag with `Error: Unknown option: …` and exit 1, which is exactly the
signal that makes the argv result below meaningful.)

## 3. Claims

Each claim has **two independent witnesses**, and they agree — a self-report is only evidence
when something external corroborates it:

- the **CLI's own** `🔧 runtime: <bin> (source: <layer>)` line (added in `f9a15cf` — the code's
  claim about which layer it used), and
- the **wrapper logs** (which binary the OS actually executed).

A disagreement between them would itself have been the finding.

### Claim 1 — config `runtime` as an absolute path → that binary. **VERIFIED**

`~/.config/vclaw/config.json` → `{"runtime": "/tmp/e2e-runtime/wrapper-config.sh"}`, no
`--pi-bin`, no `VCLAW_PI_BIN`:

```
path-pi.log        ABSENT     ← PATH's `pi` was NOT used
config-runtime.log 10 lines   ← the config's absolute path WAS spawned
```

### Claim 2 — no config, no env → `pi` from PATH. **VERIFIED**

Fresh `HOME` (no `config.json`), `VCLAW_PI_BIN` unset:

```
path-pi.log        10 lines   ← resolved through PATH, as the default promises
config-runtime.log ABSENT
env-runtime.log    ABSENT
```

### Claim 3 — `VCLAW_PI_BIN` beats the config. **VERIFIED**

Config set **and** `VCLAW_PI_BIN=/tmp/e2e-runtime/wrapper-env.sh`:

```
env-runtime.log    10 lines
config-runtime.log ABSENT     ← the config lost, as specified
path-pi.log        ABSENT
```

### Completeness — the flag layer. **VERIFIED** (not asked; completes the chain)

Config + env + `--pi-bin` all set → `flag-runtime.log` 11 lines, everything else absent.
**All four layers of `flag > env > config > default` are therefore observed reaching `spawn()`**,
not just reasoned about.

**Re-run at `2a50c98`, both witnesses agreeing:**

| setup | CLI reported `source:` | wrapper that actually spawned |
|---|---|---|
| config only | `config` | `config-runtime.log` |
| nothing set | `default` | `path-pi.log` |
| config + `VCLAW_PI_BIN` | `env` | `env-runtime.log` |
| + `--pi-bin` | (`eval` does not print the flag tier) | `flag-runtime.log` |

## 4. The argv pi actually receives

From the wrapper logs (identical in every run, one arg per line):

```
--mode rpc
--session-dir <familyDir>/sessions/pi
--session-id <worker-name>
--no-builtin-tools
--append-system-prompt '[family worker <name>] role: <role>'   # only when --role is given
```

**Real pi 0.85.1 parsed all of it.** No `Unknown option`, no usage dump — pi proceeded through
session init to model resolution and failed only with:

```
pi.dev prompt failed: No API key found for the selected model.
```

That is the **desired** failure: it proves the argv composed correctly and the failure is the
absence of credentials in the scratch `HOME`, not a bad flag. This retires the "exact
argv/session-flag composition" item from `worker-pi.ts:24-30`.

## 5. Session-file placement under `--session-dir` — **VERIFIED**

With the exact daemon argv run directly against real pi, the session file lands **inside**
`--session-dir`, named from `--session-id`:

```
/tmp/pi-probe2/pi/2026-09-12T05-15-40-246Z_probe2.jsonl
  {"type":"session","version":3,"id":"probe2","timestamp":"…","cwd":"…"}
  {"type":"model_change",…,"provider":"deepseek","modelId":"deepseek-v4-flash"}
```

Two further facts pin the flag down in the daemon path:

- `worker-pi.ts` contains **no `mkdir`** — it only computes the path and passes it as
  `--session-dir` and `PI_CODING_AGENT_SESSION_DIR`. So the `sessions/pi/` directory that
  appears in every daemon run **was created by pi from that flag**.
- The daemon's env var name is correct: `config.ts:496` builds
  `ENV_SESSION_DIR = ${APP_NAME.toUpperCase()}_CODING_AGENT_SESSION_DIR`, and `APP_NAME` is
  `"pi"` → `PI_CODING_AGENT_SESSION_DIR`, matching what `worker-pi.ts:171` sets.

**In the daemon runs `sessions/pi/` is created but empty.** That is explained, not a defect: the
scratch `HOME` has no model credentials, the turn dies at model resolution, and pi writes no
session file. Confirmed by contrast — the same argv with a credentialed `HOME` wrote the file
above. So placement is verified by direct invocation; the daemon-path *file* is BLOCKED on
credentials (see §7).

## 6. The `stop` contract — **VERIFIED**

`worker-pi.ts` asserts `pi.dev exits on stdin EOF` and implements `{type:"stop"}` as
`child.stdin.end()` (the RPC subset has no quit verb). Tested through **the daemon's own
mechanism** — a `Bun.spawn` stdio pipe + `stdin.end()` — mirroring `worker-pi.ts` exactly:

```
idle          → EXITED   1 742 ms after stdin.end()
after-prompt  → EXITED     228 ms after stdin.end()
```

Independently, `< /dev/null` (immediate EOF) also exits in ~2s. The contract holds; a worker
does not need SIGTERM to stop.

## 7. BLOCKED — what could not be verified

1. **Modal extension-UI auto-cancel** (`select` / `confirm` / `input` / `editor`). No modal was
   ever emitted in the observed runs, so the cancel path was never exercised. What *was*
   exercised: real pi emits `extension_ui_request` of method **`notify`** in practice (the loaded
   A2A extension emits several at startup), and the daemon's ignore list covers it — so the
   notify-vs-modal split is live, not theoretical. **Blocked on:** a credentialed turn that
   triggers a modal. This is the one `worker-pi.ts:24-30` item still open.
2. **The daemon-path session *file*** (as opposed to placement, §5). Needs a model credential in
   the family's `HOME`; deliberately not done — the lane's method is credential-free.

## 8. An instrument that lied, recorded because it nearly became a finding

A shell-FIFO analogue (`mkfifo` + `exec 3>fifo`, then close) reported pi **still alive 12s after
EOF**, which would have meant "the daemon's `stop` is broken". **It was false.** The
mechanism-faithful test in §6 (and `/dev/null`) both show a clean exit.

The analogue was discarded, not explained: a control (`cat` on the same FIFO) *did* receive EOF,
so the FIFO pattern works in general, and I could not reproduce the false negative
deterministically. Plausible confounds, all of them harness-side: a child inheriting the write
fd (`sleep 3` ran between open and close), and `kill -0` **succeeding on a not-yet-reaped
zombie**. A later attempt to re-run it deadlocked, because opening a FIFO for *writing* blocks
until a reader appears — my ordering bug, not pi's.

**Rule taken from this:** assert a process-lifecycle contract through *the mechanism the code
under test uses* (here `child_process` pipe + `stdin.end()`), never a shell analogue of it. The
analogue disagreed with the real mechanism, and only the real mechanism was authoritative.

## 9. Environment caveats

- **pi 0.85.1** (installed) was what every empirical result above was measured against.
  `vendors/pi` is **0.84.1**, one minor behind — source reads there (e.g. `rpc-mode.ts`'s
  `onInputEnd → shutdown()`) corroborate but do not prove 0.85.1 behaviour. Where they differ,
  the measurement wins.
- `eval`'s family dir is a kept temp dir (`/var/folders/…/T/vclaw-eval-*`); transcripts are not
  auto-deleted, which is what made the after-the-fact inspection in §5 possible.
- All runs were read-only with respect to the repo: no source file was modified, no git command
  was run, and the operator's real `~/.config/vclaw/config.json` does not exist and was never
  written (every run used a scratch `HOME`, and `XDG_CONFIG_HOME` was unset).

## 10. Reproduce

```bash
BASE=/tmp/e2e-runtime; REAL=$(command -v pi)
mkdir -p $BASE/stubbin $BASE/homes/h/.config/vclaw

# three observable layers: each logs its argv, then execs the real pi
printf '#!/bin/sh\necho "layer=PATH" >> %s/path-pi.log; exec %s "$@"\n'   "$BASE" "$REAL" > $BASE/stubbin/pi
printf '#!/bin/sh\ni=0; for a in "$@"; do i=$((i+1)); printf "argv[%%d]=%%s\\n" "$i" "$a"; done >> %s/config.log; exec %s "$@"\n' "$BASE" "$REAL" > $BASE/wrapper-config.sh
chmod +x $BASE/stubbin/pi $BASE/wrapper-config.sh

# claim 1: config points at an absolute path
printf '{"runtime": "%s/wrapper-config.sh"}\n' "$BASE" > $BASE/homes/h/.config/vclaw/config.json
cd agent-sdk && env -u VCLAW_PI_BIN HOME=$BASE/homes/h PATH="$BASE/stubbin:$PATH" \
  bun src/cli.ts eval "probe task" --driver pi --workers 1 --timeout 8000

cat $BASE/config.log   # ← the worker argv, if the config layer was honoured
```

Substitute the `HOME` for claim 2 (empty, no `config.json`), and add
`VCLAW_PI_BIN=$BASE/wrapper-env.sh` for claim 3.
