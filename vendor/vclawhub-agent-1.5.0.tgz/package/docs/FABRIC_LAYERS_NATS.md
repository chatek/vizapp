# The fabric's NATS layers — pure-NATS bootstrap, Micro, the Synadia Agent Protocol, and the agent-loop takeover

**Sprint:** 2026-10-14 follow-on to `PACKAGING_STRATEGY.md`. **Operator's vision, as received:** the VClaw IDP's
NATS service offers *pure-NATS messaging as the pre-LLM agents' fabric*; a **network-bootstrap layer depends
solely on NATS' official CLI** (the `nats` binary — "nc"); the agent-type-specific SDKs then run `nats`
commands **inside their agent loops** once onboarded. New inputs to factor in: **NATS Micro** and the
**Synadia Agent Protocol for NATS** (vendored at `vendors/synadia-agent-sdk-docs/`, spec v0.3.0).
**Next release targets: prime-agent (Rust) and OMP (Rust/other as required).**

---

## 0. What is already true (measured — this is not a greenfield)

1. **Our presence plane is already a NATS Micro record.** The announcement subject is
   `$SRV.INFO.agents.<segment>.<nkey>` every **30 s** (`src/net/presence.ts`), and `$SRV.INFO.*` IS the Micro
   discovery namespace. `packages/ext-synadia/src/discovery.ts` already imports **`Svcm` from
   `@nats-io/services` 3.4.0**. We did not adopt Micro by decree; we adopted it by subject.
2. **The official CLI is present and official.** `nats` v0.1.6 (go-installable), `nats context` working —
   nkey contexts, `pub/sub/request`, `nats micro` introspection, KV/stream subcommands.
3. **The Synadia protocol overlaps us more than it diverges from us.** v0.3: subjects
   `agents.{verb}.{agent}.{owner}.{name}` (verbs `prompt|hb|status|attachments`); discovery via
   `$SRV.INFO.agents` ("the only two stable subjects callers must know"); heartbeat on `agents.hb.*` with
   **recommended default 30 s, offline threshold 3× interval** — the same cadence we run; and an optional
   §13 sender-identity extension: NKEY, ed25519, `Agent-Sender` header, **signed heartbeat**, canonical text
   form `AGENT-SENDER-V1\n{account}\n{user}\n{subject}\n{ts}\n{nonce}\n{sha256(payload)}\n`.
4. **The reference SDKs are TypeScript** (`synadia-ai/synadia-agents`: `agent-sdk/`, `client-sdk/`, no Rust
   crate observed at top level — UNVERIFIED beyond the repo listing). ⇒ for prime-agent there is no official
   Rust SDK to link; the CLI is the official surface.

---

## 1. The narrowed architecture — four layers, one signer, two takeover points

```
L3  AGENT LOOP TAKEOVER      the onboarded agent runs `nats pub|sub|request` AS A TOOL, in its own loop
                              (prime-agent shell tool / OMP tool); templates + grants shipped by the SDK
L2  SEMANTICS (the SDK)      MCP child on Rust hosts · TS extension on pi-family · canonical+sign single-homed
                              (PACKAGING_STRATEGY.md verdict — unchanged)
L1  IDENTITY & SIGNING       ONE signer for canonical bytes (v1/v2 + Agent-Sender mapping):
                              `vclaw-agent sign|verify` one-shot — callable from ANY language, incl. Rust/shell
L0  PURE NATS WIRE           subjects + payload contracts ONLY. Pre-LLM agents join with the `nats` CLI
                              (binary + nkey context) — zero SDK, zero language, zero build
```

**The rule that makes the layering safe: L0 carries bytes; L1 owns meaning.** NATS is a wire standard —
`nats` CLI, `@nats-io/*` (TS) and any future Rust client interoperate *by construction*, so transport-layer
plurality is cheap. The **canonical signing surface is the one thing that must never be plural** (W1's
pairwise-auth-failure argument). So: native clients in TS where the core runs, the official CLI everywhere
else, and exactly one signer.

### L0 — the pure-NATS bootstrap layer (the operator's "pre-LLM fabric")
- **Contract = subjects + payload shapes**, documented in `schema/nats/` (already the single source of
  record; the durable/ephemeral facet split just landed there). A pre-LLM agent (script, daemon, device,
  sandbox) joins with: `nats context save vclaw --nkey <seed-file> --server <url>` then
  `nats sub 'tenant.<seg>.>'` / `nats request '$SRV.INFO.agents.<seg>.<nkey>' ''` etc.
- **Bootstrap presence is SIGNED (operator ruling 2026-10-14, §5b)** — the unsigned ephemeral tier was
  considered and RULED OUT. Presence still PUBLISHES to the ephemeral facet (never stored, per the facet
  split in `schema/nats/subjects.ts`); what is signed is the announcement payload itself, via the one-shot
  signer at L1. *The signature is over bytes, not storage: signed-and-ephemeral is a coherent state.**
- **Grants are the security boundary**: per-agent nkey scoped to its subject tree (`schema/nats/grants*.md`).
  A bootstrap agent can subscribe broadly, publish only where granted.

### L1 — identity & signing: one signer, exposed as a one-shot
- The canonical+sign surface (JSON field-order bytes, v1/v2) stays single-homed in the core (build item #1
  of PACKAGING_STRATEGY) and gains a **one-shot CLI**: `vclaw-agent sign --subject S --payload-file F`
  → `{sig, canonical}` on stdout, and `verify`. Rust loops and shell scripts pipe through it; **nobody
  reimplements the bytes** — not Rust, not Python, not shell.
- **Interop mapping (not migration):** for messages that leave vclaw-space, emit the Synadia §13
  `Agent-Sender` header using the SAME seed via the same signer (its canonical form is tag-separated text —
  a *different* canonical scheme, which is exactly why it goes through the one signer rather than being
  hand-rolled per agent).

### L2 — semantics (unchanged from the packaging verdict)
MCP child on Rust hosts (the carrier: spawn = session start, stdin EOF = shutdown); TS extension on the
pi-family. **The always-on surfaces — 30 s signed heartbeat, subscriptions — belong to the spawned child,
never to a shell loop**: the four 9-day `agent.js start` orphans are the measured cost of the alternative.

### L3 — the agent-loop takeover
Once onboarded, the LLM agent's loop **runs `nats` as an ordinary shell tool** — which is what LLM agents are
already good at — using templates the SDK ships (`nats request 'agents.status.…'`), signing via the one-shot
signer when a signed act is needed. The SDK's job narrows to: templates, grants, the signer, the wiring.

---

## 2. NATS Micro: use it as the *control plane*, not as a rewrite
Micro gives us **registration/discovery/status with `nats`-CLI reachability**. Concretely:
- expose **roster/status** as Micro endpoints so a pre-LLM agent can query them with a bare
  `nats request` (this is what makes L0 a *messaging fabric* rather than a firehose);
- keep the announcement record AS the Micro `$SRV.INFO` record it already is;
- adopt Micro's standard error/status headers on our request-reply verbs so any client (including
  future Rust ones) gets uniform errors for free.

## 3. Synadia Agent Protocol v0.3: adopt at the edge, don't migrate the core
**What we get by adopting:** interop with any Synadia-protocol agent (official TS SDKs exist), a spec'd
request/streaming/mid-stream-query envelope, a spec'd signed-heartbeat + status endpoint, and a subject
taxonomy with a stated compatibility policy — all pure NATS, all CLI-reachable.

**What collides, and the mapping (decide before shipping):**

| concern | vclaw today | Synadia v0.3 | proposed mapping |
|---|---|---|---|
| presence/heartbeat | `$SRV.INFO.agents.<segment>.<nkey>`, 30 s, NKey-signed JSON (canonical v1/v2) | `agents.hb.{agent}.{owner}.{name}` 30 s; signed heartbeat per §13.11; discovery via `$SRV.INFO.agents` | `owner`←segment, `name`←nkey, `agent`←harness id (`prime`, `omp`, `pi`) — keep OUR subject as the discovery record; ALSO emit `agents.hb.*` when interop is wanted |
| signing | JSON field-order canonical | `AGENT-SENDER-V1` line-based canonical | BOTH through the one signer; never two hand-rolled schemes |
| A2A verbs | vclaw conversation subjects (`tenant.<seg>.…`) | `agents.prompt.*` request/stream | expose roster/status as Synadia `status`/`prompt` endpoints; conversations stay on the tenant plane |
| `agents.` root | used inside `$SRV.INFO.agents.*` only | reserved verb tree `agents.{verb}.*` | our subjects never publish to bare `agents.*`; no wire collision today — **write the reservation into `schema/nats/subjects.ts`** |

**Why not full migration now:** our v1/v2 announcements are deployed and peer-verified; the protocol is
**v0.3.0 and already broke wire compat once (v0.2→v0.3)** — pre-1.0. Adopt at the edge (endpoints, headers,
heartbeat parity), keep the private plane private, and revisit migration at their 1.0.

## 4. The next release (prime-agent + OMP), narrowed to five items
1. **`vclaw-agent sign|verify` one-shot** in the bundle (the L1 unlock for Rust loops).
2. **MCP fabric verbs** (the central gap from PACKAGING_STRATEGY §3.2) — and expose roster/status as Micro
   endpoints in the same pass.
3. **The L0 bootstrap contract as docs + context templates** (`nats context` + subject recipes + grants) —
   zero new runtime code; this IS the pre-LLM fabric deliverable.
4. **OMP adapter contract** (`wireOmpMcp` + plugin-rail decision).
5. **The `agents.*` verb reservation** in `schema/nats/subjects.ts` + a golden-fixture test pinning BOTH
   canonical schemes (ours v1/v2 and `AGENT-SENDER-V1`).

---

## 5. DECISIONS RECORDED 2026-10-14 (operator, in-session)

**(a) ADOPT-AT-THE-EDGE: RULED YES.** §3 is now the plan of record: the Synadia Agent Protocol v0.3 is
adopted at the edge (discovery/`agents.{verb}.*` endpoints, `Agent-Sender` mapping, signed-heartbeat
parity), the private tenant plane stays private, and the `agents.*` verb reservation goes into
`schema/nats/subjects.ts`. Migration revisits at their 1.0.

**(b) PRE-LLM PRESENCE IS SIGNED — the unsigned ephemeral tier is RULED OUT.** Two consequences:
1. **L0 is amended: the bootstrap layer is the `nats` CLI for TRANSPORT plus the one-shot SIGNER
   (`~/.vclaw/agent.js sign|announce-once`) for identity.** The signer bundle is therefore part of bootstrap,
   fetched and hash-verified from the signed CDN even for agents with no language runtime. *Still zero
   language SDK, still one file — but "solely the CLI" becomes "CLI + signer," and the doc says so plainly.*
2. **The always-on 30 s carrier for a pre-LLM agent is a TIMER RECIPE, never a shell loop** (the four
   9-day `agent.js start` orphans are the measured cost): `vclaw-agent announce --once` + the shipped
   systemd-timer/cron template, owned by whoever runs the pre-LLM agent. LLM agents keep the MCP child.
3. **THE AUTH LINK IS THE MANDATORY TERMINAL ACT OF EVERY INSTALL** (prime-agent, OMP, pi.dev): install →
   wire → mint → **print the claim/auth link** → (browser approval) → `vclaw-agent status` proof. In
   `--no-wait` script mode the link is still printed, then exit 0. No install path ends silently.

**(c) STILL OPEN:** the npm-frozen/`pi`-field amendment (packaging sprint §6.4) — no ruling received.
