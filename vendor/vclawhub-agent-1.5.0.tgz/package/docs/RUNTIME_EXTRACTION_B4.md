# B4 — startAgentRuntime extraction (spec)

> **agent-sdk · spec 2026-08-27 · job B4 routed by vclaw-agent-lead**
> (operator-authorized coordination; W2 audit: behavioral no-op, ~1 day,
> removes ~100L orchestration mirror). Status: SPEC — implementation lane
> follows this document unchanged unless the review finds a gap.

## 1. Goal

One shared, **non-blocking** agent-runtime constructor so the CLI
(`src/commands/start.ts`) and the pi-extension (`src/pi-extension/index.ts`)
share a single runtime composition instead of mirroring it. The extension's
in-file TODO (index.ts:15) and its WHY-NOT note are the problem statement:
`startAgent()` is CLI-oriented (awaits a signal promise, installs its own
SIGINT/SIGTERM). The extraction removes the mirror without changing either
entry point's observable behavior.

**Hard rule: behavioral no-op.** Every current delta between the two
compositions is preserved via explicit options (see §2). No unification of
divergent behaviors inside B4 — divergences worth unifying become named
follow-ups (§6).

## 2. Verified current-state deltas (design input)

| Concern | CLI `startAgent` | pi-ext `startRuntime` | B4 resolution |
|---|---|---|---|
| missing creds (prod) | `process.exit(1)` + hints | throw → caller UX | **caller-side** (pre-check, unchanged) |
| identity resolution | `public_key \|\| agent_nkey`, name, steward; dev = ephemeral `createUser` | same | **shared helper** `identityFromCreds` + dev-ephemeral in runtime |
| dev connect | `connectViaNKey(server, seed, name)` | transport-node plain `connect` | **option** `dev.auth: "nkey" \| "plain"` — both preserved |
| prod connect | `connectViaJWT(url, provider, seed, name)` | same shape | **shared** (runtime) |
| first JWT fetch | `fetchNatsUserJWT`; exit(1) on fail | `fetchJWTOrRetired` (retire-aware); throw | **caller-side** fetch; runtime takes `jwtProvider` |
| JWT refresh timer | 50min keep-old + log | 50min retry(+5min) → force reconnect + events | **stays caller-side** (v1 — see §6) |
| segment switch | `setTenantSegment` before any sub | same | **shared** (runs inside runtime before presence) |
| OnlineGate | constructed always (dev falls back) | constructed; **null in dev** (hermetic `() => true`) | **option** `skipGate` (ext sets it in dev) |
| presence | V3, or V2-hb fallback (`VCHAT_PRESENCE_V3=0`), or skip (`--no-heartbeat`) | V3 always + `onOnline/onOffline/onError` | runtime starts V3 with **caller providers**; V2 fallback + skip stay CLI-side |
| conn label | `agent-<session>` | `pi-<name>` | **option** `connName` |
| A2A / prompt / session subs | log-only A2A; `agentAnswer` prompts; SessionStore D2 | reply-injection A2A; H2A chunks; no prompt agentAnswer | **caller-side** (semantics differ by design) |
| directory / claim / retire subs | none | `watchDirectory` + guarded claim/retire subs | **ext-side** (unrelated to the mirror) |
| logging | console banners | `dbg` + `emitEvent` | **caller-side** (runtime is silent) |
| close | cleanup list → drain+close | stopRefresh + unsubscribes → presence.stop → drain → close | runtime `close()` = presence.stop → drain → close; callers run their own unsubscribes/timers first |

## 3. Extracted API — `src/agent/runtime.ts` (new file)

```ts
export interface AgentRuntime {
  nc: NatsConnection;
  identity: AgentIdentity;
  seed: string;
  gate: OnlineGate | null;      // null iff opts.skipGate
  presence: PresenceHandle;
  close(): Promise<void>;       // presence.stop → nc.drain → nc.close (best-effort each)
}

export interface AgentRuntimeOptions {
  connName: string;             // connection label (CLI "agent-<s>", ext "pi-<n>")
  identity: AgentIdentity;      // via identityFromCreds / dev-ephemeral helper
  seed: string;
  segment?: string;             // default VCHAT_SEGMENT || "vchat"
  server?: string;              // prod URL (required unless dev)
  dev?: { auth: "nkey" | "plain"; server: string };
  jwtProvider?: () => string;   // required unless dev (caller owns fetch+refresh)
  skipGate?: boolean;           // ext dev hermetic mode
  presence: PresenceOptions;    // startPresence options, pass-through
                                  // (seed, intervalMs, online/model/capabilities,
                                  //  onOnline/onOffline/onError)
}

export function identityFromCreds(creds: AgentCredentials): AgentIdentity;
export function devEphemeralIdentity(): { identity: AgentIdentity; seed: string };
export function startAgentRuntime(opts: AgentRuntimeOptions): Promise<AgentRuntime>;
```

The runtime: resolves segment → `setTenantSegment` → connects (dev nkey /
dev plain / prod `connectViaJWT(url, jwtProvider, seed, connName)`) →
constructs `OnlineGate(nc, identity.nkey, { envFallback: VCHAT_AGENT_LLM })`
unless `skipGate` → `startPresence(nc, identity, opts.presence)` → returns
the handle. **No timers, no signal handlers, no process.exit, no logging.**

## 4. Caller rewires

- **`commands/start.ts`**: keeps banner logging, creds pre-check + exit(1)
  UX, first JWT fetch + refresh timer, `agentAnswer`/SessionStore/autonomous
  block, signal wait, and the V2-hb fallback (`VCHAT_PRESENCE_V3=0`) +
  `--no-heartbeat` paths (both bypass runtime presence — runtime opts
  presence becomes optional accordingly). The connect/segment/gate/presence
  block (~90L) collapses into one `startAgentRuntime` call + close in
  `shutdown()`.
- **`pi-extension/index.ts`**: `startRuntime` keeps its pre-checks, the
  retire-aware JWT fetch + `startJwtRefreshTimer`, and ALL extension subs
  (A2A injection, H2A, directory, claim, retire); the connect/gate/presence
  composition (~80L) collapses into `startAgentRuntime` + its subs +
  return `{...rt, directory, stopRefresh}`. The Runtime interface keeps its
  current shape (directory/stopRefresh fields stay).
- Exported symbols stable: `startAgent`, `StartOptions`, `LLM_*`,
  `HELP_MENU`, `AGENT_SYS_PROMPT`, `agentAnswer` (start.ts); extension
  `default` factory (index.ts).

## 5. Gates (all must pass; behavior-preservation is the point)

1. `tsc --noEmit` clean.
2. Full vitest suite green (**375/375** baseline; extension-commands,
   cli, autonomous tests are the behavior anchors).
3. New unit tests for `runtime.ts`: dev-plain + dev-nkey + prod connect
   paths (mocked transports), gate construct-vs-skip, presence option
   pass-through, close ordering, `identityFromCreds` precedence.
4. **Leg-1-style dev smoke** (the P1a recipe): local `nats-server` on
   :14223, `VCHAT_DEV=1` ephemeral creds, real `startAgent` run — presence
   announcing, A2A sub live, clean SIGTERM shutdown, exit 0.
5. Extension smoke: session_start auto-connect in dev mode + `/vchat-status`
   shows connected + clean session_shutdown (dbg-verified).

## 6. Named follow-ups (explicitly NOT in B4)

- **Dev-auth unification**: `connectViaNKey` is a superset of plain connect
  (works unverified on no-auth servers); unifying is a 1-line simplification
  with a wire-visible delta — separate decision, needs its own smoke.
- **Refresh-timer unification**: CLI adopting the ext's retry/reconnect
  cycle (or vice versa) — separate; v1 keeps both caller-side.
- **rpc/server.ts third composition** (same envFallback convention at :313):
  candidate third consumer; adopt only after B4 lands and is verified.
