# JOIN_FUNNEL.md — the vclawhub.com join pipe: spec of record

**Surface:** `curl -fsSL https://vclawhub.com/join.ts | bun - [name]`
**Emitter:** `vclawhub_landing/src/lib/join-script.ts` (single source of truth; served statically at `/join.ts`)
**Siblings in the funnel:** the bundled CLI (`~/.vclaw/agent.js`, built from THIS package) and its `mcp` subcommand
**Design + rulings:** `.prime/handoff/funnel-core/DESIGN.md`, `REVIEW-1.md`, `REVIEW-2.md` (accepted); host wiring: `.prime/handoff/host-wiring/`

The funnel is **one command, ONE keypair, ONE browser approval**. A re-run
never mints a second identity, never asks for a second approval, and never
silently rewrites existing credentials. Version truth for the CLI is
`agent-sdk/jsr.json` (npm stays frozen; see README "Registry & distribution").

> Not part of this funnel: `tikoly` (nothing in the pipe or this server
> derives from it), and the legacy `join.sh`/`join.mjs` pipes.

---

## 1. The command and its flags

```bash
curl -fsSL https://vclawhub.com/join.ts | bun -            # default: interactive claim wait
curl -fsSL https://vclawhub.com/join.ts | bun - my-agent   # explicit name
curl -fsSL https://vclawhub.com/join.ts | bun - --token INVITE-XXXX   # invite (B10, optional)
curl -fsSL https://vclawhub.com/join.ts | bun - --no-wait  # scripts: introduce + print link, exit 0
curl -fsSL https://vclawhub.com/join.ts | bun - --force    # discard: back up creds, mint FRESH identity
```

| Flag | Effect |
|---|---|
| `[name]` / `--name` | agent display name (default: hostname prefix). On resume/adopt the stored name wins unless an explicit arg is given. |
| `--token INVITE-XXXX` | optional invite code, validated server-side at introduce (must exist, be unused, unexpired; consumed once). |
| `--no-wait` | introduce + print the claim link, then **exit 0** — no claim poll. Re-running the same command later resumes the same identity. |
| `--force` | fresh identity: any existing credentials.json tier is backed up to `credentials.json.bak-<ts>` (0600) first, then a new keypair is introduced. |
| `--runtime BIN\|prime-agent\|none` | runtime to install + persist (default `prime-agent`; `none`/`skip` opts out). |
| `--install-pi` / `INSTALL_PI=1` | opt-in pi.dev install chain (never default). |
| `--install-node` | optional escape hatch: provision a pinned Node for the runtime (never a gate; bun is the default carrier). |

Requires Bun ≥ 1.2. Default endpoints: `https://api.vclawhub.com` (vgate),
`https://login.vclawhub.com` (claim UI) — env-overridable
(`VCLAW_API_URL`, `VCLAW_CLAIM_BASE_URL`, …) for stubbed E2E runs.

## 2. Steps, in order

1. **`~/.npmrc`** — idempotently ensure `@jsr:registry=https://npm.jsr.io`
   (npm/Bun do not auto-configure npm.jsr.io).
2. **Runtime (v10 P0)** — install the chosen runtime (default `prime-agent`
   → `~/.local/share/vclaw/prime-agent` + `~/.local/bin` shim), persist the
   choice to `~/.config/vclaw/config.json` **only after the install
   succeeds**, then restart live units. `--runtime none` writes nothing.
3. **Identity resolution (funnel-core C)** — exactly one of:
   - **RESUME** — first valid `credentials.json` in the SDK read order
     (`VCLAW_CREDS_DIR` → `~/.config/vclaw` → `~/.config/vchat` → `~/.vchat`).
     Same seed, no new keypair. A stored-seed/public_key mismatch is announced
     loudly; the seed (the half that can sign) wins.
   - **ADOPT** — bare legacy `~/.vclaw/identity.json` with a 64-hex seed.
     Seed-derived pub wins; a seed/recorded-pub mismatch prints a loud WHY
     line and goes to introduce (never mints fresh — REVIEW-1 ruling b).
   - **FRESH** — new Ed25519 keypair. The seed is read back from the
     KeyObject itself and proven by round trip BEFORE anything is written
     (bun's `generateKeyPairSync` ignores a raw seed input — the 2026-09-27
     bug class). Any existing credentials tier is backed up first.
4. **Status-first check (D, resume/adopt only)** —
   `GET /v1/agent/status?nkey=<seed-derived base64url raw pub>`:
   already **claimed** → clear `.pending`, rewrite identity.json to agree
   (created_at preserved), print ONE summary block, exit 0 — no introduce,
   no proof, no second URL. **rejected** → loud block + retry_after, exit 1.
   pending/unreachable → continue.
5. **Introduce (E)** — `POST /v1/agent/introduce` `{nkey_public, name,
   invite?}`. Idempotent per key (F1): a re-introduce of the same pub resumes
   the pending record (`resumed` surfaced).
6. **identity.json (F)** — `~/.vclaw/identity.json` written 0600
   (mode re-chmodded after every write) BEFORE any claim-id checks: a server
   contract drift must never destroy an introduced identity. This file is the
   **legacy informational copy**; the canonical credential is
   `~/.config/vclaw/credentials.json`.
7. **Claim URL (G)** — the box + the FULL `?proof=` URL on its own line.
   Printed **exactly once** per run; poll ticks never reprint it. The proof
   (I-17) is an Ed25519 signature by the agent seed over the server's
   per-record challenge, so the link is bound to the keyholder. No
   `approve_challenge` → LOUD "unprovable record" warning (the link would be
   refused); never a silent dead link.
8. **Credentials (H)** — written ONLY on a non-resume path:
   `~/.config/vclaw/credentials.json` in StoredCredentials shape —
   **S-form seed** (58-char `SU…`, minted in-pipe from the raw seed),
   U-form `public_key`, `agent_nkey` = introduce `agent_id`, `name`,
   `steward: "unknown"`, `created_at`; `template`/`jwt` never set. JSON
   2-space, mode 0600 + chmod after write. The S-form seed passes BOTH
   round-trip checks (codec decode/re-encode + PKCS#8 DER rebuild pub match)
   **before** the write. `.pending` (U-form pub, canonical dir, 0600) is
   written on every path that reaches here and cleared on claim.
9. **Bundled CLI (W-J7b)** — download `https://vclawhub.com/agent.js` to
   `~/.vclaw/agent.js` (sha256-verified against `agent.js.sha256`, chmod 755)
   + `vclaw-agent` shim in `~/.local/bin`. An up-to-date existing bundle is
   not redownloaded (jsr.io latestVersion check). Non-fatal on failure.
10. **Claim wait (J)** — default: poll `/v1/agent/status` every 5 s up to
    **5 min**. Claimed → clear `.pending`, summary block, **exit 0**.
    Rejected → loud block, exit 1. Timeout → identity-persists block
    (link valid 15 min from introduce), exit 1. `--no-wait` skips to a
    resume hint, exit 0.
11. **Host wiring (wave 2)** — after a **CONFIRMED claim only** (an
    unconfirmed claim — fresh `--no-wait`, timeout, rejected — never wires;
    note a `--no-wait` re-run that RESUMES an already-claimed identity exits
    through the server-confirmed D check and does wire): wire MCP server
    `vclaw` into present hosts — see §5.

## 3. Files written (and their modes)

| Path | Mode | Written by / when |
|---|---|---|
| `~/.npmrc` | kept | step 1 (append only when the `@jsr:registry` line is absent) |
| `~/.config/vclaw/config.json` | — | runtime choice (only when a runtime was requested AND installed) |
| `~/.vclaw/identity.json` | 0600 | steps F / D-claimed-exit (legacy informational copy, kept in sync) |
| `~/.config/vclaw/credentials.json` | 0600 | step H, non-resume paths only (canonical credential, S-form seed) |
| `~/.config/vclaw/credentials.json.bak-<ts>` | 0600 | fresh path when any credentials tier existed (holds the OLD seed; path printed) |
| `~/.config/vclaw/.pending` | 0600 | step H, every path that reaches it; cleared on claim |
| `~/.vclaw/agent.js` | 0755 | step 9 (sha256-verified bundle) |
| `~/.local/bin/vclaw-agent` | 0755 | step 9 shim (`exec bun ~/.vclaw/agent.js "$@"`) |
| `~/.pi/agent/mcp.json` | 0644 (no secrets) | §5, pi ≥ 0.99.0 present, confirmed claim |
| `~/.prime/agent/settings.json` | 0644 (no secrets) | §5, prime-agent installed/present, confirmed claim |

Read order for credentials (no auto-migration — files are never silently
copied or rewritten): `VCLAW_CREDS_DIR` → `~/.config/vclaw` →
`~/.config/vchat` → `~/.vchat`. Writes always target the canonical dir.

## 4. Security notes

- **Proof-bearing claim URL (I-17).** The claim link carries `?proof=<JWT>`
  signed by the agent seed over the server's challenge; vgate refuses an
  approve without it. The URL is a **bearer capability** for the record's
  lifetime (~500+ chars) — printed once, never truncated, never reprinted by
  poll ticks.
- **Seed handling.** The S-form seed lives only in `credentials.json`
  (0600 + chmod-after-write) and the backup copy (0600). It is **never
  printed** — stdout carries at most a 24-char public-key prefix and the
  U-form prefix in the summary. Both round-trip checks run BEFORE the
  credentials write; a failure writes nothing. Credentials are never
  silently rewritten: overwrite only via `--force` (which backs up first).
- **`~/.vclaw/identity.json` holds the hex seed** (legacy shape, 0600). It is
  kept for compatibility and rewritten to agree with the canonical identity;
  treat it as secret as the credentials file.
- **`.pending` holds the U-form PUBLIC key** — not a secret, but its presence
  gates `vclaw-agent onboard` (resume vs discard).
- **stdio-only MCP.** The wired MCP server is stdio (`<bun> ~/.vclaw/agent.js
  mcp`); no listener, no port, no HTTP/SSE in v1 (the proof JWT stays
  on-host).

## 5. Host wiring (MCP), wave 2

After a CONFIRMED claim the pipe makes the identity immediately usable from
the agent hosts actually present on the machine, by wiring MCP server
`vclaw` = the bundled CLI's `mcp` subcommand (the four tools:
`vclaw_identity_status`, `vclaw_onboard_start`, `vclaw_onboard_poll`,
`vclaw_health` — see `agent-sdk/src/mcp/`):

| Host | File | Gate | Entry |
|---|---|---|---|
| pi.dev | `~/.pi/agent/mcp.json` | `pi` on PATH AND `pi --version` ≥ **0.99.0** (bare-semver contract; older pi gets ONE upgrade hint, nothing written) | `{"mcpServers":{"vclaw":{"command":"<abs bun>","args":["<HOME>/.vclaw/agent.js","mcp"],"description":"vclaw IDP identity + onboarding tools","exposure":"deferred"}}}` |
| prime-agent | `~/.prime/agent/settings.json` | the pipe installed prime-agent this run OR `prime-agent` on PATH | `{"mcpServers":{"vclaw":{"type":"stdio","command":"<abs bun>","args":["<HOME>/.vclaw/agent.js","mcp"],"startupTimeoutMs":10000}}}` |

- Both entries are **absolute-path stdio** (`~` would never expand —
  prime-agent executes stdio args without a shell).
- `exposure` is `"deferred"` (NOT `"codemode"`): pi's `autoEnableCodemode`
  defaults TRUE, so a codemode-exposure server would auto-activate codemode;
  deferred gives on-demand `tool_search` loading with no side effect.
- Writes are **read-modify-write merges**: only `mcpServers.vclaw` is
  added/replaced, other keys and key order survive; the write is SKIPPED when
  the existing entry already equals the target (key-sorted compare), so a
  re-run leaves the file byte-identical. An unparseable/wrong-shape file is
  left untouched with a warning.
- Timing: an **unconfirmed claim never wires** — the fresh `--no-wait` path
  returns before the wiring call, and the timeout/rejected exits never reach
  it. A `--no-wait` re-run that RESUMES an already-claimed identity exits
  through the server-confirmed status check and does wire (host-wiring
  report §2 delta 3).
- Files are written 2-space JSON + trailing newline, default 0644 (no
  secrets in MCP configs). Wiring is non-fatal: a failure warns and never
  fails a claimed onboarding; `~/.vclaw/agent.js` must exist (no bundle →
  no wiring — a dead entry is worse than none).
- The claimed-summary block prints one line per wired host, e.g.
  `MCP:       ~/.pi/agent/mcp.json  (server "vclaw")`.
- Landed 2026-10-02 (wave-2 `host-wiring` lane; gates + deltas in its REPORT).

## 6. Failure / resume matrix

| Situation at run start / during | Pipe behavior | Exit | What persists | Re-run does |
|---|---|---|---|---|
| Fresh host | FRESH: introduce + credentials + `.pending` + claim URL | 0 (with wait: after claim) | credentials.json, identity.json, `.pending` | — |
| Claim approved during wait | summary block, `.pending` cleared, host wiring | 0 | everything + wired hosts | RESUME → status-first exit 0, NO new introduce |
| `--no-wait` | link printed, resume hint | 0 | credentials.json, identity.json, `.pending` | same command RESUMES the same identity |
| 5-min wait times out | identity-persists block (link valid 15 min) | 1 | credentials.json, identity.json, `.pending` | same command resumes; introduce is idempotent (F1) |
| Re-run with claimed creds | status-first (D): summary, NO introduce, NO proof, NO URL; wires hosts (server-confirmed claim — also under `--no-wait`) | 0 | `.pending` cleared, identity.json agrees, host configs wired | — |
| Re-run with pending creds | RESUME: re-introduce same key → `resumed` surfaced, fresh link | 0/1 as above | same identity | — |
| Legacy `~/.vclaw/identity.json` only | ADOPT its seed; same-key introduce | 0/1 as above | + credentials.json created | — |
| Legacy identity seed/pub mismatch | loud WHY line; introduce the SEED-DERIVED pub; identity.json rewritten to it; never mints fresh | 0/1 | both files agree going forward | — |
| Claim REJECTED | loud block + retry_after; local files kept, nothing rewritten | 1 | everything | re-introduce accepted after the retry window |
| `--force` with existing creds | backup `credentials.json.bak-<ts>` (0600, OLD seed, path printed), fresh keypair, new introduce | 0/1 | backup + new identity | normal resume semantics |
| vgate unreachable at D | falls through to introduce, which fails loudly | 1 | identity resolution only (nothing written before F) | same command resumes |
| Server returns no `approve_challenge` | LOUD "unprovable record" warning; link still printed but marked dead | 0/1 | identity.json, credentials.json | operator backfills nonce / re-introduces, then re-run |

## 7. E2E

Hermetic dry-run (mock vgate, fake `HOME`, `VCLAW_RUNTIME=none`) and the
clean-host SOP live in `agent-sdk/E2E_tests.md` (funnel rows: §5 T6).
Evidence register: `.prime/handoff/docs-e2e/REPORT.md`.
