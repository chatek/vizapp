# PEARS P2P MIGRATION PLAN — agent-sdk (Tier P: same-owner A2A)

> **STATUS: EXECUTING — M1–M3 LANDED** *(2026-10-25 audit: this header read "PLAN ONLY — NO CODE, PENDING
> OPERATOR REVIEW (2026-10-23)" and was stale. Landed since: M1 the seam `43b58b5`, M2 the sidecar `b832f80`,
> M3 artifacts `9475287` — all at agent-sdk HEAD. M4 stays GATED: the a2a-meter that gates it is COMMITTED
> (`6e327808`, parent repo) but UNDEPLOYED (`deploy/a2a-meter/README.md`: nothing installed), and
> `A2A/pears-assessment/PEARS-SPRINT-STRATEGY.md` §M4 upgraded the gate to the prerequisite chain (rows live,
> standing presence, meter deployed+showing flow). M3.5 — the MCP-fleet retarget — lives in the strategy doc;
> the convergence decision deleted its per-host node-helper prerequisite (Electron main IS Node:
> `A2A/convergence-sprint/SYNTHESIS.md` §1.3).* Authority:
> [`docs/PEARS_SAME_OWNER_A2A_MANDATE.md`](../../docs/PEARS_SAME_OWNER_A2A_MANDATE.md) (V3.2 canon
> amendment — same-owner A2A → P2P; NATS `a2a.>` = governed cross-owner only). Evidence:
> [`A2A/pears-assessment/`](../../A2A/pears-assessment/README.md) (esp. `A2A-SURFACE.md` for the
> code facts this plan anchors to, `CAP-BRIDGE.md` for the capability model).
> **This plan is reviewed before the first line of code**; each milestone is then reviewed on its own.

## 0 · Goal, in one paragraph

Give agent-sdk a **Tier P** transport — P2P (Hyperswarm + Corestore + Hyperblobs, Autobase later) —
that carries **same-owner** A2A traffic (agents + their human as peers of ONE `vchat_delegations`
row) without the vclaw IDP NATS fabric, while **Tier L** (same-host socket), **Tier W** (the hub) and
every governed path (cross-owner `a2a.>`, H2A, policy, wallet, announcements) keep working
**unchanged**. The routing decision is made by the existing, currently-unwired `DeptRouteTable`.

## 1 · What exists today (measured, `A2A-SURFACE.md`)

*(2026-10-25 audit: this snapshot predates M1–M3 — the seam now EXISTS (`src/net/transport.ts`, `43b58b5`),
`src/net/p2p/` exists (`b832f80`, `9475287`), and `DeptRouteTable` was RETIRED by sdk-review Batch B
(`c619b84`, rider) with the precedence contract preserved in `M1-SEAM-DESIGN.md` §10. Read as history.)*

- **NATS is inline in every `net/*` module** (`src/net/{a2a,h2a,presence,session,directory,fabric,
  roster,conversation,reply,retire,heartbeat,identity,capabilities,connect}.ts`) — no transport
  seam exists today; only the protocol core abstracts the envelope. **This is the main cost of the
  migration: the seam, not the P2P library.**
- `DeptRouteTable` (`src/daemon/dept-transport.ts:109-156`) is a **STUB**: `DeptPlane = "socket" |
  "bus" | "mailbox"` with `route()` defaulting to `mailbox`; **no live bus** at this checkpoint. It
  is exactly the seam Tier P needs — it was built for a department bus, and the mandate adds a fourth
  plane.
- **Same-owner is not separated** on the wire: the `tenant.<seg>.a2a.>` grant is segment-wide; the
  only same-owner planes are `family.*` under the owner nkey, riding **Tier W** (the hub). Tier L
  (same-host socket) exists inside the daemon.
- **No cross-host file exchange exists at all**: attachments are inline JSON against the hub's 8 MB
  `max_payload`; no chunking, no object store.
- Agent identity: Ed25519 **NKey** seed; vgate-minted NATS JWT (1 h) presented via `jwtAuthenticator`
  (`src/agent/lifecycle.ts`). The NKey is the root identity the P2P tier will derive from.

## 2 · Target shape

```
src/net/p2p/            NEW module family (P2P thin adapter; no NATS imports)
  identity.ts           derive subkeys: HKDF(root NKey seed) -> {peerKey, contentKeyBase}
  topic.ts              delegation id -> 32-byte swarm topic (+ discoveryKey note)
  swarm.ts              Hyperswarm join/leave, connection lifecycle, reconnect policy
  store.ts              Corestore owner-process (exclusive FS lock; one owner per dir)
  blobs.ts              Hyperblobs/drive put/get, range reads (artifacts)
  workspace.ts          (M5) Autobase + Hyperbee view; indexer role = human device
  envelope.ts           the A2A envelope over the P2P wire (reuse protocol-core shape)

src/daemon/dept-transport.ts   DeptPlane gains "p2p"; route(): socket -> p2p -> bus -> mailbox
src/net/a2a.ts                 behind the seam: same public API, transport chosen by route()
```

**Non-negotiable ordering rule:** the seam lands and is proven **with zero behavior change** before
any P2P library is imported. If M1 cannot be made behavior-neutral, the plan stops there.

## 3 · Milestones (each = a review gate)

*Folding M0's results (v1.3): PASS, kill criteria not hit; runtime split forced (node sidecar);
discovery posture hardened; Q5 semantics specified; raw-NAT traversal UNMEASURED (M0 caveat C2) —
multi-device fleets beyond shared LAN/tailnet get a follow-up measurement before M4 relies on it.*

### M0 — the spike (THROWAWAY, ~2–3 days, no agent-sdk code)
A sandbox (not the SDK tree) that answers the questions the plan cannot:
**(a)** holepunch success between two estate hosts, including one behind NAT (measure attempts, not
vibes); **(b)** latency p50/p95 of a P2P round-trip vs the NATS baseline on the same pair of hosts;
**(c)** CPU/RSS per agent process with a Corestore open; **(d)** does the dependency set install and
run under **bun** (agent-sdk's package manager) on macOS + Linux; **(e)** the membership negative
test — a non-member peer that has the base key but NOT the encryption key cannot read content;
**(f)** restart/resume: does a restarted agent rejoin and catch up without replaying everything.
**Kill criteria:** holepunch unusable on our host pairs AND no acceptable relay shape, or bun/Linux
incompatibility with no workaround. The spike's artefacts (numbers, logs) become an appendix; its
CODE is thrown away — nothing from it merges.

### M1 — the seam + tier routing (no P2P code) — **LANDED `43b58b5`**

*(2026-10-25 audit: landed; Batch B (`c619b84`) later retired `DeptRouteTable` per the sign-off riders —
the class AND M1's dept-route-p2p test went together; the seam itself survives and M2's loopback rides it.)*
- **Scope:** introduce a transport interface inside `net/` that `a2a.ts` calls instead of NATS
  directly; wire `DeptRouteTable` with a fourth plane `"p2p"` (defaulting off); all existing planes
  behave exactly as before.
- **Files (v1.2, corrected by the M1 design pass):** NEW `src/net/transport.ts` (the seam
  interface — measured surface is exactly THREE operations: `publish(subject, bytes)`,
  `subscribe(subject, cb)`, `unsubscribe`; **no request/flush/drain/JetStream call sites exist**);
  `src/net/a2a.ts` (the four measured call sites, signatures frozen); `src/daemon/dept-transport.ts`
  (add the `"p2p"` plane, default off). **`src/daemon/serve.ts` is UNTOUCHED in M1** — the design
  pass measured ZERO references: the family dir does NOT feed `DeptRouteTable` today (the stub's
  own comment `dept-transport.ts:117-121` describes intent, not wiring); feeding it becomes M4's
  job when routing actually needs fleet knowledge. Full spec:
  `A2A/pears-assessment/M1-SEAM-DESIGN.md`.
- **Gates:** existing test suite green with **no assertion changes**; a routing test table proving
  `socket→p2p→bus→mailbox` order with the p2p plane disabled; no new runtime dependency.
- **Rollback:** delete the interface; behavior was identical.

### M2 — `net/p2p` skeleton: identity + topic + swarm + store — **as a NODE SIDECAR (v1.3, forced by M0)** — **LANDED `b832f80` (2026-10-25 audit)**

*Scope correction (v1.4, from the sdk-review sign-off): Tier P serves **a2a wire operations ONLY**
(publish/subscribe over the seam). Roster and capabilities are JetStream KV **services** and STAY on
Tier W — the fabric is their owner, and the P2P plane never grows KV semantics.*
- **Runtime split (M0 Q4):** bun 1.4.x cannot run the dep set on ANY tested OS (rocksdb-native +
  hyperswarm libuv panics; bun #18546), while node 22.22.x is verified on both. The P2P plane
  therefore runs as a **node owner-process sidecar** the bun daemon spawns and talks to over IPC —
  the shape Corestore's exclusive lock already pointed at. `q4-isolate2.js` (kept in the M0
  artefacts) is the bun-release re-test probe: if a future bun runs it, the sidecar can collapse
  back in-process.
- **Scope:** key derivation from the NKey seed (Q7 confirmed foreign ed25519 at every surface);
  topic from the delegation id; Hyperswarm join/leave with **persistent peer keys + `joinPeer` —
  never DHT-dependent loopback** (M0: discovery is the weak layer; same-machine fleets connect
  directly/Tier L); Corestore owned by the sidecar; loopback integration test (two agents, one
  delegation).
- **Deps (pinned exactly, reuse the pass lane's vendored org review):** `hyperswarm`, `corestore`,
  `hypercore`. Pins/provenance: `pass/PEARS_M1.md` §vendored + `A2A/pears-assessment/PASS-ORG-REVIEW.md`.
- **Gates:** derivation deterministic and per-fabric distinct; two row-peers connect; **the Q5
  gate in M0's exact language** — a non-member (base key, no encryption key) gets (a) zero
  plaintext bytes at any position, (b) NO error (silent garbage is the failure mode), (c) length
  metadata IS disclosed — so app-layer content digests are mandatory; Corestore lock enforced.
- **Rollback:** plane remains off; nothing routes to it.

*Also folded from M0:* connect-time budget is seconds fresh (~21 s median) / sub-250 ms resumed —
M4's envelope layer carries the reconnect policy + Tier W fallback (already planned); resume cost
is ~0.06 % of full transfer after hard kills (Q6).

### M3 — artifacts (the wedge; the capability that does not exist) — **LANDED `9475287` (2026-10-25 audit)**
- **Scope:** put/get files over Hyperblobs per delegation; the A2A surface gains a **file verb** whose
  payload is `{delegation, baseKey, blobRef, size, sha256}` — the BYTES never touch the hub. Tier W
  carries only the announcement.
- **Gates:** a **20 MB+ artifact across two hosts, one delegation** (the size that fails today against
  the 8 MB cap); receiver-side sha256 match; no hub bytes for the payload (measured at the gateway);
  range reads work (video-style).
- **Rollback:** verb refuses when the plane is off; hub path unchanged.

### M4 — same-owner messaging on Tier P, hub fallback — **GATED (v1.4)**
*Gate: proceeds only when the hub subject-volume exporter (sign-off Batch C) shows same-owner
traffic worth the tier, OR a concrete product driver names one. Until then M2+M3 ship as the
capability fill and Tier W carries messages as today.*
*(2026-10-25 audit: the exporter now EXISTS AS CODE — the a2a-meter, `6e327808` (sign-off Batch C2),
12 tests — but is UNDEPLOYED (`deploy/a2a-meter/`: nothing installed, operator-gated install order), so
the gate still cannot answer. `PEARS-SPRINT-STRATEGY.md` §M4 UPGRADED this gate to a prerequisite chain:
(a) delegation rows live (vpay undeployed ⇒ zero rows, F5), (b) some standing-presence mode runs, (c) the
meter deployed AND showing flow.)*
- **Scope:** route same-owner A2A messages over the P2P envelope when the peer is reachable;
  fall back to `family.*` Tier W when not (unreachable, holepunch failure, no relay). Measured
  negotiation, not assumption.
- **Gates:** same-owner message round-trip over Tier P (hub byte count = 0 for the payload);
  forced-unreachable test falls back to Tier W and the message still arrives; governed `a2a.>` path
  untouched (its tests unchanged).
- **Rollback:** config flag pins the fleet to Tier W (no code change needed at runtime).

### M5 — shared workspaces (Autobase) — **ON-DEMAND (v1.4)**
*Returns when two fleets ask for shared workspaces; not scheduled otherwise.*
- **Scope:** per-delegation Autobase (task board / transcript) with a Hyperbee view; **the human's
  device runs the indexer**; agents are writers.
- **Gates:** two agents + the device converge after offline edits (causal re-linearization); the IDP
  holds no content key (negative test: the estate cannot read the base); writer revocation appears
  on-log; a leaked key test = group rotation procedure documented and rehearsed.
- **Rollback:** workspace feature off; messages unaffected.

### M6 — optional: typed seam (`hrpc-c`)
Only if a non-JS participant (the gateway) must join Tier P natively. `hrpc-c` shipped
(`CAP-BRIDGE.md`); no Go generator exists. Default: **not now**.

## 4 · The capability mint (who hands out what), and rotation in detail

**Membership:** the delegation row (the console writes it). One row = one content group. **Two
scopes, kept distinct:** the row is the CONTENT scope (what may be read together — per task); the
FLEET (the human + their device fleet) is only a DISCOVERY scope for device pairing, derived as the
union of the human's rows and carrying no content. A human with two tasks gets two groups and two
bases; device pairing never merges them.

**Bases per content class:** one base per (delegation, class) — artifacts and workspace are SEPARATE
bases, so rotating or discarding one never touches the other. Recommendation: start with artifacts
only; add the workspace base at M5.

**Distribution is SEALED, so the IDP can distribute without reading.** The console mints the
`encryptionKey`, derives each peer's X25519 key from its Ed25519 nkey (the standard conversion), and
stores one **sealed blob per peer** (key sealed to that peer). An agent fetches its own blob, unseals
with its derived key, and joins. The estate holds sealed blobs it cannot open — distribution without
disclosure. (This replaces the earlier "stores the bundle" line, which was too loose.)

**Rotation runbook (group rotation is the only revocation):**
- **Triggers:** member removed · agent decommissioned · device lost · key suspected leaked · task
  complete and its content must stop flowing. NOT triggered by: a cap change, a tier preference, a
  gateway restart.
- **Steps:** (1) console writes a NEW row (new group id) and mints a NEW base + encryptionKey;
  (2) sealed blobs go to the retained peers only; (3) vgate revokes the removed agent's NATS grants
  (governed + Tier W) immediately — that happens now, not at rotation; (4) a NATS announcement tells
  live agents the group id changed (Tier W carries the control message; content never returns to it);
  (5) agents join the new base and abandon the old one for new writes.
- **Forward-only, stated:** rotation does NOT rescind what a removed member already replicated. Their
  copies remain readable; the estate cannot un-share. Rotation bounds FUTURE content, not past
  content — that is the honest limit of every key-based scheme and must be in the mandate.
- **In-flight:** the old base stays readable to retained peers for grace (read-only); new writes go
  only to the new base.
- **Rehearsal:** a rotation drill on the M2 fixture before M4 lands (test, not prose).

## 5 · Risks (each with the mitigation this plan commits to)

| risk | mitigation |
|---|---|
| npm supply chain (new deps in agent-sdk) | **see §5a** — pins, licence gate, sealed provenance |
| Corestore exclusive FS lock | one owner process per agent (the daemon already is one); a lock failure is a loud start error |
| holepunch failure (both-side random NAT) | Tier W fallback is the design, not a patch; a user-side relay is an operational option, **never required for same-machine fleets** |
| IP exposure | same-owner scope only; same-machine = no network; multi-host fleets may use a private DHT bootstrap list |
| the stubbed `DeptRouteTable` has an intended contract we don't know | read its history + `DEPT_BUS_SUPERVISOR.md` before wiring (M1 first task) |
| plan drift vs the pass lane's Pears program | this plan touches **libraries only**; the platform tier is theirs; pins are shared, not duplicated |

### 5a · Supply-chain posture (what M2 must satisfy)

Measured 2026-10-23: the parent already carries **15 holepunchto submodules pinned in `.gitmodules`**
(the pass lane's vendoring); agent-sdk builds with **bun** (`bun.lock`); the pass lane's org review
(`.prime/handoff/pears-pass-sprint/org-review.md`, **untracked — should be moved alongside the A2A
dossier under the same durable-artefact rule**) lists licences: hypercore/hyperswarm/hyperdht/
hyperbee/sodium-native **MIT**, hyperdrive/bare/pear/blind-peer/blind-relay **Apache-2.0**, and
**corestore reported NONE by GitHub detection — correction: its `package.json` declares
`"license": "MIT"`; the repo simply ships no LICENSE file.** Record the correction; a licence gate
that trusts the API would have failed a permitted dependency.

M2 must therefore: commit exact versions in `bun.lock` and install `--frozen-lockfile` in CI; pin
sources (reuse the pass-lane submodules for reading/patching — not the build input); run a licence
gate against **package.json** fields + a manual check of the two Apache-2.0 modules' NOTICE
obligations; review postinstall scripts and native prebuilds (`sodium-native`); and record provenance
(verified holepunchto org) in a tracked file, not `.prime/`.

## 5b · Runtime provisioning (bun funnel × node P2P — reconciled, v1.4)

Measured facts: the join funnel carries **bun** (`join.ts | bun -`; agent-sdk ships `bun.lock`);
M0 proved bun 1.4.x **cannot host the P2P dep set** (bun #18546) while node 22.22.x is verified on
both platforms; and a **node shim already execs bun on nodeless hosts** (F4's miss) — prior art for
graceful runtime substitution.

The rule: **Tier P is OPTIONAL BY CONSTRUCTION.**
1. The agent daemon (bun) spawns the P2P owner-process as a **node sidecar** when a node runtime is
   present, and the seam routes same-owner a2a wire ops to it.
2. When node is absent, the sidecar does not start, the `p2p` plane reports unavailable, and the
   seam **degrades automatically to Tier W** — the mandate's fallback is the default, not an error
   path. An agent without node is a fully functional Tier W agent.
3. The join pipe grows one **detect-and-skip** step: probe for node at install; present ⇒ install
   the sidecar bundle; absent ⇒ skip silently and note it in the install log. No bundling of node,
   no hard prerequisite, no second funnel.
4. `q4-isolate2.js` (kept from M0) re-tests bun on every release; if bun ever closes #18546, the
   sidecar collapses back in-process and this section retires.

## 6 · Explicit non-goals

- No changes to governed A2A, H2A, policy, wallet, announcements, retire control.
- No second identity system (no Keet identities); the NKey root + derivations only.
- No Pears **platform** adoption here (no OTA, no worklets) — that is the pass lane.
- No change to VClawBuzz or its media path (a separate assessment).
- **No code before operator review of this plan.**

## 7 · Review checklist for the operator

1. Is the **Tier P scope** exactly "peers of one delegation row" for CONTENT, with the fleet used only
   for discovery? (§4 — the row is the content scope; the fleet is the device-pairing scope.)
2. Is **group-rotation revocation** acceptable for same-owner content, given the no-re-key finding?
3. Is **M0 (throwaway spike) → M1 (zero-change seam)** the right order? (The spike buys measured
   answers to the unknowns; the seam buys integration safety. Neither substitutes for the other.)
4. Is the **artifact wedge (M3)** the right first user-visible capability, or should messaging (M4)
   come first?
5. Are the **dependency pins** (reuse of the pass lane's vendored org review) the right supply-chain
   posture for agent-sdk?
