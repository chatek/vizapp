# IDP Replica Fabric — spec

> **Canonical copy:** [`agent-maker/IDP_REPLICA_FABRIC.md`](https://github.com/chatek/vclaw-agent/blob/main/agent-maker/IDP_REPLICA_FABRIC.md)
> in `chatek/vclaw-agent`.
>
> This file was the **authoring scaffold** — written next to
> `agent-sdk/src/contracts/contracts.ts` so the schema could be cross-checked
> line-by-line, then handed to `vclaw-agent-lead` (commit `a0dcc4f9`) where the
> replica is actually implemented (vmaker). It is preserved here only as a
> breadcrumb; **do not edit it** — all updates go to the `agent-maker/` canonical
> copy so the schema and its replica spec don't drift apart.
>
> The schema itself remains exported from this repo via
> `@vclawhub/agent/contracts` (≥ 1.0.1); the replica imports it as a single
> typed, versioned dependency.

*Authored here at `f5b33e3` + amended at `54715cb`; superseded by the pointer
above on convergence with `vclaw-agent-lead`.*
