# Commit/Merge Policy — multi-agent builds (v9 + later)

> Applies to agent-sdk waves built by `plans` (coordinator) + `sprint1`/`sprint2`
> (workers). Approved by operator 2026-09-04 (draft presented in session; adopted
> with coordinator recommendations). Amend only via operator.

## Context this policy is built for
- One shared working tree (`agent-sdk/` submodule), 3 agent sessions, 1 operator,
  remote = `git@github.com:chatek/agent-sdk.git`.
- Single-tree reality: parallel branches in one checkout would carry another
  agent's uncommitted WIP across branch switches — wave work stays on `main`
  locally; branches return only if/when per-agent worktrees are introduced.

## Rules
1. **Workers never run git.** Create/edit files only. No add/commit/checkout/
   rebase/delete/rename. Proven in cp1; keeps the collision class at zero.
2. **`plans` is the only local committer.** Commits are wave-sized, staged BY
   PATH (never `git add -A`), never including another agent's uncommitted files.
3. **Gates before every commit:** `bunx tsc --noEmit` exit 0 AND `bun run test`
   all green on the full tree.
4. **Transient red tolerated mid-wave, never at checkpoint.** Coordinator commits
   promptly when a wave declares done; long-lived red tree = wave blocker,
   coordinator pings the owner.
5. **Linear history, no merge commits.** `git pull --rebase origin main` before
   pushing; conflicts resolved conservatively (upstream semantics win; ambiguity
   -> ask operator, never silent discard).
6. **Push = operator-triggered**, at milestone ends (not per checkpoint).
7. **Operator-only actions:** publish (jsr), tags/releases, force-push, reverting
   a pushed commit.
8. **Emergency rollback (local):** coordinator may `git revert` an unpushed
   checkpoint; affected workers notified via steer.
9. **Commit message template:** `feat|fix|docs(v9): <wave> — <what>`; body lists
   files + verify line (e.g. `tsc 0 · 466/466`).
10. **Heavy typegen/gate runs are serialized by the coordinator** (off-peak, one
    at a time). Workers run only their own scoped vitest files mid-wave.
11. **Worktrees trigger:** when a wave needs 2+ agents in OVERLAPPING paths, the
    coordinator moves that wave to per-agent worktrees (+ symlinked `.prime`)
    before dispatch.
12. **Review:** coordinator reviews every checkpoint diff before commit; operator
    gets a human pass at milestone ends.

## Commit shape (cp1 precedent)
- One wave = 1 commit; occasionally 2 when a regen is genuinely separable
  (e.g. `e01f0c9` schema-types).
- Changelog: `CHANGELOG.md` updated per milestone push.
