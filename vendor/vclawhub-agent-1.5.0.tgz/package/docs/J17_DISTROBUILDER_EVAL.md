# J17 — `distrobuilder` desk evaluation + timed-run procedure (CLEAN-path candidate)

> **Status: EVALUATION + PROCEDURE, 2026-09-16 · lane `vchat-email-dc9818` · desk-only.**
> The job (`RUNTIME_incus.md` §5 J17): *"distrobuilder evaluation in a builder container on
> ct17 (install + one timed trixie build) — or a documented rejection of it as the clean
> path"*, acceptance *"a measured build time on THIS fleet; never a vendor figure"*.
> §8.1 ruled distrobuilder out as the **routine** path; §8.3 made the scripted bake the
> CLEAN path and deferred distrobuilder to this evaluation. Nothing here executes against
> ct17 — the timed step is operator-gated (`--execute-timed-build`, §3).
>
> Finding IDs: this document uses **D1, D2, …** — the F1–F10 namespace belongs to
> `AGENT_RETIRE_ADVERSARIAL_REVIEW.md` and stays frozen.

---

## 0. Verdict (desk half — the timed half is deliberately blank)

**distrobuilder is worth the timed run, and the motivation is provenance, not speed.**
The CLEAN path's weak link today is the *base image it starts from*: §8.3 says "from a
cloud-capable trixie base", but the base that actually exists — and the one the P1 bake
launched from — is `debian-trixie-pi-agent`, a **July 20 prototype local image** that is
past its `Expires 2026/08/18` stamp, carries pi.dev `pi` 0.80.10, ships the July
prototype's `NATS_URL` artifacts (`/etc/profile.d/pi-agent.sh`, `pi-auto.service`,
cached cloud-init user-data), and has leftover build residue (`RUNTIME_incus.md` §1.2
[O]; `D-incus-P1-bake.md` T5 + open items 4–7). The P1 bake spent two full script stages
(4b, 4c) purging that residue. Every future CLEAN bake inherits this tax.

A distrobuilder build replaces the base's *provenance*: an **in-repo definition +
pinned Debian mirror → pristine trixie + cloud-init + nothing else** — no prototype
residue to purge, no expiry repin, no opaque third-party layer. The price: new tooling
on the fleet and an unmeasured build time. Whether that trade wins is exactly what the
timed run (§3) decides — **the number comes from ct17 or it does not exist.**

## 1. The three CLEAN-path candidates

| | **A. scripted bake from public `images:debian/trixie/cloud`** | **B. distrobuilder base + scripted bake (the J17 candidate)** | **C. status quo — bake from `debian-trixie-pi-agent`** |
|---|---|---|---|
| base provenance | third-party build (linuxcontainers.org), maintained, opaque | **in-repo definition + Debian mirror**, self-built | expired July prototype, hand-built, residue-laden |
| expiry cycle | remote images expire → repin (the doc's own open item) | **none — rebuild on demand** | already expired (open item 4, P1) |
| known cruft | unknown until grepped (the P1 gate list applies) | **none by construction**; gates still run | pi 0.80.10, NATS_URL ×3 locations, build residue (measured) |
| bake-script fit | ⚠ **python3 gap — D1 below** | same D1 (handled by the probe, §3 step 6) | fits today (base already has python3 et al.) |
| new tooling on fleet | none | distrobuilder + debootstrap + squashfs-tools **inside a throwaway builder container only** | none |
| wall time (ct17) | = today's ≈ 0.9 s launch + 67 s bake + ~1 s stop + 1 m 50 s publish | **T_base = the J17 measurement** + same downstream chain | ≈ 4 min, measured |
| failure blast radius | a bad remote refresh changes the base under you | a bad definition change is a reviewable diff | the prototype silently rots further |

**Measured baseline (all ct17, `RUNTIME_incus.md` §1.5/§7, `D-incus-P1-bake.md`):**
launch **0.885 s** · J3 bake **67 s** (apt→gates) · publish **1 m 50 s → 684 MiB** ·
P1 image **797.13 MiB packed** (base 682.33 + 114.80 delta) · stop `-f` **0.9 s**.

**Recommended decision rule (operator's call, proposes a new §6 row):** judge B on
*provenance and reproducibility first, time second*. The CLEAN path runs only on
base-OS/toolchain changes — wall time is nearly irrelevant at that frequency, and even
a 2–3× slower base build would be acceptable if the definition kills the expired-
prototype/cruft-purge class permanently. A vendor-quoted "typical build time" is
**inadmissible** — the same vantage rule that falsified §8.2's "sub-5 seconds" claim.

## 2. Desk findings

### D1 — the bake script silently requires python3, which no pristine minimal base has
`assets/bake.sh` step 4 parses `latest.json` with a **python3 heredoc**. The July base
happens to carry python3; a pristine trixie cloud base may not. The probe handles this
explicitly: pre-bake gate `command -v python3`, and if absent, a **visible, recorded**
`apt-get install -y python3` inside the test container *before* bake.sh is pushed —
bake.sh itself stays unmodified (J17 is surgical; the pin `WANT_PRIME_VER=0.9.4` and
all six trap-guards stay as landed).

### D2 — bake stages 4b/4c become no-op hygiene on a pristine base — keep them anyway
The purge of `pi-auto.service` / `pi-agent.sh` / cached cloud-init state is exactly
what a distrobuilder base makes unnecessary — and exactly what must **stay** in
bake.sh: the steps are `|| true`-guarded (no-op safe), and they are the standing
defense if any future base regresses to shipping artifacts. J17 modifies nothing.

### D3 — builder privileges: verify at run, don't assume from memory
distrobuilder configures a chroot and installs packages (debootstrap path), which needs
mount/namespace privileges. J17's own wording puts it "in a builder container": the
probe uses a **privileged throwaway container** (`security.privileged=true`,
`vcx-j17-builder`) — no incus daemon inside, output files pulled to the host for
`incus image import`. Whether an unprivileged mode suffices on this incus build is a
run-time check (`distrobuilder --help` at preflight), recorded in the result JSON —
this evaluation does not assert it from memory.

### D4 — the upstream-definition anchor beats a hand-written one
The probe does **not** invent a definition: it fetches upstream `debian.yaml` pinned to
the installed distrobuilder release tag, then applies minimal `-o` overrides
(`image.release=trixie`, `image.variant=cloud`, container target) and hashes the
composed definition into the run log. `assets/distrobuilder/trixie-cloud.yml` records
the intended overrides; it is not executed directly. Rationale: upstream carries the
cloud-init generator/file set that makes the image actually behave like a cloud image —
the piece most likely to be wrong if hand-written from memory.

### D5 — the cloud variant is not optional (confirms the skill's own finding)
`SKILL.md` CLEAN: "plain trixie is a dead end, §2" — non-cloud trixie has no
cloud-init, so the `vclaw-agent` profile's per-link DNS never applies. The probe
enforces the cloud variant upstream (D4) and gates the outcome empirically:
`getent hosts vchat3` + TCP `vchat3:4223` must succeed, exactly as P1's gates did.

### D6 — scope fence: containers only, aliases untouched
`--type container` only (the runtime is containers; a VM variant additionally needs the
incus agent + kernel packages — out of scope, recorded). All artefacts are `vcx-j17-*`
throwaways; the probe may never write `vclaw-agent:*` or `:stable`/`:stable-prev` —
promotion stays the operator's ADD→FLIP→SOAK→DROP (§8.3). No `join.ts`, no `onboard`
anywhere in this probe: **J17 builds a base, not an identity** (the §3.1 invariant).

## 3. The timed-run procedure (dry-run default; step 5+ is operator-gated)

Artefact: `skills/incus-repackager/assets/j17-distrobuilder-probe.sh`. Modes:

```
j17-distrobuilder-probe.sh --plan                    # read-only: preflights + prints the exact command sequence + gates (safe anywhere)
j17-distrobuilder-probe.sh --execute-timed-build     # THE J17 RUN — operator-gated, ct17 vantage only
                     [--skip-old-base-control]       # optional: skip re-launching the July base for the detector control
```

Honest absence note (recorded, per the lead's ask): `distrobuilder` is **verified
absent on this lane** (`command -v` = empty) and its ct17 status is *unverified until
the `--plan` preflight runs there* — consistent with §8.1's "installed nowhere on this
fleet", which the plan-mode check confirms or refutes without installing anything.

Stages (each timed with `date +%s.%N` deltas; every number lands in the result JSON —
`/tmp/vcx-j17/result-<ts>.json` + stdout; **no vendor figure ever fills these slots**):

| # | stage | gate (must be able to fail) |
|---|---|---|
| 1 | preflight | `incus` present; pool free ≥ 20 GB; `deb.debian.org` + GitHub reachability (HEAD); `distrobuilder` absent-or-version printed |
| 2 | builder up | `vcx-j17-builder` (privileged, no `vclaw-agent` profile — base has no identity need) active |
| 3 | tool install | pinned-from-run distrobuilder release (version + sha256 **recorded**, pin v2 later) + `debootstrap` + `squashfs-tools`; `distrobuilder --version` printed |
| 4 | base build | upstream `debian.yaml@<tag>` + D4 overrides; **T_base stage timers: fetch / rootfs / packages / pack**; definition sha256 in log |
| 5 | import | `incus image import … --alias vcx-j17-distrobuilder-<ts>`; fingerprint recorded |
| 6 | base gates | launch `vcx-j17-base` (profile `vclaw-agent`): cloud-init status clean · `su - debian -c id -un` · **python3 gate (D1: visible apt if absent)** · DHCP+route · `getent hosts vchat3` · TCP `vchat3:4223` · **NATS_URL grep EMPTY (filenames-only output — the value never enters a log)** · **`/usr/bin/pi` ABSENT** · `systemctl is-system-running` recorded |
| 7 | bake + full chain | push `bake.sh` UNMODIFIED → run (its own gates must reach `GATE-DONE`, FATAL-free; D2 purges no-op) → STOP → `incus publish --alias vcx-j17-image-<ts>` → **T_downstream expected ≈ 67 s + 1 m 50 s ± fleet noise — measured, not assumed** |
| 8 | negative controls | (a) **mutation control**: `python3 → python3-nonexistent-xyz` in the definition → build MUST FAIL (proves the package path is enforced, not silently skipped); (b) **import control**: truncated rootfs copy → import MUST FAIL (proves the import gate reads bytes) |
| 9 | detector control | NATS_URL grep against a launch of `debian-trixie-pi-agent` MUST find the July artifacts (proves the detector on this host) — skippable via `--skip-old-base-control` because `D-incus-P1-bake.md` already holds this evidence; the skip is recorded |
| 10 | cleanup + report | delete builder/containers/imported test images (fingerprints recorded first); result JSON emitted; **no alias touched** |

## 4. Contradiction check against the canon (the lead's ask (b))

1. **Not a contradiction — a measured gap in §8.3's realization.** §8.3's CLEAN path
   says "from a cloud-capable trixie base"; the only such base on the fleet is the
   expired July prototype with baked-in prototype artifacts (§1.2, P1 T5). The doc
   already self-corrects in the P1 section; the later statement governs. J17-B is the
   structural fix for exactly this gap.
2. **Consistent:** §8.2's "a performance number is only as good as its vantage" is the
   rule this whole evaluation obeys — T_base comes from ct17 or stays blank.
3. **Consistent, sharpened:** §8.1's "installed nowhere on this fleet" is confirmed
   locally, confirmable on ct17 by the read-only plan preflight — before anything is
   installed, so the ruling's premise is checked, not assumed.
4. **No contradiction of the stateless-image invariant:** nothing in the distrobuilder
   path bakes or claims an identity; the probe never runs `join.ts`/`onboard`.

## 5. What the timed run decides (handing the operator the decision, not the answer)

After one execute run, §6 gets a new decision row with real numbers: *adopt B as the
CLEAN path (definition + probe versioned here, builder tooling confined to throwaway
containers), adopt A (public remote base, zero new tooling), or retain C.* The report
this probe emits is the entire input: stage timings, packed sizes, gate outcomes,
control flips, tool versions, definition hash. **Both negative controls must have
FAILED (as designed) and all gates gone green, or the run reports RED — a green-looking
run with skipped controls is inert-profile, and the probe is written to make that state
impossible to confuse with a pass.**
