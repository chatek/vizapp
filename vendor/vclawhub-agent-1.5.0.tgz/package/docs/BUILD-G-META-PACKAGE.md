# Meta-Package Build — ext-synadia Bundling (BUILD lane G)

> **Owner:** agent-sdk meta-package wiring · **Authority:** unified A2A fabric ruling #2 (meta-package of pi extensions) + W1 spec `01-agent-sdk-meta-package.md` §1.2/§2.1-2.3.
> **Artifacts:** `scripts/build-ext-synadia.mjs` · `scripts/build-pi-extension.mjs` · `package.json` (`pi.extensions` ×2, `build:extensions`, esbuild devDep).

## 1. The bundle pattern (verified against the tree)

The reference runtime entry `src/pi-extension/index.bundled.js` was originally generated with **`bun build --format=esm --target=node`** (documented at `test/unit/extension-variants.test.ts:6`; no build script existed — `scripts/` was empty before this lane). Its verified contract:

- **Fully self-contained for @nats-io**: all `@nats-io/*` mentions in the file are source-path comments (`index.bundled.js:35+`); nkeys + tweetnacl are inlined (the jiti getter-export seam — the un-bundled source can never connect under pi.dev, `extension-variants.test.ts:10-22`).
- **Externalizes only** `@sinclair/typebox` (pi.dev shims it) + node builtins (`extension-variants.test.ts:93`).
- **CJS interop banner**: `import { createRequire } from "node:module"` (`index.bundled.js:1`) — tweetnacl's top-level `require("crypto")` needs a real `require` in ESM output.
- **Post-build PRNG patch** (verified, `extension-variants.test.ts:37-40`): tweetnacl's `typeof self !== "undefined" ? self.crypto…` detection misses node/pi.dev; patch extends to `|| globalThis.crypto` (2 sites).

## 2. The esbuild port

`scripts/build-ext-synadia.mjs` reproduces the semantics with **esbuild** (added as a devDep; this lane is the sprint's only lockfile toucher per BRIEF-FOLLOWUP.md):

| esbuild option | value | why |
|---|---|---|
| `platform` / `format` / `target` | `node` / `esm` / `node18` | same as the bun build |
| `external` | `@earendil-works/*`, `typebox`, `@sinclair/typebox`, `node:*`, `fsevents` | pi-shimmed host deps + builtins only |
| (inlined) | `@nats-io/*` + `@vchatemail/protocol-core` | self-contained; protocol-core is an unpublished workspace sibling (`packages/ext-synadia/package.json` `workspace:*` dep) resolved through the pnpm symlink |
| `banner.js` | createRequire shim + role marker | the CJS interop seam + edit-source pointer |

**Why inlined @nats-io (correction mid-lane):** the first cut externalized `@nats-io/*` intending resolution from the meta-package root's node_modules — but `@nats-io/services` is only a dep of `packages/ext-synadia`, not the root, so the shipped `dist/` bundle failed to load (`ERR_MODULE_NOT_FOUND`). The reference bundle's answer (inline everything @nats-io) is the correct one for a published artifact.

`scripts/build-pi-extension.mjs` is the same pattern for the existing pi-extension bundle (previously manual): esbuild + the structural-regex tweetnacl PRNG patch (falls back to a warning if the minified shape ever drifts). **Note:** the bun-generated bundle remains the runtime artifact in-tree; the script reproduces it if needed (`pnpm build:extensions`).

## 3. package.json changes

```jsonc
"pi": {
  "extensions": [
    "./dist/pi-extension/index.bundled.js",   // ext-segment (cloud/IDP)
    "./dist/ext-synadia/index.bundled.js"     // ext-synadia (intranet)
  ]
}
```

- Multiple entries per package are loader-supported (`loader.ts:616-623` loops `manifest.extensions`, per W1 spec §0).
- Both entries are **shipped paths** (`files: ["bin/","dist/",…]`) — closes the §0 publishing bug (W1 spec: `pi.extensions` previously pointed at unshipped `src/`).
- `build:extensions` chains both bundle scripts; `prepublishOnly` now runs it after `tsc`.

## 4. Smoke verification (the gate)

`node --input-type=module` import of `dist/ext-synadia/index.bundled.js`:

- default export is a **function** (factory) ✓
- module load is **side-effect-free**: factory invocation registers `session_start`/`session_shutdown`/`turn_end` + the site-plane verbs (today `synadia-status`/`synadia-send`, which become `/vclaw status`/`/vclaw send` aliases per `src/vclaw/README.md` §4), no connection attempted at load (connect is deferred to `session_start` — `packages/ext-synadia/src/index.ts:88-99`) ✓
- `SYNADIA_AUTOSTART=0` keeps the session inert ✓

Gate: root `tsc --noEmit` + `vitest run` (315) green, both bundles present and loadable.
