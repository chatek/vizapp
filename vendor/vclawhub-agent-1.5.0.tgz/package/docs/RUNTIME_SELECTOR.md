# 00 — Runtime Selector + E2E Sprint: Handoff Synthesis

**Status:** closed. Everything below is committed, pushed, and pinned.
**Written:** end of the session that did the work; verified against the repo immediately before commit.
**Purpose:** the *decision layer* of this sprint. The e2e **records** are committed separately in
`agent-sdk/docs/`; what exists only here is *why* things are ordered the way they are, what is
blocked, and what each lane actually proved versus quietly discarded.

---

## 0. Bootstrap order for a new session

1. `AGENTS.md` (repo) — the behavioral entry point.
2. `~/.pi/agent/pitfall-log.md` — **newest entries first.** It is ~50k lines; read the head, not the file.
3. **This document**, then §5 (lane ledger) for what each peer proved.
4. The four e2e records, which are the *evidence* this summary is drawn from:
   - `agent-sdk/docs/E2E_RUNTIME_SPAWN.md` (222 lines, `78d0cc8`) — the resolver reaches `spawn()`.
   - `agent-sdk/docs/E2E_EFFECTIVE_SOURCE.md` (269 lines, `d749266`) — which layer won, and the `editor` regime.
   - `agent-sdk/docs/E2E_INSTALL_CHAIN.md` (238 lines, `78d0cc8`) — the installer, and F1.
   - `agent-sdk/docs/RPC_LIVE_VERIFICATION.md` (266 lines, `9e770e6`) — the RPC surface audit.
5. `.prime/handoff/prime-agent-sprint/00-SYNTHESIS.md` — the *vendor* sprint (the fork), a different thread.

---

## 1. What this sprint was

Two threads, deliberately joined:

1. **Give `@agent-sdk` a runtime selector** so a host can run `pi.dev` or `prime-agent` without
   forking the SDK, and so `vclawhub.com/join.ts` can install either.
2. **Prove it end to end** before flipping any default — because a runtime selector is exactly the
   kind of feature that passes every unit test while never being reachable in the shipped artifact.

The second thread is what earned its keep. **It found that the feature had never been committed.**

The operator's framing that mattered: the runtime selector is **not three options but three roles** —
a config field is the *noun*, `vclaw-agent runtime` is the *verb*, `join.ts` is the *initializer*,
env/flag is the *override*. One precedence chain, resolved by one function.

---

## 2. State (verified, not recalled)

```
superproject   adfb3a5   (branch: main)
  agent-sdk    pointer 2a50c98 = head 2a50c98   unpushed 0   fetchable 2 remote branches
  landing      pointer 616b80b = head 616b80b   unpushed 0   fetchable 2 remote branches

tests          agent-sdk 529 passed / landing 28 pass
typecheck      tsc --noEmit exit 0
```

Both submodules were pushed **before** every pointer commit. A gitlink to an unfetchable commit
resolves perfectly on the machine that made it and breaks every fresh clone.

**Dirty in the superproject, and NOT this sprint's work:** `landing`, `vendors/authelia`,
`vendors/chatto`, `vkey-app`, and `agent-sdk` (four grant-sync files belonging to another lane).
Leave them alone or hand them to their owner; do not "tidy" them into a pointer commit.

---

## 3. What shipped

### 3.1 The runtime selector

`src/lib/runtime.ts`. Precedence, first hit wins:

```
flag (--pi-bin)  >  VCLAW_PI_BIN  >  ~/.config/vclaw/config.json "runtime"  >  "pi" (PATH)
```

`resolveRuntime(explicit?) -> {bin, source}` where `source` is the **supplying layer**. Exposed as
`vclaw-agent runtime [value] | --unset`, which reports the effective value **and** which layer
supplied it. `VCLAW_CREDS_DIR`/config paths come from `configFilePaths()`; `readConfigSync()` is the
lazy read. Resolution is **call-time**, never a module-load binding.

### 3.2 The observability gap (§2 of `E2E_EFFECTIVE_SOURCE.md`) — fixed in `f9a15cf`

The feature was **unprintable**. The only code that printed `source` called `resolveRuntime()` with
**no argument**, and `serve` exposed **zero** `--pi-bin` flags — so `source: flag` could never be
produced by any real execution. The daemon now prints `Runtime: <bin> (source: <layer>)` in its
banner and `eval` logs the same. Verified live for all three: `pi (source: default)`,
`/opt/pretend-fork/pi (source: flag)`, `prime-agent (source: config)`.

**Generalizable rule:** a feature whose *source of truth* is unobservable cannot be verified from a
running system. Add the reporting surface with the feature, not after.

### 3.3 Hardening that fell out of the e2e

| Change | Commit | Why |
|---|---|---|
| `enforceSecretMode()` applied to `saveConfig`/`saveCredentials`/`writePendingFlag` | `5d4b338` | `writeFile`'s `mode` is **create-only**; an existing 0644 file stayed 0644. Measured, not assumed. |
| `setRuntime` **refuses** an unparseable config | `5d4b338` | It was silently *destroying* one: `{ this is not json` → `{"runtime":"pi"}`. |
| `editor` added to `MODAL_UI_METHODS` | `1a241fd` | See §4.2. |
| Truthy-only `INSTALL_PI` (both emitters) | `4822e70` | `INSTALL_PI=0` **installed pi.dev** — any non-empty value counted as "on". |
| Node fallback can persist `--runtime` | `4822e70` | It previously exited 1. Persists only when no config exists; refuses otherwise. |
| `test: EMITTED join.ts parses` | `616b80b` | The recurring-hazard gate; see §6.1. |
| Two-knob relationship documented | `2a50c98` | F3, below. |

---

## 4. The decision layer — ordered

### 4.1 ⚠️ FIRST: the fix is code-complete and **not deployed**

**This is the single most important item in this document.** At the time of the e2e pass:

```
live https://vclawhub.com/join.ts : 12,707 B, sha256[:12] 66c2c2b24450
                                    --runtime 0, INSTALL_PI 0, SKIP_PI_INSTALL 2   ← Aug-31 bytes
```

while `landing` carried 18,692 B of working-tree changes that were **never staged** (working tree
18,692 B / 6 `--runtime`; staged and HEAD both 14,166 B / 0). **A user running the documented command
today gets neither the runtime choice nor the pi.dev consent flip.**

> Those three numbers are the **e2e-time** state, and they are historical — do not re-measure the
> current tree and compare against them. As of `adfb3a5`/`landing 616b80b` the committed file is
> **19,204 B / 6 `--runtime`**, identical at HEAD, index, and working tree (i.e. the change *is*
> committed). The gap that remains is not in the repo at all:
>
> ```
> landing committed HEAD : 19,204 B
> live (deployed)        : 12,707 B   ← the deployed build predates every commit in this sprint
> ```

What remains is **operator-gated**:

```bash
cd landing && pnpm deploy          # astro build && wrangler pages deploy dist/ --project-name vchat-landing
```

**Do not freeze a byte count for the emitted script — and be careful which UNIT you measured.** I
recorded 16,323 and 17,215 for the same artifact and called it unreconcilable; the real explanation is
mundane and I got it wrong twice before landing on it:

```
JOIN_PIPE_SCRIPT.length        16,323   UTF-16 code units  <- what console.log prints
UTF-8 bytes                    17,215   what is actually served
non-ASCII code points             446   box-drawing + emoji
446 x 2 bytes each          =    892   exactly the discrepancy
```

Every non-ASCII character (box-drawing, `✅`, `🔧`, `⚠️`) costs exactly **2 more UTF-8 bytes than
UTF-16 code units** — 3-byte BMP chars count 1 unit, 4-byte astral chars count 2. So `.length` and
file size are different units of the same string, and comparing them is meaningless. (An earlier
revision of this document blamed "measurements of a moving file at different revisions". That was
wrong: the file was not moving between those two numbers. A count is only evidence if its UNIT is
what you claim — the same trap as the `wc -l` incident in §6.2.)

### 4.2 R5 — `--no-extensions` + explicit `-e` is **load-bearing**

`--no-builtin-tools` (-nbt) keeps **extensions and custom tools enabled**. Consequence: N workers
produce N fabric registrations with random nonce identities, and nothing reaps them.

Separately, and more sharply: an `editor` (or any modal UI) awaited inside a `session_start` handler
**blocks stdin entirely**. The mechanism was traced line-for-line — `session_start` is emitted at
`agent-session.js:~1926` via `await this._extensionRunner.emit(...)`, which reaches
`rpc-mode.js:289 await rebindSession()`, while the stdin reader is at `rpc-mode.js:644` — **a 355-line
gap**. The cancel R1 taught us to send has nowhere to arrive.

`--no-extensions` + explicit `-e` is the **only remedy that reaches both regimes** (the fabric
pollution *and* the modal wedge). No default runtime may flip before this is decided.

### 4.3 The `landing` twin — cost now demonstrated

`landing` serves `vclawhub.com` (deploy script: `--project-name vchat-landing`; the
`vclawhub.com → vchat-landing.pages.dev` mapping lives only in the CF dashboard).
`landing` has **no deploy script at all** — yet its `site: "https://vclawhub.com"` makes it
*look* like the server, and it **misrouted a careful verifier** during this sprint.

Note what `site:` actually is: Astro's **canonical-URL base** for absolute links and sitemaps, *not* a
deployment binding. This is a **false confirmation**, which is worse than a missing one because it
**terminates the search**. The twin is no longer a hypothetical divergence risk; it has a
demonstrated cost. **Needs an operator/fleet ruling on which repo is authoritative.**

### 4.4 The 0600 fix for the remaining credential-bearing sites

`enforceSecretMode()` exists and is exported. Four credential-bearing sites write NKey seeds or
config: `src/commands/import.ts:38`, `src/commands/onboard.ts:445`, `src/rpc/server.ts:157`,
`src/lib/llm.ts:49` (whose own comment already says *"Persist the config (0600 — it holds a
secret)"*).

**All four already pass `{ mode: 0o600 }`** — so "missing mode" is the wrong description and would
send the fix to the wrong place. The gap is narrower and nastier: `writeFile`'s `mode` applies
**only on create**, so a file that already exists keeps whatever mode it has. The fix is to stop
relying on creation semantics — call `enforceSecretMode()` after the write, which is exactly what it
was added for. Measured, not assumed: a pre-existing 0644 file stayed 0644.
And `src/daemon/paths.ts:80/:89` inherits **0644 inside 0755** — two unchosen defaults stacking. That
is acceptable *only* while the daemon is single-user; it is invalidated the moment a secret lands on
that path or the target becomes multi-user.

### 4.5 F3 — two knobs, one feature (documented, not fixed)

`VCLAW_RUNTIME` is the **installer's seed**; `VCLAW_PI_BIN` is the **resolver's override**. The names
are deliberately distinct — persisting the override variable would collapse two tiers into one. The
stated consequence: **exporting `VCLAW_RUNTIME` has no effect on an already-running daemon**; only
the config it wrote does. Second-class-fallback note: on a node-only host that already has a config,
the installer refuses to set the runtime, so the CLI is the only path.

### 4.6 Carried from the IDP hardening sprint (not this sprint's, still open)

Secret rotations, each with a specific trap: OIDC signing key (needs a **dual-key** recipe; I do the
templating) · NATS callout seed · CF token · NATS tokens (4 files) · LDAP password · `hmac_secret`
(**file-side rotation is a silent no-op** — env wins) · `.vchat.email` retire-or-restore · `users.yml`
· real end-to-end sign-in · `vclaw-app` source. Then prune the 3 `redirect_origin_unreachable`
baseline entries **when** `.vchat.email` retires — findings must disappear because the *config*
stopped registering the hosts, never because the baseline absorbed them.

---

## 5. Lane ledger — what each proved, and what it discarded

Three peer lanes plus the lead's own run. **The discarded conclusions matter as much as the kept
ones** — two lanes retracted their own findings after negative controls, which is why the survivors
are trustworthy.

| Lane | Session | Kept | **Discarded by its own controls** |
|---|---|---|---|
| **2** (installer) | `94205c` | F1 unshipped/uncommitted · F2 · F3 · F4 | **Proof 1 of F1** — `site:` read as a deploy target. Retracted and quoted in the record. |
| **3** (effective source) | `5653e0` | §2 the feature was unprintable · §3 the `editor` regime + the 355-line gap · R1 re-test | **Three** of its own conclusions. |
| **R** (RPC audit) | (earlier) | R1 the `editor` wedge · R2 `extension_error` dropped · R3 `--session-id` unvalidated · R5 | — |
| **1** (spawn) | `e23ab2` | All four precedence layers reach `spawn()` · **session-file placement VERIFIED** (real pi, credentialed HOME) · the empty `sessions/pi/` **explained, not a defect** · the `stop` contract | — |
| **Lead** | this session | config→fake-A; env-beats-config→fake-B; argv observed | **My own first run** — I set the env on the *client*, not the daemon, and produced a confident false bug report against my own resolver. The control caught it. |

**Lane 1's advance is easy to miss:** it turned R's *"session file is a planned path / creation
UNVERIFIED"* into **placement verified by direct invocation**. The daemon's empty `sessions/pi/` is
explained by the scratch `HOME` having no model credentials — the turn dies at model resolution and pi
writes no session file — pinned by contrast (same argv + credentialed `HOME` → file written).

---

## 6. Method notes — the traps that cost time this sprint

These are the transferable part. Each one cost real work and each generalizes.

### 6.1 The single-template-literal pattern (hit twice)

`JOIN_PIPE_SCRIPT` makes the **entire emitted script one template literal**. So every backtick and
`${` inside it must be escaped — **a comment is as hazardous as code.** Two distinct failure modes:

- **(a)** an unescaped backtick breaks the *literal* → the module stops parsing → the whole test file
  fails to import. Caught by tsc/the runner.
- **(b)** the literal is well-formed but **evaluates** to malformed TS (an over-escaped quote) → the
  module compiles, every source check passes, **the served artifact is broken.**

For (b), **parse the evaluated value**, never slice the source — slicing yields the *source's*
escaping (`\\"`), not the artifact's (`\"`). Gate added at `616b80b`, honestly labelled a
**directness check, not a coverage gain** (the mutation took down 23 existing tests too).

### 6.2 False confirmations terminate the search

Three instances this sprint, all the same shape: the `landing` `site:` field; a `wc -l` used
as a file count; and a normal-looking `package.json` version bump attached to a package that was
**already using the name in question**. In each case the wrong signal *agreed with expectation*,
which is why it stopped inquiry rather than prompting it. **When a fact confirms what you already
believe, that is when it most needs a provenance check.**

### 6.3 A check is uninterpretable without both controls

My near-miss false HIGH finding: the extraction was broken, not the artifact. What identified it was a
**known-positive** (`valid.ts` built clean) **and** a known-good input (the live file built clean) —
which proved the check worked and convicted the *input*. A too-broad and a too-narrow check are one
bug: without both controls you cannot tell which you have.

### 6.4 Exit codes through a pipe

`cmd | head` and `cmd | tail` report the **pager's** status. I read `npx tsc --noEmit | head -3; echo $?`
as `0` and called a typecheck clean while TS1005 errors were in the output. Use `PIPESTATUS`, or drop
the pipe.

### 6.5 Enumerate by property, not by name

The `editor` method was missed because the list was built by *enumerating what we knew about*. The gate
now parses pi's own `RpcExtensionUIRequest` union and asserts every declared method is in exactly one
of `MODAL_UI_METHODS` / `IGNORED_UI_METHODS` — anchored on `resolveRuntime()`, printing provenance,
tri-state (no runtime → SKIP; runtime but no declarations → **FAIL**; resolved + declared → PASS). It
gates **completeness**, not soundness.

### 6.6 `pinned` ≠ `fetchable`

A superproject gitlink must reference a commit that **exists on the submodule's remote**. Push before
pin, always, and verify with `git branch -r --contains HEAD`.

### 6.7 Submodule content is invisible from the parent

`git status` in the superproject shows a dirty submodule and says nothing about what changed. A commit
SHA is only meaningful as `(repo, SHA)`. `cd` in.

---

## 7. Explicitly not done

- **The deploy** (§4.1) — operator-gated.
- **R5** (§4.2) — a decision, not a change; nothing may flip before it.
- **The 0600 sites** (§4.4) — awaiting an owner.
- **The twin ruling** (§4.3) — fleet-level.
- **F3's fix** (if a fix is wanted at all) — currently documentation.
- The IDP rotations (§4.6).
- `landing-removed/src/lib/join-script.ts` → `landing/` was **deliberately not touched**: the twins
  are byte-identical at their HEADs and copying into the dead twin would multiply the divergence. The
  ruling comes first.

---

## 8. One thing to keep doing

Every finding in §5 was produced by someone who **tried to falsify their own result** and reported
what survived. Two lanes retracted their own findings; one lane's negative controls discarded three of
its own conclusions; the lead's own first run produced a false bug report against his own code and the
control caught it. **That is the whole method.** A result nobody tried to break is not evidence.
