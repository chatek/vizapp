# DEPT BUS — Supervisor Sidecar & Bus Contracts (SDK-facing, Design C)

> **Status:** DRAFT — part of the GZONE department plan (`docs/GZONE_DEPT_BUILD_PLAN.md`,
> Design C: department bus + bridges). SDK-facing surface of that plan.
> **Companions:** `agent-sdk/UPGRADE.md` §v9 (orchestration layer) · `docs/PRIME_AGENT_LXD_DEPARTMENT.md`.
> **Placement rule:** agent-sdk-related design lives here in `agent-sdk/docs/`.

## 1. Role of this document

The department bus plan needs a per-container process that bridges a pi.dev session to
the local NATS "bus". That process is the **supervisor sidecar**. This doc specifies its
SDK-facing surface: bus subject contracts, envelope reuse, the `--mode rpc` reuse path,
and the fold-in relationship to the v9 daemon. It is deliberately small — most of the
orchestration semantics are already specced in UPGRADE.md §v9 and reused here verbatim.

## 2. Bus subject contracts (v1, mirror the A2A envelope)

Envelopes reuse the `A2aRequest/Response` shape from `src/contracts/contracts.ts`
(`type`, `id`, `prompt`/payload, `from`, `a2a{intent, replySubject, conversationId}`).
No new wire grants are involved — the bus is department-owned.

| Subject | Pub (allowed) | Sub | Meaning |
|---|---|---|---|
| `dept.job.<job_id>.<op>` | lead | workers (queue group `dept-workers`) | dispatch + control (`op`: run/cancel/steer) |
| `dept.result.<job_id>.<worker>` | workers | lead | per-worker results, `conversationId` correlation |
| `dept.report.<bot>.*` | bots | comms bridge | human-facing report envelopes |
| `dept.prompt.<bot>.*` | comms bridge | bot | human reply → agent prompt |
| `dept.hb.*` | all | all | bus presence (short TTL) |

**ACL principle:** workers may *sub* `dept.job.>`, *pub* only their own result/report
paths; the lead owns job/control; nobody touches hub subjects on the bus. Verified by a
perm-probe matrix (mirrors `PERMISSIONS.CLAIMED_AGENT` conformance style).

## 3. Supervisor sidecar (per container)

```
pi.dev session (in container)  ⇄  supervisor  ⇄  bus (NATS, own container user)
      (prompt/agent_end)            │
                                    └─ optional: drive headless pi via `vclaw-agent --mode rpc`
```

- **Bus leg:** one NATS connection as the container's bus user; durable JetStream inbox
  (offline catch-up when the container restarts).
- **pi leg:** two options, mixable per worker:
  1. *Interactive*: `pi.sendUserMessage(...)` on bus prompt; `agent_end` text published as
     result/report with the same `conversationId`.
  2. *Headless*: drive `vclaw-agent --mode rpc` (JSONL stdio; 9 cmds / 6 events) — for
     workers that don't need a full interactive session (see `RPC_PROTOCOL.md`).
- **State:** small local JSONL per job (registry mirror) — same idea as v9's family dir.
- **Identity on the bus:** the container's bus user (bus-side trust); the container's IDP
  NKey stays exclusively for the hub leg. Never reuse hub creds on the bus.

## 4. Relationship to v9 (fold-in)

The supervisor is functionally v9's Tier L daemon with the loopback socket replaced by
the department bus ("Tier LAN"). To keep the later fold-in mechanical:

- Bus verbs and envelope fields MUST stay aligned with v9's family-lane vocabulary
  (`conversationId`, steer/receipt semantics, role=capabilities).
- When `vclaw-agent serve` lands (v9 W1), the supervisor should become a *mode* of it
  (`--bus` / Tier-LAN), not a separate codebase. Until then, the sidecar is the
  prototype.

## 5. Open items

- Segment/tenant naming **starts with `gzone`** (operator-ruled); admission mode (invite vs approval) open.
- Whether bot workers run full pi.dev sessions or headless rpc (start full, trim later).
- Human-reply routing depth: thread↔`conversationId` mapping table lives in the comms
  bridge (P3), but the `dept.prompt.<bot>` envelope shape is fixed here.
