# E2E LANE 2 — installer → config → resolver, end to end

**Date:** 2026-09-12 · **Commit tested:** agent-sdk `9e770e6`
**Verifier:** Lane 2 (independent — daemon-side work, not the install half's author)
**Mode:** read-only on committed code. No source file was edited; this document is the only artifact added.

---

## TL;DR

**All five claims are VERIFIED against the source-of-truth artifact, and three of them are FALSE on the artifact users actually download.**

The runtime-choice feature (LANE J) and the pi.dev opt-in flip (R2) exist in
`landing/src/lib/join-script.ts` and are exercised end-to-end below. But
**neither live installer URL serves that code**:

| surface | live sha256 (12) | size | LANE J (`--runtime`) | R2 (pi opt-in) |
|---|---|---|---|---|
| `https://vclawhub.com/join.ts` | `66c2c2b24450` | 12,707 B | **absent** | **absent — installs pi.dev by default** |
| `https://vchat.email/join.sh` | `a5ca77a00fb2` | 7,682 B | **absent** | **absent — installs pi.dev by default** |
| source of truth (emitted from `landing/src/lib/join-script.ts`) | `0e5761938cf6` | 15,813 B | present | present (opt-in) |
| ↑ that file **at `HEAD`/index** (`2a3d243`) | — | 14,166 B | **absent** | **absent** |

The live pipe is **byte-identical to the Aug-31 build** `vclawhub_landing/dist/join.ts`.
Root cause is structural and named in F1: **one served artifact, one server repo, one dead twin**,
and the change never reached a committed revision of either.

> **Correction (2026-09-12, by the lead).** An earlier revision of this document used
> `vclawhub_landing/astro.config.mjs:10` (`site: "https://vclawhub.com"`) as proof that
> `vclawhub_landing` serves the URL. **That is wrong and is retracted**: `site:` is Astro's
> canonical-URL base for absolute links/sitemaps, not a deployment binding. The actual server is
> **`landing`** — `landing` deploys with
> `npx astro build && npx wrangler pages deploy dist/ --project-name vchat-landing`, while
> `vclawhub_landing` has **no deploy script at all**; the custom-domain mapping
> (`vclawhub.com → vchat-landing.pages.dev`) lives only in the Cloudflare dashboard. The two
> decisive proofs below (2 and 3) do not depend on which repo serves the URL, so the finding
> stands; only the attribution changes.

Established independently of the retracted proof:
(1) *(retracted — see above)*;
(2) `git -C vclawhub_landing log -S"--runtime" -- src/lib/join-script.ts` is **empty** — the flag
never existed in that repo, and its last commit is `13bad2d` (Aug 31);
(3) the live bytes equal that repo's build output (and `landing`'s, which is byte-identical).

**Consequence of the correction:** because `landing` *is* the server, the live Aug-31 bytes mean
the deployed Pages build simply predates the change — the fix is commit + rebuild + redeploy
`landing`, not a port between repos. The dead twin is not the cause; it is a hazard that made a
careful verifier misread the situation (it supplies a plausible-looking "this repo serves that
URL" signal while nothing deploys from it).

And there is a **prior blocker: the feature is not committed anywhere.** In the `landing`
submodule the change is *unstaged working-tree only* — `git show HEAD:src/lib/join-script.ts`
and `git show :src/lib/join-script.ts` (the index) both yield 14,166 B with **zero**
occurrences of `--runtime`, while the working-tree file is 18,692 B with six (and
`test/join.test.ts` at `HEAD` has 0 mentions of "LANE J" vs 5 in the tree). So no revision of any
repo can currently be deployed that includes this chain.

---

## Method and isolation

Every run used a throwaway `HOME`; the real `~/.config/vclaw` was never written
(verified: it does not exist — see §Isolation).

- **Artifact under test:** the *emitted string* `JOIN_PIPE_SCRIPT`, extracted from the current
  source and run with `bun` exactly as `curl … | bun -` would — not the module, not the build copy.
- **Mock vgate** on `127.0.0.1:8899` (`/v1/agent/introduce` → `{session_id, agent_id, status}`,
  `/agent.js` + `.sha256`, `/jsr-latest`) — no live agent was created, no real network call.
- **Fake `curl` / `npx`** (log-and-exit) in `PATH` — the pi.dev installer is *observed*, never executed.
- **`pi` removed from `PATH`** (minimal PATH: fake bin + bun + coreutils), because the real machine
  has `/…/nvm/…/bin/pi` and a present `pi` short-circuits the installer branch.
- Invocation env: `VCLAW_API_URL`, `VCLAW_CLAIM_BASE_URL`, `VCLAW_AGENT_BUNDLE_URL`,
  `VCLAW_JSR_LATEST_URL` → mock. `VCLAW_RUNTIME` / `INSTALL_PI` / `VCLAW_PI_BIN` unset unless stated.

---

## Claim results

### C1 — `--runtime <bin>` writes `~/.config/vclaw/config.json`, preserves fields, mode 0600

**VERIFIED** (source of truth) · **NOT SATISFIED** (live pipe) · **NOT SATISFIED** (`bin/join.sh`)

Pre-existing config at **0644** with three fields that must survive:

```
before: {"segment":"vchat","server":"srv-alpha","vgateUrl":"https://api.example"}   mode 644
run:    bun join-emitted.ts my-agent --runtime prime-agent
after:  {"segment":"vchat","server":"srv-alpha","vgateUrl":"https://api.example",
         "runtime":"prime-agent"}                                                   mode 600
```
- Value written ✅ · all three pre-existing fields preserved ✅ · **0644 → 0600** ✅
  (the `writeFileSync` mode-only-at-creation trap is closed by an explicit `chmodSync`).
- No trailing newline (last byte `7d` = `}`) → byte-compatible with `store.ts saveConfig` ✅.
- The live pipe: `--runtime` → `Unknown option: --runtime`, **exit 1**, no config.json written.
- `bin/join.sh`: same — `--runtime` is not in its arg parser (`Unknown option`, **exit 1**).

### C2 — no `--runtime`, no `VCLAW_RUNTIME` ⇒ nothing written

**VERIFIED** (source of truth)

Fresh HOME, `bun join-emitted.ts fresh-agent`:
`.config/vclaw` **not created at all**; `config.json` absent ✅.
Other artifacts written as expected (`.npmrc`, `.vclaw/identity.json`, `.local/bin/`).
`VCLAW_RUNTIME=prime-agent` (same fresh-HOME setup) ⇒ `{"runtime":"prime-agent"}` created ✅ —
so the env knob is live, and *omission*, not the empty value, is what suppresses the write.

### C3 — the SDK reads it back: `source: config`

**VERIFIED** · `bun bin/agent.js runtime` against the C1 HOME:

```
effective : prime-agent
source    : config
env knob  : VCLAW_PI_BIN
config    : ~/.config/vclaw/config.json → "runtime"
```
Same result via `node bin/agent.js` (the bin's other load path) ✅.
Precedence sanity: `VCLAW_PI_BIN=from-env` ⇒ `effective: from-env`, `source: env` ✅.

### C4 — `runtime --unset` removes the field, leaves others intact

**VERIFIED** · after `runtime --unset`:

```
{"segment":"vchat","server":"srv-alpha","vgateUrl":"https://api.example"}   mode 600
effective : pi     source : default (built-in default: pi)
```
Field gone ✅ · other fields intact ✅ · mode stays 0600 ✅.

SDK-writer half of the same mode trap: pre-existing **0644** config + `runtime my-bin`
⇒ `{"segment":"vchat","runtime":"my-bin"}` at **0600** ✅ (both writers enforce the contract).

Cross-writer compatibility: installer updates an SDK-written config
(`{"segment":"vchat","runtime":"my-bin"}` → `runtime:"from-installer"`, `segment` preserved, 0600) ✅.

### C5 — pi.dev is opt-in (negative control)

**VERIFIED** (source of truth, both installers) · **FAILS on both live artifacts**

pi ABSENT, counting `pi.dev/install.sh` invocations:

| case | emitted `join.ts` | `bin/join.sh` | **live `vclawhub.com/join.ts`** | **live `vchat.email/join.sh`** |
|---|---|---|---|---|
| default (nothing opted in) | **0** ✅ | **0** ✅ | **1** ❌ | **1** ❌ |
| `--install-pi` | 1 ✅ | 1 ✅ | n/a (flag unknown) | n/a (flag unknown) |
| `INSTALL_PI=1` | 1 ✅ | 1 ✅ | n/a (no gate exists) | n/a (no gate exists) |
| `INSTALL_PI=0` | **1** ⚠️ | **1** ⚠️ | 1 | 1 |
| `pi` present + `--install-pi` | **0**, "pi.dev already present" ✅ | — | — | — |

Live pipe console on a default run: `🔧 Installing pi.dev via upstream installer...` /
`✅ pi.dev installed` — the pre-R2 consent behaviour, on the pipe the docs tell users to run.

---

## Findings

**F1 (HIGH, deployment) — the entire chain is unshipped, and was uncommitted.**
`https://vclawhub.com/join.ts` is byte-identical to the Aug-31 build (`66c2c2b24450`,
12,707 B), which predates the change in the server repo (`landing`). The twin
`vclawhub_landing/src/lib/join-script.ts` (14,166 B, `13bad2d`, Aug 31) also lacks it entirely
(0 occurrences of `--runtime`/`installPi`/`VCLAW_RUNTIME`) but serves nothing — see the
retraction above; it was my misattribution alone, and it is the reason the twin is worth
resolving rather than tolerating: a dead repo with a plausible canonical-URL field
**misroutes investigation** instead of merely risking divergence.
*Fix:* commit the work in `landing` (**done: `21d714f`, superproject `c4c06f1`**), rebuild and
redeploy Pages (`astro build && wrangler pages deploy dist/ --project-name vchat-landing`), then
re-run C1/C5 against the live bytes. Resolve the dead twin (delete it, or make it a pointer) so
the next verifier is not misrouted.
*Guard:* assert on the **live fetch**, not on a local copy — three copies in this repo give
three different answers (see "stale-copy trap" below).

**F2 (MED) — `INSTALL_PI=0` installs pi.dev.** `installPi = flag || !!process.env.INSTALL_PI`,
so *any* non-empty value is "on". Provisioning scripts that set `INSTALL_PI=0` to mean "off"
now install a third-party runtime. The source comments this deliberately (unset it instead),
but the convention is one-way: 0/false both read as on. Consider `!== "" && !== "0"`.
**FIXED (lead, `4822e70`)** — truthy-only (1/true/yes/on) in both emitters; controls:
`=0` → 0 installs, `=1` → 1, unset → 0.
**F3 (LOW, docs) — two env knobs, one feature.** The installer accepts `VCLAW_RUNTIME`
(install-time seed); the SDK resolves `VCLAW_PI_BIN` (call-time override) — the CLI itself prints
`env knob: VCLAW_PI_BIN`. A user who exports `VCLAW_RUNTIME` and then runs the daemon gets the
built-in default; the variable only has an effect while installing. Worth one line in the
onboarding docs, or accept both names in `resolveRuntime`.

**F4 (LOW) — the node fallback cannot persist a runtime.** `bin/join.sh` (documented fallback
for hosts without Bun) rejects `--runtime` with exit 1 and never writes config.json. On such a
host the durable choice is reachable only via `vclaw-agent runtime <bin>`. Consistent with
"deprecated fallback", but it means C1/C2 hold only on the Bun path.
**FIXED (lead, `4822e70`)** — `--runtime` now persists to `$VCLAW_CREDS_DIR|~/.config/vclaw/config.json`
at 0600, but only when no config exists: an existing config is refused and reported rather than
clobbered, rather than reimplementing the SDK's read-modify-write rule in bash.

**Observation (not a defect) — the stale-copy trap is real and tri-directional.**
Running the three local copies gives three different answers:
`landing/src/lib/join-script.ts` (emitted) → features present;
`landing/dist/join.ts` (gitignored build output, Aug 31) → features absent;
`vclawhub_landing/src` → features absent. Only the **live fetch** settles it, and it agrees
with the stale pair. `landing/dist/` is gitignored and regenerated by `astro build`
(`astro check && astro build`), so it is *not itself* the deployment risk — but it *is*
what a verifier reaches for first, and it answers the pre-LANE-J question.

---

## Isolation

| check | result |
|---|---|
| real `~/.config/vclaw/config.json` | **does not exist** — never created by these runs |
| temp HOMEs used | 7 (`/tmp/e2e-lane2/home1…7`), one per case |
| mock vgate | `127.0.0.1:8899`, local only; captured the introduce body |
| pi.dev installer | observed via fake `curl` log; **never executed** |
| live fetches | `curl` of the two public URLs only; no remote code executed |

---

## Evidence appendix (commands)

```bash
# emitted artifact (= what the endpoint serves), NOT the build copy
bun -e 'import {JOIN_PIPE_SCRIPT} from "…/landing/src/lib/join-script.ts";
        await Bun.write("/tmp/e2e-lane2/join-emitted.ts", JOIN_PIPE_SCRIPT)'

# C1 (with the 0644 trap pre-created)
printf '{"segment":"vchat","server":"srv-alpha","vgateUrl":"https://api.example"}' \
  > $H/.config/vclaw/config.json && chmod 0644 $H/.config/vclaw/config.json
env -i HOME=$H PATH="$W/bin:$BUN:/usr/bin:/bin" … bun join-emitted.ts my-agent --runtime prime-agent
stat -f '%Lp' $H/.config/vclaw/config.json     # 600

# C3/C4
env -i HOME=$H PATH=… bun agent-sdk/bin/agent.js runtime
env -i HOME=$H PATH=… bun agent-sdk/bin/agent.js runtime --unset

# C5 (negative control; `pi` absent from PATH, fake curl logs invocations)
grep -c 'pi.dev' $FAKE_LOG

# deployed bytes
curl -fsSL https://vclawhub.com/join.ts | shasum -a 256      # 66c2c2b24450  (12,707 B)
curl -fsSL https://vchat.email/join.sh  | shasum -a 256      # a5ca77a00fb2  (7,682 B)
```
