# Request-assertion wiring — the outbound LLM client

**Status: SPEC. Owner of implementation: agent-sdk lane.** Nothing in `src/lib/llm.ts` is changed by this
document; it states exactly what changes, and why each alternative was rejected. The minting half already
exists and is tested (`src/lib/request-assertion.ts`, 7 cases in `test/unit/request-assertion.test.ts:21-88`).

Scope: attach the per-request agent assertion to the SDK's outbound LLM traffic (the `llm set` smoke test
and the real chat reply), and nothing else. Identity at the door is verified against the kevproxy lane's
middleware spec (`kevproxy/docs/R6_IDENTITY_MIDDLEWARE_SPEC.md`, R6 hereafter); the verifier it calls is
`kevproxy/src/identity/assertion.ts`.

---

## 0 · Ground truth this design rests on

| fact | evidence |
|---|---|
| `llmChat` reads a **static** provider key from `<dataDir>/llm.json` and nothing else | `src/lib/llm.ts:22-26`, `:37-38`, `:189` |
| it serializes the body inline, in the `fetch` call itself | `src/lib/llm.ts:191` |
| it fetches once — no retry, no redirect policy | `src/lib/llm.ts:185-193` |
| its callers are the reply layer and the `llm set` smoke test; failures become a chat line, not a throw | `src/commands/start.ts:173-176`, `src/lib/llm.ts:141-147` |
| creds are read through a 3-tier chain with seed validation; **both** "absent" and "corrupt" come back as `null` | `src/lib/store.ts:193-211`, `:214-223` |
| `public_key` in that file is the U-form | `src/types.ts:64-65`, `src/mcp/fabric-tools.ts:214,249` |
| the seed is validated at 58 chars starting `S`, and `fromSeed` decodes it | `src/lib/store.ts:214-223` |
| env reads in the SDK go through one helper (`VCLAW_*`, `VCHAT_*` fallback) | `src/env.ts:15-21` |
| the mint takes `seed` + U-form `publicKey` + body digest, defaults `aud=kevproxy`, TTL 60 s, fresh `jti` | `src/lib/request-assertion.ts:36,38,53-55,80-104` |
| `assertionHeaders` deliberately never includes `authorization` | `src/lib/request-assertion.ts:107-110` |
| the door's skew allowance is 120 000 ms and its `aud` default is `kevproxy` | `kevproxy/src/identity/assertion.ts:139`; R6 `:62-63` |
| each refusal has a distinct code, `unknown_agent` is **403** | `kevproxy/src/identity/assertion.ts:39-48,185-199`; R6 `:74-86` |
| a refused assertion must not be downgraded to the bearer | R6 `:90-92` |

The last two rows are the whole reason §3 is written per-failure: R6 `:143-145` says fail-closed vs
fail-open is decided **per failure**, never globally.

---

## 1 · Identity resolution at call time

### 1.1 The trigger is the destination, not the presence of a seed

An assertion is a credential for **the kevproxy door only**. The same `llm.json` can point at Ollama, at
OpenAI, or at the door (`src/lib/llm.ts:8` lists exactly this range). Sending the header to a direct
provider would hand that provider the agent's NKey, a body digest and a jti — the leak the R6 placement
exists to avoid (R6 `:16-19`), only now caused by the client instead of a forward. So:

```
VCLAW_DOOR_URL  (via env("DOOR_URL"), src/env.ts:15-21)   → the door's BASE url, same form as `llm set url=`
mint IFF normalize(chatCompletionsURL(cfg.base_url)) === doorEndpoint(VCLAW_DOOR_URL)
```

- Unset `VCLAW_DOOR_URL` ⇒ **no assertion is attempted at all**, on any request. This is the default, and
  it makes shipping this wiring a no-op until the door is configured (R6 `:137` "middleware not mounted").
- Set but unparseable ⇒ warn `[llm] VCLAW_DOOR_URL is not a URL; requests are UNATTRIBUTED` and attempt
  nothing. Never guess a door.
- `VCLAW_DOOR_URL` is deliberately **not** allowed to be inferred from the bearer, the model name or the
  base URL's host: an inferred door is a sender-side invention that the door cannot confirm.
- `KEVPROXY_BASE_URL` (`kevproxy/pi-extension/index.ts:15`) is the pi-extension's name for the same value
  and belongs to that lane. `llm.ts` reads only `env("DOOR_URL")`; deployments that set both are
  consistent by operator action, not by fallback logic.

Comparison is exact after canonicalization (`new URL(...).toString()` on both sides, both passed through
`chatCompletionsURL` so a trailing slash or a missing `/v1` cannot disagree — `src/lib/llm.ts:131-135`).
No prefix matching: a host can serve several services, and `/kevproxy` prefix matching would mint for a
sibling path.

### 1.2 Resolution order (only when the destination is the door)

1. **`loadCredentials()`** (`src/lib/store.ts:193-211`, exported at `src/index.ts:15-23`). This is the same
   function `startAgent` uses for the NATS session (`src/commands/start.ts:191`), so the LLM call and the
   fabric session can never disagree about who the agent is. It already enforces read order
   `VCLAW_CREDS_DIR` → `~/.config/vclaw` → `~/.config/vchat` → `~/.vchat` (`src/lib/store.ts:32-55`),
   resolved at call time, which is what keeps a test harness or a second identity in one process honest.
2. **Derive the U-form from the seed** — `fromSeed(new TextEncoder().encode(creds.seed)).getPublicKey()` —
   and use *that* as `publicKey`, not `creds.public_key`. The verifier resolves the signature against
   `iss` (`kevproxy/src/identity/assertion.ts:166-178`), so an `iss` that the seed did not produce is a
   guaranteed `bad_signature`. Deriving makes keypair inconsistency unrepresentable. If
   `creds.public_key !== derived`, warn once: `[llm] credentials.json public_key does not match its seed;
   signing as the seed's key` (the stored field is wrong; the signature is not).
3. **No usable identity ⇒ proceed UNATTRIBUTED** — see §1.3.

**The dev-mode ephemeral keypair is not an identity source.** `startAgent` mints a throwaway keypair
when there are no creds and `--dev` is set (`src/commands/start.ts:205-206`). It is never persisted and
never registered at the door, so asserting with it is a guaranteed `403 assertion_unknown_agent` and would
break chat in every dev run. `llm.ts` reads `credentials.json` only; the ephemeral `seed` in `startAgent`
must not be threaded into `llmChat`.

**No caching, deliberately.** One `readFile` (worst case three, on a tier miss) per LLM call is noise next
to a network round trip, while a cached seed survives a re-onboard and turns into `unknown_agent` on every
call after it, or worse, attributes traffic to a retired key. A stale-attribution bug is far more
expensive than a syscall, so resolution is per call. `loadCredentials` does not throw (`src/lib/store.ts:196-209`
catches per file), so the call site needs no try/catch.

### 1.3 When the agent HAS NO identity

"Absent" and "unreadable" are the same return value (`src/lib/store.ts:204-210` falls through every tier
and returns `null`), and they get the same treatment: **send the request with the bearer and nobody's
name on it**, and say so:

```
console.warn("[llm] request assertion omitted: no usable agent identity in credentials.json — the door records this call UNATTRIBUTED")
```

Requirements this satisfies, and the ones it must not violate:

- The request carries **no identity header, no identity body field, no identity query parameter** — not an
  empty `x-agent-assertion`, not a placeholder NKey, not `sub: "unknown"`. Absence is the only honest
  encoding; R6 `:126-127` reads absent as NOT ATTRIBUTED, never as "unknown agent".
- The **bearer stays** (it is the provider credential, and the door's bearer map is a legitimate principal
  attribution — R6 `:128-129`). This is *not* a bearer fallback: no assertion was ever attempted, so
  nothing was refused. §3.2 keeps the distinction load-bearing.
- The warning is the observable signal. There is no return-type change: `llmChat` still returns the reply
  string (`src/lib/llm.ts:180-206`), and the caller's error line stays as is (`src/commands/start.ts:175`).
  A machine-readable "unattributed" flag was rejected — it would add a second result channel that one
  caller ignores, i.e. dead API.

---

## 2 · Which requests carry an assertion, and when it is minted

| request | asserts? | why |
|---|---|---|
| `POST /chat/completions` — real reply | **yes** | the attributable, billable call; the body exists to bind |
| `POST /chat/completions` — the `llm set` smoke test (`verifyLLMEndpoint`) | **yes**, inherited | it goes through `llmChat` (`src/lib/llm.ts:141-147`); asserting there is how a `403 unknown_agent` surfaces at configure time instead of on the first real message |
| `GET /v1/models` (`listModels`, `src/lib/llm.ts:162-178`) | **no** | no body, so `digest` semantics are unproven (the door hashes the body it parsed, `kevproxy/src/identity/assertion.ts:188-190`; R6 never defines an empty-body digest), and model discovery attributes nothing. Adding it would create a second failure surface for zero attribution gain |
| any future call to a non-door origin | **no** | §1.1 |

**Per request, per attempt.** The assertion is minted inside `llmChat`, after the body string exists,
immediately before the `fetch`:

- `digest` is `requestBodyDigest(body)` of the **exact string sent** (`src/lib/request-assertion.ts:48-55`).
  The body must therefore be serialized once into a `const` and passed to `fetch` unchanged. Re-serializing
  for the digest and again for the wire is the one bug that produces a valid-looking credential the door
  refuses with `body_digest` (`kevproxy/src/identity/assertion.ts:188-190`).
- `jti` is left to the default (`src/lib/request-assertion.ts:94`): a fresh UUID per mint. **A retry must
  re-mint**, because the door's nonce store is single-use (`kevproxy/src/identity/assertion.ts:19,192-194`;
  R6 `:56`). Concretely: the mint lives *inside* the attempt loop; hoisting a token above a loop, or
  reusing a `headers` object across attempts, makes attempt 2 a `replay` 401.
- Default TTL 60 s is kept (`src/lib/request-assertion.ts:38`); `now`/`ttlSeconds` are not passed, so `iat`
  is the send instant. The door tolerates 120 s of skew (R6 `:63`), so a queued request is safe; the TTL is
  **not** raised, because a longer window is a longer replay window for no gain.
- `aud` is left at the constant `kevproxy` (`src/lib/request-assertion.ts:36`, R6 `:62`). No per-agent
  audience override: if an operator changes `gateway.assertionAudience`, the SDK constant changes in the
  same release. A configurable `aud` would add a failure mode (`assertion_wrong_audience`) reachable from
  `llm.json`, which the agent's human operator cannot fix.

---

## 3 · Failure modes

### 3.1 The table

| condition | client behaviour | wire effect | tradeoff, decided |
|---|---|---|---|
| `VCLAW_DOOR_URL` unset | no assertion attempted, no warning | bearer only | The pre-R6 state. Nothing to attribute, nothing claimed |
| door URL set, **no credentials** (`loadCredentials() === null`, including dev mode's ephemeral keypair — see §1.2) | proceed unsigned + `console.warn` | bearer only; door row `clientNkey` absent | Chat keeps working; the operator loses attribution. Failing instead would make a not-yet-onboarded agent unable to talk — but the warning makes the loss visible per call, which is the property that matters |
| **unreadable / invalid seed** (corrupt JSON, `ST…` legacy seed, wrong permissions — all collapsed to `null` at `src/lib/store.ts:204-210`) | identical to the row above: proceed unsigned + warn; operator action is the same (`vclaw-agent vclaw connect` / re-onboard) | bearer only | Distinguishing the two would need a second `loadCredentials` variant that duplicates the tier walk (`src/lib/store.ts:193-211`) for a message difference. Rejected: same remedy, no extra code |
| seed present, **pubkey mismatch** with the stored `public_key` | proceed, signing with the **seed-derived** key + warn | attributed to the seed's NKey | The signature is still correct and names the real holder of the seed; the local record is what is wrong |
| **clock skew > 120 s** — door answers `assertion_expired` or `assertion_not_yet_valid` | **fail** the call with the reason in the message; no retry, no unsigned retry | nothing reaches the provider | The client cannot know the door's clock before sending, so this is detect-and-report, not prevent. A retry with a fresh `iat` fails identically; an unsigned retry hides a broken clock. Only fix: NTP |
| `assertion_replayed` | **re-mint once and retry once** (fresh `jti`, same body bytes, same digest); a second `assertion_replayed` fails the call | one extra request | A replay on a first attempt means a token was hoisted/reused (a client bug). One bounded re-mint converts a transient duplicate into success without weakening single-use: the retry is a *new* credential. Unlimited retries would be a replay loop |
| `assertion_unknown_agent` (**403**) | **fail, no retry, no bearer fallback** | nothing reaches the provider | The signature verified and the key is not in `gateway.agentAssertions` (`kevproxy/src/identity/assertion.ts:196-199`, R6 `:85`). This is an **authorisation** answer, not a transport glitch. Letting it through unlabelled would silently convert a config error into unattributed traffic — exactly R6 `:92`'s "attribution quietly becomes `null` again". The error must name the fix (register the NKey; `vclaw-agent` prints it, `src/cli.ts:148`) |
| `assertion_body_mismatch` | **fail** | nothing reaches the provider | Guaranteed client bug (digest over a re-serialization). Retrying cannot help; the code must change |
| `assertion_wrong_audience`, `assertion_bad_signature`, `assertion_malformed`, `assertion_bad_alg` | **fail** | nothing reaches the provider | A credential was presented and refused; R6 `:143` — a refusal is a refusal |
| any other non-OK (429, 5xx, 401 with no `reason`) | fail as today: `LLM HTTP <status>: <body>` (`src/lib/llm.ts:194-196`) | unchanged | No new retry behaviour is introduced by this wiring |
| door answers 3xx while an assertion is attached | **fail**: `LLM door redirect <status> → <location>; an assertion is not followed` | nothing | `fetch` would resend custom headers to the redirect target (a third party). Only the asserting request sets `redirect: "manual"`, so direct-provider behaviour is untouched |

### 3.2 The one rule that must survive review

There are exactly two outcomes for an asserting request: **verified** or **failed**. "Unattributed" exists
only for requests that never had a credential to present (§1.3). Any code path that catches a door refusal
and re-sends without the header is forbidden — that is the "silent bearer fallback" R6 `:90-92` names as
how attribution becomes `null` again, and it would also make a 403 indistinguishable from success to every
operator.

---

## 4 · What changes in `llm.ts` — exact call sites

All in `src/lib/llm.ts`. No other source file changes.

**4.1 Imports** (block at `src/lib/llm.ts:16-19`). Add:

```ts
import { fromSeed } from "@nats-io/nkeys";                     // already a dependency: package.json:48
import { env } from "../env.js";
import { loadCredentials } from "./store.js";                  // no cycle: store.ts imports only types/env/nkeys
import {
  assertionHeaders,
  buildRequestAssertion,
  requestBodyDigest,
} from "./request-assertion.js";
```

**4.2 `canonicalURL` + `doorEndpoint` + `identityHeaders`**, placed after `chatCompletionsURL` (`src/lib/llm.ts:131-135`):

```ts
/** Canonical form of an endpoint URL; null when it is not a URL at all. */
function canonicalURL(url: string): string | null {
  try {
    return new URL(url).toString();
  } catch {
    return null;
  }
}

/** The door's chat endpoint from VCLAW_DOOR_URL (a base, or a value that already ends in
 *  /chat/completions), or null when it is not a URL. */
function doorEndpoint(raw: string): string | null {
  const b = raw.trim().replace(/\/+$/, "");
  return canonicalURL(b.endsWith("/chat/completions") ? b : chatCompletionsURL(b));
}

/** Warn at most once: a permanent record mismatch must not spam every call. */
let keyMismatchWarned = false;

/** The assertion headers for THIS body, or {} when the call must not carry identity. */
async function identityHeaders(target: string, body: string): Promise<Record<string, string>> {
  const doorRaw = env("DOOR_URL");
  if (!doorRaw) return {};                                     // §1.1: not configured ⇒ never attempted
  const door = doorEndpoint(doorRaw);
  if (!door) {
    console.warn("[llm] VCLAW_DOOR_URL is not a URL; requests are UNATTRIBUTED");
    return {};
  }
  if (canonicalURL(target) !== door) return {};                // §1.1: destination is not the door
  const creds = await loadCredentials();
  if (!creds) {
    console.warn(
      "[llm] request assertion omitted: no usable agent identity in credentials.json — the door records this call UNATTRIBUTED",
    );
    return {};
  }
  const derived = fromSeed(new TextEncoder().encode(creds.seed)).getPublicKey();
  if (creds.public_key !== derived && !keyMismatchWarned) {
    keyMismatchWarned = true;
    console.warn("[llm] credentials.json public_key does not match its seed; signing as the seed's key");
  }
  return assertionHeaders(
    buildRequestAssertion({ seed: creds.seed, publicKey: derived, digest: requestBodyDigest(body) }),
  );
}
```

`buildRequestAssertion` is **not** wrapped in try/catch: after §1.2 the seed is validated
(`src/lib/store.ts:214-223`) and the key is derived, so the only remaining throws are programmer errors
(`src/lib/request-assertion.ts:82-91`) that must surface loudly. A corrupt `public_key` — the one reachable
runtime case — is eliminated by deriving it.

**4.3 `llmChat`** (`src/lib/llm.ts:180-206`). Keep the signature and the return value. Replace the body
from `const res = await fetch(...)` through the `if (!res.ok)` block (`:185-196`) with a call to one new
helper, and add the helper beside 4.2:

```ts
/** One POST with the assertion minted per attempt. Returns only an OK response. */
async function postWithAssertion(
  target: string,
  body: string,
  headers: Record<string, string>,
  signal: AbortSignal,
): Promise<Response> {
  for (let attempt = 0; ; attempt++) {
    const assertion = await identityHeaders(target, body);        // minted per attempt (§2)
    const asserting = Object.keys(assertion).length > 0;
    const res = await fetch(target, {
      method: "POST",
      headers: { ...headers, ...assertion },
      body,
      signal,
      ...(asserting ? { redirect: "manual" as const } : {}),      // never carry an assertion across a redirect
    });
    if (asserting && (res.type === "opaqueredirect" || (res.status >= 300 && res.status < 400))) {
      throw new Error(
        `LLM door redirect ${res.status} → ${res.headers.get("location") ?? "?"}; an assertion is not followed`,
      );
    }
    if (res.ok) return res;
    const text = await res.text();
    const reason = refusalReason(text);
    if (attempt === 0 && reason === "assertion_replayed") continue;   // exactly one re-mint
    throw new Error(describeRefusal(res.status, reason, text));
  }
}
```

```ts
export async function llmChat(
  cfg: LLMConfig,
  messages: Array<{ role: string; content: string }>,
  timeoutMs = 60_000,
): Promise<string> {
  const target = chatCompletionsURL(cfg.base_url);
  const body = JSON.stringify({ model: cfg.model, messages, stream: false });   // serialized ONCE
  const res = await postWithAssertion(
    target,
    body,
    {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.api_key}`,                    // UNCHANGED: provider credential
    },
    AbortSignal.timeout(timeoutMs),
  );
  // ... unchanged response decoding (src/lib/llm.ts:197-204)
}
```

**4.4 `refusalReason` + `describeRefusal`**, placed beside 4.2:

```ts
/** The door's machine `reason`, when the body is its JSON refusal shape. */
function refusalReason(text: string): string | null {
  try {
    const v = JSON.parse(text) as { reason?: unknown };
    return typeof v.reason === "string" ? v.reason : null;
  } catch {
    return null;
  }
}

function describeRefusal(status: number, reason: string | null, text: string): string {
  const base = `LLM HTTP ${status}${reason ? ` (${reason})` : ""}: ${text.slice(0, 200)}`;
  switch (reason) {
    case "assertion_expired":
    case "assertion_not_yet_valid":
      return `${base} — this host's clock differs from the door by more than 120 s. Fix the clock; the call was not retried and not sent unlabelled.`;
    case "assertion_unknown_agent":
      return `${base} — this agent's NKey is not registered at the door (gateway.agentAssertions). Ask the operator to register it; the call was not retried and not sent unlabelled.`;
    case "assertion_body_mismatch":
      return `${base} — the request body changed after it was signed. This is a client bug.`;
    case "assertion_wrong_audience":
      return `${base} — the door expects a different aud than "kevproxy"; check gateway.assertionAudience.`;
    default:
      return base;
  }
}
```

`reason` is read from the response body because the verifier's codes are what distinguish "fix the clock"
from "register the key" (`kevproxy/src/identity/assertion.ts:39-48`, R6 `:74-86`). The raw text stays in
the message, so a door returning a different envelope still produces a diagnosable error.

Notes that are part of the change, not open questions:

- `Authorization` stays exactly as at `src/lib/llm.ts:189`. The assertion is a second, sibling header
  (`src/lib/request-assertion.ts:33,107-110`); the bearer never disappears and never carries identity.
- The header name is taken from the constant; the string `"x-agent-assertion"` must never be spelled in
  `llm.ts`.
- **Nothing else may ride the request**: no identity in the body (the reuse gateway drops body extras, and
  the door reads a header — R6 `:1-12`), none in the query, none in a new "agent" header of our own.
- `listModels` (`:162-178`) and `verifyLLMEndpoint` (`:141-147`) are not edited. The latter inherits §4.3
  because it calls `llmChat` (`:146`).
- `chatCompletionsURL` (`:131-135`), `LLMConfig` (`:22-26`), `loadLLMConfig` (`:32-44`) are unchanged: the
  door URL is env, not per-agent `llm.json` state — per-agent config would need a `llm set` grammar change
  and would let a chat message repoint identity.

**No change** to: `src/lib/request-assertion.ts`, `src/lib/store.ts`, `src/lib/keygen.ts`,
`src/index.ts` (every needed symbol is already exported — `:15-23`, `:44-52`), `src/commands/start.ts`
(`:173` keeps its two arguments), `package.json` (`@nats-io/nkeys` is already a dependency, `:48`).

---

## 5 · Who builds what

| piece | owner |
|---|---|
| `llm.ts` wiring (§1-§4) + `test/unit/llm-assertion.test.ts` | **agent-sdk lane** |
| R6 ingress middleware, `gateway.agentAssertions` / `assertionAudience` / `assertionSkewMs` config, outcome-row `clientNkey`/`clientHow:"assertion"` | **kevproxy lane** (already specced, R6 §2-§5) |
| setting `VCLAW_DOOR_URL` per agent, registering each agent's NKey in the door config, keeping NTP on the hosts | **operator** |
| index.ts export of a new symbol | **nobody** — none is needed (§4). Revisit only if a second producer of asserts appears |

No IDP or vpay work: the door verifies against its own config map, so no per-request introspection call
exists (and IDP has no caller-introspection route today). vpay's x402 acceptance of any signing key is
untouched — this wiring never calls it.

---

## 6 · Acceptance tests (new file `test/unit/llm-assertion.test.ts`)

`fetch` stubbed; `VCLAW_CREDS_DIR` pointed at a temp dir holding a real `credentials.json` (the override is
read at call time, `src/lib/store.ts:32-34`).

1. `VCLAW_DOOR_URL` unset + valid creds ⇒ request has `Authorization` and **no** `x-agent-assertion`.
2. door URL set, `base_url` = door ⇒ header present; `digest` in the payload equals
   `sha256(the exact body string received by the stub)`; `aud === "kevproxy"`; `iss` is U-form;
   `exp - iat === 60`; `Authorization` still the configured bearer.
3. door URL set, `base_url` = a different endpoint (another origin, or a sibling path on the same host)
   ⇒ no header (the §1.1 leak test).
4. creds dir empty ⇒ no header, one `[llm] request assertion omitted` warning, call still succeeds.
5. stub returns 401 `{"reason":"assertion_replayed"}` then 200 ⇒ two requests, **different** `jti`s, same
   body, overall success.
6. stub returns 403 `{"reason":"assertion_unknown_agent"}` ⇒ throws, exactly one request, message names
   registration and says not unlabelled.
7. stub returns 401 `{"reason":"assertion_expired"}` ⇒ throws, exactly one request, message names clock.
8. `listModels` against the door URL ⇒ no assertion header.
9. door answers `302` with a `location` while an assertion is attached ⇒ throws, exactly one request,
   message says the assertion is not followed.
10. `VCLAW_DOOR_URL` given as the full `…/v1/chat/completions` (not the base) ⇒ same assertion as case 2.
    A config form that silently loses attribution must fail here.

These fail today and are the definition of done for the agent-sdk lane.

---

## 7 · Decisions closed by this document (nothing open)

1. Trigger: exact match of the normalized chat endpoint against `VCLAW_DOOR_URL`; unset ⇒ never.
2. Identity source: `loadCredentials()` per call; U-form **derived** from the seed; no cache.
3. No identity ⇒ unsigned + warn; refusals ⇒ fail; the only retry is one fresh-jti re-mint on
   `assertion_replayed`.
4. Assertion on `POST /chat/completions` only, minted per attempt, 60 s TTL, `aud=kevproxy`.
5. Bearer, URL, body and the public surface of `llm.ts` other than `llmChat`'s internals are unchanged.
