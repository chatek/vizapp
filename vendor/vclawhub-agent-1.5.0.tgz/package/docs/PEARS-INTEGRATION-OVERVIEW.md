# Pears / Holepunch integration in agent-sdk — overview for the next sprint

**Status:** reference document (written 2026-10-27 by vclaw-lead). It summarizes HOW this SDK integrates the
Holepunch stack for P2P agent messaging, what is proven, what is not, and what a future sprint must know
before extending it. It cites the canon docs rather than restating them; where a claim is measured, the
measurement's home is named.

**Canon beside this file:** `src/net/p2p/PROTOCOL.md` (§1–§9 wire/IPC/artifacts/listen, **§10 dependency map**),
`docs/PEARS_P2P_MIGRATION_PLAN.md` (the plan + milestone gating), `../A2A/pears-assessment/` (M0-SPIKE,
M1-SEAM-DESIGN, M2-BUILD, M3-BUILD, P2-AVAILABILITY-EVIDENCE, A2A-SURFACE, H2A-FLOWS, COMM-CENSUS),
`../docs/PEARS_SAME_OWNER_A2A_MANDATE.md` (the ownership/tier rule), `../docs/BACKLOG.md` (E24 and friends).

---

## 1 · The shape: a seam, not a dependency

The SDK does **not** link Pears into its own process. `src/net/transport.ts` defines exactly two operations:

```ts
publish(subject: string, data: Uint8Array): void
subscribe(subject: string, opts: { callback(err, msg) }): TransportSubscription
```

`TransportMessage` mirrors the NATS `Msg` shape field-for-field (`subject`, `data`, `reply` — where `reply`
stays `""` when absent, and that falsy check is load-bearing in `subA2A`'s ack branch). The NATS adapter is a
zero-coercion passthrough.

Everything above the seam — `a2a.ts` (envelope + conversation identity + acks), `h2a.ts` (human prompts),
`conversation.ts` (UUIDv7 ids + monotonic per-conversation `seq`), `directory.ts`/`heartbeat.ts` (presence) —
is **transport-agnostic**. That is why routing can be decided by ownership rather than by code path, and why
the same frames ride both tiers.

**Routing rule** (`docs/PEARS_SAME_OWNER_A2A_MANDATE.md`): same-owner A2A ⇒ Tier P (P2P, IDP never reads the
content); cross-owner or cross-segment ⇒ NATS `a2a.>` with a vgate-minted grant. Never both for one message.

## 2 · Why a sidecar process (and not in-process)

The dependency set **cannot run under bun** — measured in M0: bun 1.4.2 / 1.4.4 crash on the dep set
(`uv_buf_init` / `uv_get_osfhandle` NAPI panics, bun #18546); node 22 runs it fine. The SDK's CLI and MCP ship
under bun, so the P2P plane lives in a **stock-Node sidecar**: `src/net/p2p/sidecar/`.

`PROTOCOL.md` §9 defines the lifecycle: one helper per host, spawn-or-attach over a shared socket, refcounted
attach, linger on last close, crash → next caller respawns, losers exit `E_HELPER_LOCKED`. The IPC contract is
owner-agnostic (a fixed socket path) so whoever wins the spawn race serves everyone. Sharing is verified by a
three-process test, not assumed.

## 3 · The seven packages, bottom-up

Exact pins live in `src/net/p2p/sidecar/package.json` (lockfile-pinned; **88 entries, 0 install scripts**,
`npm ci --omit=dev`). Role per package is PROTOCOL.md §10.

| layer | package | pin | role |
|---|---|---|---|
| crypto | `sodium-native` | 5.2.0 | XSalsa20-Poly1305 frame ciphertext; **NAPI prebuilds — no per-host compile** |
| storage | `corestore` | 7.16.1 | multi-core store; **one directory per owning PROCESS** |
| log | `hypercore` | 11.39.3 | append-only log per delegation/namespace |
| blobs | `hyperblobs` | 2.13.0 | artifact tree (the 20 MB wedge) |
| transport | `hyperdht` · `hyperswarm` | 6.34.1 · 4.17.2 | DHT discovery + peer connections; pulls `udx-native` (native) |
| mux | `protomux` | 3.13.0 | multiplexes the pubsub channel **and** hypercore replication over one noise stream |
| identity (vendored, NOT a sidecar dep) | `keypear`, `keet-identity-key` | — | the pass lane's identity layer; the sidecar's identity uses `hkdfSync` (`identity.ts:63`) |

**Corrections a future sprint must carry** (found in the 2026-10-27 close review, `../docs/lanes/PEARS_POC_CLOSE-REVIEW_2026-10-26.md`):
- `keypear` is **not** a sidecar dependency — absent from lockfile, `package.json`, and `src/`.
- "pure JS" holds for **`protomux` only**: `hyperdht → dht-rpc → udx-native`, `hyperblobs → block-map →
  hypercore-crypto → sodium-universal`.
- "per-host npm ci for ABI" is wrong: sodium-native ships NAPI prebuilds; every host still needs `npm ci` +
  build because **dist is gitignored** and runtime-resolved — that is also why bun cannot host the set.
- Package scope is **`@vclawhub/*`**; `@vchatemail/*` does not exist.

## 4 · Store, artifacts, and identity semantics

- **Store:** one `Corestore(dir)` **per sidecar process** (`sidecar/src/store.ts:53`); cores **per delegation**
  inside it (`:79`). The failure mode when peers disagree is **identity divergence**, not directory count.
  BACKLOG E24's original wording ("one store per delegation") was corrected after the close review.
- **Artifacts:** Hyperblobs; **sha256 is mandatory on every payload** because M0 measured that a non-member
  receives ciphertext which decrypts to garbage (confidentiality holds) while **length leaks** — integrity must
  not depend on the fabric.
- **Identity:** derived per delegation; the Q7 spike verified foreign ed25519 acceptance on six surfaces and
  that `corestore` named cores IGNORE a `keyPair` (a real trap).

## 5 · DHT posture — the hollow-dial class and its fix

**Measured root cause** (dht-matrix lane, `.prime/handoff/pears-assessment/dht-matrix/FINDINGS.md`): `dht-rpc`
peers boot `ephemeral=true, firewalled=true` and leave that state only after a NAT/firewall check against a
**cross-host** sampler. With a **co-located private seed** that check never completes, so the peer stays
firewalled: requests leave an ephemeral client socket, the seed records the peer at that port,
`remoteAddress()` stays null, punch relays stay empty → **hollow dials** (reader "connects", writer silent,
ETIMEDOUT ~13 s). Measured: same-host p50 ~15 s with a 29–40 s tail, sometimes never; cross-host 0/6.

**Fix (agent-sdk `04064fb`):** the sidecar's two DHT constructions take explicit flags via `DhtNetworkFlags`
(`sidecar/src/dht.ts`), plumbed from `NetworkConfig` → `BootMessage.network`. `ephemeral=false, firewalled=false`
is a **fleet declaration** that the host is reachable on its bind address. Measured with flags false: connects
in **17–22 ms, zero hollow**. Both default to **true** (upstream lifecycle) — a genuinely firewalled peer
declared un-firewalled would be unreachable, so this is opt-in for fleet-deployed hosts with a co-located seed.

## 6 · What is PROVEN vs NOT PROVEN (read this before promising anything)

| claim | state | where |
|---|---|---|
| artifact exchange, 20,000,003 B, sha256-exact, 746 ms | **PROVEN** (one host) | M3-BUILD |
| loopback RTT p50 0.23 ms; LAN p50 ~6 ms vs ~389 ms hub approximation | **PROVEN** | M0-SPIKE |
| same-host connect with DHT flags | **probe-proven, small n** | dht-matrix |
| seeder-full reliability ≥ 0.95 | **NOT MET** — 18/20 = 0.90 at n=20; canary 0/20 | P2-AVAILABILITY-EVIDENCE |
| iteration-A "bigger warm budget" | **did not lift the rate** (9/10; 75% fast / 20% slow / 5% never) | same |
| cross-host workstation↔danilab | **NOT DEMONSTRATED** — never connects; asymmetry measured (B→A works, A→B DHT lookups empty) | same + m0-spike-2 |
| same-owner **messaging** (M4) | **NOT BUILT** — gated | plan §M4 |

**The honest sentence:** P2P carries **artifacts** reliably on one host today; **messaging on Tier P does not
exist**, and cross-host is an open, measured failure.

## 7 · M4's gate (why messaging is intentionally unbuilt)

Three prerequisites, all externally owned:
1. **delegation rows live** — `KV_vchat_delegations` is EMPTY (vpay deploy chain);
2. **standing presence** — MCP-mode agents are offline between tool calls; the per-host helper is the shape,
   measured at 0.90 seeder reliability, not yet estate operation;
3. **the a2a-meter deployed and showing flow** — **now PASSES** (live on vchat3:8094 since 2026-10-27,
   `connected:true`, 3 subscriptions, 0 violations).

Until (1) and (2), M4 would build transport for traffic that cannot exist — the "built-unreachable" failure
this sprint already paid for once (M2/M3 shipped with no production caller).

## 8 · Queued v2 work (owned, not started)

- **SDK-1 · proxy-root H2A subscription** — `subPrompt` listens on exactly one prefix
  (`tenant.default.user.<nkey>.agent.<nkey>.prompt.>`, `h2a.ts:154-159`), so a supervisor-proxy root is
  **silently dropped**. Prerequisite for any supervisor→subordinate proxy grant.
- **SDK-2 · H2A `actor`** — the prompt frame carries no sender field, so with SDK-1 the agent still cannot name
  the human. Additive optional field.

## 9 · Working rules this sprint earned (do not re-learn)

1. **A publish with no subscriber is silent** — no error, no ack, no "queued". Never render delivery you did not
   observe.
2. **`.req` is mandatory** — a subscription on `...prompt.>` / `...a2a.<nkey>.>` never receives a bare publish
   (NATS `>` needs ≥1 token). This class has now bitten twice (J1b, and the N9 subject-form review).
3. **One key in both H2A slots** — `user.<nkey>.agent.<nkey>` is the ONLY form the SDK builds, subscribes and
   mints. A two-key form is dropped AND denied.
4. **`seq` is in-process** — the SDK's per-conversation counter resets on restart; a gateway must own it.
5. **Numbers quoted from memory are unmeasured claims** — this sprint produced three (receipt vocabulary, a
   stale byte count, a size). Quote from the instrument.
6. **Design written against cited contracts invites line-level rebuttal; design written from confidence invites
   argument** — the cheapest catch (a cannot-work subject form) was only possible because refs existed to check.
