# @agent-sdk packaging strategy — the debate, the evidence, the verdict

**Sprint:** 2026-10-14 packaging-strategy debate, opened by the operator.
**Question on the table:** should `@vclawhub/agent` (JSR + the `vclawhub.com/join.ts` funnel) stay ONE
cross-runtime SDK, or split into per-agent-type packages (`agent-pi` / `agent-prime` / `agent-omp`), each
one-shot-installing the latest stable of its upstream (pi.dev, prime-agent, omp.sh)?
**Method:** six measured inputs — two peer votes (W1 signing/contracts lane, W2 install/runtime lane) and three
research legs (A upstream surfaces, B distribution mechanics + precedents, C decision history with
survive/amend/invalidate verdicts), plus the lead's own 2026-10-12/13 measurements. Scratch files live in
`.prime/handoff/packaging-sprint/` (gitignored — **this document is the tracked, self-contained record**).

---

## 1. Reality check: what "one SDK supports all three" can even mean

**The premise needs one correction before it can be debated.** The three runtimes are not three languages;
they are **two families**:

| runtime | latest stable | family | official install | OUR integration surface |
|---|---|---|---|---|
| pi.dev (`@earendil-works/pi-coding-agent`) | **1.2.0** (npm, 2026-10-12; scope moved from `@mariozechner`, stale at 0.73.1) | TS, in-process extensions (jiti, no build step) | `curl -fsSL https://pi.dev/install.sh \| sh` · `npm i -g` · distributed as Pi packages: `pi install npm:@scope/pkg` under the `pi` key | **in-process TS extension** (our `src/pi-extension/`, 967 ln, 9 surfaces) |
| OMP (`@oh-my-pi/pi-coding-agent`, omp.sh) | **18.10.4** (vendored here at 18.9.0) | **Pi fork** (TS on Bun + ~80k-ln Rust core); same `ExtensionAPI` lineage (`on("session_start", …)` model; OMP adds injected schema builders and richer events) | `curl -fsSL https://omp.sh/install \| sh` · brew · `bun i -g`; plugins via `omp.extensions` npm manifest, `omp plugin`, Claude-registry-compatible marketplace | **same TS extension entry, drift-gated** (lineage confirmed; a per-release API-drift check is required, not assumed) |
| prime-agent | **0.10.0** (Rust, 2026-10-09) | **Rust; executes NO TypeScript.** Confirmed: no extension loader in help or binary strings; the `extensions` settings key is dead (the vendor's own test is named `removed_extensions_key_loads_gracefully`) | `curl -fsSL https://app.primeintellect.ai/prime-agent/install.sh \| sh` (self-identifies `install-rust.sh`, R2 channel; **removes the old TS npm package**) | **stdio MCP child only** (`bun ~/.vclaw/agent.js mcp`) + Python skills; also has its own capability channel: `prime-agent package install npm:/git:/https:` |

**So "one SDK" is true only in the subprocess sense.** A TS package can never load *inside* prime-agent; what
loads there is our **bundle-as-subprocess**. The lead's own measurement (2026-10-12) closes the lifecycle worry
that motivated in-process integration: **on Rust hosts the stdio MCP server is a per-session child — the spawn
IS session start and stdin EOF is shutdown — so the MCP child is a first-class carrier, not a compromise.**

**And one premise-shaped gap, measured by leg B:** the JSR→npm alias tarball **drops the `pi` field and ships no
`bin`** — so the pi extension has **no live registry channel today**; the extension reaches users only through
the bundle/meta-package path. Whatever we decide, that is a hole to close or to declare.

---

## 2. The debate: per-agent-type packages vs one core — and the evidence

**The instinct behind "per-agent-type SDK" is right about ONE thing** (per-runtime integration is real and must
be first-class) **and wrong about the artifact** (it should not be a package). Six independent lines of evidence:

1. **We already ran the split experiment and it died.** `@vchatemail/a2a-net` 0.1.0: unpublished (npm 404), zero
   consumers, retired 2026-08-04 and **inlined back** to create one canonical home
   (`docs/A2A_NET_DRIFT_REVIEW_2026-08-04.md`); a second split (`packages/nats-contracts`) is recorded dead in
   the same review. The only split that survived is tiny-core + adapter (`protocol-core` + `ext-synadia`).
2. **Drift is not a build error, it is a protocol partition.** The canonical form is five precise rules
   (field order `contracts.ts:800`, undefined-skip `:811-815`, stringify-no-space/HTML-escape-off, UTF-8
   TextEncoder, nkeys codec `:830-836`) living in `src/contracts/contracts.ts` (1,758 ln) — consumed by `src/net/*`
   (16 files, 3,020 ln). Verification is mesh-distributed (`directory.ts:159-160`, `presence.ts:160-172`), so a
   drifting copy **fails pairwise as auth failures** — the worst diagnosability class we have. N packages give N
   chances to drift; one core, one version is the only invariant that prevents it.
3. **A per-agent package for the Rust host is an empty package.** The entire prime-agent integration is a spawn
   line — `wirePrimeMcp` writes `{type:"stdio", command:<bun>, args:[<agent.js>,"mcp"]}` to
   `~/.prime/agent/settings.json`, **absolute paths, no shell** (`join-script.ts:36-40`). That is *data*, not
   code. `@vclawhub/agent-prime` would be "documentation wearing a version number."
4. **Identity is single-writer by design.** `~/.vclaw/identity.json` (0600) with a never-silently-re-key rule
   (`join-script.ts:46-48`); the bundle is written by **exactly one installer**. Two versioned packages both
   touching identity material is a split-brain risk on the fabric.
5. **The registry cannot host the alternative anyway.** JSR serves TS/ESM exports (+arbitrary files ≤20MB via
   `publish.include`, no postinstall ⇒ no installable natives); Rust/Python artefacts ride it only as inert
   blobs. Polyglot already has an in-house answer: the **signed-CDN prime-agent release contract**
   (`latest.json`/beta, Ed25519 manifest — verified live at v0.9.4).
6. **Every winning precedent is one-core + thin adapters.** Registry-measured: typescript-language-server (one
   server + thin stdio clients — exactly our MCP shape), tailwind 4 (one core + framework adapters depending on
   it + platform optionalDeps), @biomejs/biome (one package + 8 platform optionalDeps), prisma 8 (full split —
   won for *org autonomy*, heaviest version matrix). **None ships N copies of the core per host.** The split's
   only structural win is blast-radius isolation — buyable later by moving one adapter out, without pre-paying.

**Verdict: ONE package, ONE core, TWO entry surfaces, adapters as wiring.** The per-agent-type-ness lives in
**wiring data + distribution rails**, not in packages.

---

## 3. The architecture (what to build)

```
                    ┌────────────────────────────────────────────────┐
                    │  @vclawhub/agent  (ONE published core, JSR=truth)│
                    │  fabric client (net/*) + identity/onboarding    │
                    │  canonical+sign: ONE home, exported publicly     │
                    │  ├─ entry 1: TS extension  (pi.dev + OMP)        │
                    │  └─ entry 2: `vclaw-agent mcp`  (universal;      │
                    │      THE carrier on Rust hosts)                  │
                    └───────────────┬────────────────────────────────┘
                                    │ spawned as stdio child / imported in-process
   pi.dev 1.2.0 ── extension ───────┤          OMP 18.10.4 ── extension (drift-gated)
   prime-agent 0.10.0 ── MCP child ─┘
                                    │ wired by
   vclawhub.com/join.ts (ONE installer; --runtime selects WIRING, persisted to
   ~/.config/vclaw/config.json; per-host files: ~/.pi/agent/mcp.json ·
   ~/.prime/agent/settings.json · [NEW] omp adapter per its contract)
```

**Five things to build or close, in order:**

1. **Give the canonical+sign surface exactly one PUBLISHED home.** Today `canonicalAnnouncementBytes/V2`,
   field orders and signing live only inside agent-sdk (`contracts.ts`); `protocol-core` does not own them
   (verified: no hit in `packages/protocol-core/src`). Export them from the published core **before any second
   consumer appears** — closes W1's C5 and is precondition to everything else.
2. **Close the central gap: the fabric has NO carrier on Rust hosts.** `src/mcp/server.ts` registers **exactly 4
   identity tools** (identity_status, onboard_start, onboard_poll, health — verified twice) — no presence, no
   announce, no A2A, no roster. Grow the MCP surface to the fabric verbs. This is also register `O498` option
   (a): the MCP child **is** the presence owner, and its lifetime brackets the session for free (measured:
   spawn = session start, stdin EOF = shutdown). It resolves the stale-presence defect class (the four
   unreaped `agent.js start` orphans) without a second supervisor.
3. **Add the OMP adapter as a CONTRACT, then as wiring.** OMP has zero installer support today (measured: no
   `omp` occurrence in join.ts). Define the adapter contract (wiring file shape + the `omp.extensions`/`omp
   plugin` channel decision), then `wireOmpMcp` joins `wirePrimeMcp`/`wirePiMcp` in the one installer.
4. **Ship the extension through per-agent DISTRIBUTION RAILS (where "per-agent-type" genuinely wins):**
   pi: `pi install npm:@vclawhub/agent` (requires the `pi` field to survive packaging — the JSR→npm alias drops
   it today, so this needs the frozen-npm ruling amended for the pi field or a pi-manifest tarball from our
   signed CDN); OMP: `omp plugin` / `omp.extensions`; prime-agent: keep the signed CDN and optionally deliver
   the wiring + skills via `prime-agent package install https://…`. Same core everywhere; different rails.
5. **A drift gate, not a hope:** extend the existing `extension-variants` test into a **pi+OMP matrix** (the
   extension must build/load against both APIs) and **golden-vector fixtures** for the canonical bytes (v1+v2)
   so any core change that moves a byte fails CI before it reaches the mesh.

**Upstream latest-stable policy:** the funnel already ships prime-agent via our own signed release contract;
pi.dev/OMP official installers stay **OPT-IN** (R2 ruling, 2026-09-11 — piping a third-party installer is an
operator decision, never a side effect of onboarding). Any change to that is an operator ruling to request,
not a packaging detail to smuggle.

---

## 4. Rulings this sprint supersedes or amends (from leg C's 19-row verdict table)

- **INVALIDATED:** the "4 npm tarballs" as a platform/runtime matrix (they are **prime-agent's workspace
  members** — prime-agent/-ai/-core/-tui, same version, staged+verified against the signed manifest; bun
  installs only the public one); the meta-package "every pi session" ruling (scoped to **pi.dev-family**);
  the J5 extension bake into the v10 image (the `extensions` key is dead on 0.10.0).
- **SURVIVES, vindicated:** the MCP host-wiring shape (wave 2 built the right thing); npm-frozen /
  jsr-version-truth / bundled-CLI npm-free; the funnel identity contract (runtime-agnostic by construction).
- **AMENDED:** runtime-selector default tier (verified on pi 0.85.1 only — re-verify at 1.2.0); R5
  no-extensions gate scoped to pi.dev; the uv hard gate re-measured on Rust; Forgejo build step redefined for
  Rust artefacts; AUTONOMOUS_MODE re-scope before P1b; **the twin-repo ruling is still unwritten** (6 inherited
  open questions + 8 new ones are listed in leg C's file — carry them, do not re-litigate them here).

**One more measured caution for whatever ships next:** agent-sdk's docs contain **zero references to 0.10.0** —
every distribution ruling was written against TS prime-agent ≤0.9.5. The architecture above is written against
the Rust facts; the doc trail should say so wherever the old rulings appear.

---

## 6. The end-user install surface on vclawhub.com, after the upgrade

**Shape first: per-agent-type EXPERIENCE, one core.** We do not ship `@vclawhub/agent-prime` /
`-omp` packages (§2); the per-agent-type-ness the operator wants — "install the SDK for MY agent, with that
agent's latest stable included" — is delivered as **one copy-paste command per runtime, from one funnel**.
The website sells the choice; the funnel implements it.

### 6.1 The page: a runtime picker, not a package catalogue

Three cards, one command each (plus "bring your own"):

```
┌─ prime-agent (Rust) ─────────┐  ┌─ OMP (omp.sh) ──────────────┐  ┌─ pi.dev (TS) ───────────────┐
│ The Rust agent.              │  │ The Pi-fork agent.          │  │ The original TS agent.      │
│ curl -fsSL https://vclawhub.com/join.ts | bun - --runtime prime-agent my-agent
│                              │  │ curl -fsSL https://vclawhub.com/join.ts | bun - --runtime omp my-agent
│                              │  │                              │  │ curl -fsSL https://vclawhub.com/join.ts | bun - --runtime pi --install-pi my-agent
└──────────────────────────────┘  └──────────────────────────────┘  └──────────────────────────────┘
   Default card = prime-agent; a bare `curl … | bun -` selects it. pi.dev stays OPT-IN per R2 (2026-09-11).
```

### 6.2 What ONE command does (the six user-visible steps)

1. **Ensure Bun** (prompt with the bun.sh one-liner; never silent).
2. **Fetch + verify the SDK bundle**: `~/.vclaw/agent.js` from our signed CDN, checked against the
   Ed25519-signed manifest — one file, zero deps, works on every runtime because it runs as a subprocess.
3. **Install the chosen runtime at its latest stable**:
   - **prime-agent** — from OUR signed release contract (`<base>/latest.json`, hash-verified). ⚠ **GAP,
     measured:** the live mirror serves **v0.9.4 (the TS-era build)** while upstream stable is **0.10.0
     (Rust)** — "latest stable from upstream" is not true today; the mirror must be bumped to 0.10.0 and the
     TS-era assumptions (J5 extension bake — already ruled invalid) retired with it.
   - **OMP** — recommended: add OMP to the SAME signed mirror (deterministic versions, one verification
     mechanism, no omp.sh availability dependency). Alternative: OMP's official `omp.sh/install` now that the
     operator has sanctioned upstream bundling for this path. Either way: **pin + record** the installed
     version.
   - **pi.dev** — unchanged: official installer, opt-in.
4. **Mint or resume ONE identity** (`~/.vclaw/identity.json`, 0600; claim link / browser approval). Re-runs
   resume; a re-run never re-keys silently — user sees the same agent, not a second one.
5. **Wire the runtime** (idempotent, read-modify-write, touching only our entry): prime-agent →
   `~/.prime/agent/settings.json` `mcpServers.vclaw` stdio with ABSOLUTE args; OMP → its wiring/plugin
   contract (`wireOmpMcp`); pi → `~/.pi/agent/mcp.json`.
6. **END WITH THE AUTH LINK — operator ruling 2026-10-14, mandatory on every path (prime-agent, OMP,
   pi.dev):** install → wire → mint → **print the claim/auth link** → (browser approval) → proof. In
   `--no-wait` script mode the link is still printed, then exit 0. No install ends silently. Then the proof:
   `vclaw-agent status` (identity + fabric), the installed runtime version + channel, and one L0 probe
   (`nats request` against the roster/status Micro endpoint). Presence is SIGNED from install time on
   (ruling §5b) — the first signed announcement goes out during the post-claim wiring, from the carrier that
   runtime owns (MCP child for LLM agents; timer recipe + `announce --once` for pre-LLM).

Every card carries the disclosure block (what is installed, from where, at what version, which files are
touched — the R2 consent spirit, applied uniformly).

### 6.3 After install: the takeover, one command family
The user's agent now runs the fabric from its own loop — `nats pub|sub|request` as ordinary shell tools with
the SDK's subject templates, `vclaw-agent sign` for signed acts, `vclaw-agent check-update` extended to also
report the runtime channel (and `--force`-style upgrades through the same funnel). Updates = re-run the same
one-liner; idempotent, same identity, new bundle/runtime version.

### 6.4 Build delta to make §6 real
(a) bump the prime-agent mirror to 0.10.0 + retire TS-era assumptions; (b) `--runtime omp` +
`wireOmpMcp` + the OMP mirror-or-official decision; (c) the vclawhub.com picker + per-runtime commands +
disclosure; (d) `check-update` extension; (e) L0 probe wired into the success output.
---

## 7. Re-organizing the `@vclawhub` scope on JSR for the new model

**Measured starting point (registry, 2026-10-14):** the scope holds exactly THREE packages —
`@vclawhub/agent` **1.4.0**, `@vclawhub/protocol-core` **0.2.2**, `@vclawhub/ext-synadia` **0.2.2**
(the npm.jsr.io aliases are `@jsr/vclawhub__{agent,protocol-core,ext-synadia}`; npm proper stays frozen at
1.0.2 per standing ruling). The reorganization KEEPS three packages and gives each an unambiguous role —
the model changes what is IN them, not how many there are:

| package | role in the new model | what MOVES in / stays | next version |
|---|---|---|---|
| **`@vclawhub/protocol-core`** | **THE WIRE CONTRACT.** Everything a second implementer needs to be byte-compatible: subjects/types, envelope, **canonical bytes v1/v2 + `ANNOUNCEMENT_FIELD_ORDER` + sign/verify (moves here from `agent`'s `contracts.ts`)**, **the `AGENT-SENDER-V1` canonical (Synadia §13 mapping — load-bearing since ruling (a))**, and the **golden fixtures** pinning both schemes | +canonical, +sign, +fixtures; zero I/O deps (nkeys/ed25519 + typebox only) | **0.3.0** — wire ADDITIONS; breaking here = wire break = fabric partition, so 1.0 waits for the Synadia mapping to settle |
| **`@vclawhub/agent`** | **THE SDK.** Fabric client (`net/*`), identity/onboarding **+ the mandatory auth-link terminal act (ruling b)**, the `vclaw-agent` CLI (`mcp`, `sign`, `verify`, `announce --once`, `status`, `onboard`), the pi-family extension entry, MCP fabric verbs | depends on `protocol-core`; **re-exports the canonical surface for one release** so existing `@vclawhub/agent/contracts` importers do not break | **2.0.0** — the new distribution model (MCP fabric verbs, sign CLI, OMP wiring) |
| **`@vclawhub/ext-synadia`** | **THE PROTOCOL EDGE** (ruling (a) makes it load-bearing): `Svcm`/`$SRV.INFO` registration+discovery, `agents.{verb}.*` endpoints, signed-heartbeat parity, `Agent-Sender` emission | depends on `protocol-core` ONLY — usable without the full agent SDK, so a pre-LLM client can speak the Synadia edge without dragging the fabric client in | **0.3.0** |

**Registry vs rails, restated as the organizing rule:**
- **JSR = the TS library surface** (these three). **The CLI/bundle is NOT a registry artefact** — the
  npm.jsr.io alias measurably drops `bin` (and the `pi` field), so `~/.vclaw/agent.js` ships from the
  **signed CDN**, which is also the signer source for pre-LLM bootstrap (ruling b).
- **Rails carry the runtime-specific packaging fields the alias drops:** pi → `pi install npm:` needs the
  `pi` field (**still blocked on open decision (c)**: amend the npm freeze, or serve a CDN tarball); OMP →
  `omp plugin` needs the `omp.extensions` manifest (same mechanism, same open decision); prime-agent →
  `prime-agent package install https://…` takes our CDN tarball directly (no JSR involvement at all).
- **Version policy:** `protocol-core` semver = wire compatibility; `agent` semver = SDK surface;
  `ext-synadia` tracks the Synadia spec version it implements (0.3.x) and says so in its metadata.
- **Nothing is retired from the scope** — the dead experiments (`@vchatemail/a2a-net`, `nats-contracts`)
  lived outside it and are already recorded dead; agent's nine historical versions stay as history.

**Migration order (small, each step releasable):** ① `protocol-core` 0.3.0 with canonical+sign+fixtures
moved in (agent temporarily imports its own vendored copy → swap to the dependency) → ② `agent` 2.0.0 with
re-exports + MCP fabric verbs + `sign|verify|announce --once` CLI → ③ `ext-synadia` 0.3.0 on the new core →
④ rails (blocked only by decision (c) for pi/omp manifests; prime-agent's rail needs no registry change).
---

## 8. Decision (c) guidance: amend the npm freeze, or serve CDN tarballs?

**The mechanics, measured (OMP tree, 2026-10-14) — this is what decides it:**
- **The INSTALL side of both rails is npm-scheme.** OMP's plugin parser literally handles `npm:` specifiers
  (`extensibility/plugins/parser.ts:96-99`, `extractPackageName("npm:lodash")`); Pi's channel is
  `pi install npm:@scope/pkg` (leg A). **Neither one-command rail fetches a URL tarball** (Pi git/URL
  support: UNVERIFIED — pi.dev is not vendored; OMP's is measured).
- **The LOAD side is channel-blind.** Extension discovery reads the LOCAL `package.json` of whatever got
  installed and looks for the `omp`/`pi` extensions array
  (`extensibility/extensions/directory-resolution.ts`) — so ANY channel that delivers a complete
  package.json loads fine, including a manually-unpacked CDN tarball.
- **prime-agent's rail is URL-native** (`prime-agent package install https://…`) — CDN serves it today.

So the real question is not "where do fields live" but **"whose one-liner must work: the runtimes' native
plugin commands, or ours?"** Three options:

| | **A — amend the freeze** (npm carries the real package) | **B — CDN tarballs** (no npm change) | **C — rail wrapper on npm** (freeze intact for the core) |
|---|---|---|---|
| `pi install npm:` / `omp plugin add npm:` | ✅ native | ❌ (installers don't fetch URLs) | ✅ native |
| `prime-agent package install https:` | (n/a either way) | ✅ | ✅ (CDN unchanged) |
| our funnel (front door, §6) | ✅ | ✅ | ✅ |
| npm freeze ruling | reversed | preserved | preserved in letter **and substance** (core still single-sourced on JSR) |
| version-sync burden | dual-publish every release — the exact thing the freeze existed to prevent | none | one mechanical stamp: wrapper version ← `jsr.json`, with a CI drift gate (wrapper ≠ core = red) |
| infra / security surface | npm token + provenance, npm availability | already ours (signed CDN, Ed25519 manifest) | small: one ~zero-code npm package |
| ecosystem discoverability | full npm | none | npm listing for the wrapper only |

**Recommendation: C, with B underneath — the narrow amendment, not the broad one.** Publish ONE tiny npm
package (`@vclawhub/agent-rails`) whose entire content is: the `pi.extensions` + `omp.extensions` manifests
and stub files re-exporting the extension entry from the JSR alias (`.npmrc` `@jsr` alias — which our funnel
already ensures per ruling R5 — or Bun's native `jsr:` specifier under OMP). The CORE stays frozen on npm at
1.0.2 forever; version truth stays `jsr.json`; the bundle/signer stays on the signed CDN. Users inside the
runtimes' own UX get native one-liners; everyone else uses the funnel; nobody gets a second source of truth
for code.

**What would change this answer:** (i) if the funnel is declared the ONLY supported front door (then B
alone suffices and we skip npm entirely — the cheapest posture of all); (ii) if Pi's installer accepts
git/URL sources (then a git mirror serves that rail without npm — VERIFY before building C);
(iii) if we later want npm dist-tag channels (`beta`) for the core itself (then A's cost is accepted
deliberately).
---

## §9 RULING RECORDED 2026-10-14 (operator, in-session): **JSR-ONLY HOSTING — npm dropped entirely**

> *"can we only use jsr.io to host and allow package download? run auth url prompt for me whenever you
> need access to publish."*

**The wrapper (§7/§8's decision C) is DEAD, and that is a simplification, not a loss.** No npm publish ⇒
**open item ① (npm `@vclawhub` scope ownership) is CLOSED AS MOOT** — there is nothing to unfreeze and no
token to manage.

**How every need is met without npm:**

| need | served by |
|---|---|
| library download (TS consumers, bun) | **JSR only** — `jsr:@vclawhub/agent` natively in Bun; npm/bun clients via the `.npmrc` `@jsr` alias the funnel already ensures (R5) |
| CLI/bundle + signer (pre-LLM too) | the **signed CDN** (`vclawhub.com/agent.js` + `.sha256`, Ed25519 manifest) — unchanged |
| **runtime-native rails** (`pi install` / `omp plugin`) | **git refs** — NOT the npm.jsr.io alias |
| prime-agent rail | `prime-agent package install https://…` (URL-native, CDN) |

**Why the rails are git, not the alias (measured):** the npm.jsr.io alias tarball DROPS the `pi`/`omp`
manifest fields (leg B) — but **git installs read the repo's real `package.json`**, where the fields live.
Both installers accept git sources and PIN refs (L2/L3: pi `git:`/bare URLs with `@tag`; OMP a superset
— `github:`/`gitlab:` shorthands — with `#ref`). So:
`pi install github:chatek/agent-sdk@vX.Y.Z` · `omp plugin add github:chatek/agent-sdk#vX.Y.Z`.

**And why NOT the loader's convention fallback (read from the vendored source, recorded so nobody
re-derives it):** `directory-resolution.ts` falls back to directory conventions when the manifest is
absent (direct index file, then a one-level scan of children). For an ALIAS-installed package that scans
the package root's children — and `src/` has an `index.ts`, i.e. it would load **the library root as the
extension — the WRONG entry**. Convention fallback is therefore NOT a route to alias-installed
extensions; the manifest-bearing git install is. *(The fallback remains the right behavior for OMP's own
unmanaged plugin dirs — just not for ours.)*

**Prerequisites this adds to the ladder:** (i) ship an `omp` manifest field alongside `pi` in
agent-sdk's package.json (same `extensions[]` shape — the loader reads `pkg.omp ?? pkg.pi`,
`directory-resolution.ts`); (ii) confirm the in-tree bundled artifact loads as omp's extension entry
from a git checkout; (iii) the JSR `.js`-export acceptance spike (L3's G-R1/R2) — `jsr publish --dry-run`
validates WITHOUT auth; **when a real publish is needed, `jsr publish` emits an auth URL and the operator
has asked to be prompted with it — that is the standing procedure.**
