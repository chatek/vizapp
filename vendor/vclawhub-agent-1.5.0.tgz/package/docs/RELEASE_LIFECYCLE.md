# RELEASE_LIFECYCLE — the vclaw agent SDK's release design and full lifecycle (install → update → offline → retire → uninstall)

**Sprint:** packaging-strategy prep, 2026-10-14. **Inputs:** four measured legs (L1 lifecycle gaps, L2 rail
sources, L3 rails-wrapper spec, L4 release pipeline — scratch files in `.prime/handoff/packaging-sprint/`,
gitignored; **this doc is the tracked record**), plus the operator's rulings: (a) Synadia adopt-at-the-edge
YES; (b) pre-LLM presence SIGNED + auth link as the mandatory terminal act; (c) **C — rail wrapper on npm**.
**Next release:** agent 2.0.0 / protocol-core 0.3.0 / ext-synadia 0.3.0 / agent-rails 2.0.0 (npm).

---

## 1. Release design — what ships, from where, gated how

**Artifacts per release (8 rows, L4):**

| artifact | where | published by | version linkage |
|---|---|---|---|
| `@vclawhub/protocol-core` | JSR | CLI (private repo — CI cannot publish) | wire semver; 0.3.0 adds canonical+sign+fixtures |
| `@vclawhub/ext-synadia` | JSR | CLI | tracks Synadia spec 0.3.x |
| `@vclawhub/agent` | JSR (version truth = `jsr.json`) | CLI | 2.0.0; **must export `./pi-extension` + publish dist bundles** (L3: the un-bundled source can NEVER connect on pi — nkeys/PRNG seams, `extension-variants.test.ts`) |
| `@vclawhub/agent-rails` | **npm** (new, decision C) | CLI | **stamped = core, absolute lockstep** (wrapper-only fix still bumps core patch — ruling in L3) |
| bundle `agent.js` + `.sha256` | signed CDN | landing push | manifest `latest.json` (+`beta` — supported, **not staged today**) |
| prime-agent release set | signed CDN | release lane | `latest.json`/beta; ⚠ **mirror serves v0.9.4 (TS-era) vs upstream 0.10.0 (Rust) — must bump** |
| OMP release set | signed CDN (new) | release lane | mirror per §6.2 decision |
| `join.ts` + picker page | vclawhub.com | landing push | — |

**Gates (L4's G1–G10):** existing — typecheck, vitest, jsr dry-run, secret-scan. **New:** pi+OMP extension
drift matrix (extends `extension-variants.test.ts`); **golden canonical fixtures** (move
`announcement-fixtures.ts` + port Synadia `--check` vectors for `AGENT-SENDER-V1`); **wrapper+member version
drift** — ⚠ **already red today: member package.json 0.2.0 vs JSR 0.2.2 (L4, measured)**; bundle sha256
determinism; rails error-ladder strings (G-R3); the core-export gate (G-R1/R2 above).

**Channels & rollback:** CDN `latest.json`/beta; env pins `VCLAW_AGENT_BUNDLE_URL` / `VCLAW_PRIME_AGENT_URL|CHANNEL|REQUIRE_SIG`. **JSR = fix-forward only · CDN = git revert · runtime set = repoint + re-sign, old dirs kept.**

⚠ **npm reality check (measured 2026-10-14):** `@vchatemail/agent` AND `@vclawhub/agent` both **404** on
registry.npmjs.org — the "npm frozen at 1.0.2" ruling describes a state npm no longer serves, and
**`@vclawhub` npm scope ownership is unmeasurable from outside** (needs the npm-credential holder).
`agent-rails` cannot publish until that is settled. **Provenance stays OFF** (needs GHA OIDC; we publish CLI-side).

## 2. The lifecycle — states, commands, and what exists vs what we build

```
NEW ──install──▶ INTRODUCED ──claim(auth link)──▶ ACTIVE ──update──▶ ACTIVE'
                                                    │ └─offline/online─▶ OFFLINE ⇄ ACTIVE
                                                    └─uninstall──▶ RETIRED ──▶ (files gone)
```

| stage | user action | exists today (L1, file:line) | build |
|---|---|---|---|
| **install** | `curl …/join.ts \| bun - --runtime prime-agent\|omp\|pi [name]` | pipe idempotent (resume/adopt/fresh JOIN:325-443); signed sha256-gated runtime install (JOIN:826-941) | `--runtime omp` + `wireOmpMcp`; auth-link terminal act + status proof + first signed announcement; timer unit for pre-LLM (**SERVICE_UNITS JOIN:143 only restarts active units — no unit is ever written**) |
| **update** | `vclaw-agent update` | **detect-only**: check-update prints a curl hint (check-update.ts:38-46); runtime update = re-run pipe (JOIN:870-873) | `update` cmd: bundle from CDN (hash-verified) + optional runtime channel; identity untouched; `--bundle <ver>` rollback |
| **offline** | `vclaw-agent offline [--away]` / `online` | **MISSING as command**: shutdown-by-product only (online:false presence.ts:250-253; 90s TTL directory.ts:40); schema offline\|away values **unpublishable** (heartbeat.ts:105) | command + schema fix |
| **retire** | `vclaw-agent retire` | **strong**: vgate retire.go + J16a CLI + J16b zombie-kill | **J16c self-retire** (refused today, retire.ts:104-106) |
| **uninstall** | `vclaw-agent uninstall [--keep-identity] [--with-runtime]` | **THE CRATER**: nothing un-wires `mcpServers.vclaw` (mcp/index.ts:13-15 *disclaims* it); `clear` = credentials tiers only (store.ts:246-261); `retire --purge-local` adds two paths (retire.ts:245-260); **17 write-paths enumerated in L1, none removed** | `uninstall`: announce-offline → retire (default) → **surgical vclaw-only un-wire** (~/.prime/agent/settings.json, ~/.pi/agent/mcp.json, omp) → remove the 17 paths (+ shim, npmrc `@jsr` line **only if we added it**, timer unit, sessions) → `--with-runtime` opt-in (default: leave the runtime, print its own uninstaller) → removal summary |

**Rails wrapper (`@vclawhub/agent-rails`, L3+L2):** thin npm manifest carrier — `pi.extensions` +
`omp.extensions` → `dist/pi.js`/`dist/synadia.js` stubs re-exporting the **bundled** subpath; bytes resolve
via the R5 `~/.npmrc` `@jsr` alias; **host-API deps are peerDependencies** (pi skips peers, OMP remaps to
host — prevents a second host-API instance); no `bin` (CLI stays npm-free). **Git fallback:** both rails pin
refs (pi `git:…@tag`, omp `#ref`) — same content, zero npm; npm stays primary (dist-tags, freshness oracle,
no-git-egress hosts). **Error ladder when the alias is absent:** funnel R5 → print `.npmrc` line → `npx jsr
add` → git tag (exact strings gated). **W1 fallback if JSR rejects `.js` exports:** the wrapper ships the
bundles itself.

## 3. Build order (the ready-to-code ladder)

0. **Fix the member drift** (pkg 0.2.0 → 0.2.2) — trivial; the new gate starts green.
1. **Golden canonical fixtures FIRST** (v1/v2 + `AGENT-SENDER-V1` bytes) — pin the bytes *before* any code moves.
2. `protocol-core` 0.3.0 — canonical+sign move in; fixtures land here; agent re-exports (one release).
3. `agent` 2.0.0 — lifecycle commands (`update`, `offline`, `uninstall`, self-retire), MCP fabric verbs + Micro-exposed roster/status, `sign|verify|announce --once`, `wireOmpMcp` + `--runtime omp`, timer unit, L0 probe, core export `./pi-extension` + dist bundles.
4. `agent-rails` on npm — after **npm scope ownership is settled** (open item ①).
5. CDN — prime-agent mirror 0.9.4→0.10.0, OMP set, beta staging.
6. vclawhub.com picker page + per-runtime one-liners + disclosure.

**Open items for the operator:** ① npm `@vclawhub` scope ownership + token stance (both agent names 404
today — the freeze may be moot); ② pin `bun-version:latest` in workflows; ③ the release packer lives in the
prime-agent repo (needs access); ④ JSR `.js`-exports acceptance (spike; W1 fallback if rejected); ⑤ vendored
OMP 18.9.0 vs live 18.10.4 (refresh before the drift matrix means anything).
