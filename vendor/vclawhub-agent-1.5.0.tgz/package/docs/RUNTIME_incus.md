# RUNTIME_incus — VClaw Runtime as an Incus container (reality check, feasibility, proposal)

**Goal (operator, 2026-09-15):** package the VClaw Runtime with Incus, maximising Incus facilities (networks, btrfs storage, profiles, projects),
so that `curl -fsSL https://vclawhub.com/join.ts | bun -` installs **prime-agent (default)** into a **pre-provisioned Debian trixie Incus container**.

**Method.** Two hosts were driven live over Tailscale; every claim below is marked **[O]** (observed with a command whose raw output is archived under
`.prime/handoff/incus-runtime/`) or **[R]** (read from source/docs). Evidence index in §7. Date of measurement: 2026-09-15.

---

## 0. Verdict

**Feasible — demonstrated end to end — but not with the artefacts that exist today, and not until three specific things are fixed.**

| question | answer |
|---|---|
| Can the pipe install prime-agent into an Incus container? | **Yes** — RC=0, prime-agent v0.9.4 (298 MB) in a `debian-trixie-pi-agent` container with the `pi-agent` profile, run as the unprivileged `debian` user **[O]** |
| Does it work in the image the prototype used (`debian-trixie`)? | **No** — that image has no cloud-init, so the profile is inert, and no DHCP, so it has no IPv4/DNS **[O]** |
| Is prime-agent the default today? | **No** — with no flag/env the pipe installs **no runtime at all** and persists nothing; the SDK default stays `pi` **[O]+[R]** |
| Can a container reach the IDP fabric? | **Half** — tailnet **egress** works through the host with zero extra devices; **inbound requires a `proxy` device**; and **no VClaw NATS is reachable from ct17 at all** **[O]** |
| Are per-agent disk quotas a usable boundary? | **No** — btrfs qgroup limits are **not enforced** (700 MiB written into a 512 MiB volume, rc=0, both pools) **[O]** |
| Is a pre-provisioned container safe to restart? | **Yes** — two `incus restart`s (2.19 s / 1.81 s): same DHCP lease, default route, DNS, networkd+resolved active, unit active, markers intact, no manual fix **[O]** |
| Is `uv` needed, and can a headless container get it? | **Required, hard gate, no silent fallback** — and the interactive installer can never be answered in a container (`stdin.isTTY && stderr.isTTY`), so it must be **baked** or set via `PRIME_AGENT_INSTALL_UV=1` **[O]+[R]** |

The remaining work is not an Incus unknown: it is (1) baking a correct base image, (2) making prime-agent the default in the funnel, (3) putting a reachable fabric endpoint in front of the container.

---

## 1. Reality check

### 1.1 Platform
| | ct17 | kuai |
|---|---|---|
| OS | Ubuntu 24.04.5 LTS | **Debian 13 (trixie)** — the container target OS |
| Incus | **7.0.1**, client = server | client **6.0.4**, daemon **active**, but socket is `root:incus-admin` and user `debian` is **not** in the group |
| usable by our user | **yes** (`chance` ∈ `incus-admin`) | **no** — needs group membership or sudo |

**[O]** The fleet carries an **Incus version skew** (6.0.4 vs 7.0.1), and the host that *is* trixie is the one we cannot drive.

### 1.2 What already exists on ct17 — a July prototype of exactly this architecture
- Pools: `sda-data` (btrfs, `/opt/sda-data`, 932 G, **251 G free / 74 % used**, zstd) and `btrfssdb` (btrfs, `/var/lib/docker`, 932 G, 845 G free, lzo). One project (`default`). ~27 containers, nearly all stopped. **[O]**
- Image **`debian-trixie-pi-agent`** (682 MiB, "cloud", 2026-07-20) and profile **`pi-agent`**, whose cloud-init writes `/etc/profile.d/pi-agent.sh` (`NATS_URL=nats://10.148.17.1:4222`, `VMAKER_LXC=1`) and creates `pi-auto.service` with `ExecStart=/usr/bin/sleep infinity`. **[O]**
- **The prototype is inert in the wrong image, but the `(cloud)` image is a sound base.** Plain `debian-trixie` has **no cloud-init**, so the profile never ran there.
  In `debian-trixie-pi-agent` cloud-init **is present and runs** (v25.1.4, 12 modules, 0 failures, ~30 s), network comes up automatically
  (`10.148.17.194/24` via DHCP, default via `10.148.17.1`, DNS resolving, `10-cloud-init-eth0.network` written), and the profile's user-data applies
  (env file, `pi-auto.service` enabled+active, ready marker, packages). **[O]**
  What that image still lacks: **no prime-agent anywhere**, **no `uv`, no `jq`**; it does bake `bun 1.3.14`, `node 22.23.1`, `npm`, `python3 3.13.5`, `git`, `unzip`, `curl`, `tar`;
  it also carries **`@earendil-works/pi-coding-agent 0.80.10` as `/usr/bin/pi`** (the *pi.dev* runtime), the alias is **past its Expires date**, and leftover build residue exists. **[O]**

### 1.3 Funnel reality (the command the operator wants)
| measurement | value |
|---|---|
| `curl -fsSL https://vclawhub.com/join.ts \| bun -` | **rc 0, 3.02 s, 257 KiB** — identity, jsr npmrc, bundled `vclaw-agent` (`agent.js` 969,705 B), 15-minute claim URL. Installs **no runtime**. **[O]** |
| with `--runtime prime-agent` | **rc 0, 28.90 s, 47.3 MiB wire, 249 MB on disk**, prime-agent **v0.9.4** verified via `prime-agent --version` **[O]** |
| without a runtime, after the pipe | claim reaches "Status: pending" then dies: `❌ Claim wait failed: getaddrinfo ETIMEOUT vchat3` **[O]** |
| reliability | **1 of 2 runs died at `bun install -g`** (a URL dependency failed to resolve) **[O]** |

**Two defects in the funnel itself, both independent of Incus:**
1. **prime-agent is not the default** (`join-script.ts:136 runtimeChoice = (runtimeArg || VCLAW_RUNTIME || "").trim()`; `:177 if (runtimeChoice)` → install+persist only when asked). The SDK resolver's final fallback is `"pi"`. Making prime-agent the default is a **code change**, not a config.
2. **`https://vclawhub.com/prime-agent/latest.json` is served inconsistently**: **820 B `application/json` from ct17** but **43,002 B `text/html` (SPA fallback) from a Mac** (5/5 tries, same minute). `join.ts`'s JSON guard turns the HTML into a hard error, so **installing prime-agent fails from some locations today** **[O]**. `landing-removed/public/prime-agent/` is gitignored, i.e. the artifacts are fetched at deploy time — a missed fetch leaves exactly this fallback.

### 1.4 Fabric reality
- **Tailnet egress from a container works, with no device**: an `ip rule` (`5270: from all lookup 52`) applies to *forwarded* packets, table 52 carries default + peer routes via `tailscale0` (+ exit node `vchat3`), and Incus masquerades to the out-interface address. tcpdump proof: container TCP to `100.64.1.16` leaves as `100.64.1.17 > 100.64.1.16` (SSH banner returned). Internet egress also rides the exit node (host and container share public IP `209.38.136.237`). **[O]**
- **Inbound is impossible**; the mechanism that works is a `proxy` device — `listen=tcp:100.64.1.17:18080` answered **HTTP 200** from a tailnet peer. **[O]**
- `10.148.17.1:4222` (the profile's `NATS_URL`) = **connection refused**, inside and on the host. `login.vclawhub.com` is **public**, not tailnet-internal (302 → `agents.vclawhub.com`, Cloudflare). **NATS 2.11.2 exists only inside the unrelated `timeliner` container** (`10.148.17.224`); **no VClaw NATS was found** on the host, `lxdbr0`, `vchatidp`, or any online tailnet peer. **[O]**
- Consequence: a ct17 container currently has **no working route to the VClaw fabric**. That is a deployment gap, not an Incus limitation.

### 1.5 Facility limits that matter
- **[O]** btrfs **qgroups are not enforced** (700 MiB into a 512 MiB volume: rc=0 on both pools; rescan stuck) → a declared size is not a boundary.
- **[O]** Network ACLs exist and can be created, but *enforcement* on `lxdbr0` requires editing the shared bridge config. No cluster.
- **[O]** Container snapshot: **27.07 s first / 1.26 s after**; restore **2.29 s** and it **restarts the container**. Volume snapshot 1.674 s; volume restore is **refused while attached** ("Cannot restore custom volume used by running instances") and 1.20 s after a stop (stop itself times out gracefully at 30 s; `-f` = 0.9 s). btrfs exclusive use is only 8–16 KiB vs 477 MiB shared, so snapshots are cheap. `-t custom` is invalid in 7.0.1 → `-t filesystem`.
- **[O]** Verified available: network ACLs/zones, projects with features+limits, cloud-init, `launch --ephemeral`, `exec`/`file`, `config device add` (disk|nic|proxy), instance+volume snapshots, snapshot schedules/expiry, `incus publish` (1 m 50 s → 684 MiB), storage buckets, `/1.0/metrics`.

---

## 2. Feasibility — the proven path

**Base = a cloud-capable trixie image; plain `debian-trixie` is a dead end.** In `debian-trixie-pi-agent` + `--profile pi-agent`, as user `debian`:
`prime-agent v0.9.4 (298 MB)` + `config.json` + identity + the `vclaw-agent` CLI, **RC=0, 9 s warm / 31 s cold** **[O]**.
The cloud image differs because cloud-init writes `10-cloud-init-eth0.network` → **DHCP + DNS work**, and the profile's user-data actually applies (packages, env file, unit).

### 2.1 Requirements, and who satisfies them
| requirement | stock `debian-trixie` | `debian-trixie-pi-agent` (cloud) | who must provide it |
|---|---|---|---|
| cloud-init (consumes the profile) | **absent** — profile inert | **present** | image (bake) |
| IPv4 + default route + DNS | **none** (networkd unconfigured) | works (cloud-init) | image |
| `curl`, `apt`, `tar`, `sha256sum` | present | present | image |
| **`bun`** (the pipe is run BY it and never installs it) | missing | **1.3.14** | image |
| `unzip` (bun's installer needs it) | missing | present | image |
| node | missing | 22.23.1 | image |
| **`uv` / python3** (RLM kernel) | missing | python3 **3.13.5** yes, **`uv` NO** | **required**, with no silent fallback: `PRIME_AGENT_INSTALL_UV=1` installs uv 0.12.14 (49.3 MB) and builds a Python 3.11.16 venv (273 MB) in **100.4 s**; otherwise bake uv. A headless container cannot answer the prompt at all |
| prime-agent | — | **absent** (`/usr/bin/pi` = pi.dev 0.80.10, wrong product) | image (bake v0.9.4) |
| SDK extension in `~/.prime/agent/extensions` | — | — | **blocked** by the `dist/` publish blocker (see `docs/RUNTIME_SELECTOR.md` sibling sprint) |
| supervisor unit | — | `sleep infinity` | profile cloud-init (real unit) |
| identity / claim | — | — | **the pipe** (never baked) |

### 2.2 Failure modes that will bite, in order
1. **Inert profile** — launch exits 0, nothing happens (§1.2).
2. **No network** on a non-cloud image — no IPv4, DNS fails, `curl` exit 6.
3. **`bun` missing** — the one-command form cannot even start; the installer also errors with `unzip is required`.
4. **`uv` missing + non-TTY is a hard stop.** Exact error (exit 3, 0.08 s): *"Failed to set up the Python kernel runtime. uv is required… Install uv yourself: `curl -LsSf https://astral.sh/uv/install.sh | sh`, or set `PRIME_AGENT_INSTALL_UV=1`… Set `PRIME_AGENT_KERNEL_PYTHON` to a Python with a current `prime-agent-runtime`…"*.
   `confirmUvInstall()` requires `stdin.isTTY && stderr.isTTY`, so **a headless container can never answer the prompt** — the channel must be a baked `uv` or the env var, never an interactive fix. Verified fix: with `PRIME_AGENT_INSTALL_UV=1` the kernel came up "✓ ready" (venv passes the rlm runtime check, imports all default extras + dill); a later call with no env and stripped `PATH` found `~/.local/bin/uv` in 0.18 s.
5. **No model credential in a fresh container** — `prime-agent -p "reply with OK"` → rc 1, *"No API key found for the selected model."* The run cannot succeed until the per-agent provider credential is supplied.
6. **Root-owned state** — running the pipe as root with `HOME=/home/debian` leaves root-owned `0600`/`0700` `config.json` and `~/.vclaw`; the agent user then cannot read them. Run it **as the agent user**.
7. **No fabric** — the claim cannot complete (`vchat3` unresolved, no reachable NATS).
8. **The pipe's dependency fetch is the slow, flaky leg.** The same command took **~25 s as `debian`** and **321 s as root** in the same container; probes show
   `registry.npmjs.org` TLS 5.2 s and `npm.jsr.io` TLS 4.9 s versus `vclawhub.com` 0.57 s, with npm at **51 KB/s** against vclawhub's **1.95 MB/s**.
   Baking prime-agent **and** the CLI bundle removes both slow legs from the boot path; a packaged installer must still retry/tolerate a slow npm.
9. **Volume restore while attached is refused**, and container restore restarts the container — a snapshot/restore policy must account for both.

---

## 3. Proposed solution — the VClaw Runtime on Incus

### 3.1 Layers (each layer owns exactly one kind of fact)
```
image (bake)            runtime + toolchain, NO identity            vclaw-agent:trixie-<runtime>-<ver>
profile (cloud-init)    env, DNS, unit, extension symlink, devices  vclaw-agent
instance (per agent)    1 container = 1 agent = 1 $HOME = 1 agent dir
volume (per agent)      ~/.prime/agent state, snapshot/restore      agent-<nkey>-state
network                 egress via host tailnet (free); inbound via proxy device per exposed port
project (optional)      per-tenant grouping + limits                (later)
```

**One container = one agent = one `$HOME` is the key invariant.** It also dissolves a defect found in the sibling sprint: prime-agent's supervisor-owner registry is hardcoded to `$HOME` and ignores the agent dir, so a relocated agent dir is not isolated — in a container, `$HOME` *is* per-agent, so the registry stops being a hazard.

### 3.2 The pre-provisioned image (bake)
Debian trixie **cloud-capable** base + `bun` + **`uv` (pinned 0.12.14)** + `unzip` + `git`/`curl`/`ca-certificates` + **prime-agent v0.9.4 pinned** + the SDK extension bundle. **No identity, no config, no runtime choice.**
**Sizing (measured):** the image is 682 MiB; a *ready* agent adds ≈**570 MB** (`prime-agent` ~249 MB + `uv` 49 MB + kernel venv 273 MB) → **~1.25 GB per ready container**; bootstrap peak memory reached **1.05 GiB against a 2 GiB profile cap**, so the cap is a real constraint during first-run bootstrap.
**The kernel venv is per-agent state, not image content** — it costs ~100 s to build, so it belongs on the state volume (snapshotted), not re-created per container. Rebuild from a script (not by hand) so it is reproducible; drop the stale `pi-coding-agent 0.80.10` and the expired alias.

### 3.3 The profile (`vclaw-agent`)
- `cloud-init.user-data`: env file with `VCLAW_RUNTIME=prime-agent`, `PRIME_AGENT_INSTALL_UV=1`, correct `NATS_URL` + tailnet DNS names, `PATH`; a **real** systemd unit (prime-agent `--mode daemon`, `Restart=always`), the extension symlink into `~/.prime/agent/extensions`, and a readiness marker that is *asserted* by the acceptance gate.
- devices: `disk` (the per-agent state volume → `/home/debian/.prime/agent`), `nic` (the managed bridge), `proxy` (only for ports that must be reachable inbound).
- limits: cpu/memory. **Disk limits are decorative** (§1.5) — see §3.6.

### 3.4 The one-command flow (target)
```bash
incus launch vclaw-agent:trixie-prime <agent> --profile vclaw-agent      # pre-provisioned, no identity yet
incus exec <agent> -- su - debian -c \
  'curl -fsSL https://vclawhub.com/join.ts | bun -'                      # identity + claim + config only
```
`--runtime prime-agent` must become the **default** so the documented one-liner is literally correct. The pipe then downloads no runtime (it is baked), which also removes the `bun install -g` reliability failure observed on 1 of 2 runs.

### 3.5 State, snapshots, restore
Per-agent **custom volume** for `~/.prime/agent` (not the container root): it survives container rebuilds and is the thing worth versioning. Policy: snapshot on demand + before upgrades; **restore requires the volume detached** (stop the container first); containers are treated as disposable, the volume as durable. Cheap because btrfs data is shared (8–16 KiB exclusive). The transcript-safety case from the sibling sprint (no host identity in prime-agent leases; one agent dir per host) is satisfied by one volume per container.

### 3.6 Isolation without quotas
Because qgroups do not enforce, choose explicitly:
1. **Class-per-pool** (e.g. `sda-data` for interactive agents, a separate pool/quota for unattended ones) — physical separation is the only real limit.
2. **Monitor + alert** (`/1.0/metrics`, per-instance disk) with a scheduled sweep.
3. **`incus publish` + recreate** as the reset path when an agent's volume grows.
Do **not** document a volume size as a boundary until a negative control proves it fails closed.

### 3.7 Fabric connectivity — RESOLVED: option A, and the fabric was never missing
> **SCOPE CORRECTION 2026-09-16 — read before applying this anywhere but `ct17`.** Option A below was
> validated **on `ct17`, which lives in the `ruffe-court.ts.net` tailnet, the same tailnet as `vchat3`**. It does
> **not** extend to hosts in another tailnet. Measured on **`kuai`** (`finch-iwato.ts.net`) the same day:
> `tailscale status` lists **no `vchat3` peer at all**, and TCP to **`100.106.248.70:4223` times out** — so for
> `kuai` the fabric endpoint is not reachable by name, by IP, or by egress, and the DNS fix in this section
> cannot help (there is nothing to resolve *to*). Kuai-side consequence: a service on `kuai` that needs this
> fabric must attach through a broker it *can* reach (see `apps/kuai/docs/WA_NETWORK_TOPOLOGY.md`, which places
> the broker on the WhatsApp edge and dials **outbound** from `kuai`). Recorded on the kuai side as register row
> `O63`; the claim here is scoped to `ct17` until a `kuai`-side path is measured.
> *(Reported by kuai's lead, who could not resolve this citation because this file lives in the vchat.email
> repo, not the kuai repo — correct routing: the scope fix belongs here.)*

**Decision: A** — containers reach the fabric over the host's tailnet **egress**, with the container's **per-link DNS pointed at the tailnet resolver**. No proxy, no
per-container `tailscale`, no new port, no new credential — and **no agent-sdk change**, because the SDK's own default string then works verbatim.

**Evidence (lane F, lead-verified):**
- **The agent needs no inbound at all [O]+[R].** Every inbound path in the SDK is an `nc.subscribe`; every outbound is publish/fetch; the only listener binds `127.0.0.1`
  (`daemon/serve.ts:232-246`). One outbound TCP to NATS + outbound HTTPS is the entire requirement.
- **The fabric is real and reachable [O].** `vchat3` = tailnet node `100.106.248.70` (lead-verified: `vchat3.ruffe-court.ts.net`, and it *also offers the exit node*
  ct17 uses). `vchat3:4223` is NATS **2.11.5** (`auth_required`, JetStream) — INFO banner captured; `:4224` is NATS **WebSocket** (HTTP 101 + INFO). From a container the
  **IP connects fine** (`100.106.248.70:4223` OK); only the **name** failed (`NXDOMAIN`). DNS was the whole gap.
- **The DNS fix works end to end [O].** Launching with `-c cloud-init.network-config=<netplan: nameservers [100.100.100.100] + search ruffe-court.ts.net>` makes cloud-init
  render DNS into the **per-link** file; `resolvectl` then shows `100.100.100.100`, `getent hosts vchat3` returns `100.106.248.70`, and a **full NATS CONNECT/PING round trip**
  succeeds from inside an unprivileged container (53/tcp+udp ≤8 ms, 8/8). Search-domain-only also works.
- **Gotcha [O]:** a global `resolved.conf.d` `DNS=` does **not** work — the per-link DHCP DNS carries `+DefaultRoute` and wins. It must be per-link (i.e. written by cloud-init's network config, which is what the recipe does).
- **Falsifier already run [O]:** with the resolver removed, the same container cannot address `vchat3` (rc=2). The causal claim is tested, not assumed.

**Why A is also the canon-correct choice** (`docs/UNIFIED_A2A_FABRIC.md` V3.1): an agent-sdk agent is an **IDP agent (per-agent JWT)**, whose canonical attachment is the hub —
that is what `nats://vchat3:4223` is. The SITE class (local Synadia mesh + leaf, hub admitting one principal per site) is a *different principal class* for intranet deployments;
it is not required here, and it would add a NATS server, a leaf credential and a second endpoint for one container per agent.

**⛔ Blocker to fix in P2 (found by lane F):** the existing `pi-agent` profile injects a **dead** address —
`/etc/profile.d/pi-agent.sh` and `pi-auto.service` both set `NATS_URL=nats://10.148.17.1:4222`, and `pi-extension/index.ts:68` reads `env("NATS_URL") || "nats://vchat3:4223"`,
so the profile's value **overrides the working default** and points at nothing. The new `vclaw-agent` profile must not set `NATS_URL` at all (or must set the correct one).

**Caveats that come with A:**
- **No per-agent network isolation [O].** Containers are masqueraded as `100.64.1.17`, so they inherit ct17's tailnet identity and filter; `tailscale debug netmap` shows
  **2 default-allow rules**, no subnet routers, TKA off. Isolation must therefore come from **NATS identity** (per-agent JWT + grants), which is the IDP's model — do not
  claim tailnet isolation for agents.
- **Fallback C is proven** if DNS injection ever becomes impossible: a `proxy` device forwards full NATS traffic (`listen=tcp:10.148.17.1:24223 connect=tcp:100.106.248.70:4223`,
  `connect=` must be an **IP**; an `0.0.0.0` proxy on one container serves **every** container on the bridge — measured). It costs a host process and muddies the trust boundary.
- **Future B** (per-container `tailscale`): capability is proven (`/dev/net/tun` present, `CapEff` includes `net_admin`+`sys_admin`, `ip tuntap add` rc=0) but **auth is untested**
  (needs a throwaway tailnet key). This is the answer *if* per-agent network isolation is ever required.

---

## 4. Migration plan (dependency-ordered)

| phase | content | gate |
|---|---|---|
| **P0 — fix the funnel** | make prime-agent the default (funnel default + SDK `DEFAULT_RUNTIME`); fix the `latest.json` SPA-fallback serving; re-verify digests | `curl … \| bun -` with no flags installs prime-agent vX; manifest served as JSON from **two** locations | — **2026-09-16: default landed in the funnel (landing@7dad7ad); serving root-caused** (live Pages deploy serves NOTHING under /prime-agent/ from origin, warm-cache countdown; fix = wrangler Pages login + `pnpm deploy:pages`; monitor `scripts/verify-funnel.mjs` added, currently HARD-FAIL on prod)
| **P1 — bake the base** | build `vclaw-agent:trixie-prime` from a script: cloud base + bun + uv + unzip + pinned prime-agent + extension bundle, no identity | inside the image: `prime-agent --version`, `uv --version`, the extension loads (`get_commands` = 5), no `~/.vclaw` present | **DONE 2026-09-16**: image `vclaw-agent/trixie-prime` fp `e7ccedc63ada…`, 797 MiB packed / 2237 MB rootfs, all gates green (versions, no-identity, no NATS_URL anywhere, DNS+NATS reachability, restart-safety) — extension NOT in image (blocked by v8 publish, J5); see §8 + lane report D-incus-P1-bake.md
| **P2 — profile + volume** | `vclaw-agent` profile (cloud-init env/unit/extension/DNS, disk volume, nic, proxy when needed) + the per-agent state volume | launch → unit active, marker written (asserted), IPv4+route+DNS up, volume mounted at `~/.prime/agent`; **restart-safe: GREEN** (`incus restart` ×2 — same lease, route, DNS, unit active, markers intact; cloud-init's per-instance semaphores make packages/write_files/runcmd run once while the datasource+network stage runs every boot, which is what keeps DHCP working) |
| **P3 — fabric** | a reachable NATS/IDP endpoint for ct17-hosted agents + the inbound proxy where required | a container completes a claim **and** appears in the fabric (presence) — the acceptance run |
| **P4 — one-command acceptance + fleet** | in-container host-readiness gate (`D7-host-checks.py`) + the pipe + claim + presence as one scripted gate; kuai parity (Incus 6.0.4, group/permission, version skew); snapshot/restore drill | a fresh container reaches "agent ready + present" with **one command**, and the D7 gate exits 0 **inside** the container |

## 5. Jobs

| id | job | depends on | acceptance |
|---|---|---|---|
| J1 | Funnel default → prime-agent; SDK `DEFAULT_RUNTIME` | — | no-flag run installs prime-agent |
| J2 | Fix `latest.json` serving (SPA fallback) + artifact deploy check | — | JSON from ≥2 vantage points; digests verified |
| J3 | Image bake script + publish `vclaw-agent:trixie-prime` | J1 | §P1 gate; rebuild is one command |
| J4 | Profile v2 (cloud-init, unit, DNS, devices, limits) | J3 | §P2 gate, marker asserted |
| J5 | Extension install into `~/.prime/agent/extensions` | the `dist/` publish blocker (OD-1 in the sibling sprint) | `get_commands` returns 5 `vchat-*` in-container |
| J6 | Fabric endpoint + inbound proxy for ct17 agents | — | container completes a claim and shows presence |
| J7 | Per-agent state volume + snapshot/restore policy (detach-before-restore) | J4 | restore drill passes with the container stopped |
| J8 | In-container host-readiness gate (reuse `D7-host-checks.py`) | J3,J4 | exit 0 inside the container; negative control flips |
| J9 | kuai parity: `incus-admin` membership/sudo + version skew decision | — | same acceptance on 6.0.4 or a documented reason |
| J10 | Observability: per-instance metrics + agent panel column | J4 | disk/CPU/agent state visible per instance (note: `incus list -c n,d,4` prints **no** disk usage in 7.0.1 — the `4` resolves to IPv4; use `incus info`) |
| ~~J11~~ | Reboot survival — **ANSWERED, PASS** | — | two restarts: same DHCP lease, route, DNS, unit active, markers intact |
| ~~J12~~ | `uv` necessity — **ANSWERED: required** | — | exit-3 hard gate with no silent fallback; fix verified (`PRIME_AGENT_INSTALL_UV=1`) |
| J13 | Per-agent sizing + memory cap | J3,J4 | disk ≈1.25 GB/ready agent and bootstrap peak ≤ the profile cap (measure a first-run bootstrap under the cap) |
| J14 | Per-agent provider credential path | J4 | a real agent turn runs in-container (currently rc 1: "No API key found for the selected model") — keyless image + operator/SDK-supplied credential |
| J15 | `incus-repackager` skill — `SKILL.md` + Bun/TS runner, FAST path (launch→push→install→publish) | J3 | rebuild is ONE command; publishes `vclaw-agent:trixie-prime-<ver>`; duration+size recorded from a real run here, not a vendor figure (§8) |
| J16 | Validation lifecycle: pipe-claim → asserted markers → presence → identity CLEANUP — the SDK CLI has no `retire`/`revoke` today (`src/cli.ts`: 0 hits). **Proposal: `docs/AGENT_RETIRE.md`** (J16a CLI · J16b runtime subscriber · J16c vgate NKey-proof path) | J15 | a validation run leaves ZERO residual identities; the cleanup path is decided (SDK command vs operator dashboard) |
| J17 | `distrobuilder` evaluation in a builder container on ct17 (install + one timed trixie build) — or a documented rejection of it as the clean path | J3 | a measured build time on THIS fleet; never a vendor figure |
| J18 | Forgejo/act-runner trigger: pushed tag → rebuild+validate → hold at `:trixie-prime-<ver>`; `:stable` flip stays operator-gated | J15,J16 | a pushed tag produces a validated image WITHOUT flipping `:stable` |
| J19 | Nightly **throwaway-container** image gate in CI: launch the published image, assert agent version + kernel-venv import + extension `get_commands`==5 + NATS reachability, destroy it | J15,J18 | the gate goes RED when an assertion is falsified (mutation check), and it retires the hand-copy drift class (kuai O52) — §10.4 E1 |
| J20 | Image **transport** measurement: `incus remote add --protocol oci` against our Forgejo vs `incus image export` + local simplestreams | J15 | a measured pull path on THIS fleet, or a documented rejection of OCI — §10.4 E1 |
| J21 | Incus OS **nested-VM spike on ct17** (documented `virtual-incus` recipe), §9.4's four questions with Q1 narrowed to container device visibility | J17 | four pass/fail results with raw output; `/dev/dri`+`/dev/kfd` visible in-container and `mem_info_vram_used` non-zero, **or** a documented limitation — §10.2/§10.4 E2 |
| J22 | **Node-class prerequisites + policy**: physical-TPM check, recovery-key custody, update `channel`/`maintenance_windows`/`auto_reboot`, one API-driven A/B revert drill | J21 | an operator checklist executable **without a shell on the node** — §10.4 E3/E4 |

## 6. Open operator decisions
1. **Fabric topology** (§3.7 A/B/C) — recommendation **A + a real NATS endpoint on/near ct17**.
2. **Where the fabric endpoint lives** — deploy a VClaw NATS leaf on the host, or point agents at the existing one (none reachable today).
3. **Pool choice** — recommendation `sda-data` (zstd, holds profiles) despite only 251 G free; `btrfssdb` has more space but sits on `/var/lib/docker` and is the pool the CHANGELOG wants re-laid out.
4. **Isolation expectation** — accept "monitor + class-per-pool" instead of enforced quotas (§3.6)?
5. **kuai** — grant `incus-admin` (or sudo) and decide the version support matrix (6.0.4 vs 7.0.1).
6. **CI venue + flip authority** (§8) — operator-run skill first, ct17's act-runner (already up, per the
   ct17 lane report 2026-09-15) later (J18). In BOTH, **flipping `:stable` stays operator-gated**: build
   and validate may run automatically, promotion may not — the same commit-vs-deploy separation as the
   O36 ruling.
7. **Validation-identity cleanup** (J16) — `src/cli.ts` has `onboard` but no `retire`/`revoke`, so a
   validation claim leaves a residual identity. SDK addition, or operator-dashboard-only?
8. **CLEAN-path base provenance** (J17 — `docs/J17_DISTROBUILDER_EVAL.md`) — the CLEAN path presupposed
   *"a cloud-capable trixie base"*, but the only one on the fleet is `debian-trixie-pi-agent`: an
   **expired (2026/08/18) July prototype** carrying pi 0.80.10 + `NATS_URL` artifacts in three locations
   + build residue — the exact tax the P1 bake purged in stages 4b/4c, inherited by every future clean
   bake. Choose **A** scripted bake from public `images:debian/trixie/cloud` (zero tooling — but *D1:
   `bake.sh`'s python3 manifest parser, `bake.sh:60`, breaks on a pristine base*, so the proven script
   must be modified), **B** `distrobuilder` (in-repo definition + pinned mirror + sha256 in the run log;
   tooling confined to a throwaway privileged builder container; `--type container` only, no alias
   written, no identity), or **C** status quo. *Recommendation: judge on **provenance, not speed** — CLEAN
   runs only on base/toolchain changes, so 2–3× slower still wins if it permanently kills the
   expired-prototype class — and let the operator-gated timed run be the gate.*

## 7. Evidence index
- Lanes (all under `.prime/handoff/incus-runtime/`): `D-incus-A-facilities.md` (+ `raw-D/`), `D-incus-B-requirements.md` (+ `raw/DB-*`), `D-incus-C-feasibility.md` (+ `raw-c-ct17/`), `00-FINDINGS.md` (consolidated ledger).
- Raw measurements: launch 0.885 s; pipe 3.02 s/257 KiB and 28.90 s/47.3 MiB/249 MB; prime-agent 0.9.4; snapshot 27.07 s→1.26 s; restore 2.29 s; volume snapshot 1.674 s; restore-after-stop 1.20 s; stop timeout 30 s (`-f` 0.9 s); `join.ts` 33,716 B sha256 `cbeec6a5603b…`; `agent.js` 969,705 B sha256 `7673a924…`; prime-agent tgz 10,030,390 B; edge HTML 43,002 B vs JSON 820 B.
- All test containers (`vcx-c-*`, `dreq-probe*`, `dincus-*`) deleted and verified; no pre-existing instance, profile, pool, network or image was modified.
- Sibling sprint (agent-sdk runtime seam): `.prime/handoff/agent-sdk-prime-agent/03-REFACTOR-PLAN.md` — the extension publish blocker and the host-readiness gate are the same artefacts referenced here.

---

## 8. CI/CD as an agent skill — consolidation of two proposals (2026-09-16)

**Inputs (operator instruction, 2026-09-16).** Two external proposals, reviewed against this
document's measured facts rather than their own assertions. **(A) "skill-driven Incus packaging"** —
CI/CD as agent skills: a Markdown skill, a Python-backed executor, a Python orchestrator,
`distrobuilder` per release, and vclaw onboarding run inside the test container during the build.
**(B) a critique** — Bun/TS-native execution, stateless images with first-boot identity, dual-path
builds. **The two never disagreed on the idea — CI/CD as an invocable, improvable skill — only on
runtime, identity timing, and build weight. All three are settled by this document's own
measurements.** Every ruling cites its grounding.

### 8.1 Rulings on proposal A

| claim | ruling | grounding |
|---|---|---|
| CI/CD becomes a skill the agent invokes and improves | **ADOPT** — and already half-true here: J3's acceptance *"rebuild is one command"* IS a skill-shaped control | §4 P1, J3 |
| Markdown `SKILL.md` interface | **ADOPT** | — |
| Python executor + orchestrator (`pyproject.toml`, `asyncio`) | **REJECT — toolchain contagion.** This SDK is TypeScript on Bun (`bun.lock`, `tsc`, `vitest`, `bin/agent.js`); the pipeline is one runtime. Python stays *inside the image* as prime-agent's kernel (uv venv, §3.2) — that is runtime, not build tooling | `package.json` |
| `distrobuilder` for every release | **REJECT as the routine path** — and distrobuilder is **installed nowhere on this fleet** (absent from the §1.2 inventory); it cannot even be the *clean* path until a build is timed here (J17) | §1.2, J17 |
| onboarding run inside the build (`incus exec … npx … onboard`) | **REJECT — violates the stateless-image invariant.** §3.1: the image carries *"runtime + toolchain, NO identity"*. Baking one NKey bakes ONE identity for EVERY instance of the image — a shared credential inside a template, the exact class this fleet spent 2026-09-15 removing (O42/O44/O50). Identity is per-instance, minted by the pipe at launch | §3.1, §3.2, §3.4 |
| `npx @vchatemail/agent-vclaw onboard` | **WRONG PACKAGE** — the SDK is `@vclawhub/agent`, bin `vclaw-agent`, `onboard` at `src/cli.ts:60` | `package.json`, `src/cli.ts` |
| rollback by keeping the previous alias | **ADOPT** — `:stable-prev`, matching ADD→FLIP→SOAK→DROP (the retired alias is the rollback target, not dead weight) | §8.3 |
| credentials in `auth.json`, never env/argv | **ADOPT** — argv is world-readable via `systemctl show` (O37); a `0644` env file is a proven breach class (O44) | O37/O44 |
| Forgejo/CI triggers (its P5) | **ADOPT, deferred** — and the runner half exists: act-runner is up on ct17 (ct17 lane, 2026-09-15) | J18 |

### 8.2 Rulings on proposal B

| claim | ruling | grounding |
|---|---|---|
| Bun/TS-native execution | **ADOPT** | `package.json` |
| stateless images + first-boot identity | **ADOPT — already this document's invariant** (§3.1). But the first-boot mechanism is **the pipe** (§3.4, measured end to end), not a new `vclaw-init` unit: a second identity path duplicates `onboard`. If claim-on-boot is wanted, the prime-agent unit invokes the pipe once, marker-gated — one identity path, not two | §3.4, `src/cli.ts:60` |
| dual-path build (fast overlay vs clean rebuild) | **ADOPT** | §8.3 |
| **"total execution time is sub-5 seconds"** | **FALSE on this fleet.** Measured `incus publish` here: **1 m 50 s → 684 MiB** (§1.5 [O]). The fast path is *minutes*, not seconds — still the right path (a re-bake is far slower), but the figure comes from §1.5, not a demo. *A performance number is only as good as its vantage* | §1.5 [O] |
| `incus file push ./dist/pi …` | **WRONG BINARY** — the image's product is **prime-agent**; `/usr/bin/pi` is pi.dev 0.80.10, the WRONG product, scheduled for removal (§3.2) | §1.2, §3.2 |
| launch → push → stop → publish → delete | **ADOPT the shape**, with our exec form (`su - debian -c`, §3.4) and the stdin caveat: `incus exec` swallows stdin, so nothing in the path may prompt — §2.2.4 proved a headless prompt is unanswerable (exit 3) | §2.2.4, §3.4 |

### 8.3 The consolidated design — ONE skill, two paths, zero identity

```
skill    incus-repackager              SKILL.md + src/index.ts (Bun/TS), versioned in this repo

FAST      routine runtime/extension release                  [publish: 1 m 50 s / 684 MiB — §1.5 O]
          incus launch vclaw-agent:trixie-prime <build-tmp> --profile vclaw-agent
          incus file push <prime-agent-tgz> <ext-bundle> <build-tmp>/tmp/
          incus exec  <build-tmp> -- '<J3 install script>'   # as ROOT — bake-parity (J15 note below)
          incus stop  <build-tmp>                    # publish from STOPPED (§1.5 restore caveat)
          incus publish <build-tmp> --alias vclaw-agent:trixie-prime-<ver>
          incus delete <build-tmp>
          — no distrobuilder, no rootfs rebuild, no identity

⚠️ **Exec form — corrected by J15 (2026-09-16):** the FAST **install** runs as **root** (`incus exec`
default), which is what `bake.sh`'s proven `/usr/local` flow does; `su - debian -c` is reserved for
**VALIDATE's identity pipe** (below), where the spec means it. *Bake-parity outranks this sketch's
original form* — an illustrative sketch does not override a script that has actually built the image.

CLEAN     base-OS / toolchain change
          the J3 bake script from a cloud-capable trixie base (cloud-init provision → publish).
          distrobuilder is the OPTIONAL variant, unmeasured here (J17): it becomes the clean path
          only after a timed build on THIS fleet — until then the scripted bake is the clean path
          (J17 eval + procedure: `docs/J17_DISTROBUILDER_EVAL.md` · probe
          `skills/incus-repackager/assets/j17-distrobuilder-probe.sh`, dry-run default,
          `--execute-timed-build` operator-gated. Findings D1–D6 there; key one: the current
          clean-path base is the EXPIRED July prototype `debian-trixie-pi-agent` — provenance,
          not speed, is what the distrobuilder run decides)

ALIASES   :trixie-prime-<ver>  →  :stable (FLIP — operator-gated)  →  :stable-prev (SOAK/rollback)
          ADD → FLIP → SOAK → DROP; the retired alias is the rollback target, never dropped early

VALIDATE  one throwaway instance, J8's assert-landed discipline:
          incus launch <alias> vcx-validate-<ts> --profile vclaw-agent
          incus exec … su - debian -c 'curl -fsSL https://vclawhub.com/join.ts | bun -'  # identity NOW
          ASSERT each (or the gate is vacuous): unit active · marker present AND non-empty ·
               claim status reached · presence in the fabric · prime-agent --version == <ver>
          cleanup: incus delete --force.  ⚠️ the claimed identity has NO SDK retire today → J16
```

**Invariants carried from §2–§3:** no identity in the image, ever; no credential in argv or a `0644`
env file (`auth.json` `0600` only); nothing in the path may prompt; **every assertion must be able to
fail** — a gate that cannot go red is §2.2.1's inert-profile defect wearing a CI costume.

### 8.4 What this adds

Jobs **J15–J18** (§5) and operator decisions **6–7** (§6). **Nothing in §0–§4 changes:** the
consolidated design is the same four artefacts (image / profile / instance / volume) with the
*rebuild* of them expressed as one invocable skill instead of a hand-run script — **J3's acceptance
criterion, promoted.** The one genuinely new obligation the proposals surfaced is **J16**: a CI that
claims an identity per validation needs a way to retire it, and the SDK has none.

## 8. P1 bake — landed (2026-09-16, lane report D-incus-P1-bake.md)
- **Image** `vclaw-agent/trixie-prime` fingerprint `e7ccedc63adad21e734937314c235a69812ed7e282b2217e6b76f908fd9b808d`,
  **797.13 MiB packed / 2237 MB uncompressed rootfs** (base 682.33 + 114.8 MiB). Sizing note: the earlier "≈1.25 GB ready agent"
  assumed the runtime installs at first boot; with the runtime baked, a **ready container ≈ image + ~273 MB per-agent venv volume**
  (built at first kernel start) ≈ 2.5 GB uncompressed — **apparent** size (`du -sx`), not exclusive. Both figures are correct under
  their own accounting. **Pool planning:** on btrfs, containers cloned from the same image SHARE extents — measured 8–16 KiB
  exclusive vs ~477 MiB apparent for a same-image clone — so size the pool on **incremental growth per agent** (state volume +
  venv + logs), never on 2.5 GB × N; sda-data had ~251 GB free at bake time.
- **Gates (all green)**: prime-agent 0.9.4, uv 0.12.14, bun 1.3.14 (baseline build), python3 3.13.5; no `~/.vclaw`, no config.json,
  no extensions, **NO NATS_URL anywhere** (login + non-login env; filesystem grep over `/etc /usr/local /var /root /home /opt` —
  this MUST include the base image's own `/etc/profile.d/pi-agent.sh`, enabled `pi-auto.service`, and cloud-init's cached
  `/var/lib/cloud/instances/*/user-data.txt`); cloud-init `done`, errors `[]`; IPv4+route; per-link DNS 100.100.100.100 +
  search ruffe-court.ts.net; `getent hosts vchat3` → 100.106.248.70; TCP to 100.106.248.70:4223 **and** `vchat3:4223` succeed;
  `incus restart -f` keeps all of it (restart-safety PASS).
- **Profile `vclaw-agent`** on ct17: cloud-init network-config ONLY (per-link DNS), no user-data, no packages, no runcmd.
- **Bake traps (all hit + fixed)**: *bake.sh identity — two hashes, one name*: the archived copy
  `.prime/handoff/incus-runtime/raw-p1/bake.sh` and the vendored
  `agent-sdk/skills/incus-repackager/assets/bake.sh` are byte-identical at **`b26d423d`**, while this
  report's prose claims `ddd52cd6` for ct17's `/tmp/vcx-p1/bake.sh` — **unresolved**; J15's timed run
  makes *"md5 ct17's copy and reconcile"* its **first step**. *Never trust a hash quoted in prose over a
  hash of the artefact.* **(1)** ct17 Celeron G4900 has **no AVX2** — bun must be the
  `bun-linux-x64-baseline` build and the version assert must fail on empty output; (2) `UV_INSTALL_DIR=/usr/local` puts the binary
  at `/usr/local/uv` — use `/usr/local/bin`; (3) python urllib gets **403** from the CDN where curl gets 200 — downloads use curl;
  (4) `bun install -g` makes `/usr/local/bin/prime-agent` a **symlink** into the package — `cat >` on it follows the link and
  destroys `dist/bundle/cli.js`; rm the symlink first; (5) the base image itself ships `NATS_URL` (profile.d + pi-auto.service +
  cached cloud-init user-data); (6) deleting the cloud-init instance dir by hand leaves `/var/lib/cloud/instance` dangling →
  cloud-init `degraded` — use `cloud-init clean --logs`.
- **Open**: base image alias already past `Expires 2026/08/18` (repin at next bake); `/usr/local/install/cache` 249 MB prunable;
  stale `pi` 0.80.10 still in base; CONNECT returns `-ERR Authorization Violation` without creds (expected — by design);
  full e2e onboarding awaits the funnel deploy + a claim.

---

## 9. Incus OS — findings, and whether it belongs under the VClaw runtime (appended 2026-09-17)

**Provenance.** Appended by `kuai-worker1` after the operator asked for the Incus OS findings to be recorded here. **Nothing above this
line was modified** — this is an append-only section, and §3.7's dated *SCOPE CORRECTION* banner (recorded in the `kuai` register as **O63**)
is untouched. Sources: the official Incus OS pages, each fetched **200 OK on 2026-09-17** and cached under
`/tmp/kuai-agentmesh/sources/incus-os/` (introduction, docs index, system/update, seed, applications, applications/incus); plus live measurements
of the `kuai` agent fleet recorded in `apps/kuai/docs/reviews/AGENT_MESH_SPRINT.md` (commits `fb333e2`, `1cca5c7`).
Stamps follow this file's convention: **[R]** = read from source/docs, **[O]** = observed with a command whose output is archived, **[I]** = inference.

### 9.1 What it is [R]

- **"IncusOS is an immutable OS solely designed around safely and reliably running Incus"** — Debian 13 base with LXC's own Incus and kernel
  builds, built on systemd's image/update features. **"Updates are applied atomically using an A/B scheme"** with easy revert; UEFI Secure
  Boot and a TPM give a measured boot chain and full-disk encryption. (`incus-os/introduction/`)
- **There is no shell.** **"The system itself is completely locked down with no local or remote shell, only an authenticated REST API to access
  Incus and manage the OS through it."** The OS does not listen on the network at all: it needs a *primary application* (Incus, Migration
  Manager, Operations Center, Shared API) to provide the endpoint and the authentication. (`introduction/`, `docs/main/reference/applications/`)
- **Installation is a seed; updates are declarative.** The install seed is **"a simple tar archive consisting of one or more JSON or YAML
  configuration files"**, written to the start of the second partition (or a `SEED_DATA` FAT USB/ISO). Recognized files include
  `install.*`, `incus.*`, `network.*`, `storage.*`, `services.*`, `update.*`; the presence of `install.*` **"even if empty, will trigger
  IncusOS to start the installation process."** The OS **"will check the configured provider for stable updates at each boot and then by
  default every six hours thereafter"**, stages them for next boot, and exposes `auto_reboot`, `channel` (`stable`|`testing`),
  `check_frequency`, `maintenance_windows`. Manual check: `incus admin os system update check`. (`docs/main/reference/seed/`, `.../system/update/`)
- **The selling property is sameness: "All IncusOS servers are guaranteed to be running bit for bit the same software, eliminating any
  deployment variance."** Also named on the intro page: automatic local ZFS pool, VLAN-aware bridging, OVS/OVN support, native Tailscale,
  centralized management through Operations Center, backup/restore of OS config and application data, factory reset.
- **The Incus it ships is not necessarily yours.** The Incus application is **"Incus as packaged by Zabbly"**, in two flavors: `incus`
  (stable/monthly, default) and `incus-lts-7.0`. (`.../reference/applications/incus/`)
- **Seed defaults to watch.** With `apply_defaults: true` the Incus application creates a **ZFS-backed pool `local` that "will use all
  remaining free space on the main system drive"**, creates bridge `incusbr0`, listens on **8443 on all interfaces**, and **"At least one
  trusted client certificate must be provided in the Incus preseed, otherwise it will be impossible to authenticate to any API endpoint or
  the web UI post-install."** (`.../reference/applications/incus/`)
- **"No package manager" is [I], not a quote** — it follows from the cited facts (read-only signed OS partitions, no shell, bit-for-bit
  identical servers). The phrasing to use is "no package manager, by construction", cited on *no shell* + *immutable*.

### 9.2 What it changes for this document's own design [R]+[I]

§2–§3 here assume a host a human can shell into (`bake.sh`, profiles, `incus restart`, cloud-init fixes). Under Incus OS that vantage
disappears: every step must be driven through the **Incus REST API with a trusted client certificate** — including the per-NIC
configuration this repo's profile work depends on. Three further consequences:

| topic | today (§1–§8 of this file) | under Incus OS |
|---|---|---|
| version pin | repo citations pinned to **Incus 6.0.4**; `6.0.4`-specific behaviours measured (nftables NIC-ACL exception, bridged-NIC `drop` defaults) | ships Zabbly **stable/monthly** or **`incus-lts-7.0`** — the pin does not carry over [R] |
| storage | btrfs pool, volumes per agent (this file's bake/prototype) | `apply_defaults` wants a ZFS `local` pool on the main drive; a different layout is a **seed** decision, i.e. a from-scratch install [R] |
| host-side work | packages, systemd units, shell fixes on the host | **no host package path** — anything not shipped as an Incus OS application image must live *inside* a container [I] |

For the VClaw runtime that last row is benign: **the runtime is already a container**, and container rootfs is unaffected by the host's
immutability — bun/node, `uv`/venv and an inner systemd unit keep working (this file's §3.2 bake stays valid in substance). What changes is
the *outer* machinery: image/profiles/ACL creation and `incus restart`-class operations become API calls rather than shell commands.

### 9.3 Feasibility — three separate questions, three different answers [I]

**(a) Into the prime-agent runtime CI/CD: yes — and Incus OS is not required for it.**
The measured gap (kuai sprint) is that the agent runtime is currently *hand-copied*: `/opt/prime-agent` on three containers, carrying macOS
AppleDouble residue (`._*` siblings) and per-container drift (kuai register **O52**). The fix is image-based delivery, which works on the
6.0.4 hosts we have today:

1. Bake a **`kuai-agent` / VClaw-runtime image** in CI: pinned agent package + bun, the Python kernel venv, the mesh endpoint unit, the
   acceptance-test script — deterministic, digest-addressed. This is the same bake idea as §3.2, moved from a hand-run script into CI.
2. Publish with a digest. **Check first:** whether our own Forgejo (`kuai-git`) serves a container/package registry — the repo documents
   read-only *code* identity per consumer, not a registry, so treat this as unverified.
3. Nightly: launch a **throwaway container** from that image, run the three-check ACL test and the four-direction agent-exchange test,
   destroy it. This is the regression test the kuai rulings require, and it retires the drift class permanently.
4. Two unknowns, one command each: does the host's Incus accept an **OCI registry remote** (`incus remote add … --protocol oci`; only
   `images:` simplestreams and `local` exist on `kuai` today), and how a CI run reaches a model when the default route is a container
   (`kuai-llm`) rather than a hosted API.

**(b) As the infrastructure for the `kuai` host today: no.** Four reasons, one unverified and load-bearing:
(i) every lane's vantage is `ssh` + shell + host packages — that path does not exist here; (ii) the version pin (6.0.4) is what all of the
kuai ACL/NIC measurements are quoted against; (iii) storage layout (`btrfs` pool on a second NVMe) is a seed-time decision, not a change;
(iv) **unverified for that hardware:** the local model depends on GPU/VRAM passthrough (26 GiB of 48 GiB in use), and Incus OS ships its own
kernel — whether containers still get working `/dev/dri`/`/dev/kfd` for that Ryzen AI Max+ 395 must be measured, not assumed.

**(c) As infrastructure for future or customer-site nodes: yes, promising.** The properties that cost us today (host shell, package
installs, hand-edited config) are exactly what a *customer* box should not have. "Bit-for-bit identical", weekly auto-update with A/B
rollback, TPM encryption and API-only operations is the shape of an on-prem appliance running the agent fleet — and it composes with the
fleet's `boot.autostart=true` invariant, because a node that must return unattended after a power cut benefits from a host OS that also
self-heals. Conversely, a host that auto-updates weekly needs a policy: pin `channel`, use `maintenance_windows`, and decide whether
`auto_reboot` is allowed on customer premises.

### 9.4 The spike that would settle it — four questions, one VM [I]

| # | question | how to test | pass looks like |
|---|---|---|---|
| 1 | GPU/VRAM passthrough for llama.cpp | Incus OS VM on `kuai` (KVM), one container with the GPU devices, run the router | tokens answered; `mem_info_vram_used` non-zero |
| 2 | our NIC/ACL step without a shell | create the ACL + `device override` through the REST API with a client cert | same nft chains in table `bridge incus`; peer allowed, non-peer blocked, owner's turn still works |
| 3 | storage layout via seed | seed `storage.*` for a non-ZFS or secondary-drive pool | containers land where we expect, no loss of the existing pool |
| 4 | our ops without ssh | drive a bake + restart + rollback through the API only | bake reproducible; A/B revert verified once |

### 9.5 Recommendation [I]

1. **Now, no Incus OS:** image-based delivery + throwaway-container CI test on the existing 6.0.4 hosts. Biggest win, no new platform.
2. **Next, one spike:** the four-question VM above. Cheap, touches no running fleet, and answers (b)(iv) which is the only blocker that is
   genuinely unknown rather than a policy choice.
3. **Later, only if a customer-site box becomes real:** adopt Incus OS for *nodes*, never for the agent runtime layer, which stays a
   container from an image we build.

**Evidence index for this section:** Incus OS pages — `https://linuxcontainers.org/incus-os/introduction/`,
`…/incus-os/docs/main/`, `…/reference/system/update/`, `…/reference/seed/`, `…/reference/applications/`, `…/reference/applications/incus/`
(all 200 OK, 2026-09-17). kuai-side measurements — `apps/kuai/docs/reviews/AGENT_MESH_SPRINT.md` §2–§4 and §7.

---

## 10. Incus OS — §9 verified, the pages its survey missed, and the agent-sdk integration proposal (appended 2026-09-17)

**Provenance.** Appended by `vchat-email-434674` (vchat.email repo session) on the operator's instruction to track the
Incus OS learning, digest it, and propose the `agent-sdk` integration. **§9 and everything above it are untouched** —
the only edits this section makes elsewhere in the file are four rows appended to the §5 job register (J19–J22), which is
this document's own convention (§8.4 added J15–J18 the same way). Sources are stamped as in §9: **[R]** read, **[O]** observed with an
archived command, **[I]** inference.

### 10.0 Method, and the state of the update

- **§9 is prose-complete but uncommitted.** `git show HEAD:docs/RUNTIME_incus.md | grep -c 'Incus OS — findings'` → **0** [O]:
  §9 exists only in the working tree. The pending diff is **144 insertions / 2 deletions** and contains §9 (104 lines) plus the
  §3.7 dated SCOPE CORRECTION banner and NATS blocker, the §8.3 exec-form corrections, and §8.4 — i.e. the update is one
  coherent batch whose remainder is already reviewed above. No `TODO`/`TBD`/placeholder strings in §9 [O].
- **§9's citations are faithful.** All twelve load-bearing §9.1 quotes were re-found in the fetched artefacts (`/tmp/kuai-agentmesh/sources/incus-os/`,
  8 files, stamped 2026-09-17 11:48–11:49) rather than taken from the prose [O]. Quote checks run:
  *no local or remote shell* · *A/B* · *bit for bit* · *Zabbly* · *remaining free space* · *8443* · *trusted client certificate* ·
  *even if empty* · *six hours* · *auto_reboot* · *maintenance_windows* · *incus-lts-7.0* — **12/12 found** [O].
- **Two provenance defects in §9's own evidence index** [O]: (i) `docs.html` and `ref.html` in the cache are **byte-identical**
  (md5 `9462df8240bbbb86e0a3bb6c1d1cae79`, both 31,138 B) — one page under two names, cited as if distinct. Same class as §8.5's
  *"two hashes, one name"* trap: **hash the artefact, never the label.** (ii) The survey is a **5-of-61** sample [O]: the docs index
  navigation lists **61** doc pages, and §9 cites five (`introduction`, the docs index, `system/update`, `seed`, `applications/incus`).
  The pages it did not fetch are exactly the ones that answer its own open questions — §10.2.
- **Digest in one line:** §9 is a correct, well-stamped description of the *platform*; its three recommendations survive; what changes
  is (a) its one "genuinely unknown" (GPU) is now a known-shaped question with a documented dead end for one vendor, and (b) the
  spike it proposes can run **here on ct17**, not on kuai.

### 10.1 Verification of §9's claims against the artefacts [O]

| §9 claim | verdict |
|---|---|
| no local or remote shell; API-only management, needs a primary application to expose it | **holds** — `applications/` states it verbatim: *"IncusOS itself doesn't listen on the network. For the system to be accessible and manageable over the network, it requires a primary application"* |
| A/B atomic updates, boot-time + ~6 h checks, `channel`/`auto_reboot`/`maintenance_windows` | **holds** |
| install seed = tar of JSON/YAML; `install.*` present (even empty) triggers install | **holds** |
| Incus = **Zabbly** packaging, `incus` (stable/monthly) or `incus-lts-7.0` | **holds** |
| default ZFS `local` pool using *"all remaining free space"*, bridge, 8443, trusted-cert-or-locked-out | **holds**; the trusted-cert requirement is repeated for **Operations Center** and for the **fallback API endpoint** |
| "no package manager" is [I], not a quote | **correct discipline** — keep it |
| version pin does not carry over (6.0.4 measurements vs Zabbly stable/LTS) | **holds** as a statement about the pin |
| storage layout is "a seed decision, i.e. a from-scratch install" | **too strong — refine** (see §10.2 storage row): devices can be **added/removed/replaced in an existing pool** post-install via the API; what is seed-time is the *initial main-drive* layout |
| "everything through the REST API with a trusted client certificate" | **holds and is broader than §9 claimed** — network, storage, security state, applications, recovery all have API paths |

### 10.2 New learning — the pages §9's survey missed [R]

Each row: what the page says → what it does to §9.

| page (all 200 OK 2026-09-17, sha256 in §10.6) | finding | consequence for §9 |
|---|---|---|
| `reference/applications/gpu-support/` | a **non-primary application** adding **firmware** for **amd/nvidia/intel**; *"only includes firmware files — it does not include any drivers (Kernel modules are always part of the IncusOS base image…)"*; **"The out of tree Nvidia drivers are not available on an IncusOS host."** | §9.4 Q1 / §9.3(b)(iv) is this document's one *"genuinely unknown"*. It **splits into three**: firmware — **answered** (`gpu-support`), driver — **in the base image**, container visibility (`/dev/dri`, `/dev/kfd`) — **still the spike**. And one **documented dead end**: a GPU node must be **AMD/Intel**, never Nvidia |
| `getting-started/installation/virtual-incus/` | IncusOS installs as a **VM inside Incus**: `incus init --empty --vm`, `security.secureboot=false` (so IncusOS enrolls its own keys), **a `vtpm` device is required**, the ISO imported as a storage volume `--type=iso`, root **≥50 GiB**, then *"IncusOS depends on Secure Boot and a v2.0 TPM"* | **the spike venue is ct17, not kuai.** §9.4 named a VM on `kuai`; ct17 is drivable today with our tools (Incus 7.0.1, no GPU to preserve, inside our blast radius) and this recipe is the documented path |
| `reference/installing-without-tpm/` | TPM is a dependency; a `swtpm`-backed fallback exists but *"Running IncusOS in an enterprise environment without a physical TPM is UNSUPPORTED"* | §9.1 sold TPM+measured boot as a *feature*; for a **node class** it is a **hardware prerequisite**. Check each candidate node for a physical TPM **before** promising it |
| `reference/recovery/` | if the system boots the **prior version** or the **primary application fails**, it *"automatically attempt[s] to activate a fallback API endpoint"* — random port by default, configurable, can be made **`persistent`**, and trusted client certs are taken from the seed on first boot | §9.2's largest implied risk — *no shell, how do we rescue a dead node?* — is **answered by design**. This is the mitigation §9's table implied was missing |
| `reference/system/security/` | pool keys are random and TPM-unlocked; a **recovery key** exists and *"IncusOS will report a warning about needing to retrieve encryption recovery keys until they are explicitly marked as retrieved by running `incus admin os system security show`"* | a **new operational obligation** for any node adoption: someone must custody the recovery key. Absent from §9 |
| `reference/system/network/` | interfaces/bonds/VLANs/WireGuard via **seed or the network API**; every interface/bond **auto-bridged**; pre-apply validation; **auto-revert** on failure, plus **`confirmation_timeout`** (roll back unless a confirmation command arrives) | confirms §9.2's API-only claim **and** adds a property §9.4 Q2 does not assume: a bad *remote* network change **cannot permanently lock the node out** |
| `reference/services/tailscale/` | a first-class service: `enabled`, `login_server`, `auth_key`, `accept_routes`, `advertised_routes`, `advertise_exit_node`, `exit_node`, and **`serve_enabled` = expose `localhost:8443` (the Incus API) over Tailscale Serve** | the strongest fit yet with this repo's fabric (§3.7): a node's tailnet attachment — and API reachability without a public port — becomes **seed/API declarative**, no host shell. This upgrades §3.7's "Future B" from *per-container* tailscale to a **node-level** property |
| `reference/applications/non-primary/` | *"You can install any of the non-primary applications on an IncusOS system by running `incus admin os application add <application name>`"* (`debug`, `gpu-support`, `incus-ceph`, `incus-linstor`, `openfga`) | refines §9.2's row: the **seed-time** constraints are storage/network layout, **not** the application set |
| `reference/applications/operations-center/`, `reference/api/` | the management plane (same trusted-cert-or-locked-out rule, 8443) and the API surface every operation goes through | the fleet-management half of the node story; `openfga` is notable as an authorization application for the same customer-node class |

### 10.3 Re-rating §9.3's three answers [I]

1. **(a) "Into the runtime CI/CD: yes, and Incus OS is not required" — ADOPT, unchanged.** Now the only recommendation that depends on
   no unreleased-hardware check. Two amendments: the drift class it retires (kuai **O52**, hand-copied `/opt/prime-agent` with AppleDouble
   residue) is retired by a **gate**, not by an intention (J19); and the registry transport is a **measurement** (J20), because nothing on
   this fleet is known to serve OCI today.
2. **(b) "As the infrastructure for kuai today: no" — verdict unchanged, reason changed.** The blocking unknown is no longer unmeasured
   in kind: AMD firmware is an application, the driver is in the base image, so what remains is **container device visibility** — one
   measurable question. And the spike should run on **ct17** (nested VM, per the documented recipe), not on the kuai box that is currently
   serving the local model. So: *"not yet — and the deciding test is now cheap and off-fleet."*
3. **(c) "For future/customer-site nodes: yes, promising" — ADOPT, strengthened; two new prerequisites.** Add to the selling points:
   the **fallback API endpoint** (rescue without a shell), **network auto-revert + `confirmation_timeout`** (cannot lock yourself out),
   the **tailscale service** (fabric join as seed config), **`gpu-support`** (GPU nodes, AMD/Intel only), weekly scrub/trim. Prerequisites:
   a **physical TPM** and a **recovery-key custody policy**.

### 10.4 Proposed enhancements — the `agent-sdk` integration

**Ruling on the seam — Incus OS is a HOST class, not a runtime. Do not add it to the runtime selector.**
`src/lib/runtime.ts` defines the selector axis as *which agent binary answers the RPC contract* (`DEFAULT_RUNTIME = "pi"`,
precedence flag > env > config > default), and `docs/RUNTIME_SELECTOR.md` §3.1 fixes that meaning. An `incusos` value there would
conflate *the OS the host runs* with *the runtime an agent spawns*, and would give a caller two ways to say different things
(§6.1's single-template-literal class of defect). The integration seams that **do** exist are the ones this document already owns:
**image delivery** (§8.3, `skills/incus-repackager`) and **provisioning/validation** (§8.3 VALIDATE, J8/J15/J18). Everything below is phrased
against those two seams.

| id | enhancement | why it is worth doing | gate that can go red |
|---|---|---|---|
| **E1** | **Make image-based delivery a standing gate, not an intention** (J19): nightly CI launches a throwaway container from the published alias, asserts agent version + kernel-venv import + extension `get_commands`==5 + NATS reachability, destroys it. Plus **J20**: measure the pull path (`oci` remote vs `incus image export`). | It retires the hand-copy drift class that §9.3(a) exists to kill (kuai O52) **on hosts we already have**, with no new platform. | mutate the image (drop the extension, bump the version) → the nightly gate must go RED; a gate that cannot fail is §2.2.1's inert profile in CI costume |
| **E2** | **Run §9.4's spike on ct17 as a nested IncusOS VM** (J21), using the documented `virtual-incus` recipe, with **Q1 narrowed**: not "does the GPU work on IncusOS" but *"are `/dev/dri`+`/dev/kfd` visible in-container and does `mem_info_vram_used` go non-zero on AMD"*, and a fourth-added check that the **tailscale service** can reach our fabric from a no-shell node. | Cheapest possible test of the only genuine unknown; no customer hardware, no kuai disruption, and it doubles as the "can we drive an IncusOS node at all" rehearsal (bake + restart + A/B revert through the API only). | each question must be able to answer **NO** (a documented AMD/ROCm limitation is a valid, recorded result) |
| **E3** | **Node-class prerequisites become a checklist** (J22): physical TPM present, recovery key retrieved and custodied, Secure Boot enrolled, trusted client cert(s) registered, fallback API endpoint configured (`persistent` where the node is remote). | §9.2's cost model changes once a node has no shell: the prerequisites are now *hardware and secrets*, not packages. Naming them prevents an operator discovering them mid-install. | the checklist is executable **without a shell on the node** — if a step needs one, it is not an IncusOS step |
| **E4** | **Self-update + storage policy** (J22): pin `channel=stable`, set `maintenance_windows`, decide `auto_reboot` per site, align weekly scrub/trim with the backup window, and run **one API-driven A/B revert drill** before any node is trusted. | A host that updates itself weekly and reboots is an operational decision, not a default — and this fleet's `boot.autostart=true` invariant assumes a node returns unattended. | the revert drill must actually roll back to the prior version and come back serving |
| **E5** | **Doc hygiene** (§10.5): renumber the duplicate `## 8`, drop the duplicate evidence citation, and keep §10 as the IncusOS delta so §9 never needs editing. | Anchors are the citation currency in this repo; two `## 8`s make *"see §8"* ambiguous (§4 P1 row and §8.4 both use it). | `grep -c '^## 8' → 1` |

**Not proposed:** a `RUNTIME_incus_os.md` sibling document (this §10 is the delta and the file is the register), and any
IncusOS adoption for the **runtime layer** — §9.5's ruling that *nodes, never the runtime layer* is correct and unchanged.

### 10.5 Doc-integrity findings (recorded here, **not** edited above §9's append-only boundary)

1. **Two `## 8` headings** — *"CI/CD as an agent skill"* (§8.1–§8.4) and *"P1 bake — landed"*. Anchors *"see §8"* (§4 P1 row) and
   *"§8.3"* (§8.3/J15) therefore resolve ambiguously. **Recommendation:** renumber the P1-bake heading to `§8.5` in a commit that owns
   §9's *"nothing above this line was modified"* claim, or accept §10.4 E5 as the fix. Not applied here deliberately [I].
2. **§9's evidence index lists one page twice** — `docs/main/` and the docs index are md5-identical (§10.0).
3. **§9's survey is 5 of 61 pages** — the gap is now closed by §10.2, whose artefacts are archived with hashes.
4. **Both §9 and §10 are uncommitted** in the `agent-sdk` worktree; the repo's `docs/COMMIT_MERGE_POLICY.md` applies, and the lead commits.

### 10.6 What would falsify §10's re-ratings [I]

| claim | falsifier |
|---|---|
| (b) is "not yet" rather than "no" | the IncusOS base kernel lacks the AMD GPU modules needed by the Ryzen AI Max+ 395, **or** Incus container device passthrough cannot expose `/dev/kfd` on an IncusOS host → (b) becomes **NO** (J21 Q1) |
| a node's fabric join is declarative | the `tailscale` service cannot authenticate/reach our hub from a no-shell node → the §3.7 "Future B" upgrade weakens back to per-container tailscale (J21 added check) |
| "no shell" is an acceptable risk for a node | the fallback API endpoint is unreachable in practice when the primary application is killed → the recovery assumption dies (J21 rehearsal, deliberate primary-app failure) |
| AMD firmware is sufficient | `gpu-support`'s firmware set omits the needed `amdgpu` firmware for that APU → Q1 resolves NO for a *different* reason than visibility |

### 10.7 Evidence index for §10

- **Fetched 2026-09-17, all HTTP 200**, archived locally at `.prime/handoff/incus-runtime/raw-incusos-verify/` (10 files; gitignored,
  so the sha256 list below is the durable part) and originally in `/tmp/lane-incus-os-verify/` [O]:

| page | sha256 (prefix) |
|---|---|
| `getting-started/installation/virtual-incus/` | `ec657426f7fe19b9…` |
| `reference/applications/gpu-support/` | `ad5c15f83f75c399…` |
| `reference/applications/non-primary/` | `237634d395dcae22…` |
| `reference/applications/operations-center/` | `9ba495ffc3fa59c3…` |
| `reference/installing-without-tpm/` | `33d2d9a5ced1a5c7…` |
| `reference/recovery/` | `256060d90736f7c3…` |
| `reference/services/tailscale/` | `c9c96fd21845f9f6…` |
| `reference/system/network/` | `9e2bda7118ed63e5…` |
| `reference/system/security/` | `c8ffe0d6d2cfbe41…` |
| `reference/system/storage/` | `807691a9b57c2e2c…` |

- **§9's own cache** (re-verified, not re-fetched): `/tmp/kuai-agentmesh/sources/incus-os/` — 8 files, `docs.html` ≡ `ref.html`
  (md5 `9462df8240bbbb86e0a3bb6c1d1cae79`) [O].
- **Upstream cadence observed** [O]: `lxc/incus-os` tags are **date-stamped**, newest `202609150130` (2026-09-15 01:30); repo pushed
  2026-09-17T00:54Z, 1,105 stars, description *"Immutable Linux OS to run Incus"*. So a node's OS version is identifiable by date
  tag — record it next to every `gpu-support`/`tailscale` claim, because those are *leaf images* whose content moves with the tag.
- **kuai-side measurements** cited by §9: `apps/kuai/docs/reviews/AGENT_MESH_SPRINT.md` (O52 hand-copied runtime + AppleDouble residue,
  line 178/189/239; O63 fabric unreachable from kuai, line 170) — read at
  `~/Documents/Chatek/apps/kuai/docs/reviews/AGENT_MESH_SPRINT.md` [O].
- **Cross-check that failed and was not used:** `api.github.com/repos/lxc/incus-os/releases/latest` returns **no release** (the repo
  tags, it does not publish GitHub Releases) — so *release notes are not available via that route*; the docs pages are the source [O].
