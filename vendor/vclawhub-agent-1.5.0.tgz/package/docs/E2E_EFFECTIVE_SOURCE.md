# E2E — the effective-source contract, verified with negative controls

**Lane:** E2E LANE 3. **State under test:** agent-sdk `9e770e6` (superproject `9f74d2c`).
**Environment:** node v22.22.2, darwin-arm64, pi 0.85.1. **Read-only** — no committed file was edited.
**Credentials spent: none.** Every claim below is verifiable without a model call.

**Isolation:** all runs used `VCLAW_CREDS_DIR=/tmp/e2e/creds` (the SDK's creds-dir override,
`store.ts:32-33` `credsDirOverride()` → `env("CREDS_DIR")`), so the operator's real
`~/.config/vclaw/config.json` was never read or written. `dist/` was verified **newer** than `src/` (mtime 1789161248 vs 1789158596) so the
built CLI under test matches HEAD — a stale build would have been this sprint's own failure mode.

---

## 0. Negative-control policy (applied to the verification itself)

The dispatch asks that every command relied on be run against a case that **must** match and one that must
**not**, and that any "no output" claim prove the command *can* produce output. Each instrument here was
controlled:

| Instrument | Known-positive | Known-negative |
|---|---|---|
| `grep -c '"command":"get_state"'` on a transcript | no-op-extension run → **1** | editor-run → **0** (meaningful *only* because the positive case is nonzero) |
| `grep -c '"method":"editor"'` | editor probe → **1** | notify probe → **0** |
| `resolveRuntime()` source field | `flag`/`env`/`config`/`default` all observed as distinct values | an unknown source string was never observed |
| spawned-binary marker file | RUN A recorded `fakepi-flag` | RUN B recorded `fakepi-env`, **not** `fakepi-flag` |

Three of this lane's own intermediate conclusions were **discarded** because a control contradicted them — see
§6. Two of them were instrument faults, not product faults.

---

## 1. Claims — VERIFIED / UNVERIFIED

### Claim 1 — all four layers report correctly — **VERIFIED (3 of 4 through the CLI; 4th at the resolver)**

`vclaw-agent runtime` prints the effective value **and** the layer:

```
$ VCLAW_CREDS_DIR=/tmp/e2e/creds node dist/cli.js runtime        # no config, no env
   effective : pi
   source    : default (built-in default: pi)
   env knob  : VCLAW_PI_BIN
   config    : ~/.config/vclaw/config.json → "runtime"

$ … node dist/cli.js runtime /opt/from-config                    # config layer
✅ runtime set to "/opt/from-config"
   source : config
```

- **default** ✅, **config** ✅, **env** ✅ — all three verified through the CLI.
- **flag** — ⚠️ **not reachable from `vclaw-agent runtime`.** The command calls `resolveRuntime()` with **no
  argument** (`cli.ts:446`), and an explicit override is the *only* way to reach the flag tier
  (`runtime.ts:57-58`). Verified instead at the resolver, which is the same function the spawn path uses:

```
no arg        : {"bin":"pi","source":"default"}
explicit flag : {"bin":"/opt/from-flag","source":"flag"}
```

**This is a real gap in the feature's own claim — see §2.**

### Claim 2 — precedence is total: the winner is reported *and* it is what would be spawned — **VERIFIED**

Reported value and source, all four layers present at once:

| Config | `VCLAW_PI_BIN` | `VCHAT_PI_BIN` | Reported | Correct? |
|---|---|---|---|---|
| `/opt/from-config` | — | — | `effective: /opt/from-config`, `source: config` | ✅ |
| `/opt/from-config` | `/opt/from-env` | — | `effective: /opt/from-env`, `source: env` | ✅ env beats config |
| `/opt/from-config` | — | `/opt/legacy` | `effective: /opt/legacy`, `source: env` | ✅ legacy tier |
| `/opt/from-config` | `/opt/vclaw` | `/opt/legacy` | `effective: /opt/vclaw`, `source: env` | ✅ VCLAW beats VCHAT **and** config |
| `/opt/from-config` | (flag used) | — | `source: flag` (resolver) | ✅ flag beats env |

**And it is the binary that is actually spawned — proven with marker binaries**, not inferred. A fake `pi` that
appends its own `$0` to a log:

```
RUN A  --pi-bin /tmp/e2e/fakepi-flag   → spawned.log:
  fakepi-flag --mode rpc --session-dir …/sessions/pi --session-id w1 --no-builtin-tools

RUN B  (no flag) VCLAW_PI_BIN=/tmp/e2e/fakepi-env  → spawned.log:
  fakepi-env  --mode rpc --session-dir …/sessions/pi --session-id w1 --no-builtin-tools
```

RUN B is also the **known-negative**: `fakepi-flag` does **not** appear. So both the flag and env tiers
demonstrably decide the spawned process, and the log independently reproduces the daemon's real argv — a
cross-check of the Lane R §1 argv verification using the actual daemon rather than a hand-typed command.

### Claim 3 — `VCHAT_PI_BIN` (legacy fallback) resolves and reports `env` — **VERIFIED**

```
CASE 4 config + VCHAT_PI_BIN only : effective : /opt/legacy | source : env
```
`env.ts` checks `VCLAW_*` first, then `VCHAT_*`, and the resolver reports the **layer** (`env`) not the
variable name — so a legacy variable is correctly indistinguishable from the canonical one in the report,
which is right: both are the env layer.

### Claim 4 — blank/whitespace values are ignored at every layer — **VERIFIED**

```
CASE 6 VCLAW_PI_BIN=''   + config : effective : /opt/from-config | source : config
CASE 7 VCLAW_PI_BIN='   ' + config: effective : /opt/from-config | source : config
CASE 8 VCLAW_PI_BIN='   ' no config: effective : pi             | source : default
flag whitespace-only              : {"bin":"pi","source":"default"}
flag empty string                 : {"bin":"pi","source":"default"}
```
Three mechanisms cover it: `env()` treats `""` as absent (`env.ts`), the resolver `.trim()`s every layer
(`runtime.ts:57,60,63`), and `setRuntime` deletes the config key when the trimmed value is empty
(`runtime.ts:101-103`) — verified by writing a config and reading it back after `--unset`: `{}`.

### Claim 5 — after `--unset` the source falls to the *next in chain*, not straight to `default` — **VERIFIED**

```
config set, then --unset, with VCLAW_PI_BIN=/opt/still-here:
  effective : /opt/still-here | source : env          ← NOT default
config set, then --unset, nothing else set:
  effective : pi | source : default
config file after unset: {}
```
Claim 5 holds in both directions: with an env var still set the source falls to `env` (not `default`), and
with nothing else set it falls to `default`. The config key is removed rather than blanked.

---

## 2. Gap: the `flag` layer has no reporting surface

`resolveRuntime()` takes an optional `explicit` argument, and the flag tier is reachable only when a caller
passes one. Grep of every call site:

```
src/cli.ts:446:      const r = resolveRuntime();              ← the ONLY reporter, no argument
src/lib/runtime.ts:75:  return resolveRuntime(explicit).bin;  ← the spawn path
```

So:
- **The one surface that reports a source can never report `flag`.** `vclaw-agent runtime` is the sole code
  that prints `source` (`cli.ts:448`), and it always calls the resolver argumentless.
- The only commands that *use* the flag tier are `eval --pi-bin` (`cli.ts:402`) and the daemon/eval spawn path
  (`worker-pi.ts:155` `spec.piBin ?? resolvePiBin()`) — **neither reports the source**, and the daemon does not
  log the resolved runtime at startup (grep for log/console/source around `serve.ts` runtime handling: nothing).

**Why this matters, in the feature's own terms.** The stated purpose is answering "which runtime am I actually
running" — and the failure the lead named is "the reported *source* can be wrong while the *value* is right."
That is reachable: start a daemon or eval with `--pi-bin /opt/fork`, then run `vclaw-agent runtime` in another
shell — it will report `env` or `config` (or `default`) with a *different* binary, correctly for its own
process and misleadingly for the one actually running. The report is not wrong; **its coverage is incomplete**,
and the gap is exactly the layer an operator uses deliberately, i.e. the one where they are most likely to
believe they already know the answer.

**Suggested shape (not implemented — read-only lane):** have the daemon/eval log
`runtime: <bin> (source: <layer>)` once at startup, or surface `source` in the eval report header, both of
which already know the `ResolvedRuntime`. One line each.

### Minor, unrelated
`src/env.ts:5` documents the fallback as `env("SEGMENT") → VCLAW_SEGMENT ?? VCLAW_SEGMENT` — the second
operand should be `VCHAT_SEGMENT`. The code below it is correct; the comment is not.

---

## 3. `ui.editor(...)` — the wedge, re-tested with the `MODAL_UI_METHODS` fix in place

Lane R's finding was that `editor` is a modal `extension_ui_request` with **no timeout path at all**
(`rpc-mode.js:174-193`, a bare `new Promise`) that the daemon did not cancel. `MODAL_UI_METHODS` now includes
it. Re-confirmed live, **with no model call**, using a probe extension that awaits `ctx.ui.editor(...)`:

**Result: the fix works for a mid-session modal, and there the cancel is verified end-to-end.**

```
CONTROL 1  get_state before any modal   → <- response get_state success=true     (channel alive)
trigger    bash command → user_bash event → probe calls ctx.ui.editor
           editor frame mid-session? YES | marker: UBASH-CALLED
CONTROL 2  get_state while modal pending → <- response get_state success=true    (still alive!)
send       {"id":…,"type":"extension_ui_response","cancelled":true}
           <- response bash success=true                                        (turn resumed)
           marker after cancel: UBASH-CALLED | RESOLVED:undefined               ← UNBLOCKED
```

`RESOLVED:undefined` is the contract working exactly as designed: the extension sees "declined", the turn
resumes, and the worker stays alive. **This discharges Lane R §3's UNVERIFIED item** — the cancel path had
never been exercised at runtime before; it has now been, including the known-negative that the promise really
does stay pending without a response.

### But there is a second regime, and there the fix cannot help

A modal raised during **`session_start`** does not merely wedge the worker — it prevents the RPC channel from
ever opening, so the daemon's cancel **cannot be delivered**. Isolated with two controls, same harness:

| Extension at `session_start` | `get_state` answered? | Reading |
|---|---|---|
| does nothing | **1** | channel alive |
| calls `ui.notify()` (fire-and-forget) | **1** | channel alive |
| **awaits `ui.editor(...)`** | **0** | **channel DEAD** (editor frame *was* emitted) |

The 0 is meaningful only because the same command returned 1 in the two sibling runs.

**Mechanism, source-verified:**
```
agent-session.js:1906   async bindExtensions(bindings) { … this._extensionUIContext = bindings.uiContext …
agent-session.js:1926       await this._extensionRunner.emit(this._sessionStartEvent);   ← AWAITS handlers
rpc-mode.js:289         await rebindSession();            ← calls bindExtensions
rpc-mode.js:644-646     process.stdin.on("end", …); detachInput = attachJsonlLineReader(process.stdin, …)
```
The stdin reader is attached **355 lines after** `await rebindSession()`. A never-settling promise inside a
`session_start` handler blocks `bindExtensions` → blocks `rebindSession` → **stdin is never read**. So the
worker cannot be commanded at all: the daemon's `prompt` sits unread in the pipe, `agent_settled` never fires,
and the 60s `get_last_assistant_text` timer is the only thing that eventually reports anything.

**Severity, stated precisely:** this needs an extension that opens a modal during `session_start` — plausible
(consent/config prompts at startup) but not the common case. `select`/`confirm`/`input` are degraded-but-
recoverable there because an extension *may* pass `opts.timeout`; **`editor` has no timeout at all**, so that
one path is unrecoverable. This is an upstream property of pi 0.85.1, not a daemon bug — but the daemon's
defence is structurally unable to reach it, so it is worth knowing before the runtime default flips.

**The remedy that covers both regimes is the R5 remedy, not R1's:** workers should not load the host's
extension set at all (`--no-extensions` plus an explicit `-e` for the worker extension). That removes the
`session_start` modal *and* the N-workers = N-fabric-registrations problem (§R5) in one change. Recorded here
as an option for that decision, not as a recommendation to make unilaterally.

---

## 4. Still UNVERIFIED

| Item | Blocker |
|---|---|
| That a `session_start` modal wedges a worker **through the daemon** (`--driver pi`), rather than through a direct RPC spawn | needs a daemon run with a modal-raising extension; the spawn path itself was exercised (§1 claim 2), the modal path through it was not |
| Whether the daemon's 60s timer is the *only* recovery (vs. a crash-reap) | as above |
| Any end-to-end reply (`prompt` → `agent_settled` → text) | requires a model round-trip; **not spent** |
| `select`/`confirm`/`input` cancel at runtime | the probe covered `editor` only; the other three share `createDialogPromise` but were not individually exercised |

---

## 5. Reproduce

```bash
cd agent-sdk && export VCLAW_CREDS_DIR=/tmp/e2e/creds && mkdir -p $VCLAW_CREDS_DIR

# Claims 1-5 (config/env/default; the flag tier needs the resolver, see §2)
node dist/cli.js runtime                                  # default
node dist/cli.js runtime /opt/from-config                  # config
VCLAW_PI_BIN=/opt/from-env node dist/cli.js runtime         # env beats config
VCHAT_PI_BIN=/opt/legacy   node dist/cli.js runtime         # legacy tier
VCLAW_PI_BIN='   '         node dist/cli.js runtime         # blank ignored
node dist/cli.js runtime --unset                           # falls to next in chain

# Claim 2 end-to-end: which binary is really spawned (marker binary, no creds)
printf '#!/bin/sh\necho "$(basename $0) $@" >> /tmp/e2e/spawned.log\nexit 0\n' > /tmp/e2e/fakepi-flag
chmod +x /tmp/e2e/fakepi-flag
node dist/cli.js eval "probe" --driver pi --pi-bin /tmp/e2e/fakepi-flag --workers 1 --timeout 2000
cat /tmp/e2e/spawned.log
```
The `editor` probe scripts (§3) are scratch files under `/tmp/e2e/` (`editor-probe.mjs`, `probe-ubash.mjs`,
`editor-driver.mjs`, `ubash-driver.mjs`) — deliberately **not** committed, since a test that spawns the real
`pi` would load the host's extensions and pollute the A2A fabric (the R5 effect, observed in Lane R).

---

## 6. Method notes — three conclusions discarded by their own controls

1. **"The cancel does not unblock `editor`."** My first probe sent the cancel and saw the promise stay
   pending. Before writing it up I added a known-positive control for the stdin channel (`get_state`) — which
   **also** got no answer. That inverted the reading: the channel was dead, so the cancel was never received.
   The corrected two-regime result is §3. *An absence of response proves nothing until the same channel is
   shown to deliver.*
2. **A `sed -i` that replaced only the declaration** left the old identifier in the body, so the first
   `user_bash` run died on `ReferenceError` rather than reporting anything about the product. Fixed and re-run.
3. **An extraction that captured only the `source` line.** Claim 2 is about *value and source together*; my
   first matrix printed only `source`, which would have "verified" precedence while never showing whether the
   **effective value** was the expected one. Re-run extracting both — the failure mode the lead named ("source
   right, value wrong") would have passed unnoticed.
