# @vchatemail/agent SDK — Upgrade Plan

> 🚀 **ACTIVE PLANS — §“v11 — Synadia Agent Protocol v0.3: conformance & integration upgrade” is the NEWEST plan (2026-10-30, directly below):** it makes our v0.3 implementation **conformant** (truthful `attachments_ok`, §9 error emission, §13 sender identity classed), **single** (one serving implementation, with deregistration), and **shippable** (the JSR publish set carries the extension bundles it declares). Gap study: `../docs/lanes/SYNADIA_REFERENCE_INTEGRATION_2026-10-30.md`; rows E38/E39.
>
> §“v10 — Incus container runtime” (2026-09-15) is **no longer the newest** — §v11 above is the active conformance lane. v10 remains the **deployment plan of record:** it makes the
> **container the unit of deployment** (`curl -fsSL https://vclawhub.com/join.ts | bun -` installs prime-agent into a
> pre-provisioned Debian trixie Incus container). Study + evidence: `docs/RUNTIME_incus.md`.
> §“v9 — Orchestration & Multi-Agent Communication” is the next plan (2026-09-02); it owns the daemon-side worker model
> that v10 hosts. §“v8 — JSR migration” remains the packaging lane (operator directive 2026-08-31, unchanged below) and is
> a **dependency of v10 P0/P1** (the extension is not published, so no image can carry it yet).
> Historical v7.1/v0.6 content follows unchanged below the `── HISTORICAL ──` separator.

## v11 — Synadia Agent Protocol v0.3: conformance & integration upgrade

> 🚀 **NEWEST PLAN (2026-10-30).** Makes our v0.3 implementation **conformant, single, and shippable**,
> and decides whether the reference protocol ever reaches the IDP plane.
> Study of record: [`docs/lanes/SYNADIA_REFERENCE_INTEGRATION_2026-10-30.md`](../docs/lanes/SYNADIA_REFERENCE_INTEGRATION_2026-10-30.md);
> backlog rows **E38** (serving registration) / **E39** (one implementation).
> Spec: `vendors/synadia-agent-sdk-docs/core-protocol.md` (v0.3, status **Draft** — §11.3).
> Reference: `vendors/synadia-agents/{agent-sdk/typescript,agents/pi,client-sdk}`.
> Evidence tags: **[C]** code · **[M]** measured live · **[D]** doc. Every row below was checked against
> `packages/ext-synadia/src/` or the live site fabric on 2026-10-30.

### 0. Executive summary

| | Today | Target (v11) |
|---|---|---|
| Conformance | §2/§3/§5/§6/§8 largely correct; **§13 sender identity entirely absent**; §9 errors read but never emitted | every §12 checklist item either implemented or explicitly waived with a reason |
| Serving code | a second in-estate implementation answers; `ext-synadia` (spec-cited, tested) is built but idle **[M]** | **one** implementation serves, and it is the one with tests |
| Registration quality | `version: 0.1.0` (should be harness semver), no `session`, 8 stale instances **[M]** | `version` = harness semver, `session` set, deregistration + TTL sweep |
| Packaging | **JSR artefact omits `dist/**` and `packages/**`** while `pi.extensions` points into `dist/` **[M]** | `jsr publish --dry-run` file set == `npm pack` file set |
| Reach | v0.3 is site-fabric-only; no path to the IDP/tenant plane | an explicit decision: bridge, or document v0.3 as site-only with a fence |

### 1. Gap register

Severity: **H** breaks a conforming external client · **M** degrades interop or hides faults · **L** hygiene.

| # | § | obligation | our state | verdict | sev |
|---|---|---|---|---|---|
| **G1** | §13 | optional sender identity: `Agent-Sender` header, `min_sender_trust`, `id_sig`, replay window, 400/401 taxonomy | **0 occurrences** of `Agent-Sender` or `min_sender_trust` in `packages/ext-synadia` and `src/net` **[C]** | **MISSING** | **H** |
| **G2** | §9.1/§9.2/§9.3 | an error is a message carrying `Nats-Service-Error-Code` from the fixed taxonomy (400/401/403/404/409/429/500) **followed by** the empty terminator — two messages, and nothing after | headers are **read** correctly (`bridge.ts:152-160`, right precedence) but our inbound path never **emits** a coded error, so a conforming caller cannot distinguish a refusal from a normal stream **[C]** | **MISSING (egress)** | **H** |
| **G3** | §5.2/§12 | `attachments_ok` must be truthful; a caller enforces it locally before sending | `attachments_ok` defaults to **`"true"`** (`registration.ts:104`) while `index.ts` consumes **no** attachments **[C]** | **MISMATCH (false advertisement)** | **H** |
| **G4** | §7 | mid-stream query chunks and their replies (optional; §6.7 says an agent detects an abandoned caller only via a query timeout) | no `query` handling in `ext-synadia` **[C]**; §6.6 inactivity timeout and §6.7 cancellation semantics are **correct** (`bridge.ts:94-95,194`) | **MISSING (optional clause)** | M |
| **G5** | §8.3 | heartbeat SHOULD carry `endpoints` (prompt subject + metadata) and MAY carry `protocol_version` so a listener can prompt without discovery | heartbeat payload has `agent/owner/instance_id/ts/interval_s/session?`; **no `endpoints`, no `protocol_version`** **[C]** | **WEAKER** | L/M |
| **G6a** | §11.2/§12 | a caller reads `metadata.protocol_version` and applies compatibility rules | `discovery.ts:95` **copies** `protocol_version`; nothing branches on it **[C]** | **WEAKER** | M |
| **G6b** | §5.4 | enforce `max_payload` / `attachments_ok` locally before sending | `discovery.ts:31-34` exposes both; `bridge.ts:20` imports `parseMaxPayload` and uses it **[C]** | **OK** | — |
| **G7** | §8.5/§12 | subscribe to the heartbeat wildcard **before** the initial `$SRV.PING.agents` | discovery is **delegated** to `@nats-io/services` (`discovery.ts:75-80`, `svcm.client(...).info("agents")`) — the same library the reference uses, so the ordering is its contract, not ours | **OK (delegated)** — assert it in a test | L |
| **G8** | §3.1 | `version` = **semver of the harness**, not the protocol and not the extension | `registration.ts:88` uses `EXT_SYNADIA_VERSION` **[C]** | **DIVERGENT** | L |
| **G9** | §3.2 | `session` MUST be set for session-aware harnesses — `pi` named explicitly | `ext-synadia` sets it (`registration.ts:90-94`); the **serving** implementation reports none **[M]** | **MISMATCH (serving)** | **H** |
| **G10** | §3.4/§8.6 | multiple instances coexist; shutdown deregisters | **8 simultaneous instances**, all `version 0.1.0`, empty descriptions **[M]**. Deregistration **does** exist on the graceful path (`registration.ts:158-161` → `svc.stop()` on `session_shutdown`), so the leak is the **kill/crash** path: nothing reaps a registration whose process died, and nothing sweeps `started_at` | **PARTIAL** | **H** |
| **G11** | packaging | the published artefact must carry what `pi.extensions` declares | `jsr publish --dry-run` publishes **80 files** — `src/**` + `bin/*.js` + docs — with **0 from `dist/` and 0 from `packages/`** **while `pi.extensions` = `./dist/{pi-extension,ext-synadia}/index.bundled.js`** **[M]**; `npm pack` ships both bundles **[M]**. So on the declared primary registry the extension entries dangle | **MISMATCH (primary registry)** | **H** |
| **G12** | — | two planes, one estate | `ext-synadia` binds the local site fabric; the tenant plane lives in `src/net`; **no bridge in either direction** **[C]** | **MISSING (by decision)** | M |
| **G13** | §5 | one envelope implementation, shared | `bridge.ts:19` imports `parseCore`/`serializeCore` from **`@jsr/vclawhub__protocol-core`** — the published workspace package, not a copy. The §5 envelope is reused, not re-implemented **[C]** | **OK** | — |
| **G14** | §6.6 | chunks for a request go to **that request's** reply subject | ✅ **FIXED 2026-10-31** — the bridge now keeps **one prompt in flight** (`bridge.ts` `createBridge`): the next prompt is injected only on `turn_end`, so two inbound callers can no longer receive each other's answer, and a `turn_end` with nothing in flight (the local operator typing) replies to nobody. **Known limit, now tested rather than surprising:** the host carries no correlation id, so when a remote prompt IS in flight, the operator's own next turn is attributed to it — serialising removes the crossing defect, not this one (the reference's queued/active model has the same constraint). Regression test: `packages/ext-synadia/test/bridge-correlation.test.ts` (5 cases). |
| **G15** | §13/§10 | a sender identity must be a **key** that can sign (`id_sig`, `Agent-Sender`); per-agent authentication where the fabric allows it | the site plane has **no per-agent credential**: `connect.ts:51-52` connects with a **shared site token** (env → `~/.config/pi-a2a/server.seed`), and the agent identity is a **nonce string**, not a keypair (`identity.ts:2-7,43` — sprint ruling **Q1**, "separate nonce chain, independent from the NKey") **[C]**. So on the site fabric any holder of the token can claim any agent identity, and **§13 cannot be implemented without amending Q1** (a nonce cannot sign) | **MISSING / BLOCKED BY RULING** | **H** |
| **G16** | — | one implementation per concept |
| **G17** | §3.4/§8.6 | a reconnected instance must be discoverable again (registration survives a NATS reconnect) | `stop()` deregisters correctly (`registration.ts:157-164` → `svc.stop()`), but there is **no re-register on reconnect**: the service registers once and is never re-published, so after a transport blip a caller's `$SRV` view holds a dead instance until something evicts it (nothing does — G10) **[C]** | **MISSING** | **H** | presence / directory / heartbeat exist twice with different interfaces: `packages/ext-synadia/src/{presence,discovery,identity}.ts` vs `src/net/{presence,directory,heartbeat}.ts` **[C]** | **DUPLICATED** | M |


**What is already right, so it is not re-litigated:** §6.6 per-stream inactivity timeout (60 s default + overall TTL,
`bridge.ts:94-95,194`); §8.2 cadence, `interval_s` in the payload and "heartbeats begin AFTER registration"
(`registration.ts:14-15,84,145,153`); §6.7 cancellation (the spec defines **no** wire signal — our behaviour is the
specified one); §11.1 version format and `PROTOCOL_VERSION = "0.3"` (`registration.ts:27,94`); subject shape is conformant —
`defaultSubject()` builds `agents.{verb}.pi.{owner}.{name}` (`subjects.ts:23-25`, §2 + Appendix C);
§5.1 accepts **both** JSON envelopes and plain-text shorthand (`bridge.ts:14,22,28,30,122`);
§6 streaming is correct — `ack` first, `response` chunks, then a **zero-byte headerless terminator**
(`bridge.ts:77,85-87`, §6.4/§6.5); §3.1/§3.2/§3.3/§2.1/§8.7 registration fields are present and cited.

### 2. Beyond conformance — three real gaps, and one claim that did not survive checking

1. **The conformant code is not the code answering** (G9/G10, E39). Measured: 8 instances, `version 0.1.0`,
   `agent: omp`, empty description — none is `ext-synadia` (which would report its own description).
   Two implementations means neither is the source of truth; the one with tests is idle.
2. **The primary registry ships a broken extension declaration** (G11). JSR is the declared primary host
   (v8 §0). Measured: `jsr publish --dry-run` lists **80 files, none under `dist/` or `packages/`**, while
   `pi.extensions` names two files inside `dist/`. A JSR consumer gets a package whose extension entries
   point at nothing. npm still ships both bundles — which is exactly why nobody noticed.
3. **Checked and *not* a gap — the two extensions cannot collide on `$SRV`:** both declare in `pi.extensions`, but
   `ext-synadia` connects to the **site** fabric (`127.0.0.1:14222`, token) and `src/pi-extension` connects to the
   **tenant** fabric (`vchat3:4223`, JWT) — different servers, so neither sees the other's service registrations.
   A delegated report flagged this as a collision risk; it is not one today, and it would only become one if both
   were pointed at the same server.
4. **v0.3 cannot reach the fleet** (G12). Canon says sites get Micro and IDP agents do not
   (`docs/UNIFIED_A2A_FABRIC.md` V3.1), so this may be correct — but "correct by omission" is not a
   decision. v11 forces one: **bridge** the two planes, or **fence** v0.3 as site-only in the docs and
   drop the pretence that the estate speaks v0.3 end-to-end.

### 3. Migration plan (P0 → P3)

| phase | content | gate (observable) |
|---|---|---|
| **P0 — stop lying, ship what we declare** — ✅ **DONE 2026-10-31** | **G3** `attachments_ok` now defaults `false` **and the endpoint refuses attachments**; **G2** §9.2/§9.3 refusals emitted (empty · malformed JSON · oversize · attachment-when-false → `400` + code, then terminator); **G11** `dist/**` added to `jsr.json` (`packages/**` tried and dropped — jsr publishes nothing from it, and `@vclawhub/ext-synadia` ships that source); **G8** `version` = `harnessVersion ?? bundle`; **G9(part)** `session` wired | **[M] verified on the live site fabric:** four refusals `code=400 bytes=0`; valid envelope `bytes=2`; direct `$SRV.INFO.agents.<id>` shows `version=99.1.2`, `session=p0-session`, `attachments_ok=false`, `queue_group=agents`; `jsr publish --dry-run` 80 → **82 files** with both bundles. Unit pins: `packages/ext-synadia/test/conformance-p0.test.ts` (11 tests) |
| **P1 — one implementation, orderly lifecycle** (week) | **G9/G10**: pick the serving implementation (recommendation: `ext-synadia`, it has the tests) and retire the other; set `session`; deregister on shutdown (`svc.stop()`); TTL sweep on `started_at` | `$SRV.PING.agents` returns **1** instance per live session; killing a session removes it within the sweep interval; `version` reads the harness semver |
| **P2 — caller-side conformance** (week) | **G6** apply §11.2 compatibility on `protocol_version`; **G7** subscribe-before-discover; **G5** heartbeat `endpoints` + `protocol_version` | test asserts the heartbeat subscription is live before the first `$SRV.PING` is published; an unknown future version is handled per §11.2, not crashed on |
| **P3 — the big ones** (needs a ruling) | **G4** §7 mid-stream queries; **G1** §13 sender identity — **which first needs Q1 amended, because a nonce cannot sign (G15)**; **G12** bridge-or-fence | §13: a signed request verifies end-to-end, a bad signature gets `401`, a `signed`-only endpoint refuses an unsigned caller — and our own `Tier W` `from`-spoofing note (canon V3.1 Q9) can cite a real mechanism instead of an open question |

**Sequencing rationale:** P0 is all one-line-ish and removes the defects that make a conforming client
misbehave *today*. P1 removes the ambiguity of which code is authoritative — without it every later fix
lands in a tree that may not be the one running. P2 is where a caller stops being subtly wrong. P3 is
where the estate decides how much of the reference it wants to be.

### 4. Contract & surface changes (additive)

1. `registration.ts` — `attachments_ok` default `false`; `version` from the harness; `session` always set.
2. `bridge.ts` — an `emitError(code, message)` alongside the existing read path, using `msg.respondError`
   (or `respond` with headers if the framework lacks it — see **C1**).
3. `presence.ts`/`registration.ts` — heartbeat gains `endpoints.prompt{subject,metadata}` and
   `protocol_version` (§8.3 optional fields).
4. `discovery.ts` — a `compatible(info)` predicate implementing §11.2, used before any prompt.
5. `subjects.ts` — unchanged (already conformant).
6. `jsr.json` — `publish.include` gains `dist/**` and `packages/**`.
7. **Human surface — one tool, `/vclaw`, with subcommands** (operator ruling 2026-10-30):
   `status · claim · connect · peers · send · inbox · ping · family`. The ten existing commands
   (`vchat-status`, `vchat-connect`, `vchat-claim-status`, `vchat-directory`, `vchat-onboard`,
   `vchat-family`, `synadia-status`, `synadia-send`, `synadia-buddies`) become aliases for one release,
   each printing a deprecation pointer, then are removed. The *plane* becomes a flag (`--tier`), never a
   name prefix. `vclaw-agent doctor` is a **CLI** verb, deliberately outside the extension — it must work
   **Roadmap A LANDED 2026-10-31** — the model-free core is built and smoke-tested: `src/vclaw/{run,render,state}.ts`
   + `verbs/{status,doctor,peers}.ts`, `/vclaw` registered in the IDP extension (text via `ctx.ui.notify`, **no**
   envelope), `vclaw-agent vclaw <verb>` in the CLI with `--json`, completions generated from the one table; 14 unit
   tests; on this host `status` reports 59 cached peers and `doctor` passes 5/5. Next: **B** (`claim`, `watch`, `family`).
   exactly when the extension cannot load (G11).
   **CANONICAL SPEC: [`src/vclaw/README.md`](src/vclaw/README.md)** (verbs, flags, exit codes, degraded
   matrix, invariants, roadmap A-E).
   **It must run with no LLM configured** (operator mandate 2026-10-30): OMP executes command handlers
   locally without a model (`agent-session.ts:7249-7278`), and the interactive TUI starts model-less
   (`main.ts:2515-2523`, guarded by `!isInteractive`) — but **non-interactive `omp -p` requires a model**,
   so automation belongs to `vclaw-agent`, never to `omp -p "/vclaw …"`. The mandate is enforced as a
   lint: `grep -rE "prompt\(|sendUserMessage|model" src/vclaw/` must return nothing.
   **Consumer constraint (measured by `vclaw-desktop`, 2026-10-30):** that app ships extensions as
   `extraResources` and loads them into a harness child spawned with a cwd-scoped environment, so the
   module must be **import-side-effect-free** (no credential read, no connect, no write, no timer at load).
   `packages/ext-synadia` already passes this (BUILD-G §4); `src/vclaw` must too. Hosts consume the CLI
   `--json` — the `command_result` envelope is TUI-internal and is **not** a host API.
8. *(P3)* §13: `Agent-Sender` build/verify module + `min_sender_trust` in endpoint metadata; and, if the
   bridge is built, a v0.3↔tenant adapter in `src/net` (one direction at a time; start with
   v0.3-in → tenant-out).

### 5. Compatibility gates — verify, do not assume

| # | question | why it blocks | how to verify |
|---|---|---|---|
| **C1** | does `@nats-io/services` expose an error-response helper with headers, or must we set headers ourselves? | G2's implementation shape | read `@nats-io/services` types; one live probe |
| **C2** | what does `pi` do when `pi.extensions` names a file that does not exist? | decides whether G11 is "broken install" or "silent no-extension" | install the JSR artefact in a throwaway home and start pi |
| **C3** | do requests arriving on `prompt` carry editable NATS headers (for §13 `Agent-Sender`)? | G1 depends on it | probe with a header-bearing request |
| **C4** | does any *real* caller send attachments today? | decides whether G3 is active or latent | grep our own callers + the reference client |
| **C5** | is `0.3` still Draft upstream, and has 0.4 appeared? | we implement a draft; §11.2 tolerance matters | check `core-protocol.md` §11.3 at build time |

### 6. Wave breakdown (dispatch-ready)

- **W11-0 (P0)** — attachments default, §9 error emission, JSR publish set, `version` = harness semver.
  *Verify:* malformed-prompt probe returns `400` + code; `jsr publish --dry-run` lists both bundles.
- **W11-1 (P1)** — one implementation + deregistration + TTL sweep + `session`; **and G14** reply correlation
  (key the pending map by reply subject / conversation id instead of popping an array).
  *Verify:* `$SRV.PING.agents` instance count equals live sessions; a killed session disappears; two
  concurrent prompts each get their own answer (a test that fails against the array today).
- **W11-2 (P2)** — §11.2 compatibility predicate, subscribe-before-discover, heartbeat `endpoints`.
  *Verify:* ordering test; unknown-version test.
- **W11-3 (P3a)** — §7 mid-stream queries. *Verify:* a query chunk during a slow turn gets a §7.2 reply.
- **W11-4 (P3b)** — §13 sender identity. *Verify:* signed/unsigned/bad-signature matrix per §13.9.
- **W11-5 (P3c)** — bridge-or-fence decision + doc.

### 7. Acceptance criteria

1. A **reference** client (`vendors/synadia-agents/client-sdk`, python) discovers our agent, prompts it,
   and consumes the stream — including the `ack` chunk and the zero-byte terminator — without adaptation.
2. A malformed prompt returns `400` with `Nats-Service-Error-Code`; an oversize prompt is rejected
   *before* work starts; `attachments_ok` and the actual behaviour agree.
3. `$SRV.PING.agents` shows exactly one instance per live session, each with the harness semver and a
   session label; kill a session → it leaves within the sweep.
4. The JSR artefact contains both `dist` bundles and `packages/ext-synadia`; installing it and starting
   pi loads both extensions.
5. §11.2: an agent advertising an unknown future version is skipped with a log, never prompted.
6. *(P3, if taken)* §13: the four-case matrix (absent / claimed / verified / bad-signature) behaves per
   §13.9, and our canon's "`from` is self-asserted" note is retired with a citation.

### 8. Risks / non-goals

- **Risk — the spec is a Draft** (v0.3). §13 alone is ~300 lines and `0.2`→`0.3` was wire-incompatible.
  Pin the revision we implement (ship the spec file in-tree) and re-check on every bump.
- **Risk — P1 deletes code someone depends on.** Whichever implementation loses must be proven dead
  first: grep for its description string, its metadata keys, and its build entry.
- **Non-goal — replacing `@nats-io/*` with `@synadia-ai/agent-service`.** The re-implementation is
  deliberate (no extra dependency, our identity model). v11 makes it *conformant*, not upstream-owned.
  The doc, not the dependency, is what was missing.
- **Non-goal — forcing v0.3 onto the IDP fleet.** G12 asks for an explicit decision, and "site-only,
  documented" is a legitimate outcome.

### 9. Coverage of this register

Every row above was checked in `packages/ext-synadia/src/` or against the live site fabric on 2026-10-30;
G9/G10 and G11 also carry **[M]** measurements (instance enumeration; `jsr publish --dry-run` file counts).

**Delegated claims that did not survive checking** (recorded so they are not re-filed): *"`$SRV.STATS` is MISSING"* —
it is provided by the framework we use (`@nats-io/services` `service.d.ts:7-9,43,74`, and `registration.ts:24` uses `Svcm`);
*"instance enumeration MISSING"* — the framework serves `$SRV.*.<name>.<id>`; only our *helper* omits the instance form
(`discovery.ts:80`), a caller nicety (§4.2), not a server gap; *"max_payload WEAKER"* — `parseMaxPayload` **is** used
(`bridge.ts:20`); *"subject tokens from `$USER`/cwd MISSING"* — that is the reference channel's **default**, deliberately
not ours (owner + nonce, Q1). The reference's `tools.ts` / `local-turns.ts` are **harness features, not protocol**
clauses; their substance is already covered by G14 (concurrency).

**Delegated slices that did not return — and the manual replacement:** `ProtocolMatrix` was re-run by hand
(§1–§11 walked clause by clause on 2026-10-30); its findings are folded into the register above, and the
clauses it would have "found" already correct are recorded so nobody repeats the pass. The other two, (`ProtocolMatrix` — full §-by-§ requirement
matrix; `ReferenceImpl` — capability diff against `@synadia-ai/agent-service` + `agents/pi`;
`TwoPlaneWiring` — two-plane collision/bridge audit) were spawned for a deeper sweep and produced **no
output** on this fabric. The rows above are therefore **mine, verified individually**; the delegated
sweep may add rows, but nothing here depends on it. Re-run those three when the fabric is healthy —
`ProtocolMatrix` in particular is mechanical and would find any §-clause missed below.

## v10 — Incus container runtime (VClaw Runtime as a container)

> **Status:** AGREED (operator, 2026-09-15) — plan of record. Study, measurements and lane reports:
> `docs/RUNTIME_incus.md` (detailed) + `.prime/handoff/incus-runtime/` (ledger `00-FINDINGS.md`, lanes A–C,
> raw command output, 20+ captures). Every claim below is marked **[O]** observed with archived raw output or
> **[R]** read from source. Measured 2026-09-15 against ct17 (Ubuntu 24.04.5, Incus 7.0.1) and kuai (Debian 13 trixie).
> **Supersedes the ad-hoc July prototype** (`debian-trixie-pi-agent` image + `pi-agent` profile), which is inert as built.

### 0. Executive summary

| | Today | Target (v10) |
|---|---|---|
| Deployment unit | a host with an SDK install; container only accidentally | **one container = one agent** = one `$HOME` = one agent dir; disposable instance, durable volume |
| Base image | `debian-trixie` (no cloud-init, no DHCP → silent no-op) or a stale July image baking **pi.dev** | a baked `vclaw-agent:trixie-prime` image: cloud-capable trixie + bun + **uv** + pinned **prime-agent v0.9.4** + the extension bundle, **no identity** |
| Runtime installed by | the pipe, over a slow/flaky npm leg (25 s–321 s per container) | **baked**; the pipe only establishes identity + claim + config |
| Runtime default | **none installed** unless `--runtime`/`VCLAW_RUNTIME` is given; resolver falls back to `"pi"` | **prime-agent is the default**, so the documented one-liner is literally correct |
| Provisioning | manual, per host | **profile + cloud-init**: env, DNS, a real systemd unit, extension symlink, per-agent state volume, `proxy` device where inbound is needed |
| State | in-container, lost with the container | **per-agent custom volume** for `~/.prime/agent` (kernel venv included), snapshotted; containers are disposable |
| Limits | assumed volume quota | **quotas are NOT enforced** (btrfs qgroups) → class-per-pool + monitoring, and never document a size as a boundary |

### 1. Reality check (what the measurements say)

- **The platform is capable.** Incus 7.0.1 on ct17 provides network ACLs/zones, projects with features+limits, cloud-init, `launch --ephemeral`,
  `exec`/`file`, `config device add` (disk|nic|proxy), instance+volume snapshots, snapshot schedules/expiry, `incus publish`, storage buckets, `/1.0/metrics` **[O]**.
  Two btrfs pools (`sda-data` = `/opt/sda-data`, 932 G / **251 G free**, zstd — recommended; `btrfssdb` = `/var/lib/docker`, 845 G free but scheduled for re-layout), one project.
- **The cloud image is the viable base; the plain image is a trap.** Plain `debian-trixie` has **no cloud-init** (the profile's user-data never runs; launch still exits 0) and **no DHCP**
  (no IPv4, no route, DNS fails). `debian-trixie-pi-agent` has cloud-init that **runs** (v25.1.4, 12 modules, 0 failures) and brings the network up automatically **[O]**.
- **The pipe works** in that image with **no apt step**: `curl … | bun - --runtime prime-agent` → rc 0, prime-agent **v0.9.4**, as root and as the unprivileged `debian` user **[O]**.
- **prime-agent is not the default** (`join-script.ts:136/:177`) — a code change, not a config **[R]**. `https://vclawhub.com/prime-agent/latest.json` is also **served as the
  43,002 B HTML fallback from some locations** (JSON from ct17, HTML 5/5 from a Mac) so **prime-agent installs fail from those locations today** **[O]**; `landing-removed/public/prime-agent/` is gitignored, pointing at the deploy-time fetch.
- **`uv` is a hard gate with no silent fallback**, and the interactive installer **can never be answered in a container** (`stdin.isTTY && stderr.isTTY`): either bake `uv` or set
  `PRIME_AGENT_INSTALL_UV=1`. Verified fix: uv 0.12.14 + a Python 3.11.16 kernel venv in **100.4 s** **[O]+[R]**.
- **Restart safety: PASS.** Two `incus restart`s: same DHCP lease, default route, DNS, unit still active, markers intact. cloud-init's per-instance semaphores make packages/write_files/runcmd
  one-shot while the network stage runs every boot — which is what keeps DHCP working **[O]**.
- **Sizing:** a *ready* agent adds ≈**570 MB** (prime-agent 249 + uv 49 + venv 273) over the 682 MiB image → **≈1.25 GB per ready container**; bootstrap peak memory **1.05 GiB against a 2 GiB cap** **[O]**.
- **Quotas are decorative:** 700 MiB written into a 512 MiB volume returned rc=0 on both pools **[O]** (logged in the pitfall log).

### 2. Architecture

```
image (bake)            runtime + toolchain, NO identity, reproducible build script
profile (cloud-init)    env (VCLAW_RUNTIME, PRIME_AGENT_INSTALL_UV, NATS URL, PATH), real systemd unit,
                        extension symlink, readiness marker, devices (disk/nic/proxy), limits
instance (per agent)    1 container = 1 agent = 1 $HOME = 1 agent dir  — also removes the
                        supervisor-owner-registry hazard (it is keyed to $HOME, not the agent dir)
volume (per agent)      ~/.prime/agent state incl. the kernel venv (100 s to build) — snapshotted, survives rebuilds
network                 egress via the host (free, no device); inbound only via `proxy` device; fabric endpoint per §3
```
- **One command flow:** `incus launch vclaw-agent:trixie-prime <agent> --profile vclaw-agent` then
  `incus exec <agent> -- su - debian -c 'curl -fsSL https://vclawhub.com/join.ts | bun -'`.
- **Run the pipe as the agent user**, never root with `HOME` pointed at the agent user's home (it leaves root-owned 0600/0700 state the agent cannot read) **[O]**.
- **Never bake identity.** The image carries no `~/.vclaw`, no `config.json`; identity + claim are per agent.

### 3. Phases

| phase | content | gate |
|---|---|---|
| **P0** | funnel: prime-agent as default; fix the `latest.json` HTML-fallback serving; re-verify digests | no-flag run installs prime-agent; manifest served as JSON from ≥2 vantage points — **default LANDED 2026-09-16** (`landing@7dad7ad`); serving ROOT-CAUSED: live Pages deploy serves nothing under `/prime-agent/` from origin (warm-cache countdown ~5 days); fix = operator `wrangler login` (Pages scope) + `VCLAW_MANIFEST_SIGNING_KEY=… pnpm deploy:pages`, then `verify-funnel.mjs` from 2 vantages; manifests now Ed25519-signed + verified in-pipe (VGATE_UPGRADE §2026-09-16) |
| **P1** | bake `vclaw-agent:trixie-prime` from a script (cloud base + bun + uv + unzip + pinned prime-agent + extension), no identity | in-image: `prime-agent --version`, `uv --version`, extension `get_commands` = 5, no `~/.vclaw` — **DONE 2026-09-16** (fp `e7ccedc63ada…`, 797 MiB packed / 2237 MB rootfs; all gates + restart-safety green; extension blocked by v8 publish — J5) |
| **P2** | `vclaw-agent` profile + per-agent state volume | launch → unit active, marker asserted, IPv4+route+DNS, volume at `~/.prime/agent`; **restart-safe (already GREEN)** |
| **P3** | a reachable fabric endpoint for ct17-container agents (see §4) | a container completes a claim **and** appears in the fabric |
| **P4** | one-command acceptance (in-container host-readiness gate + pipe + claim + presence); kuai parity; snapshot/restore drill | one command reaches "agent ready + present"; the gate exits 0 **inside** the container |

### 4. Fabric topology — **DECIDED: option A** (canon: `docs/UNIFIED_A2A_FABRIC.md` V3.1)

**A**: containers reach the fabric over the host's tailnet egress with the container's **per-link DNS → `100.100.100.100` + search `ruffe-court.ts.net`**. No proxy, no per-container
`tailscale`, no new port/credential, **no agent-sdk change** (the SDK default `nats://vchat3:4223` then works verbatim). Measured: a container resolves `vchat3` (`100.106.248.70`)
and completes a full NATS CONNECT/PING round trip; with the resolver removed it cannot address `vchat3` at all (falsifier run). The agent needs **no inbound** — every path is
subscribe/publish and the only listener binds `127.0.0.1`. Caveat: containers masquerade as the host, so **network-layer isolation does not exist** — isolation comes from NATS
identity (per-agent JWT + grants). Blocker found: the old `pi-agent` profile sets a dead `NATS_URL=nats://10.148.17.1:4222` which **overrides** the working default; the new
profile must not set it. C (host proxy device) is proven as a fallback, B (per-container `tailscale`) is the future answer for per-agent isolation (capability proven, auth untested).

<details><summary>Original open question (kept for the record)</summary>

Reality: containers get tailnet **egress** free through the host (masquerade via `tailscale0`, exit node `vchat3`) **[O]**; **inbound requires a `proxy` device** **[O]**;
**no VClaw NATS is reachable from ct17 today** (the profile's `10.148.17.1:4222` is refused; the only NATS found is the unrelated `timeliner` container) **[O]**;
`login.vclawhub.com` is public. Canon says the fabric is a **Synadia mesh over a leaf-hub**: intranet sites run a local site NATS and the hub admits each **site** as one principal.
Options under review: **(A)** containers ride host tailnet egress to the hub endpoint; **(A′/recommended direction)** **the host IS the site** — a site NATS on ct17 (bound to the bridge) that containers use locally,
with the host holding the leaf/uplink, so containers need no tailnet, no proxy and no per-container NATS identity; **(B)** per-container `tailscale`; **(C)** host-side broker/proxy with containers tailnet-free.
The decision is driven by which principal a container *is*: an IDP agent with its own JWT, or a principal on the host's site plane.</details>

### 5. Jobs

J1 funnel default → prime-agent · J2 fix `latest.json` serving · J3 image bake script + publish · J4 profile v2 · J5 extension install into `~/.prime/agent/extensions` (**blocked by the v8 publish blocker**:
`jsr.json` `publish.include` omits `dist/`, so no published artifact carries the extension) · J6 fabric endpoint + inbound proxy where needed · J7 state volume + snapshot/restore policy ·
J8 in-container host-readiness gate · J9 kuai parity (`incus-admin` membership + the 6.0.4-vs-7.0.1 support matrix) · J10 observability (`/1.0/metrics`; note `incus list -c n,d,4` prints no disk usage in 7.0.1 —
use `incus info`) · **J11 restart survival — ANSWERED, PASS** · **J12 `uv` necessity — ANSWERED: required** · J13 per-agent sizing vs memory cap · J14 per-agent provider credential path
(a fresh container has none: `prime-agent -p` → rc 1, "No API key found for the selected model").

### 6. Relationship to v9 and v8

- **v9 (orchestration)** assumed a daemon spawning worker sessions on a host. v10 does not change that model: the container hosts the daemon, and the family/worker semantics are unchanged.
  Where they meet: **one container = one `$HOME`** removes v9-era hazards that come from many agents sharing one home.
- **v8 (JSR publish)** is now a **hard dependency**: v10's P1 image must carry the extension, and the extension is not in any published artifact
  (`dist/` is excluded from the JSR publish set). Either publish `dist/` or bundle the extension into `bin/agent.js`.

### 7. Non-goals / risks

- **Not** a cluster: ct17 is a single node; multi-node placement, and the kuai version skew, are out of scope for v10.0.
- **Not** an isolation boundary for disk: quotas are decorative (§1). Memory/CPU limits do hold; disk needs class-per-pool + monitoring.
- **Risk — image drift:** the July image baked the wrong runtime and expired. The image must be built by a script, version-pinned, and re-verified by the P1 gate.
- **Risk — fabric endpoint:** until P3 lands, no container can finish a claim; this is a deployment gap, not an Incus limitation.

## v9 — Orchestration & Multi-Agent Communication (Prime-Agent-style session model)

> **Plan of record (2026-09-02).** Study: `docs/PRIME_AGENT_VCLAW_INTEGRATION.md`
> (RESEARCH-ARCHIVE) + Prime Agent blog "Orchestration and Multi-Agent Communication".
> Direction: give the SDK a **daemon-owned orchestration layer** — worker sessions
> spawned under **one steward credential**, family-scoped communication, steering with
> receipts, persistent children with transcripts — mapped onto the IDP ownership plane
> so it needs **no new wire grants and no vgate changes** in its first form (Tier L,
> local). The IDP wire (Tier W) is used only where it is actually needed: same-owner
> multi-host. Cross-owner segment A2A stays on today's mailbox semantics.
>
> **Rulings (operator, 2026-09-02):** R1 — **local-first** (Tier L daemon socket; wire lane
> stays Tier W / v9.5, G1-gated; wire-first benefit analysis in `docs/PRIME_AGENT_VCLAW_INTEGRATION.md` §7.1).
> R2 — **one steward credential per host-daemon**, consistent with the IDP's one-steward-per-pi model.
> R3 — **lead announcement carries `children[]`** (announcement v2); workers are not directory principals.
> R4 — **best-effort mailbox + local durable inbox**; store-and-forward gated on V3.1 Q7.
> R5 — §5 of the study promoted into this §v9 (plan of record); the study doc stays RESEARCH-ARCHIVE.

### 0. Executive summary

| | Today | Target (v9) |
|---|---|---|
| Agent model | Flat: one NKey = one agent = one subject root; peers are equals on a segment | **Lead + workers**: one steward credential spawns worker sessions; workers are family members, not segment peers |
| Orchestration | A2A mailbox request/reply only; no session lifecycle | **Daemon** (`vclaw-agent serve`) owns worker pi processes: spawn / steer / stop / reload; Running-Idle-Inactive states |
| Communication scope | Segment-wide `a2a.>` (no follow gate) | **Nuclear family first**: parent⇄children via local socket (Tier L); same-owner family lane on the wire (Tier W, additive) |
| Delivery | Fire-and-forget mailbox | Tier L: real receipts (`delivered`/`queued`, ack over socket). Tier W: best-effort + envelope `receipt` extension |
| Results | Reply or file | Reply, file, or family `events` subject — plus per-child JSONL transcripts (pi.dev session files already exist) |
| Persistent state | Credentials + roster on disk (read-only on KV) | Family dir per lead: roster, role specs, receipts — agent-CRUD-able (harness analog), **still not on KV** |
| Identity | One claim per NKey (steward-bound) | **Unchanged** — workers share the lead's NKey/JWT; no new claims, no new approvals |
| Wire grants | PERMISSIONS.CLAIMED_AGENT (deny-by-default) | **Unchanged** — family names live under the already-granted owner plane |

### 1. What we're copying from Prime Agent — and what we're not

**Copy (mapped to IDP constraints):**
1. Spawn returns at admission, answer arrives later — worker spawn is async; results via reply/file/event.
2. Communication confined to the **nuclear family** (parent/siblings/children) — prevents the "undesirable cross-session communication" the Prime Agent blog cites; maps to the IDP's owner plane (already owner-only by grant).
3. Persistent children: a worker's session dir, context, and history persist after the task; the lead can send follow-ups by `(family_id, name)` later — survives daemon restarts.
4. Steering a busy worker mid-run (blog: "steer or extend a child mid-flight").
5. Idle children unload after inactivity and reload on demand (Running/Idle/Inactive state machine, ~30-min unload analog — locally tunable).
6. One daemon owns all sessions; attach/detach safe; crash recovery from JSONL + kernel state.
7. Files as results; transcripts as audit artifacts.
8. Roles as configuration: reusable role specs (prompt + caps) persisted per lead, spawnable by name.

**Not copying (IDP-mismatched or not-yet-secure):**
- Cross-owner messaging *outside* segment policy — stays denied by grants.
- Trusting wire `from` for steering — envelope `from` is still self-asserted (V3.1 Q9); Tier L derives sender from the socket; Tier W trusts only the owner-plane namespace (same steward).
- Harness state CRUD on the IDP KV — agents are read-only on KV; the harness analog lives in the family dir, with vgate sync as a later option.
- Micro discovery / per-child signed announcements — children are not directory principals in v9; the lead's announcement may carry `children[]` (see R3 in the study doc, and §4 below).

### 2. Current-state inventory (verified 2026-09-02)

| Surface | State | Evidence |
|---|---|---|
| Identity | One NKey per agent; one steward per NKey; claim via browser OIDC; 1h JWT mint/refresh | `src/commands/onboard.ts`, `src/agent/lifecycle.ts` (`fetchNatsUserJWT`, 50-min refresh) |
| Wire plane | `tenant.<seg>.user.<nkey>.agent.<nkey>.{hb,prompt.req,session.<op>.req}` + `a2a.<nkey>` mailbox; **one SUBJECT_ROOT per process** | `src/contracts/contracts.ts`, `src/agent/runtime.ts` (`setTenantSegment`) |
| Grants | `PERMISSIONS.CLAIMED_AGENT` pub13/sub7, deny `$SYS.>`; agents read-only on KV; group grants dead | `src/contracts/contracts.ts`, `test/unit/v3-grants-conformance.test.ts` |
| Envelope | `A2aRequest/Response {type,id,prompt,from, a2a{intent,replySubject,conversationId}}` + ChunkPayload §6 | `src/contracts/contracts.ts` |
| Presence | 30s hb + 30s NKey-signed announcement; 90s TTL; canonical-byte sigs | `src/net/presence.ts`, `src/net/directory.ts` |
| Family precedent | pi-a2a local fabric only: `family.ts` familyId gate, child registry, receipts rehydration, `/a2a-children` | `A2A/pi-a2a/src/a2a/family.ts`, `docs/FAMILY_ORCHESTRATION.md` |
| pi integration | Per-session extension instantiation; `session_start` → creds → presence → A2A sub (sendUserMessage injection); 5 slash commands | `src/pi-extension/index.ts` |
| Site mesh | ext-synadia = separate local site fabric (Synadia v0.3, Micro) | `packages/ext-synadia` |
| Session files | pi.dev JSONL per session (`~/.pi/agent/sessions`) | pi-a2a README (storage layout) |

**Gap that defines v9:** nothing on the IDP plane models *sessions under a lead*. A
worker today is either an independent NKey (full onboarding friction per worker) or a
second pi process that is simply *not addressable* as a child.

### 3. Target architecture

```text
ONE HOST (owner X)                            v9 pieces (NEW)
┌──────────────────────────────────────────┐
│ vclaw-agent serve  (daemon, new)         │  spawn/stop/steer workers
│  ├─ family dir per lead                  │  roster + role specs + receipts
│  │   ~/.config/vclaw/family/<lead>/      │  (agent-CRUD, disk; NOT KV)
│  ├─ session JSONL per worker             │  transcripts = audit artifacts
│  └─ local socket (Tier L)                │  identity = daemon-derived
│       ▲ worker pi processes (same host)  │  Running/Idle/Inactive
└───────┼──────────────────────────────────┘
        │ Tier W (same-owner, multi-host; v9.5): reuses the OWNER plane
        │ tenant.<seg>.user.<nkey>.agent.<nkey>.family.<family_id>.<name>.<verb>
        ▼ (inside existing CLAIMED_AGENT `.>` grants — verify per §5 G1)
    vclaw IDP wire — unchanged grants, unchanged vgate
```

### 3.1 Deployment notes — LXC/LXD container topologies

Assumptions adopted for v9's scope (design: `docs/PRIME_AGENT_LXD_DEPARTMENT.md`):

- **One container = one Prime Agent = one IDP agent** (one NKey, one steward claim) plus
  its own Tier L family inside; never two IDP principals in one container.
- Containers on one LXD managed bridge form a private LAN — a department NATS bus may
  run there (Design C, recommended for multi-agent "company department" deployments);
  each container keeps its own IDP connection for announcements/segment mailbox/humans.
- **Cross-steward department hierarchy is segment-level** (roles via policy ∩
  announcement capabilities), NOT NKey-subject family — R3's `children[]` stays
  same-steward-only. A `role` announcement facet is deferred (announcement v3 candidate).
- Tier W (wire family lane, v9.5) covers **same-steward multi-host** only; the dedicated
  SITE leaf-node shape (Design B) is out of scope until `SITE_MESH` has a live consumer.
- The local durable inbox (R4) is the per-agent floor; a department bus with its own
  JetStream extends store-and-forward *internally* without touching hub grants.

### 4. Contract & surface changes (all additive)

1. **Envelope extension** (v9 fields, §5.6-tolerated style): `family { role?, steer?, receipt? }`
   on `A2aRequest`; `receipt` = `delivered|queued` on replies when requested. Tier L uses
   socket acks (real); Tier W uses these fields (best-effort).
2. **Family subjects (Tier W, same-owner only):**
   `tenant.<seg>.user.<nkey>.agent.<nkey>.family.<family_id>.<name>.<verb>`
   with verbs `prompt.req` / `hb` / `events` / `reply.<conv_id>`. Family id = UUIDv4
   minted at first worker spawn, persisted in the lead's family dir.
3. **Announcement v2 (optional `children[]`):** `{v:2, ..., children:[{name, role, caps,
   state}]}` — published by the **lead** only, same exact-path-pinned subject. Keeps
   workers off the directory as principals while making the family visible. Bump `v`
   (v1 announcements keep validating; directory must accept v1+v2).
4. **New binary** `vclaw-agent serve` (daemon) + `vclaw-agent panel` (Agents-View-analog
   TUI: leads see workers with job text, states; workers see their lead) + `vclaw-agent
   spawn/steer/kill <name> --role <spec> --prompt "…"`.
5. **Dept transport profile (dual-plane, optional — W1.5):** second first-class NATS
   connection for a department bus (e.g. ct17 `gzone-net` NATS) alongside the IDP plane
   — `VCLAW_DEPT_URL` + local user creds (nsc-minted, `gzone.>`-scoped ACLs), own
   subject root and reconnect policy, modeled on `packages/ext-synadia/src/connect.ts`.
   Daemon routes per recipient: Tier L socket → dept bus → IDP mailbox, so callers
   address `(agent, role)`, never a wire. Bus traffic reuses the A2a envelope
   (`family{}`/receipt fields) but is department policy, NOT owner-plane — no
   interaction with `PERMISSIONS.CLAIMED_AGENT`. JetStream on the bus is the R4
   durable-inbox floor *inside* the department.
6. **Pi-extension**: worker sessions auto-connect to the daemon socket on `session_start`
   (mode `family-worker`); `/vchat-family` slash command on the lead lists/steers.
7. **No changes**: `contracts.ts` principal planes, `PERMISSIONS.CLAIMED_AGENT`,
   token.go/callout, nats-init buckets, KV grants, vgate routes. (Verify, don't assume — §5.)

### 5. Compatibility gates — VERIFY before building (blocking questions)

- **G1 (grant reach):** perm-probe that `tenant.<seg>.user.<nkey>.agent.<nkey>.family.>` is
  inside the minted JWT allow-list (both pub + sub) for a claimed agent. If the grant is a
  template narrower than `.>`, Tier W needs a token.go template widening (small, but a
  grant change — ruling required).
- **G2 (announcement v2):** directory (`sidecar/internal/directory` + Go mirror) must
  accept `v:2` + `children[]` without breaking v1 consumers; canonical-byte signing must
  cover `children[]`; conformance fixtures TS↔Go updated in lockstep.
- **G3 (one subject root):** `runtime.ts` currently runs one SUBJECT_ROOT per process.
  Tier W needs per-conversation multiplexing inside that root (family id in subject +
  conversationId correlation) — verify no cross-family bleed in reply routing (pi-a2a's
  FIFO-pop sharp edge is the cautionary tale: use conversation-scoped replies, not a
  head-of-line FIFO).
- **G4 (worker creds):** workers sharing the lead's JWT connect as the same NKey —
  verify multi-connection same-credential is unproblematic server-side (it is stock NATS;
  confirm no client-side singleton assumptions in `lifecycle.ts`).
- **G5 (offline):** Tier W has no store-and-forward (V3.1 Q7 deferred) — document
  best-effort semantics; Tier L daemon keeps a local durable inbox for its own workers.
- **G6 (retire/lifecycle):** killing a lead must terminate or orphan its workers —
  rule: workers die with the daemon (SIGTERM cascade); wire family state cleared on
  lead `retire`.

### 6. Wave breakdown (dispatch-ready)

- **W0 — contracts + fixtures:** envelope `family` fields; subject templates; v2
  announcement schema + canonical bytes; TS conformance fixtures + Go mirror update;
  G1 perm-probe result recorded. *Verify: contract tests green; perm-probe table filled.*
- **W1 — Tier L daemon:** `vclaw-agent serve/panel/spawn/steer/kill`; family dir
  (roster/role specs/receipts); socket protocol; pi-extension worker mode; session JSONL
  per worker; Running/Idle/Inactive + reload-on-address; crash recovery. *Verify:
  spawn→steer→reply round-trip; daemon restart rehydrates children (list via
  `vclaw-agent panel`); idle unload/reload.*
- **W1.5 — dept transport profile (dual-plane; ct17 gzone pilot):** second first-class
  NATS connection for the department bus alongside the IDP plane — `VCLAW_DEPT_URL` +
  local user creds (nsc-minted, `gzone.>`-scoped ACLs), own subject root + reconnect
  policy, modeled on `packages/ext-synadia/src/connect.ts`; daemon routing table
  (Tier L socket → dept bus → IDP mailbox) so callers address `(agent, role)`, never a
  wire; envelope reuse (A2a + `family{}`/receipt fields) on the bus — department policy,
  NOT owner-plane, no `PERMISSIONS` interaction; JetStream durable inbox as the R4 floor
  *inside* the department. *Verify: dual-connect simultaneous with hub presence; ACL
  isolation per container user; cross-container round-trip with mid-flight disconnect
  replay; plane-independence drills (hub down → dept continues; bus down → IDP
  continues).*
- **W2 — Tier W family lane (same-owner multi-host, gated on G1):** family subjects +
  envelope receipts; per-conversation reply routing (G3); best-effort delivery
  documented. *Verify: lead on host A ⇄ worker on host B under one steward; no
  cross-family bleed; receipt semantics as specced.*
- **W3 — directory children[]:** announcement v2 + children state mirror (30s tick);
  directory/board shows family grouping. *Verify: v1 agents unaffected; v2 sigs verify;
  cross-segment invisible.*
- **W4 — acceptance + eval:** full matrix; eval harness (fan-out review task over N
  workers); docs (`docs/PRIME_AGENT_VCLAW_INTEGRATION.md` §7 rulings R1–R5 consumed).

### 7. Acceptance criteria + test plan

1. One steward credential spawns ≥3 workers on one host; each runs a full pi.dev
   session under the daemon; results return by reply **and** file.
2. Family communication is unreachable from any other owner's agent (perm-probe +
   integration test) and unreachable from the segment plane (no new grants).
3. Steering a busy worker mid-task changes its trajectory (follow-up injected between
   turns); a worker that finished can be re-addressed by `(family_id, name)` after
   daemon restart.
4. Idle workers unload from memory and reload on demand without losing history.
5. Announcements v2 with `children[]` verify end-to-end; v1 peers unaffected.
6. Lead `retire`/kill cascades workers; no orphan NATS connections after SIGTERM.
7. No changes to vgate routes, token.go grant sets, KV buckets, or nats-init (unless G1
   forces the single template widening — recorded as a ruling).
8. **Dual-plane (dept profile, W1.5 / ct17 gzone pilot):** a container holds hub + bus
   connections simultaneously with hub presence intact; dept user cannot pub/sub outside
   its ACL slice; cross-container bus round-trip survives a mid-flight disconnect
   (JetStream replay); plane-independence drills pass (hub down → dept continues; bus
   down → IDP mailbox + announcements continue).

### 8. Related documents

- `docs/PRIME_AGENT_VCLAW_INTEGRATION.md` (study + integration proposal; rulings R1–R5)
- `docs/PRIME_AGENT_LXD_DEPARTMENT.md` (container topology + department A2A designs)
- `docs/GZONE_DEPT_BUILD_PLAN.md` (ct17 host execution plan, P0–P4; NOT-EXECUTED, operator-gated)
- Prime Agent blog — "Orchestration and Multi-Agent Communication"
- `A2A/pi-a2a/docs/FAMILY_ORCHESTRATION.md` (local family precedent)
- `docs/AGENT_NETWORK_SEGMENT_FABRIC.md` + `docs/UNIFIED_A2A_FABRIC.md` (canon)

### 9. Wave status — working annex (updated by waves; folded by the committer)

> Status as of the 2026 W3+G2+W2+W4-side batch (reports:
> `.prime/handoff/v9/W3-DIRECTORY-CHILDREN-REPORT.md`,
> `W3-G2-GO-MIRROR-REPORT.md`, `W2-FAMILY-WIRE-REPORT.md`,
> `W4-EVAL-ACCEPTANCE-REPORT.md`; commit refs for earlier waves in the
> submodule log: W0 `01cf2e9`, W0.5 `119df6c`, W1 cp1+W1.5 `9130567`,
> W1 cp2 `7ea8312`).

| Wave | Content | Status |
|---|---|---|
| W0 | contracts + fixtures + G1 probe | ✅ (structural G1 PASS recorded) |
| W0.5 | schema regen + live-JWT mint helper | ✅ |
| W1 | Tier L daemon + pi.dev worker driver + receipts + idle unload/reload | ✅ cp1+cp2 |
| W1.5 | dept transport profile (dual-plane code) | ✅ code; live ct17 gzone pilot operator-gated |
| W2 | Tier W family lane transport (`src/daemon/family-wire.ts`) | ✅ v1, hermetic-tested; not yet wired to any caller (cp3/deploy) |
| W3 | directory children[]: lead v2 emission + family-dir mirror | ✅ `presence.ts` v2 + `daemon/family-children.ts` |
| G2 | Go directory mirror accepts v2 (dash/sidecar) | ✅ v2 acceptance + golden tests (39/39 pkg) |
| W4 | eval harness + acceptance + docs | ✅ SDK-side (`daemon/eval.ts` + `vclaw-agent eval`); full-matrix live legs operator-gated |
| cp3 (W1 §4.6) | pi-extension worker mode / `/vchat-family` | ✅ ruling A implemented: lead-side `/vchat-family` (socket panel/spawn/steer/stop/kill/unload/receipts) + worker-register seam (`attach`/`answer` verbs, `task` events; extension `VCLAW_FAMILY_WORKER=1` mode attaches on session_start and answers on turn_end) |

Gates: **G1 live-JWT run PENDING** (operator claimed-agent JWT; structural PASS
— no token.go widening required). G3/G4 covered hermetically (conversation-
scoped routing tests; multi-connection same-credential in family-wire tests).
G5 documented (best-effort, no store-and-forward; V3.1 Q7 deferred). G6
covered by daemon close-cascade tests.

cp3 note: `/vchat-family` gives the lead a live orchestration surface over the
local socket; the worker-register seam (ruling A, `.prime/handoff/v9/
CP3-WORKER-REGISTER-RULING.md`) adds `attach`/`answer` socket verbs + `task`
events so a LIVE pi session (extension mode family-worker,
`VCLAW_FAMILY_WORKER=1`) joins the family and answers steers on its own
turn_end — replies flow through the session, not daemon-side RPC polling.
Both halves tested end-to-end (`extension-family-command.test.ts`,
`daemon-attach.test.ts`, `extension-family-worker.test.ts`).

## v8 — npmjs.com → jsr.io migration + Bun-native curl DX

> ⚠ **Path note (2026-10-30):** this section's inventory says `vclaw-app/`; that directory was renamed
> **`vclaw-desktop/`** (submodule commit `a0db472e`, references updated). The text below is the dated
> 2026-08-31 record and is left as written.


### 0. Executive summary

| | Today | Target (v8) |
|---|---|---|
| **Package host** | npmjs.com (`@vchatemail/agent` 1.1.0, `@vchatemail/protocol-core` 0.1.0, `@vchatemail/ext-synadia` 0.1.0) | **jsr.io** (same names under scope `@vchatemail`), npm kept as **deprecated mirror** for one transition window |
| **Package form** | tsc → `dist/` JS + d.ts, `files: [bin/, dist/]` | **TS-source publishing** (jsr.json `exports` → `src/index.ts`); JSR generates types; ESM-only |
| **Curl DX** | `curl -fsSL https://vchat.email/join.sh \| sh` → upstream pi.dev installer (Node+npm) → `npx --yes @vchatemail/agent@latest onboard` | **`curl -fsSL https://vclawhub.com/join.ts | bun`** — zero-dep TS one-file introduce (Bun runs TS natively); SDK runtime via `bunx @jsr/vchatemail__agent …` |
| **CI/CD** | GH Actions: Node 22 + `npm ci` (pnpm-residue guard) + build + vitest; **publishing is manual** `npm publish` | Same test gates + **tag-triggered publish to jsr.io** (OIDC trusted publishing / `JSR_PUBLISH_TOKEN`) + lockstep npm-mirror job |
| **Consumers** | vclaw-app devDep pin `@vchatemail/agent@1.0.1` + `bundle-agent-sdk.sh`; landing `joinCmd` copy; `agent-sdk/bin/join.sh`; `docs/ONBOARDING_SPEC.md` | Switched to `@jsr/vchatemail__agent` npm-compat alias (installer-agnostic) or `jsr:` specifiers where verified |

**Why JSR + Bun:** the SDK is pure TypeScript with zero runtime build step; JSR hosts TS directly
(auto-generated docs + types, semver-enforced, `--allow-slow-types` guard), and Bun executes TS +
the SDK natively — the pipe loses the Node/npm/npx bootstrap entirely.

**⚠ npm-compat mechanism (CORRECTED, lead-verified 2026-08-31):** `@jsr/<scope>__<name>` aliases
are **NOT on registry.npmjs.org** (404 × 4 probes). They are served from **https://npm.jsr.io**, an
npm-API-compatible registry. npm and Bun do NOT auto-configure it — every consumer needs
`.npmrc` → `@jsr:registry=https://npm.jsr.io` (project or `~/.npmrc`; recent yarn/pnpm do it
automatically). Consequences: `bunx @jsr/vchatemail__agent` works ONLY where that line exists
(join.ts bootstraps `~/.npmrc` idempotently — R5); vclaw-app gets a repo `.npmrc`; all DX copy
shows the `.npmrc` step. Native `jsr:` specifiers FAIL in Bun 1.4.0 ("Invalid dependency name" /
treated as git URL) — documented as unsupported, revisit on Bun releases.

### 1. Current-state inventory (verified 2026-08-31)

| Surface | State | Evidence |
|---|---|---|
| Root package | `@vchatemail/agent` **1.1.0**, `publishConfig.access public`, `bin.vchat-agent`, `files: [bin/, dist/, README, CHANGELOG]`, deps `@nats-io/*` + `@noble/ed25519` + commander | `agent-sdk/package.json` |
| Workspace pkgs | `@vchatemail/protocol-core` 0.1.0, `@vchatemail/ext-synadia` 0.1.0 (`packages/*`, both have `exports`, no `files` field) | `agent-sdk/packages/*/package.json`, `pnpm-workspace.yaml` |
| Build | `tsc → dist/` + extension bundlers (`scripts/build-pi-extension.mjs`, `build-ext-synadia.mjs`); `prepublishOnly` chains them | package.json scripts |
| CI | `agent-sdk` job: Node 22, `npm ci` with **pnpm-residue guard** (JOB A), build, `vitest run`. **No publish job anywhere** | `.github/workflows/ci.yml:87-130` |
| Lockfiles | **THREE coexist**: `package-lock.json`, `pnpm-lock.yaml`, **`bun.lock`** — resolver drift risk, needs a lane ruling | `agent-sdk/` root |
| Curl DX (shown) | Landing hero: `curl -fsSL https://vchat.email/join.sh | sh` | `landing-removed/src/pages/index.astro:93` (`joinCmd`) |
| Curl DX (served) | `join.sh.ts` Astro endpoint → bash script: installs pi.dev via upstream installer (Node+npm) → `npx --yes @vchatemail/agent@latest onboard --no-wait` | `landing-removed/src/pages/join.sh.ts:92-109` |
| Curl DX (legacy) | `landing-removed/public/join.mjs` — zero-dep Node 18+ single-file introduce; **default endpoint still pre-rebrand `https://api.vchat.email`** | `landing-removed/public/join.mjs:14,19` |
| Secondary script | `agent-sdk/bin/join.sh` (same pipeline, shipped in-repo) | `agent-sdk/bin/join.sh` |
| Desktop consumer | `vclaw-app/package.json` devDep `@vchatemail/agent: 1.0.1` (STALE vs 1.1.0) + `scripts/bundle-agent-sdk.sh` (npm-install → standalone sidecar) | `vclaw-app/package.json:39` |
| JSR references | **None** anywhere in the repo | grep | 

### 2. Target architecture

```text
DX TODAY                                    DX TARGET (v8)
──────────────────────────                  ─────────────────────────────
curl …/join.sh | sh                         curl https://vclawhub.com/join.ts | bun
  └ pi.dev/install.sh (Node+npm+pi)           └ bun runs the TS pipe directly
  └ npx @vchatemail/agent onboard              └ introduce + identity.json (zero deps)
    (npmjs.com resolve)                       └ SDK: bunx @jsr/vchatemail__agent onboard
                                                 (jsr.io → npm.jsr.io alias; .npmrc bootstrap — R5)

CI/CD: manual npm publish                    CI/CD: tag → publish-with-jsr (OIDC)
                                                + lockstep npm-mirror publish job
```

**Bun-native join pipe (new `landing-removed/src/pages/join.ts.ts`, served at `https://vclawhub.com/join.ts`):**
W-J3 ruling (lead, 2026-08-31): the plan's clean `/join` URL is a **route collision with the live
join.astro signup page**, and `output:"static"` makes curl/browser UA negotiation dead code
(frontmatter runs once at build). `/join.ts` is the faithful static resolution, mirroring the
`/join.mjs` precedent. A clean `/join` returns only if join.astro retires or the landing adopts
SSR — a product decision outside W-J3. Single-file TypeScript endpoint, zero dependencies, Bun
built-ins only (WebCrypto / `node:crypto` — both work under Bun; native `fetch`). Same vgate
contract as `join.mjs` today (`POST {VGATE}/v1/agent/introduce` — token sent as `invite` field
(B10, vgate-validated), identity → `~/.vchat/identity.json`, claim code printed). Args preserved:

```bash
curl -fsSL https://vclawhub.com/join.ts | bun                    # hostname-derived name
curl -fsSL https://vclawhub.com/join.ts | bun - my-agent-name    # positional name
curl -fsSL https://vclawhub.com/join.ts | bun - --token INVITE-XXXX
```

Default endpoint becomes `https://api.vclawhub.com` (fixes the stale `api.vchat.email` default in
`join.mjs`); `VCHAT_API_URL` override stays.

### 3. Package mechanics (per package)

1. **Register scope `@vchatemail` on jsr.io** (GitHub org chatek auth — owner op, slow path).
2. **`jsr.json` per package** (root + `packages/protocol-core` + `packages/ext-synadia`):
   `{ "name": "@vchatemail/agent", "version": "1.2.0", "exports": "./src/index.ts" }`
   (+ `./mod.ts`-style multi-entry only where the current `exports` map has subpaths).
   ESM-only; **no build step** — JSR ships the TS source and generates docs/types.
3. **Dependency policy:** runtime deps stay npm-hosted (`@nats-io/*`, `@noble/ed25519`, commander,
   `@sinclair/typebox`) — JSR resolves npm deps natively; workspace-internal refs become
   `jsr:@vchatemail/protocol-core` specifiers in the dependent jsr.json.
4. **Types discipline:** `jsr publish --dry-run` must pass **without** `--allow-slow-types`
   (explicit types on all exported symbols) — this is the CI gate for publishability.
5. **npm mirror:** every JSR package is exposed as `@jsr/<scope>__<name>` (e.g.
   `@jsr/vchatemail__agent`) **via https://npm.jsr.io** — consumers need the `.npmrc` registry line
   (see §0 correction). The mirror job ALSO publishes `@vchatemail/agent@<same version>` to
   npmjs.com for one transition window, then flips to `npm deprecate` pointing at JSR.

### 4. CI/CD (`.github/workflows/jsr-publish.yml` + ci.yml additions)

- **Trigger:** tag `agent-sdk-v*` (or release publish).
- **Gates (hard):** existing `agent-sdk` job green (build + vitest, unchanged) + `jsr publish
  --dry-run` clean for all three packages + `CHANGELOG.md` entry for the tag.
- **Publish step:** `denoland/publish-with-jsr` with OIDC trusted publishing (preferred; no
  long-lived secret) — fallback `npx jsr publish --token ${{ secrets.JSR_PUBLISH_TOKEN }}` if the
  runner/org lacks OIDC support. Workspace order: `protocol-core` → `ext-synadia` → root.
- **npm mirror step (transition only):** `npm publish` per package, same versions.
- **JSR constraints to respect:** versions are immutable (no re-publish), semver strictly
  increasing, scope must own the name. Publishing is per-package from its own cwd.

### 5. DX surfaces to change (file-by-file)

| File | Change |
|---|---|
| `landing-removed/src/pages/join.ts` (NEW) | Bun-native TS pipe (§2); endpoint `https://vclawhub.com/join` |
| `landing-removed/src/pages/index.astro:93` | hero `joinCmd` → `curl -fsSL https://vclawhub.com/join.ts \| bun` (copy + copy-to-clipboard payload) |
| `landing-removed/src/pages/join.sh.ts` | keep serving during transition window; banner in output: “prefer: curl …/join \| bun”; retire at EOL (R1) |
| `landing-removed/public/join.mjs` | supersede — fix `api.vchat.email` default if kept >1 release; fold into retire plan |
| `agent-sdk/bin/join.sh` | pipeline becomes bun-first (`bunx @jsr/vchatemail__agent`), node/npx fallback documented |
| `agent-sdk/README.md` + `CHANGELOG.md` | install docs: `bunx jsr add @vchatemail/agent` / `bun add @jsr/vchatemail__agent`; npm deprecation notice |
| `docs/ONBOARDING_SPEC.md` | DX examples flip to bun one-liner |
| `vclaw-app/package.json` + `scripts/bundle-agent-sdk.sh` | devDep → `@jsr/vchatemail__agent` (alias keeps npm-installer mechanics; bump past stale 1.0.1) |
| `.github/workflows/ci.yml` | optional bun-lane job: `bun install --frozen-lockfile && bun test` (vitest via bun) — verifies the DX runtime in CI |

### 6. Compatibility gates — VERIFY, don't assume (blocking questions)

| # | Question | Verification |
|---|---|---|
| ~~G1~~ | Does `bunx @jsr/vchatemail__agent onboard` run the CLI correctly (bin export via the npm alias)? | W-J4 fresh-VM leg — **requires `.npmrc` `@jsr:registry=https://npm.jsr.io`** (see §0 correction) |
| G2 | Native `jsr:` specifiers in Bun | ❌ **FAILS (verified 2026-08-31, Bun 1.4.0)** — "Invalid dependency name"; alias form via `.npmrc` is the ONLY supported path |
| G2b | `@jsr` alias install via `.npmrc` | ✅ **PASS** — `.npmrc: @jsr:registry=https://npm.jsr.io` → `bun add @jsr/luca__cases` installs + runs — THE mechanism (R5) |
| G3 | `bun -` stdin arg passing | ✅ PASS (lead, macOS) — linux leg in W-J4 |
| ~~G4~~ | pi.dev installer in the bun pipe | **FLIPPED 2026-09-11** — pi.dev is now **OPT-IN** (`--install-pi` / `INSTALL_PI=1`), never auto-installed: piping an upstream installer into `sh` is a consent surface. `SKIP_PI_INSTALL` retired (it described the new default). The runtime is now a CHOICE, persisted to `~/.config/vclaw/config.json` `runtime` (`--runtime` / `VCLAW_RUNTIME`); see CHANGELOG. |
| G5 | `jsr publish --dry-run` without `--allow-slow-types` | ✅ **GREEN ×3 (W-J1, 2026-08-31)** — protocol-core + ext-synadia clean as-is; root fixed 68 slow-type problems (61 contracts.ts explicit-type annotations via generated `src/contracts/schema-types.ts` aliases preserving `Static<typeof X>` inference + 7 `subjects.ts` return types + `SUBJECT_ROOT: string`) |
| G6 | Lockfile drift | ✅ **RESOLVED (R6, W-J1)** — bun.lock is the SOLE lockfile (package-lock + pnpm-lock + pnpm-workspace + packages/ext-synadia/package-lock deleted); `bun install --frozen-lockfile` clean; root package.json gained `"workspaces": ["packages/*"]` (bun-native workspace — bun.lock previously had NO workspace entries) |

### 7. Transition & EOL

- **M1 (dual-host):** JSR publish + npm mirror, both at 1.2.0. DX flips to bun one-liner; node
  `join.sh` stays with deprecation banner. READMEs carry both install forms.
- **M2 (EOL, lead-scheduled):** stop npm mirror; `npm deprecate @vchatemail/agent "→ jsr.io/@vchatemail/agent"`; retire `join.sh.ts` + `join.mjs`; sweep docs.

### 8. Acceptance criteria + test plan

1. `jsr.io/@vchatemail/agent` (and both workspace pkgs) at 1.2.0, TS-source, docs rendering.
2. Fresh VM with **only Bun** installed: `curl -fsSL https://vclawhub.com/join.ts | bun` completes
   introduce, writes `~/.vchat/identity.json`, prints claim code — zero Node/npm on machine.
3. `bunx @jsr/vchatemail__agent onboard` + `… start` complete the full onboard lifecycle on Bun.
4. Tag `agent-sdk-v1.2.0` → CI publishes JSR (+ mirror) with all gates green.
5. vclaw-app bundle builds from the alias pin; landing hero shows the bun one-liner.
6. `join.sh` (node path) still works during M1 window, prints deprecation pointer.
7. `npx @vchatemail/agent@1.1.0` (existing users) unaffected until M2.

### 9. Wave breakdown (dispatch-ready)

| Wave | Content | Owner-suggested |
|---|---|---|
| **W-J1** | scope registration (owner), `jsr.json` ×3, G5 dry-run fixes, G6 lockfile ruling | worker |
| **W-J2** | `jsr-publish.yml` (OIDC + mirror + gates), optional bun-lane CI | worker |
| **W-J3** | `join.ts` bun pipe + landing copy + `agent-sdk/bin/join.sh` + README/CHANGELOG/ONBOARDING_SPEC | worker |
| **W-J4** | verification matrix G1-G4 (fresh VM, mac+linux), vclaw-app alias bump | worker |
| **W-J5** | live verify + changelog + `0B-WB-AGENT-SDK.md` inventory refresh + M2 scheduling (rulings R1-R4) | lead |

**Rulings needed from lead:** R1 `join.sh` transition-window length · R2 pi.dev installer in the
bun pipe (chain vs skip) · R3 npm-mirror EOL date · R4 confirm pi-extension bundle path
(`ext-synadia` → `~/.pi` local bundle) stays host-agnostic (proposed: unchanged).

─── **HISTORICAL SECTIONS FOLLOW (unchanged)** ───

> ⚠️ **HISTORICAL (2026-08-13):** this is the executed v7.1 upgrade plan (SDK 0.4.0 → 0.7.0). The SDK is now at **1.0.1** and the V3 agent-network canon + the Q2 one-sidecar convergence supersede the v7.1 design it specifies. Retained as migration history.

> 🔁 **URL REBRAND (2026-08-28):** service hostnames migrated `.vchat.email` → `.vclawhub.com` (5-hostname 1:1 map: nats/auth/api/login/agents). Quoted code/config below still shows the pre-rebrand URLs — read `login.vchat.email` as `login.vclawhub.com` etc. Current-state inventory: [`dash/docs/sprint-url-rebrand/0B-WB-AGENT-SDK.md`](../dash/docs/sprint-url-rebrand/0B-WB-AGENT-SDK.md). Bare-domain URLs (`vchat.email/join.sh`) and email addresses are intentionally unchanged per lead ruling.

> This document specifies the changes needed to make the agent-sdk support the **splash-screen-first onboarding UX** described in [`docs/ONBOARDING_UX.md`](../docs/ONBOARDING_UX.md). The SDK must be a **library** that PI WEB imports — not just a CLI tool.
>
> **Current version:** 0.4.0 (old direct-register flow)  
> **Target version:** 0.7.0 (v7.1 — three-layer identity, OIDC auto-approve, V2 subjects)  
> **Architecture spec:** [`VGATE_UPGRADE.md`](../VGATE_UPGRADE.md) §2.3

---

## v7.1 — Three-Layer Identity Storage

**Scope:** Complete identity architecture overhaul. Role-based identities removed,
nounce-based `.pi/agent_nonce` is the sole identity source. OIDC auto-approve
replaces the manual dashboard claim page. V2 subjects (`tenant.default.*`)
are the only subject format.

### What changed

| Layer | v0.6 (previous) | v7.1 (current) |
|-------|-----------------|----------------|
| **Agent identity** | `.pi/agent_id.md` with YAML roles (LWF) | `.pi/agent_nonce` — plain text file, single name |
| **Identity storage 1** | `~/.vchat/credentials.json` (NKey seed) | Same — unchanged |
| **Identity storage 2** | — (none) | `vchat_ownership` KV bucket — NKey → human binding at auto-approve time |
| **Identity storage 3** | — (none) | Optional PostgreSQL `agent_identities` table for directory queries |
| **Claim flow** | Open browser to dashboard, click Approve on claim page | Browser OIDC at `login.vclawhub.com` — auto-approve on successful auth |
| **Subject format** | `agents.*` (V1) and `tenant.default.*` (V2) mixed | `tenant.default.*` (V2) exclusively |
| **Auth** | NKey challenge-response | Same — no JWT, no token exchange |
| **Email** | Required CLI flag (`--email`) | Optional — local label only. Browser provides verified `claim.email` |
| **Identity roles** | LWF: `lead`, `worker-1`, `scout` with collision locks | Removed entirely. `.pi/agent_nonce` is the name. |
| **Config path** | Hardcoded `~/.config/pi-a2a/` | `$PI_A2A_CONFIG_DIR` env var (fallback `~/.config/pi-a2a`) |

### Migration guide

**If you have `.pi/agent_id.md`:**
```bash
# Remove old role file, create plain nonce file
rm .pi/agent_id.md
echo "my-agent-name" > .pi/agent_nonce
```

**If you use `--email` flag:**
```bash
# Now optional — omit it. Browser provides verified email.
npx @vchatemail/agent onboard
```

**If you set config path:**
```bash
export PI_A2A_CONFIG_DIR=/custom/path  # default: ~/.config/pi-a2a
```

### Deprecated

- `@vchatemail/pi-a2a` — npm package replaced by `https://pkg.vchat.email/pi-a2a.tar.gz`
- `@vchatemail/pi-a2a-network` — npm package replaced by tarball distribution
- `.pi/agent_id.md` — replaced by `.pi/agent_nonce`
- `agents.*` (V1) subjects — use `tenant.default.*` (V2) exclusively
- Role-based identity (LWF) — all agents use nonce-based identity

### New env vars

| Variable | Default | Purpose |
|----------|---------|---------|
| `PI_A2A_CONFIG_DIR` | `~/.config/pi-a2a` | Config directory for NATS auth token and A2A identity |
| `POSTGRES_DSN` | — | Postgres connection for three-layer identity storage |

---

## Original v0.6 Plan (historical reference below)

The rest of this document describes the v0.6 target architecture.
All items listed below have been implemented. The v7.1 changes above
supersede any conflicting details.

---

---

### Security model (critical design constraint)

The `--email` flag in the CLI has **zero server-side trust**. It is a local label for `~/.vchat/credentials.json` only. The real agent-to-human binding happens in the browser at `https://login.vclawhub.com/a/<session_id>` — the human authenticates there (password, OIDC, etc.) and vgate emits a claim event containing the **verified** email.

This means:
- The curl pipe must **never** require an email. The user's email is captured at login, not in the pipe.
- An attacker who guesses `alice@vchat.email` in the env var gains nothing — they can't claim the agent without Alice's auth session.
- The CLI's `--email` flag should be **optional**. If omitted, the `steward` field uses `claim.email` from the NATS claim event.

**Implication for the unified installer:**
```bash
curl -fsSL https://vclawhub.com/install | sh
# No env var. No email. The browser at login.vclawhub.com handles auth.
# The same command works for install-only and install+auth.
```

## Current State vs Target

```
CURRENT FLOW (SDK 0.4.0):
  keygen → POST /v1/agent/register → store credentials → "done"

TARGET FLOW (SDK 0.6.0, NKey-native):
  keygen → POST /v1/agent/introduce → subscribe tenant.default.claim.<nkey> →
  open browser to /a/<session_id> → wait for claim (NKey auth'ed) →
  store NKey seed to ~/.vchat/credentials.json → connect NATS via NKey

  No JWT. No token exchange. The NKey seed is the credential.
```

### What Stays vs What Changes

| File | Current | Target | Action |
|------|---------|--------|--------|
| `src/lib/keygen.ts` | Ed25519 NKey generation | Same — works as-is | **Keep** |
| `src/lib/store.ts` | Save/load `credentials.json` | Same — works as-is | **Keep** |
| `src/lib/vgate.ts` | 4 methods: register, token, session/resolve, health | **Add:** `introduceAgent()`; **Remove:** `getAgentToken`, `resolveSession` | **Rewrite** |
| `src/commands/onboard.ts` | Direct register | Introduce→wait→claim (NKey-native, no token) | **Rewrite** |
| `src/cli.ts` | `ensoul` → direct register, `--email` required | `onboard` → introduce + browser + wait, `--email` optional | **Rewrite** |
| `src/types.ts` | RegisterRequest, RegisterResponse, TokenRequest, TokenResponse | **Add:** `IntroduceRequest`, `IntroduceResponse` (with `session_id`), `ClaimEvent`, `StoredCredentials`; **Remove:** `TokenRequest`, `TokenResponse` | **Rewrite** |
| `src/constants/subjects.ts` | `vgate.*` legacy subject strings | Update to `tenant.default.*` naming (FABRIC V2) | **Rewrite** |
| `src/index.ts` | Exports NATS lifecycle | Prune to identity+onboarding (Phase 1); add lifecycle after pi-a2a merge (Phase 2) | **Rewrite** |
| `src/agent/*.ts` | 8 files: custom lifecycle, connect, discovery, messaging, heartbeat, delegation, wallet | **Delete all** — replaced by pi-a2a merge in Phase 2 | **Delete** |
| `package.json` | Dependencies include NATS transport | Keep `@nats-io/transport-node` + `@nats-io/nats-core` for claim sub + lifecycle | **Tidy** |

---

## File-by-File Spec

### `src/lib/vgate.ts` — Add introduceAgent

```typescript
export class VgateClient {
  // Existing (keep)
  async registerAgent(params: RegisterRequest): Promise<RegisterResponse>

  // NEW: Introduce an unclaimed agent to vgate
  async introduceAgent(params: {
    nkey_public: string;
    name: string;
    capabilities?: string[];
  }): Promise<{ agent_id: string; status: string; session_id?: string }>

  // Keep (unchanged)
  async health(): Promise<{ status: string; service: string; version: string }>
  async getVgateStatus(): Promise<{ status: string; version: string }>
}
```

**`introduceAgent` calls:** `POST /v1/agent/introduce` with `{ nkey_public, name, capabilities }`. Returns `{ agent_id, status: "pending", session_id }`.

**Removed:** `getAgentToken`, `resolveSession` — no longer needed for NKey-native flow.

### `src/commands/onboard.ts` — Rewrite for splash-screen flow

Current logic: `keygen → register → store → done`. Rewrite to:

```
export interface OnboardOptions {
  email?: string;    // Optional: local steward label. ZERO server-side trust.
  name?: string;     // Agent display name (default: agent-<pubkey_prefix>)
  force?: boolean;   // Overwrite existing credentials
  noOpen?: boolean;  // Skip browser open
  noWait?: boolean;  // Introduce and exit (no claim wait)
}

export async function onboard(opts: OnboardOptions): Promise<void> {
  1. Check for existing credentials (--force to overwrite)
  2. Generate Ed25519 NKey pair (keygen.ts — unchanged)
  3. Subscribe to tenant.default.claim.<nkey> — start listening BEFORE introducing
  4. POST /v1/agent/introduce → receive { agent_id, session_id, status: "pending" }
  5. Open browser to https://login.vclawhub.com/a/<session_id>
  6. Print: "Waiting for approval at login.vclawhub.com..."
  7. Block on claim promise (resolves when tenant.default.claim.<nkey> received)
  8. Store credentials to ~/.vchat/credentials.json
     steward = claim.email || opts.email || "unknown"
  9. Print success + next steps
}
```

**The `waitForClaim()` helper** authenticates to NATS via NKey challenge-response (no JWT):

```typescript
// src/commands/onboard.ts (new)
export async function waitForClaim(
  nkeyPublic: string,
  rawSeed: Uint8Array,
  timeoutMs?: number
): Promise<ClaimEvent> {
  const nc = await connect({
    servers: "ws://vchat3:4224",
    authenticator: nkeyAuthenticator(rawSeed),
  });
  const sub = nc.subscribe(`tenant.default.claim.${nkeyPublic}`);

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      sub.unsubscribe();
      nc.close();
      reject(new Error("Claim timed out after 300s"));
    }, timeoutMs ?? 300_000);

    (async () => {
      for await (const msg of sub) {
        clearTimeout(timer);
        const claim = JSON.parse(new TextDecoder().decode(msg.data)) as ClaimEvent;
        resolve(claim);
        break;
      }
    })();
  });
}
```

**NKey-native (no JWT):** The agent connects to NATS using its own NKey seed as credential (`nkeyAuthenticator`). The claim event is published to the agent's own subject. No token exchange needed — the NKey seed is the credential. Step 8 (token) from the old spec is removed.

### `src/cli.ts` — Rewrite ensoul command (email optional, NKey-native)

Current: `ensoul → onboard()` which does direct register.

Target:

| Command | Current | Target |
|---------|---------|--------|
| `ensoul` | keygen → register → done | keygen → introduce → open browser → wait for claim |
| `token` | Show stored token | Same — works as-is |
| `health` | Check vgate health | Same |
| `status` | Show credentials | Add pending-claim status if introduced but not claimed |
| `keygen` | Generate NKey only | Same — works as-is |
| `clear` | Delete credentials | Same + clean up any pending introduce |

**Key change:** `--email` is optional, not required:

```typescript
program
  .command("onboard")
  .alias("ensoul")
  .description("Introduce a new agent to vchat.email (NKey-native, no JWT)")
  .option("-e, --email <email>", "Human steward email — local label only, no server-side trust")
  .option("-n, --name <name>", "Agent display name")
  .option("--force", "Overwrite existing credentials")
  .option("--no-open", "Don't open browser automatically")
  .option("--no-wait", "Introduce and exit, no claim wait");
```

**New `openBrowser` helper** (cross-platform, no npm dependency):

```typescript
async function openBrowser(url: string): Promise<void> {
  console.log(`\n🔗 Opening browser to:\n   ${url}\n`);
  const { exec } = await import("node:child_process");
  const platform = process.platform;
  if (platform === "darwin") exec(`open "${url}"`);
  else if (platform === "linux") exec(`xdg-open "${url}"`);
  else if (platform === "win32") exec(`start "" "${url}"`);
}
```

### `src/types.ts` — Add introduction types

```typescript
/** Introduction request — POST /v1/agent/introduce */
export interface IntroduceRequest {
  nkey_public: string;
  name: string;
  capabilities?: string[];
}

/** Introduction response */
export interface IntroduceResponse {
  agent_id: string;
  status: string; // "pending"
  session_id?: string; // server-issued UUID for claim URL (v0.5.1+)
}

/** Claim event received on tenant.default.claim.<nkey> */
export interface ClaimEvent {
  human_uuid: string;
  email: string;
}

/** Stored credentials (NKey-native, no JWT) */
export interface StoredCredentials {
  seed: string;
  public_key: string;
  agent_nkey: string;
  name: string;
  steward: string;
  created_at: string;
}
```

**Note:** `TokenRequest`/`TokenResponse` types removed — the agent is NKey-native. No JWT/exchange token is fetched. The NKey seed stored in `~/.vchat/credentials.json` is the sole credential.

### `src/constants/subjects.ts` — Update to tenant.default.* naming (FABRIC V2)

```typescript
export const SubjectTree = {
  CLAIM: (nkey: string) => `tenant.default.claim.${nkey}`,                              // tenant.default.claim.<nkey>
  HEARTBEAT: (ownerNkey: string, agentNkey: string) => `tenant.default.user.${ownerNkey}.agent.${agentNkey}.hb`,  // tenant.default.user.{ownerNkey}.agent.{agentNkey}.hb
  PROMPT: (ownerNkey: string, agentNkey: string) => `tenant.default.user.${ownerNkey}.agent.${agentNkey}.prompt`, // tenant.default.user.{ownerNkey}.agent.{agentNkey}.prompt
  A2A: (targetNkey: string) => `tenant.default.a2a.${targetNkey}`,                      // tenant.default.a2a.<targetNkey>
  DISCOVERY: "$SRV.INFO.agents",
} as const;
```

Remove `PENDING` (not used), `WALLET` (moved to HTTP RPC). Remove the entire `RpcSubjects` object.

### `src/index.ts` — Prune + add lifecycle exports

```
Phase 1 (identity + onboarding):
Keep:     generateNkeyPair, decodeNkeySeed, NkeyPair
          loadCredentials, saveCredentials, clearCredentials, credentialsPath, StoredCredentials
          VgateClient (with introduceAgent + health)
          onboard, OnboardOptions

Remove:   connectNats, isWssUrl, NatsConnectOptions
          registerService, unregisterService, discoverAgentsByCapability, getAgentCapabilities, publishCapabilities
          subscribeToPrompts, subscribeToA2A, subscribeToMarketplace
          delegateToPeer, transferCredits, verifyTransfer
          startHeartbeat, HeartbeatState
          getWalletBalance, WalletBalance
          startAgent, AgentConfig, RunningAgent, AgentStatus (old)
          SubjectTree, RpcSubjects, DefaultServers, DefaultTimeouts
          TokenRequest, TokenResponse

Phase 2 (lifecycle — after pi-a2a merge):
Add:      connectViaNKey, startHeartbeat, subPrompt, subA2A
          startAgent, StartOptions
```

The SDK becomes focused on **identity + onboarding** (Phase 1), then **+ lifecycle** (Phase 2 after pi-a2a merge).

### `package.json` — Dependencies

```json
{
  "name": "@vchatemail/agent",
  "version": "0.6.0",
  "description": "vchat.email agent SDK — NKey-native identity, onboarding, and lifecycle.",
  "type": "module",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "bin": {
    "vchat-agent": "./bin/agent.js"
  },
  "files": ["bin/", "dist/", "README.md"],
  "dependencies": {
    "@nats-io/nats-core": "^3.4.0",
    "@nats-io/transport-node": "^3.4.0",
    "@noble/ed25519": "^3.1.0",
    "commander": "^13.1.0"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "typescript": "^5.8.0",
    "vitest": "^4.1.6"
  }
}
```

**Phase 2** (after pi-a2a merge): add `@nats-io/services` for NATS Micro discovery.

---

## Files to Delete

| Path | Reason |
|------|--------|
| `src/agent/agent.ts` | Custom lifecycle — replaced by Synadia |
| `src/agent/connect.ts` | Custom NATS connect — replaced by Synadia |
| `src/agent/discovery.ts` | Custom discovery — replaced by Synadia |
| `src/agent/messaging.ts` | Custom messaging — replaced by Synadia |
| `src/agent/heartbeat.ts` | Custom heartbeat — replaced by Synadia |
| `src/agent/delegation.ts` | Custom delegation — replaced by Synadia |
| `src/agent/wallet.ts` | Wallet is NATS-RPC, not SDK concern |
| `src/constants/subjects.ts` | Rewrite (delete old, create new) |

**Total:** 8 files deleted, 5 files kept, 3 files rewritten.

---

## Files to Create

| Path | Purpose |
|------|---------|
| (None — `openBrowser()` is small enough to be inline in `cli.ts` or `lib/open-browser.ts`) |

---

## Files to Keep (with minor changes)

| Path | Change |
|------|--------|
| `src/lib/keygen.ts` | None — works as-is |
| `src/lib/store.ts` | None — works as-is |
| `src/lib/vgate.ts` | Add `introduceAgent()`, remove token/session methods |
| `src/types.ts` | Add `IntroduceRequest/Response`, `ClaimEvent`, `StoredCredentials`; remove token types |
| `src/index.ts` | Prune to identity+onboarding (Phase 1); add lifecycle (Phase 2) |
| `bin/agent.js` | Update entry to match new cli.ts |

---

## Effort Estimate

| Job | Files | Time |
|-----|-------|------|
| **1.** Add `introduceAgent()` to `vgate.ts` | 1 | 15m |
| **2.** Add `waitForClaim()` + rewrite `onboard.ts` (email optional) | 1 | 30m |
| **3.** Rewrite `cli.ts` ensoul command (email optional, browser open inline) | 1 | 20m |
| **4.** Extend `types.ts` (add session_id, remove token types) | 1 | 10m |
| **5.** Rewrite `constants/subjects.ts` | 1 | 10m |
| **6.** Prune `index.ts` exports | 1 | 10m |
| **7.** Delete 8 obsolete agent/*.ts files | 8 | 5m |
| **8.** Tidy `package.json` dependencies | 1 | 5m |
| **9.** Test end-to-end: `npm run build && node bin/agent.js ensoul` | — | 15m |
| **Total** | | **~1h 50m** |

---

## Acceptance Criteria

1. `npx @vchatemail/agent ensoul` (without `--email`):
   - Generates NKey
   - POSTs `/v1/agent/introduce`
   - Opens browser to `https://login.vclawhub.com/a/<session_id>`
   - Prints "Waiting for approval..."
   - On dashboard approve → receives claim via NATS → stores credentials
   - `steward` field populated from `claim.email` (verified in browser)

2. `npx @vchatemail/agent ensoul --email user@example.com`:
   - Same flow; `steward` fallback uses the CLI arg if `claim.email` absent

3. `npx @vchatemail/agent status` shows credentials after ensoul

4. `npx @vchatemail/agent clear` deletes stored credentials

5. SDK library exports (`import { generateNkeyPair, VgateClient, onboard } from '@vchatemail/agent'`) work for PI WEB's splash screen

6. No remaining references to old `vgate.*` subjects, `RpcSubjects`, JSON-RPC, or token types in the SDK

---

## Related Documents

| Document | Purpose |
|----------|---------|
| [`docs/ONBOARDING_UX.md`](../docs/ONBOARDING_UX.md) | Full onboarding UX spec (splash screen, claim URL, browser OIDC) |
| [`VGATE_UPGRADE.md`](../VGATE_UPGRADE.md) | Architecture spec with auth callout, V2 tenant.default.* subjects |
| [`dash/UPGRADE.md`](../dash/UPGRADE.md) | Dashboard design (claim page at /claim/<hash>) |
| [`A2A/A2A_alpha_roadmap.md`](../A2A/A2A_alpha_roadmap.md) | A2A alpha implementation plan (KV-backed following) |
| [`A2A/A2A_blueprint.md`](../A2A/A2A_blueprint.md) | Full Fabric design spec (v7.1, post-alpha) |
| [`ALPHA_demo.md`](../ALPHA_demo.md) | Sprint demo log — IdP rewire + A2A Phase C build history |

---

## Phase 2: Agent Lifecycle — Merge pi-a2a into agent-sdk + Unified Installer (6h)

**Status:** 📋 Planned for next sprint

**Goal:** Make agent-sdk a self-contained agent runtime. New agents join the vchat.email mesh via a **single command** — `curl -fsSL https://vclawhub.com/install | sh` — that installs the full stack AND optionally runs onboard (no email in the pipe, auth handled in-browser at `login.vclawhub.com`).

**Reference:** This design was validated against the original two-goal requirement: (1) repackaged pi.dev stack as one-pipe install, (2) auth flow via `login.vclawhub.com/a/<hash>`. See security analysis in §Security model above.

**Closed-alpha constraint:** During alpha, user accounts are pre-provisioned — there is no open registration or invite token flow. Agent onboarding (`curl -fsSL https://vchat.email/join.sh | sh`) is pre-conditioned on the human already having a vchat.email account. The browser auth at `login.vclawhub.com` is the gate: if the user doesn't have an account, they can't log in and can't claim an agent. No `--token` flag is accepted by the install script or the `onboard` CLI.

---

### What's missing

Currently the SDK handles **identity** (keygen, introduce, wait claim, store NKey) but NOT **agent lifecycle** (NATS connect, heartbeat, prompt sub, A2A subscribe). Those live in `A2A/pi-a2a/` (`@vchatemail/pi-a2a`) as a separate package.

Additionally, the existing `vclawhub.com/install` script (`landing-removed/public/install`) installs infrastructure (NATS, pi.dev CLI, pi-web, vclaw-up) but **never runs onboard**. Users must run a second command to join the network.

### Merge plan: pi-a2a → agent-sdk/src/agent/

Extract the agent-side lifecycle layer from `A2A/pi-a2a/` into `agent-sdk/src/agent/`:

| pi-a2a Source | Target in agent-sdk | Purpose |
|---------------|---------------------|---------|
| `src/index.ts` (agent-side: connectViaNKey, subPrompt, pubHeartbeat) | `src/agent/lifecycle.ts` | NATS connect via NKey challenge-response, heartbeat loop (30s), prompt/A2A subscriptions |
| `src/a2a/pubsub.ts` (pub/sub for a2a messages) | `src/agent/a2a.ts` | Subscribe to own `tenant.default.a2a.<nkey>.>`, chunk stream response |
| `src/a2a/discovery.ts` (NATS Micro registration) | `src/agent/discovery.ts` | Register `$SRV.INFO.agents` service, heartbeat with capabilities |

### Files to create

| Path | Purpose |
|------|---------|
| `src/agent/lifecycle.ts` | NATS connect via NKey, credential loader, heartbeat, prompt/A2A subs |
| `src/agent/a2a.ts` | A2A pub/sub, chunk stream contract (from pi-a2a pattern) |
| `src/agent/discovery.ts` | NATS Micro service registration, capability advertisement |
| `src/commands/start.ts` | `agent start` command — connects, subs, blocks |

### Files to update

| Path | Change |
|------|--------|
| `src/cli.ts` | Add `start` subcommand; `onboard` `--email` optional |
| `src/index.ts` | Add lifecycle exports: `startAgent`, `connectViaNKey`, `A2AClient` |
| `package.json` | Add `@nats-io/services` dependency (from pi-a2a) |

### The unified installer: `vclawhub.com/install`

No separate `bin/join.sh` is created. Instead, the **existing** `landing-removed/public/install` script is extended with:

1. An optional onboard step at the end (always runs `npx @vchatemail/agent onboard` without `--email`)
2. No email in the pipe — the browser handles auth
3. The install user sees a single banner with two outcomes:

```bash
# After all infrastructure is installed, add:
if [ -t 0 ]; then
  # Interactive terminal — prompt
  echo ""
  echo "Join vchat.email agent network?"
  echo "  This opens login.vclawhub.com in your browser to authenticate"
  echo "  and link this agent to your account."
  read -p "Join? [Y/n]: " JOIN
  if [ "$JOIN" != "n" ] && [ "$JOIN" != "N" ]; then
    echo ""
    echo "  Introducing agent to vgate..."
    npx --yes @vchatemail/agent onboard
  fi
else
  # Piped (curl | sh) — always attempt onboard
  echo ""
  echo "→ Opening login.vclawhub.com to link this agent to your account..."
  npx --yes @vchatemail/agent onboard --no-wait
  echo ""
  echo "  After approving in the browser, run to complete:"
  echo "    npx @vchatemail/agent onboard"
  echo "  Or to start the agent:"
  echo "    npx @vchatemail/agent start"
fi
```

This keeps the pipe non-blocking (`--no-wait` when stdin is not a TTY) and lets the user complete the browser auth at their own pace.

### Security design of the unified pipe

```mermaid
sequenceDiagram
    participant U as User
    participant C as curl pipe
    participant I as vclawhub.com/install
    participant SDK as @vchatemail/agent
    participant V as vgate
    participant B as Browser @ login.vclawhub.com

    U->>C: curl -fsSL https://vclawhub.com/install | sh
    C->>I: pipe
    I->>I: Install NATS, pi.dev, pi-web
    I->>SDK: npx @vchatemail/agent onboard
    SDK->>SDK: Generate ED25519 NKey
    SDK->>V: POST /v1/agent/introduce
    V-->>SDK: { agent_id, session_id, status: "pending" }
    SDK->>B: open https://login.vclawhub.com/a/{session_id}
    B->>B: User authenticates (password/OIDC)
    B->>V: Approve agent binding
    V->>SDK: NATS: tenant.default.claim.{nkey}
    Note over SDK: claim.email = verified email
    SDK->>SDK: Store ~/.vchat/credentials.json
```

The email env var from earlier drafts is removed entirely. The agent identity is bound to the user's account by the browser auth session, not by anything in the pipe.

### Implementation order

| Step | What | Files | Time |
|------|------|-------|------|
| 1 | Extract `connectViaNKey`, heartbeat, prompt sub, A2A sub from pi-a2a → `agent/lifecycle.ts` | `src/agent/lifecycle.ts` | 1.5h |
| 2 | Extract A2A pub/sub + discovery → `agent/a2a.ts`, `agent/discovery.ts` | `src/agent/a2a.ts`, `src/agent/discovery.ts` | 1h |
| 3 | Add `agent start` CLI command | `src/commands/start.ts`, `src/cli.ts` | 1h |
| 4 | Make `onboard` `--email` optional in CLI + lib | `src/cli.ts`, `src/commands/onboard.ts` | 30m |
| 5 | Add onboard step to `landing-removed/public/install` | `landing-removed/public/install` | 30m |
| 6 | End-to-end test (fresh VM) | CI | 1h |
| **Total** | | | **~5.5h** |

### Build & deployment

```
# agent-sdk (npm package)
cd agent-sdk
pnpm run build          # tsc → dist/
npm publish             # @vchatemail/agent

# landing-removed/public/install (served by vclawhub.com)
# No build step — the file is served as-is
# Deploy by pushing to vclaw-agent repo → cloudflare pages
```

**Serving the installer:** `landing-removed/public/install` is served at `https://vclawhub.com/install` by the Astro static build (files in `public/` are copied verbatim). No additional routing needed.

### Test plan

| Test | Scenario | Pass criteria |
|------|----------|---------------|
| **T1** | `npx @vchatemail/agent onboard` (no email) on fresh machine | Generates NKey, opens browser to `login.vclawhub.com`, stores credentials after browser claim |
| **T2** | `curl -fsSL https://vclawhub.com/install \| sh` on macOS VM | Installs NATS + pi.dev + pi-web, runs onboard, prints success |
| **T3** | `curl -fsSL https://vclawhub.com/install \| sh` with `--no-wait` (piped) | Installs stack, runs onboard in no-wait mode, prints instructions |
| **T4** | `npx @vchatemail/agent start` on onboarded machine | Connects via NKey, heartbeats, subscribes to A2A |
| **T5** | Security: `VCHAT_EMAIL=alice@x.com curl ... \| sh` | Attacker-controlled email is ignored; browser auth required to claim |
| **T6** | Wails wrapper (post-alpha) | Desktop app embeds same installer logic, webview shows `login.vclawhub.com` |

### Acceptance criteria

1. `curl -fsSL https://vclawhub.com/install | sh` on a fresh macOS/Linux machine:
   - Installs NATS server, pi.dev CLI, pi-web, vclaw-up
   - Runs `npx @vchatemail/agent onboard` (no `--email`)
   - Browser opens to `https://login.vclawhub.com/a/<session_id>`
   - After browser auth → credentials stored to `~/.vchat/credentials.json`
   - Prints success + next steps

2. `npx @vchatemail/agent start` on an onboarded machine:
   - Loads credentials from `~/.vchat/credentials.json`
   - Connects to NATS via NKey challenge-response (no JWT)
   - Starts 30s heartbeat on `tenant.default.user.{ownerNkey}.agent.{agentNkey}.hb`
   - Subscribes to prompts and A2A
   - Blocks until SIGINT/SIGTERM

3. Agent appears in NATS connection list and `$SRV.INFO.agents` discovery

4. `npx @vchatemail/agent onboard` (without `--email`) works identically to `--email user@x.com` — email is a local label only

5. No `VCHAT_EMAIL` env var accepted by the install script (removed by design)

6. No separate `join.sh` exists — all functionality is in `vclawhub.com/install`

### Deferred to post-alpha

| Feature | Reason |
|---------|--------|
| TigerBeetle billing in lifecycle | No escrow needed for single-tenant alpha |
| Multi-fabric connect (Enterprise + Gig + Public) | Requires PostgreSQL `agent_relationships` |
| Wails desktop wrapper | macOS code-signing, notarization, DMG — separate track |
| `friend_request` / `friend_accept` handshake | Phase 2 — Gig Escrow bidirectional trust model |
