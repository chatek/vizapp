/**
 * evidence.ts — run evidence (J15 acceptance: duration + size from a REAL
 * run on THIS fleet, never a vendor figure).
 *
 * writeEvidence REFUSES to write for a dry run — a fabricated evidence file
 * is worse than none (the §1.5 "performance number is only as good as its
 * vantage" rule, inverted: a number with NO vantage is not a number).
 */

import { mkdirSync, writeFileSync } from "node:fs";
import type { RunReport } from "./exec.js";

export interface EvidenceMeta {
  vantage: string;
  operator?: string;
  /** manual annotations (e.g. observed first-launch unpack time) */
  notes?: string[];
}

export function writeEvidence(report: RunReport, meta: EvidenceMeta, outDir: string): string {
  if (!report.executed) {
    throw new Error("refusing to write evidence for a DRY run — numbers must come from a real execution");
  }
  const red = report.results.find((r) => r.status === "RED");
  if (red) {
    throw new Error(`refusing to write passing evidence for a RED run (step ${red.stepId})`);
  }
  const residual = report.results.some((r) => r.status === "stub" && r.stepId === "retire-hook");
  const totalMs = report.results.reduce((a, r) => a + (r.durationMs ?? 0), 0);
  const info = report.results.find((r) => r.stepId === "image-info")?.captured?.stdout ?? "";
  const size = /Size:\s*(.+)$/m.exec(info)?.[1]?.trim() ?? "UNRECORDED (image-info step missing)";
  const fp = /Fingerprint:\s*([0-9a-f]+)/m.exec(info)?.[1] ?? "UNRECORDED";

  const file = `${outDir}/${report.startedAt.replace(/[:.]/g, "-")}-${report.plan.name}.md`;
  mkdirSync(outDir, { recursive: true });
  const lines = [
    `# ${report.plan.name} — ${report.plan.target}`,
    ``,
    `- **Vantage**: ${meta.vantage} (host where the incus CLI ran)`,
    `- **Started**: ${report.startedAt} · **Ended**: ${report.endedAt}`,
    `- **Command wall-clock (sum of steps)**: ${(totalMs / 1000).toFixed(1)} s`,
    `- **Image size**: ${size}`,
    `- **Fingerprint**: ${fp}`,
    residual ? `- ⚠️ **RESIDUAL IDENTITY**: retire-hook still a stub (J16) — the validation identity remains claimed.` : "",
    ...(meta.notes ?? []).map((n) => `- note: ${n}`),
    ``,
    `| step | status | ms |`, `|---|---|---|`,
    ...report.results.map((r) => `| ${r.stepId} | ${r.status} | ${r.durationMs ?? ""} |`),
  ];
  writeFileSync(file, lines.filter((l) => l !== "").join("\n") + "\n");
  return file;
}

/** Figures already measured on this fleet (vantage-recorded). Do NOT replace with vendor numbers. */
export const MEASURED = {
  bakeWallClock: { value: "67 s (apt → gates)", vantage: "ct17, in-container", date: "2026-09-16", source: "D-incus-P1-bake.md §2" },
  publish: { value: "1 m 50 s → 684 MiB", vantage: "ct17, Incus 7.0.1", date: "2026-09-16 (§1.5 [O] earlier measurement)", source: "RUNTIME_incus.md §1.5" },
  publishedImage: { value: "797.13 MiB packed / 2237 MB rootfs", vantage: "ct17", date: "2026-09-16, fp e7ccedc63ada…", source: "D-incus-P1-bake.md §2" },
} as const;
