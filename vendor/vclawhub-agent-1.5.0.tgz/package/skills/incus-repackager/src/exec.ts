/**
 * exec.ts — the only place that spawns (J15).
 *
 * DRY-RUN IS THE DEFAULT. `--execute` is required for anything to run, and
 * even then every child is spawned with stdin:"ignore" — the mechanical
 * enforcement of §2.2.4: a prompt inside the path FAILS LOUDLY instead of
 * hanging an unanswerable headless session.
 *
 * Assert evaluation: an assert step reads the Captured output of the sh step
 * named by `capture` and applies its predicate. First RED stops the run
 * (abort-on-red, never continue-past-gate).
 */

import type { Captured } from "./asserts.js";
import { buildAssert } from "./asserts.js";
import type { Plan, Step } from "./steps.js";
import { checkPlan } from "./steps.js";
import { spawn } from "node:child_process";

export interface StepResult {
  stepId: string;
  status: "ok" | "RED" | "dry" | "stub";
  durationMs?: number;
  captured?: Captured;
  detail?: string;
}

export interface RunReport {
  plan: Plan;
  executed: boolean;
  results: StepResult[];
  startedAt: string;
  endedAt: string;
}

export interface RunOptions {
  execute: boolean;
  /** injection for tests; defaults to Bun.spawn-based hostRun */
  runner?: (argv: string[]) => Promise<Captured>;
}

/** Host command runner: stdin ignored ALWAYS (see file header).
 * node:child_process (not Bun.spawn) so the SDK's tsc gates typecheck it;
 * identical behavior under the bun runtime. */
export function hostRun(argv: string[]): Promise<Captured> {
  return new Promise((resolve) => {
    const p = spawn(argv[0], argv.slice(1), { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    p.stdout.on("data", (d: Buffer) => { stdout += d.toString(); });
    p.stderr.on("data", (d: Buffer) => { stderr += d.toString(); });
    p.on("error", (e) => resolve({ rc: 127, stdout, stderr: `${stderr}${e.message}` }));
    p.on("close", (code) => resolve({ rc: code ?? 127, stdout, stderr }));
  });
}

/**
 * RUNTIME assert resolution: `RUNTIME:`-prefixed expected values are
 * resolved by the caller before execution (e.g. the manifest sha). A
 * RUNTIME marker that reaches evaluation is a RED by construction — the
 * "never pass by absence" rule applies to the resolver too.
 */
export function resolveRuntimeExpected(spec: { expected: string }, resolved: Record<string, string>): string {
  const m = /^RUNTIME:(.+)$/.exec(spec.expected);
  return m ? (resolved[m[1]] ?? spec.expected) : spec.expected;
}

export async function runPlan(
  plan: Plan,
  opts: RunOptions,
): Promise<RunReport> {
  const violations = checkPlan(plan);
  if (violations.length > 0) {
    throw new Error(
      `plan violates §8.3 invariants — refusing to run (dry or live):\n` +
        violations.map((x) => `  [${x.stepId}] ${x.rule}: ${x.detail}`).join("\n"),
    );
  }

  const run = opts.runner ?? hostRun;
  const startedAt = new Date().toISOString();
  const results: StepResult[] = [];
  const capturedBy: Record<string, Captured> = {};
  const resolved: Record<string, string> = {};

  for (const s of plan.steps) {
    if (s.kind === "stub") {
      results.push({ stepId: s.id, status: "stub", detail: `${s.title} — blocked by ${s.blockedBy}` });
      continue;
    }
    if (s.kind === "assert") {
      if (!opts.execute) {
        results.push({ stepId: s.id, status: "dry", detail: s.title });
        continue;
      }
      const c = capturedBy[s.capture];
      const expected = resolveRuntimeExpected(s.spec, resolved);
      if (!c) {
        results.push({ stepId: s.id, status: "RED", detail: `no captured output for step '${s.capture}' — assert cannot run` });
        break;
      }
      const def = buildAssert({ ...s.spec, expected });
      const ok = def.predicate(c);
      results.push({
        stepId: s.id,
        status: ok ? "ok" : "RED",
        detail: ok ? def.label : `RED: ${def.howItFails} — got rc=${c.rc} stdout=${JSON.stringify(c.stdout.slice(0, 200))}`,
      });
      if (!ok) break;
      continue;
    }
    // sh step
    if (!opts.execute) {
      results.push({ stepId: s.id, status: "dry", detail: s.title });
      continue;
    }
    const t0 = Date.now();
    const c = await run(s.argv);
    capturedBy[s.id] = c;
    results.push({ stepId: s.id, status: "ok", durationMs: Date.now() - t0, captured: c });
    if (s.id === "manifest" && c.rc === 0) {
      try {
        const m = JSON.parse(c.stdout) as { tarballs?: Array<{ file: string; sha256: string }> };
        const tb = (m.tarballs ?? []).find((t) => t.file.startsWith("prime-agent-"));
        if (tb) resolved["manifest-sha256"] = tb.sha256.toLowerCase();
      } catch { /* the manifest-ver assert will go RED on non-JSON */ }
    }
    if (c.rc !== 0) {
      results.push({ stepId: s.id, status: "RED", detail: `command rc=${c.rc}: ${c.stderr.slice(0, 300)}` });
      break;
    }
  }

  return { plan, executed: opts.execute, results, startedAt, endedAt: new Date().toISOString() };
}
