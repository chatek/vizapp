/**
 * plan.ts — the three §8.3 plans as data (J15).
 *
 * FAST   routine runtime release: launch → push → install → STOP → publish.
 * CLEAN  base/toolchain change: the P1 bake script from the cloud-capable
 *        base image (distrobuilder stays J17, unmeasured — never the
 *        routine path).
 * VALIDATE  one throwaway instance, identity NOW (join pipe), asserted
 *        end-to-end, then cleanup with the J16 retire hook.
 */

import { PINS, ALIAS } from "./pins.js";
import type { Plan, Step } from "./steps.js";
import type { AssertSpec } from "./asserts.js";

const ts = () => new Date().toISOString().replace(/[-:T.]/g, "").slice(0, 14);

// ── assert spec builders (each carries its failure story) ───────────────────

const exactVersion = (expected: string, label: string): AssertSpec => ({
  assertId: "exactVersion",
  expected,
  label,
  // T1 class: empty output (SIGILL/absent binary) must FAIL, not pass silently
  howItFails: `output ≠ "${expected}" (empty output = absent binary / SIGILL rc=132 → RED)`,
});

const substringVersion = (expected: string, label: string): AssertSpec => ({
  assertId: "substringVersion",
  expected,
  label,
  howItFails: `"${expected}" not in output`,
});

const scanEmpty = (label: string): AssertSpec => ({
  assertId: "scanEmpty",
  expected: "(none)",
  label,
  howItFails: "scan listed file(s) — leftover identity/NATS artifacts in the image",
});

const cloudInitDone = (): AssertSpec => ({
  assertId: "cloudInitDone",
  expected: "status: done",
  label: "cloud-init done, not degraded",
  howItFails: "no 'status: done', or 'degraded' present (T6 dangling /var/lib/cloud/instance)",
});

const modeIs = (mode: string, label: string): AssertSpec => ({
  assertId: "modeIs",
  expected: mode,
  label,
  howItFails: `credential mode ≠ ${mode} (O37/O44: argv/world-readable credential classes)`,
});

const rc0 = (label: string, howItFails: string): AssertSpec => ({
  assertId: "rc0",
  expected: "rc=0",
  label,
  howItFails,
});

const includesNot = (expected: string, not: string, label: string): AssertSpec => ({
  assertId: "includesNot",
  expected,
  not,
  label,
  howItFails: `"${expected}" missing, or "${not}" present`,
});

// ── FAST ─────────────────────────────────────────────────────────────────────

export interface FastOptions {
  ver: string;
  /** Local prime-agent tgz; if omitted, fetched from the manifest + sha-verified. */
  tgz?: string;
  /** Base image to overlay onto (default: the last published unversioned alias). */
  from?: string;
}

export function fastPlan(o: FastOptions): Plan {
  const c = `vcx-build-${ts()}`;
  const from = o.from ?? "vclaw-agent:trixie-prime";
  const tgz = o.tgz ?? `/tmp/${c}/prime-agent-${o.ver}.tgz`;
  const steps: Step[] = [
    { kind: "sh", id: "preflight", title: "vantage preflight — incus CLI present", argv: ["incus", "version"], note: "runs on the incus host (ct17 / act-runner), nowhere else" },
  ];
  if (!o.tgz) {
    steps.push(
      { kind: "sh", id: "manifest", title: "fetch latest.json to STDOUT (curl — T3: urllib gets 403); runner parses it", argv: ["curl", "-fsSL", "--retry", "6", "--retry-all-errors", `${PINS.manifestBase}/latest.json`] },
      { kind: "assert", id: "manifest-ver", title: `manifest version == v${o.ver}`, capture: "manifest", spec: includesNot(`"version": "v${o.ver}"`, "<html", "manifest is JSON carrying the expected version (the SPA-fallback trap serves HTML)") },
      { kind: "sh", id: "fetch-tgz", title: "download prime-agent tgz", argv: ["curl", "-fsSL", "--retry", "6", "--retry-all-errors", `${PINS.manifestBase}/releases/v${o.ver}/prime-agent-${o.ver}.tgz`, "-o", tgz] },
      { kind: "sh", id: "sha-tgz", title: "sha256 the tarball", argv: ["sha256sum", tgz] },
      { kind: "assert", id: "sha-check", title: "tarball sha256 == manifest sha (expected injected by the runner from the parsed manifest; offline mode: --tgz-sha)", capture: "sha-tgz", spec: { assertId: "shaMatch", expected: "RUNTIME:manifest-sha256", label: "tgz sha256", howItFails: "digest mismatch or runner could not resolve a manifest sha — never pass by absence" } },
    );
  }
  steps.push(
    { kind: "sh", id: "launch", title: `launch throwaway ${c} from ${from}`, argv: ["incus", "launch", from, c, "--profile", PINS.profile] },
    { kind: "sh", id: "push", title: "push the tgz", argv: ["incus", "file", "push", tgz, `${c}/tmp/`] },
    // T4 trap lives in this install script verbatim: rm the bun-made symlink
    // BEFORE writing the wrapper, then re-assert the bundle exists.
    { kind: "sh", id: "install", title: "overlay-install prime-agent (bake.sh §4 shape)", argv: ["incus", "exec", c, "--", "bash", "-c", "set -euo pipefail; rm -rf /usr/local/install /usr/local/bin/prime-agent; mkdir -p /tmp/staging; cd /tmp/staging; BUN_INSTALL=/usr/local /usr/local/bin/bun install -g /tmp/prime-agent-" + o.ver + ".tgz; rm -f /usr/local/bin/prime-agent; printf '%s\\n' '#!/bin/sh' 'exec \"/usr/local/bin/bun\" \"/usr/local/install/global/node_modules/prime-agent/dist/bundle/cli.js\" \"$@\"' > /usr/local/bin/prime-agent; chmod 0755 /usr/local/bin/prime-agent; test -f /usr/local/install/global/node_modules/prime-agent/dist/bundle/cli.js"] },
    { kind: "sh", id: "ver-prime", title: "prime-agent --version", argv: ["incus", "exec", c, "--", "/usr/local/bin/prime-agent", "--version"] },
    { kind: "assert", id: "ver-prime-a", title: `prime-agent == ${o.ver}`, capture: "ver-prime", spec: exactVersion(o.ver, "prime-agent version") },
    { kind: "sh", id: "ver-bun", title: "bun --version (baseline build must still answer)", argv: ["incus", "exec", c, "--", "/usr/local/bin/bun", "--version"] },
    { kind: "assert", id: "ver-bun-a", title: `bun == ${PINS.bun}`, capture: "ver-bun", spec: exactVersion(PINS.bun, "bun version (T1 baseline)") },
    { kind: "sh", id: "ver-uv", title: "uv --version", argv: ["incus", "exec", c, "--", "/usr/local/bin/uv", "--version"] },
    { kind: "assert", id: "ver-uv-a", title: `uv ~ ${PINS.uv}`, capture: "ver-uv", spec: substringVersion(PINS.uv, "uv version (T2)") },
    { kind: "sh", id: "nats-scan", title: "NATS_URL scan (must be empty)", argv: ["incus", "exec", c, "--", "bash", "-c", "grep -rIl -i NATS_URL /etc /usr/local /root /home /opt /var 2>/dev/null || echo '(none)'"] },
    { kind: "assert", id: "nats-scan-a", title: "no NATS_URL anywhere (T5)", capture: "nats-scan", spec: scanEmpty("NATS_URL scan") },
    { kind: "sh", id: "stop", title: "STOP before publish (§1.5)", argv: ["incus", "stop", c] },
    { kind: "sh", id: "publish", title: `publish ${ALIAS.ver(o.ver)}`, argv: ["incus", "publish", c, "--alias", ALIAS.ver(o.ver)] },
    { kind: "sh", id: "image-info", title: "image info (size → evidence)", argv: ["incus", "image", "info", ALIAS.ver(o.ver)] },
    { kind: "sh", id: "delete", title: "delete throwaway", argv: ["incus", "delete", c, "--force"] },
  );
  return { name: "fast", target: ALIAS.ver(o.ver), steps };
}

// ── CLEAN ────────────────────────────────────────────────────────────────────

export interface CleanOptions {
  ver: string;
}

export function cleanPlan(o: CleanOptions): Plan {
  const c = `vcx-bake-${ts()}`;
  const steps: Step[] = [
    { kind: "sh", id: "preflight", title: "vantage preflight — incus CLI present", argv: ["incus", "version"] },
    { kind: "sh", id: "launch", title: `launch throwaway ${c} from the CLOUD-CAPABLE base (§2: plain debian-trixie is a dead end)`, argv: ["incus", "launch", PINS.baseImage, c, "--profile", PINS.profile] },
    { kind: "sh", id: "push-bake", title: "push the vendored bake.sh (md5-recorded)", argv: ["incus", "file", "push", "assets/bake.sh", `${c}/tmp/bake.sh`] },
    // The ver pin is a VISIBLE sed on the vendored script — evidence records
    // base md5 + override. Never edit the vendored file in place.
    { kind: "sh", id: "bake", title: `bake (six traps asserted inside; pin -> v${o.ver})`, argv: ["incus", "exec", c, "--", "bash", "-c", `sed -i "s/^WANT_PRIME_VER=.*/WANT_PRIME_VER=${o.ver}/" /tmp/bake.sh && bash /tmp/bake.sh`] },
    { kind: "assert", id: "bake-gate", title: "bake.sh reached GATE-DONE with rc 0", capture: "bake", spec: includesNot("GATE-DONE", "FATAL", "the bake script's own gate must complete without a FATAL") },
    { kind: "sh", id: "ver-prime", title: "prime-agent --version", argv: ["incus", "exec", c, "--", "/usr/local/bin/prime-agent", "--version"] },
    { kind: "assert", id: "ver-prime-a", title: `prime-agent == ${o.ver}`, capture: "ver-prime", spec: exactVersion(o.ver, "prime-agent version") },
    { kind: "sh", id: "ver-bun", title: "bun --version", argv: ["incus", "exec", c, "--", "/usr/local/bin/bun", "--version"] },
    { kind: "assert", id: "ver-bun-a", title: `bun == ${PINS.bun} (T1 baseline — empty output is RED)`, capture: "ver-bun", spec: exactVersion(PINS.bun, "bun version") },
    { kind: "sh", id: "cloud-init", title: "cloud-init status (T6: must be done, not degraded)", argv: ["incus", "exec", c, "--", "cloud-init", "status", "--long"] },
    { kind: "assert", id: "cloud-init-a", title: "cloud-init done, no 'degraded'", capture: "cloud-init", spec: cloudInitDone() },
    { kind: "sh", id: "stop", title: "STOP before publish (§1.5)", argv: ["incus", "stop", c] },
    { kind: "sh", id: "publish", title: `publish ${ALIAS.ver(o.ver)}`, argv: ["incus", "publish", c, "--alias", ALIAS.ver(o.ver)] },
    { kind: "sh", id: "image-info", title: "image info (size → evidence)", argv: ["incus", "image", "info", ALIAS.ver(o.ver)] },
    { kind: "sh", id: "delete", title: "delete throwaway", argv: ["incus", "delete", c, "--force"] },
  ];
  return { name: "clean", target: ALIAS.ver(o.ver), steps };
}

// ── VALIDATE ─────────────────────────────────────────────────────────────────

export interface ValidateOptions {
  alias: string;
  ver: string;
}

export function validatePlan(o: ValidateOptions): Plan {
  const c = `vcx-validate-${ts()}`;
  const steps: Step[] = [
    { kind: "sh", id: "preflight", title: "vantage preflight — incus CLI present", argv: ["incus", "version"] },
    { kind: "sh", id: "launch", title: `launch throwaway ${c} from ${o.alias}`, argv: ["incus", "launch", o.alias, c, "--profile", PINS.profile] },
    { kind: "sh", id: "cloud-init", title: "cloud-init status (boot completed)", argv: ["incus", "exec", c, "--", "cloud-init", "status", "--long"] },
    { kind: "assert", id: "cloud-init-a", title: "cloud-init done, no 'degraded' (T6)", capture: "cloud-init", spec: cloudInitDone() },
    // ── identity NOW — the ONLY place join.ts may appear (zero-identity-in-build) ──
    { kind: "sh", id: "join", title: "identity + claim via the pipe, as the agent user (§3.4)", argv: ["incus", "exec", c, "--", "su", "-", "debian", "-c", "curl -fsSL https://vclawhub.com/join.ts | bun -"], note: "stdin ignored — if the pipe ever prompts, this fails LOUD, never hangs (§2.2.4)" },
    { kind: "sh", id: "claim", title: "claim status (server-side truth)", argv: ["incus", "exec", c, "--", "su", "-", "debian", "-c", "vclaw-agent status"] },
    { kind: "assert", id: "claim-a", title: "identity claimed", capture: "claim", spec: includesNot("claimed", "pending", "claim reached, not pending/unclaimed") },
    { kind: "sh", id: "fabric", title: "fabric reachability (vchat3:4223 + INFO banner)", argv: ["incus", "exec", c, "--", "su", "-", "debian", "-c", "getent hosts vchat3 && timeout 5 bash -c 'exec 3<>/dev/tcp/vchat3/4223 && head -c 4 <&3' "] },
    { kind: "assert", id: "fabric-a", title: "NATS INFO banner received", capture: "fabric", spec: includesNot("INFO", "refused", "fabric reachable and answering") },
    { kind: "sh", id: "ver-prime", title: "prime-agent --version", argv: ["incus", "exec", c, "--", "/usr/local/bin/prime-agent", "--version"] },
    { kind: "assert", id: "ver-prime-a", title: `prime-agent == ${o.ver}`, capture: "ver-prime", spec: exactVersion(o.ver, "image carries the expected product version") },
    { kind: "sh", id: "cred-mode", title: "credential file mode (auth.json / credentials)", argv: ["incus", "exec", c, "--", "su", "-", "debian", "-c", "stat -c %a ~/.vclaw/auth.json 2>/dev/null || stat -c %a ~/.vchat/credentials.json"] },
    { kind: "assert", id: "cred-mode-a", title: "credential mode 0600", capture: "cred-mode", spec: modeIs("600", "credentials never world/group-readable (O37/O44)") },
    { kind: "sh", id: "restart", title: "restart-safety gate (P1 §4)", argv: ["incus", "restart", c, "--force"] },
    { kind: "sh", id: "ver-after", title: "prime-agent --version after restart", argv: ["incus", "exec", c, "--", "/usr/local/bin/prime-agent", "--version"] },
    { kind: "assert", id: "ver-after-a", title: `version survives restart == ${o.ver}`, capture: "ver-after", spec: exactVersion(o.ver, "restart-safety") },
    // ── cleanup: the J16 hook. NOT silent, NOT optional-looking. ──
    {
      kind: "stub",
      id: "retire-hook",
      title: "retire the validation identity (J16)",
      blockedBy: "J16a CLI green headless (J16c NKey-proof for CI)",
      body: "Attempt: incus exec <c> -- su - debian -c 'vclaw-agent retire --yes --reason \"ci validation <ts>\" --json' — if the command is absent or cannot authenticate headlessly, this run is recorded as RESIDUAL-IDENTITY in the evidence file. Never silent: the evidence row is the tracking register until J16a/J16c close it.",
    },
    { kind: "sh", id: "delete", title: "delete throwaway", argv: ["incus", "delete", c, "--force"] },
  ];
  return { name: "validate", target: o.alias, steps };
}
