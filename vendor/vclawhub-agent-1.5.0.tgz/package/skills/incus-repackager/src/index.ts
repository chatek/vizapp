/**
 * index.ts — incus-repackager CLI entry (J15).
 *
 * ONE COMMAND per §8.3:
 *   bun skills/incus-repackager/src/index.ts fast   --ver 0.9.5 [--tgz p.tgz] [--execute]
 *   bun skills/incus-repackager/src/index.ts clean  --ver 0.9.4 [--execute]
 *   bun skills/incus-repackager/src/index.ts validate --alias vclaw-agent:trixie-prime-0.9.4 --ver 0.9.4 [--execute]
 *   bun skills/incus-repackager/src/index.ts aliases show|add|flip|drop [..] [--operator-go] [--execute]
 *
 * DRY-RUN IS THE DEFAULT. --execute runs for real — from the operator-
 * authorized incus vantage only (ct17 / act-runner), never a dev laptop.
 * Zero-dep by design (Bun + node:fs only): runnable on the host with just
 * this repo + bun.
 */

import { fastPlan, cleanPlan, validatePlan } from "./plan.js";
import { checkPlan, renderStep } from "./steps.js";
import { runPlan } from "./exec.js";
import { writeEvidence, MEASURED } from "./evidence.js";
import { applyAliasOp, aliasCommands, type AliasState } from "./alias.js";
import { hostname as osHostname } from "node:os";

const HELP = `incus-repackager (J15) — vclaw-agent image rebuild as one command. DRY-RUN DEFAULT.

commands:
  fast      --ver <v> [--tgz <path>] [--from <alias>]   routine runtime release (launch→push→install→STOP→publish)
  clean     --ver <v>                                     base/toolchain change (the P1 bake, cloud-capable base)
  validate  --alias <a> --ver <v>                         one throwaway instance, identity via the join pipe, asserted
  aliases   show|add|flip|drop                            alias protocol (ADD→FLIP→SOAK→DROP; :stable operator-gated)
  measured                                                 print fleet-measured figures (vantage-recorded)

flags: --execute (real run; operator-authorized vantage only) · --operator-go (unlocks FLIP/DROP)`;

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}
function has(name: string): boolean {
  return process.argv.includes(name);
}

async function main(): Promise<void> {
  const cmd = process.argv[2];
  const execute = has("--execute");
  if (!cmd || cmd === "help" || cmd === "--help") {
    console.log(HELP);
    return;
  }

  if (cmd === "measured") {
    for (const [k, v] of Object.entries(MEASURED)) {
      console.log(`${k}: ${v.value}  [${v.vantage}, ${v.date} — ${v.source}]`);
    }
    return;
  }

  if (cmd === "aliases") {
    // State is read from `incus image alias list --format json` at execute
    // time; dry-run rules on the op shape alone.
    const sub = process.argv[3];
    const ver = arg("--ver") ?? "";
    const now = new Date().toISOString();
    const operatorGo = has("--operator-go");
    const state: AliasState = { versions: [], addedAt: {} };
    const op = sub === "add" ? { op: "add" as const, ver, now }
      : sub === "flip" ? { op: "flip" as const, ver, operatorGo, now }
      : sub === "drop" ? { op: "drop" as const, ver, operatorGo, now }
      : null;
    if (sub === "show") {
      console.log("alias state is read live via `incus image alias list --format json` (execute mode)");
      console.log(aliasCommands({ op: "add", ver: "<ver>", now }, () => "<fingerprint>").join("\n"));
      return;
    }
    if (!op) { console.error("aliases: expected show|add|flip|drop"); process.exit(2); }
    const ruling = applyAliasOp(state, op);
    console.log(ruling.reason);
    if (!ruling.ok) process.exit(2);
    if (ruling.next) console.log("next state:", JSON.stringify(ruling.next));
    console.log("commands (dry-run — add --execute):");
    console.log("  " + aliasCommands(op, (v) => `<fingerprint-of-${v}>`).join("\n  "));
    return;
  }

  const plan = cmd === "fast" ? fastPlan({ ver: arg("--ver") ?? "", tgz: arg("--tgz"), from: arg("--from") })
    : cmd === "clean" ? cleanPlan({ ver: arg("--ver") ?? "" })
    : cmd === "validate" ? validatePlan({ alias: arg("--alias") ?? "", ver: arg("--ver") ?? "" })
    : null;
  if (!plan) { console.error(`unknown command '${cmd}'`); console.log(HELP); process.exit(2); }
  if (!arg("--ver")) { console.error("--ver is required"); process.exit(2); }

  const violations = checkPlan(plan);
  console.log(`plan: ${plan.name} → ${plan.target}   [${execute ? "EXECUTE" : "DRY-RUN (default)"}]`);
  plan.steps.forEach((s, i) => console.log(renderStep(s, i)));
  if (violations.length > 0) {
    console.error(`\n❌ plan violates invariants:\n` + violations.map((v) => `  [${v.stepId}] ${v.rule}: ${v.detail}`).join("\n"));
    process.exit(2);
  }

  const report = await runPlan(plan, { execute });
  const red = report.results.find((r) => r.status === "RED");
  const stubs = report.results.filter((r) => r.status === "stub");
  if (execute) {
    const file = writeEvidence(report, { vantage: `hostname: ${osHostname()}` }, new URL("../../runs/", import.meta.url).pathname);
    console.log(`\nevidence: ${file}`);
  } else {
    console.log("\ndry-run complete — nothing executed. Add --execute from the operator-authorized vantage for a real run.");
  }
  for (const s of stubs) console.log(`⚠️  STUB: ${s.detail}`);
  if (red) { console.error(`\n❌ RED at ${red.stepId}: ${red.detail}`); process.exit(1); }
  console.log("\n✅ all gates green");
}


main().catch((e) => { console.error(e); process.exit(1); });
