/**
 * steps.ts — plan step model (J15). Plans are DATA: the dry-run harness
 * renders and invariant-checks them without touching incus; the executor
 * (exec.ts) is the only place that spawns.
 */

import type { AssertSpec } from "./asserts.js";

export type Step =
  /** Host-side command (argv[0] must be "incus", "curl", or "sha256sum"). */
  | { kind: "sh"; id: string; title: string; argv: string[]; note?: string }
  /** Gate: run predicate against the captured output of `capture`. */
  | { kind: "assert"; id: string; title: string; capture: string; spec: AssertSpec }
  /** Visible, non-silent placeholder (the J16 retire hook until wired green). */
  | { kind: "stub"; id: string; title: string; blockedBy: string; body: string };

export interface Plan {
  name: "fast" | "clean" | "validate";
  /** Published alias this plan produces (validate: the alias it exercises). */
  target: string;
  steps: Step[];
}

// ── Plan-level invariants (checked mechanically in checkPlan) ───────────────

/** Credential-ish argv that must NEVER appear in a command (O37/O44). */
const FORBIDDEN_ARGV_ALL: RegExp[] = [
  /--nkey\s+\S+/,
  /--seed(\s|=)/,
  /--token(\s|=)/,
  /X-VChat-Service-Token/i,
  /NATS_JWT\s*=/,
];

/** Identity-bearing surfaces: allowed ONLY in the validate plan. */
const FORBIDDEN_IDENTITY_BUILD: RegExp[] = [
  /\bonboard\b/,
  /join\.ts/,
];

/** Interactive/TTY markers — nothing in the path may prompt (§2.2.4).
 * NOTE: `sed -i` is NOT interactive — excluded deliberately (false-positive class). */
const FORBIDDEN_PROMPT: RegExp[] = [
  /--interactive/,
  /\bread\s+-[rp]\s/,
  /apt(-get)?\s+install(?![^\n]*\s-y)(?![^\n]*--yes)/,
];

export interface Violation {
  stepId: string;
  rule: string;
  detail: string;
}

/**
 * Mechanically check a plan against the §8.3 invariants. Returns violations
 * (empty = plan is legal). Every rule here is one of the binding REJECTs —
 * see SKILL.md "Invariants".
 */
export function checkPlan(plan: Plan): Violation[] {
  const v: Violation[] = [];
  const cmdText = (s: Extract<Step, { kind: "sh" }>) => s.argv.join(" ");

  for (const s of plan.steps) {
    if (s.kind !== "sh") continue;
    const text = cmdText(s);
    // `incus exec -t` allocates a TTY — stdin is swallowed by design, so a
    // prompt inside exec is unanswerable (§2.2.4). All exec calls stay non-TTY.
    if (s.argv[0] === "incus" && s.argv[1] === "exec" && (s.argv.includes("-t") || s.argv.includes("--force-interactive"))) {
      v.push({ stepId: s.id, rule: "nothing-prompts", detail: "incus exec with -t (TTY) — headless prompts are unanswerable" });
    }
    for (const re of FORBIDDEN_ARGV_ALL) {
      if (re.test(text)) v.push({ stepId: s.id, rule: "no-credential-argv", detail: re.source });
    }
    for (const re of FORBIDDEN_PROMPT) {
      if (re.test(text)) v.push({ stepId: s.id, rule: "nothing-prompts", detail: re.source });
    }
    if (plan.name !== "validate") {
      for (const re of FORBIDDEN_IDENTITY_BUILD) {
        if (re.test(text)) v.push({ stepId: s.id, rule: "zero-identity-in-build", detail: re.source });
      }
    }
  }

  // publish from STOPPED (§1.5 restore caveat): a stop must precede publish.
  const idx = (pred: (s: Step) => boolean) => plan.steps.findIndex(pred);
  const stop = idx((s) => s.kind === "sh" && s.argv[0] === "incus" && s.argv[1] === "stop");
  const publish = idx((s) => s.kind === "sh" && s.argv[0] === "incus" && s.argv[1] === "publish");
  if (publish >= 0) {
    if (stop < 0) v.push({ stepId: plan.steps[publish].id, rule: "publish-from-stopped", detail: "publish without a preceding stop" });
    else if (stop > publish) v.push({ stepId: plan.steps[publish].id, rule: "publish-from-stopped", detail: "stop must precede publish" });
  }
  return v;
}

/** Render a step for dry-run display. */
export function renderStep(s: Step, i: number): string {
  const n = `${i + 1}`.padStart(2, " ");
  switch (s.kind) {
    case "sh":
      return `${n}. [sh    ] ${s.title}\n         $ ${s.argv.map(q).join(" ")}`;
    case "assert":
      return `${n}. [assert] ${s.title} — (${s.spec.assertId} ${s.spec.expected}${s.spec.not ? ` NOT ${s.spec.not}` : ""})\n         fails when: ${s.spec.howItFails}`;
    case "stub":
      return `${n}. [STUB  ] ${s.title} — blocked by ${s.blockedBy}\n         ${s.body}`;
  }
}

function q(a: string): string {
  return /[\s"'|;&<>]/.test(a) ? `"${a.replace(/"/g, '\\"')}"` : a;
}
