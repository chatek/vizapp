/**
 * pins.ts — pinned versions + alias names (J15, RUNTIME_incus.md §8.3).
 *
 * PINS are the tested artifact set from the P1 bake (D-incus-P1-bake.md).
 * bun is the x64 BASELINE build BY DESIGN (T1): ct17's Celeron G4900 has no
 * AVX2; the plain bun-linux-x64 binary dies SIGILL rc=132. Never "upgrade"
 * to the non-baseline build without a new timed run on the target host class.
 */

export const PINS = {
  /** bun x64 baseline build (T1 — see file header). */
  bun: "1.3.14",
  bunFlavor: "baseline" as const,
  /** uv standalone installer (T2 — UV_INSTALL_DIR=/usr/local/bin). */
  uv: "0.12.14",
  /** Manifest base for prime-agent artifacts (T3 — curl only, never urllib). */
  manifestBase: "https://vclawhub.com/prime-agent",
  /** Cloud-capable base image for the CLEAN path (plain debian-trixie is a dead end, §2). */
  baseImage: "debian-trixie-pi-agent",
  /** Published image root + throwaway prefixes (hygiene: read-only on pre-existing objects). */
  imageRoot: "vclaw-agent",
  profile: "vclaw-agent",
} as const;

/** Alias protocol names (ADD → FLIP → SOAK → DROP, §8.3). */
export const ALIAS = {
  ver: (v: string) => `vclaw-agent:trixie-prime-${v}`,
  stable: "vclaw-agent:stable",
  stablePrev: "vclaw-agent:stable-prev",
} as const;

/** Minimum soak before a DROP is legal (hours). */
export const MIN_SOAK_HOURS = 24;

/**
 * Vendored bake.sh md5 (the canonical local archive copy). The P1 report's
 * prose cites `ddd52cd6…` for ct17's /tmp/vcx-p1/bake.sh — the local archive
 * (identical in report §5 embed and raw-p1/bake.sh) hashes `b26d423d…`.
 * RECONCILE at the timed run: md5 ct17's copy first (see SKILL.md).
 */
export const BAKE_MD5_LOCAL = "b26d423db4181e29a83c7fabf7f3a107";
export const BAKE_MD5_CT17_CITED = "ddd52cd6fa8aaecf77a6adec2062de26";
