/**
 * asserts.ts — the assert registry (J15).
 *
 * DESIGN RULE (RUNTIME_incus.md §8.3, binding): **every assertion must be
 * able to fail** — a gate that cannot go red is the inert-profile defect
 * (§2.2.1) wearing a CI costume. Mechanically enforced here: every registry
 * entry ships BOTH a good fixture and >=1 bad fixture; the unit test
 * (test/unit/repackager-asserts.test.ts) iterates the whole registry and
 * asserts predicate(good)===true && predicate(bad)===false for EVERY entry.
 * An assert without a failing fixture cannot be registered (the type
 * requires `bad: Captured[]`).
 *
 * The six P1 bake traps (D-incus-P1-bake.md §7) land here as asserts:
 *   T1 no-AVX2  → exactVersion FAILS on EMPTY stdout (SIGILL prints nothing;
 *                 a bare `echo $(…)` passes by silence — this must not)
 *   T2 uv dir   → substringVersion on `uv --version`
 *   T3 urllib403→ (plan-level: downloads use curl; not an assert)
 *   T4 symlink  → (plan-level step order; plus exactVersion on --version)
 *   T5 NATS_URL → scanEmpty on the purge re-scan
 *   T6 dangling cloud-init symlink → cloudInitDone rejects "degraded"
 */

export interface Captured {
  rc: number;
  stdout: string;
  stderr: string;
}

export type AssertId =
  | "exactVersion" // stdout.trim() === expected AND rc === 0 — fails on empty/mismatch/SIGILL
  | "substringVersion" // rc === 0 && stdout includes expected
  | "scanEmpty" // a "must be empty" scan: rc===0 and stdout is "" or "(none)"
  | "cloudInitDone" // status: done AND NOT degraded (T6)
  | "modeIs" // stat mode string equality (auth.json 0600, O37/O44)
  | "rc0" // bare exit-code gate
  | "shaMatch" // sha256sum line: FIRST TOKEN === expected digest (path-independent)
  | "includesNot"; // includes value && does NOT include `not`

export interface AssertSpec {
  assertId: AssertId;
  /** expected value (version string, mode, needle) */
  expected: string;
  label: string;
  /** for includesNot: the forbidden needle */
  not?: string;
  howItFails: string;
}

export interface AssertDef extends AssertSpec {
  predicate: (c: Captured) => boolean;
  /** Fixtures proving the assert can go green AND red. */
  fixtures: { good: Captured; bad: Captured[] };
}

export function buildAssert(spec: AssertSpec): AssertDef {
  const { assertId, expected } = spec;
  let predicate: (c: Captured) => boolean;
  let fixtures: { good: Captured; bad: Captured[] };

  switch (assertId) {
    case "exactVersion":
      predicate = (c) => c.rc === 0 && c.stdout.trim() === expected;
      fixtures = {
        good: { rc: 0, stdout: `${expected}\n`, stderr: "" },
        bad: [
          // T1: SIGILL prints NOTHING on stdout and rc=132 — passing by
          // silence is the defect this assert exists to catch.
          { rc: 132, stdout: "", stderr: "Illegal instruction (core dumped)" },
          { rc: 0, stdout: "\n", stderr: "" }, // empty output, rc 0
          { rc: 0, stdout: "1.2.3\n", stderr: "" }, // wrong version
        ],
      };
      break;
    case "substringVersion":
      predicate = (c) => c.rc === 0 && c.stdout.includes(expected);
      fixtures = {
        good: { rc: 0, stdout: `uv ${expected} (x86_64-unknown-linux-gnu)\n`, stderr: "" },
        bad: [
          { rc: 0, stdout: "", stderr: "" }, // binary absent from PATH → empty
          { rc: 0, stdout: "uv 0.0.0\n", stderr: "" },
        ],
      };
      break;
    case "scanEmpty":
      predicate = (c) => c.rc === 0 && (c.stdout.trim() === "" || c.stdout.trim() === "(none)");
      fixtures = {
        good: { rc: 0, stdout: "  (none)\n", stderr: "" },
        bad: [
          { rc: 0, stdout: "/etc/profile.d/pi-agent.sh\n", stderr: "" }, // T5 leftover
          { rc: 2, stdout: "", stderr: "grep: ..." },
        ],
      };
      break;
    case "cloudInitDone":
      predicate = (c) =>
        c.rc === 0 && c.stdout.includes("status: done") && !c.stdout.includes("degraded");
      fixtures = {
        good: { rc: 0, stdout: "status: done\nextended_status: done\nerrors: []\n", stderr: "" },
        bad: [
          // T6: the dangling /var/lib/cloud/instance symlink produces this
          { rc: 0, stdout: "status: done\nextended_status: degraded done\n", stderr: "" },
          { rc: 0, stdout: "status: running\n", stderr: "" },
        ],
      };
      break;
    case "modeIs":
      predicate = (c) => c.rc === 0 && c.stdout.trim() === expected;
      fixtures = {
        good: { rc: 0, stdout: `${expected}\n`, stderr: "" },
        bad: [
          { rc: 0, stdout: "644\n", stderr: "" }, // O44: world-readable credential
          { rc: 1, stdout: "", stderr: "No such file" }, // missing file
        ],
      };
      break;
    case "rc0":
      predicate = (c) => c.rc === 0;
      fixtures = {
        good: { rc: 0, stdout: "ok\n", stderr: "" },
        bad: [{ rc: 3, stdout: "", stderr: "Failed to set up the Python kernel runtime…" }], // §2.2.4 exit 3
      };
      break;
    case "shaMatch":
      // sha256sum prints "<sha>  <path>" — compare the digest token only.
      predicate = (c) => c.rc === 0 && (c.stdout.trim().split(/\s+/)[0] ?? "").toLowerCase() === expected.toLowerCase();
      fixtures = {
        good: { rc: 0, stdout: `${expected}  /tmp/prime-agent.tgz\n`, stderr: "" },
        bad: [
          { rc: 0, stdout: `0000000000000000000000000000000000000000000000000000000000000000  /tmp/x.tgz\n`, stderr: "" },
          { rc: 1, stdout: "", stderr: "sha256sum: /tmp/x.tgz: No such file" },
        ],
      };
      break;
    case "includesNot":
      predicate = (c) => c.rc === 0 && c.stdout.includes(expected) && !c.stdout.includes(spec.not ?? "\u0000");
      fixtures = {
        good: { rc: 0, stdout: `…${expected}…\n`, stderr: "" },
        bad: [
          { rc: 0, stdout: "something else entirely\n", stderr: "" }, // missing needle
          { rc: 0, stdout: `…${expected}… ${spec.not ?? "forbidden"} …\n`, stderr: "" }, // forbidden present
        ],
      };
      break;
  }

  return { ...spec, predicate, fixtures };
}
