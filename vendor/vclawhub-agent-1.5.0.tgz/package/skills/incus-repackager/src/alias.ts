/**
 * alias.ts — ADD → FLIP → SOAK → DROP state machine (RUNTIME_incus.md §8.3).
 *
 * Rules (each one REJECTs a real footgun):
 *  - FLIP (:stable) is OPERATOR-GATED: no flag, no flip (O36 commit-vs-deploy
 *    separation; operator decision 6).
 *  - :stable-prev is the ROLLBACK TARGET: never dropped early, never the
 *    object of a drop op while it is the rollback.
 *  - DROP requires the soak window to have elapsed (default 24h).
 *  - ADD is idempotent-refusing: the version alias must not already exist.
 *
 * Pure data-in/data-out — the incus alias commands are composed by the
 * caller; this file only rules on legality.
 */

import { ALIAS, MIN_SOAK_HOURS } from "./pins.js";

export interface AliasState {
  /** version suffixes with a :trixie-prime-<ver> alias present */
  versions: string[];
  /** current :stable target (version suffix), if any */
  stable?: string;
  /** current :stable-prev target (version suffix), if any */
  stablePrev?: string;
  /** when each version was ADDED (ISO) — soak accounting */
  addedAt: Record<string, string>;
}

export type AliasOp =
  | { op: "add"; ver: string; now: string }
  | { op: "flip"; ver: string; operatorGo: boolean; now: string }
  | { op: "drop"; ver: string; operatorGo: boolean; now: string };

export interface AliasRuling {
  ok: boolean;
  reason: string;
  next?: AliasState;
}

export function applyAliasOp(s: AliasState, op: AliasOp): AliasRuling {
  switch (op.op) {
    case "add": {
      if (s.versions.includes(op.ver)) {
        return { ok: false, reason: `${ALIAS.ver(op.ver)} already exists — ADD is not idempotent; bump the version` };
      }
      return {
        ok: true,
        reason: `ADD ${ALIAS.ver(op.ver)} (holds; :stable untouched)`,
        next: { ...s, versions: [...s.versions, op.ver], addedAt: { ...s.addedAt, [op.ver]: op.now } },
      };
    }
    case "flip": {
      if (!op.operatorGo) {
        return { ok: false, reason: "FLIP refused: :stable promotion is operator-gated (add --operator-go)" };
      }
      if (!s.versions.includes(op.ver)) {
        return { ok: false, reason: `cannot FLIP to ${op.ver} — no ${ALIAS.ver(op.ver)} alias (ADD first)` };
      }
      if (s.stable === op.ver) {
        return { ok: false, reason: `:stable already points at ${op.ver}` };
      }
      return {
        ok: true,
        reason: `FLIP :stable → ${op.ver}; :stable-prev → ${s.stable ?? "(none — first stable)"}`,
        next: { ...s, stable: op.ver, stablePrev: s.stable ?? s.stablePrev },
      };
    }
    case "drop": {
      if (!op.operatorGo) {
        return { ok: false, reason: "DROP refused: alias retirement is operator-gated (add --operator-go)" };
      }
      if (s.stable === op.ver) {
        return { ok: false, reason: `cannot DROP ${op.ver} — it IS :stable` };
      }
      if (s.stablePrev === op.ver) {
        return { ok: false, reason: `cannot DROP ${op.ver} — it IS :stable-prev, the rollback target (never dropped early)` };
      }
      if (!s.versions.includes(op.ver)) {
        return { ok: false, reason: `cannot DROP ${op.ver} — no such version alias` };
      }
      const added = s.addedAt[op.ver] ? Date.parse(s.addedAt[op.ver]) : NaN;
      const soakedHours = Number.isNaN(added) ? Infinity : (Date.parse(op.now) - added) / 3_600_000;
      if (soakedHours < MIN_SOAK_HOURS) {
        return { ok: false, reason: `DROP refused: ${op.ver} soaked ${soakedHours.toFixed(1)}h < ${MIN_SOAK_HOURS}h minimum` };
      }
      const versions = s.versions.filter((x) => x !== op.ver);
      const addedAt = { ...s.addedAt };
      delete addedAt[op.ver];
      return { ok: true, reason: `DROP ${ALIAS.ver(op.ver)} after ${soakedHours.toFixed(1)}h soak`, next: { ...s, versions, addedAt } };
    }
  }
}

/** Compose the host incus commands an op implies (caller executes). */
export function aliasCommands(op: AliasOp, fingerprintOf: (ver: string) => string): string[] {
  switch (op.op) {
    case "add":
      return [`incus image alias create ${ALIAS.ver(op.ver)} ${fingerprintOf(op.ver)}`];
    case "flip": {
      const cmds: string[] = [];
      if (op.now /* stablePrev rotation is a 3-step */) {
        // rotate: old :stable-prev dies (now two versions old), old :stable
        // becomes :stable-prev, new becomes :stable
        cmds.push(`incus image alias delete ${ALIAS.stablePrev} || true`);
        cmds.push(`incus image alias rename ${ALIAS.stable} ${ALIAS.stablePrev} || true`);
        cmds.push(`incus image alias create ${ALIAS.stable} ${fingerprintOf(op.ver)}`);
      }
      return cmds;
    }
    case "drop":
      return [`incus image alias delete ${ALIAS.ver(op.ver)}`];
  }
}
