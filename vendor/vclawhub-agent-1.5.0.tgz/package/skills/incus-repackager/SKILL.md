# incus-repackager — vclaw-agent image rebuild as one command (J15)

> **Status: BUILT + DRY-RUN-VERIFIED 2026-09-16. Timed real run NOT yet executed —
> awaits the operator's go from the authorized vantage (ct17 / act-runner).**
> Design: `agent-sdk/docs/RUNTIME_incus.md` §8 (the §8.1/§8.2 REJECTs are BINDING on
> this skill). Landed precedent: P1 bake (`D-incus-P1-bake.md`), image fp
> `e7ccedc63ada…`, 797.13 MiB packed.

## Invoke (dry-run is the DEFAULT — nothing executes without `--execute`)

```bash
bun skills/incus-repackager/src/index.ts fast    --ver <v> [--tgz <path>] [--from <alias>]   # routine runtime release
bun skills/incus-repackager/src/index.ts clean   --ver <v>                                   # base/toolchain change
bun skills/incus-repackager/src/index.ts validate --alias <a> --ver <v>                      # e2e identity validation
bun skills/incus-repackager/src/index.ts aliases show|add|flip|drop --ver <v> [--operator-go]
bun skills/incus-repackager/src/index.ts measured                                            # fleet-measured figures
```

`--execute` runs for real **from the operator-authorized incus vantage only**
(ct17 / the act-runner lane). A dev laptop has no incus — preflight fails rc≠0 there.

## Paths (§8.3)

| path | when | shape |
|---|---|---|
| **FAST** | routine runtime release | launch last image → push tgz → overlay-install (bake.sh §4 shape: rm bun symlink → wrapper → assert bundle) → **STOP** → `incus publish --alias vclaw-agent:trixie-prime-<ver>` → delete throwaway |
| **CLEAN** | base-OS / toolchain change | launch `debian-trixie-pi-agent` (cloud-capable — plain trixie is a dead end, §2) → push vendored `assets/bake.sh` → visible `sed` pin override → bake (six traps asserted inside) → **STOP** → publish → delete. distrobuilder stays J17 (unmeasured — never the routine path) |
| **ALIASES** | promotion | ADD → FLIP → SOAK → DROP. **`:stable` flip is operator-gated** (`--operator-go`); `:stable-prev` is the rollback target, **never dropped early**; DROP needs ≥24h soak + operator go |
| **VALIDATE** | after any publish | one throwaway instance → cloud-init done → **identity NOW** via `su - debian -c 'curl -fsSL https://vclawhub.com/join.ts \| bun -'` → asserts (claim reached · fabric INFO banner · version == ver · credential mode 600 · restart-survival) → cleanup |

## Invariants (each is a REJECT; each is mechanically enforced)

| invariant | enforcement |
|---|---|
| **Bun/TS only, no Python** | runner is pure TS (`node:child_process`), zero deps; Python stays inside the image as prime-agent's kernel |
| **Zero identity in the image** | plan check refuses `onboard`/`join.ts` in fast/clean steps (unit-tested); join.ts exists ONLY in validate |
| **Nothing may prompt** (§2.2.4 — `incus exec` swallows stdin) | every child spawned with `stdio:["ignore","pipe","pipe"]`; plan check refuses `incus exec -t`, `--interactive`, un-`-y`'d apt |
| **Publish from STOPPED** (§1.5) | plan check requires a `stop` step strictly before `publish` (order-tested both directions) |
| **Product = prime-agent** (`@vclawhub/agent`, bin `vclaw-agent`) | plan check refuses `@vchatemail` and pi-binary pushes |
| **Credentials: auth.json 0600, never argv** (O37/O44) | plan check refuses `--nkey/--seed/--token` argv; validate asserts `stat %a` == 600 |
| **Every assertion must be able to FAIL** | the assert registry REQUIRES a bad fixture per assert; the unit test iterates ALL asserts and proves good→green, EVERY bad→RED (the inert-gate kill switch) |
| **`:stable` operator-gated; `:stable-prev` kept** | alias state machine refuses un-gated FLIP/DROP, DROP of stable/stable-prev, DROP inside the soak window |
| **Evidence = real runs only** | `writeEvidence` THROWS for dry runs and for RED runs; every figure carries its vantage |

## The six P1 traps → asserts (D-incus-P1-bake.md §7)

| trap | where it bites the skill |
|---|---|
| T1 no AVX2 (G4900 → SIGILL rc=132) | bun pinned to the **x64 baseline** build; `exactVersion` assert FAILS ON EMPTY OUTPUT — never pass-by-silence (unit-pinned) |
| T2 `UV_INSTALL_DIR=/usr/local/bin` (not `/usr/local`) | vendored bake.sh; `uv --version` substring assert |
| T3 urllib 403 / curl 200 | every download is `curl -fsSL --retry 6 --retry-all-errors` |
| T4 bun `-g` symlink destroys the bundle | install script: rm symlink → write wrapper → `test -f` bundle (verbatim from bake.sh §4) |
| T5 base image ships NATS artifacts | NATS_URL scan assert (`scanEmpty`) in both fast and clean |
| T6 dangling cloud-init symlink | `cloud-init clean --logs` (never hand-rm); `cloudInitDone` assert rejects `degraded` (fixture is the observed failure text) |

## Measured on THIS fleet (never a vendor figure)

```
bakeWallClock:  67 s (apt → gates)          [ct17, in-container, 2026-09-16]
publish:        1 m 50 s → 684 MiB          [ct17, Incus 7.0.1 — §1.5 [O]]
publishedImage: 797.13 MiB packed / 2237 MB rootfs  [ct17, fp e7ccedc63ada…, 2026-09-16]
```

Real-run evidence lands in `skills/incus-repackager/runs/<ts>-<plan>.md` (vantage,
wall-clock, size, fingerprint, residual-identity marker). **The timed run for J15's
acceptance has NOT happened yet** — first action when the operator grants the vantage:

1. `md5 /tmp/vcx-p1/bake.sh` on ct17 — the P1 report's prose cites `ddd52cd6…` but the
   local archive (and the report's own §5 embed, identical) hash `b26d423d…`
   (vendored here, byte-identical). Reconcile before trusting either as "the" script.
2. `bun skills/incus-repackager/src/index.ts clean --ver 0.9.4 --execute`
3. `… validate --alias vclaw-agent:trixie-prime-0.9.4 --ver 0.9.4 --execute`
4. Record duration+size from `runs/` — those become this file's measured block.

## Open items wired into the runner (deliberately, visibly)

- **J16 retire hook (VALIDATE)**: the cleanup step attempts
  `vclaw-agent retire --yes --reason "ci validation <ts>" --json`; while J16a's
  headless path (J16c NKey-proof) is not green it is a **STUB that marks the run
  RESIDUAL-IDENTITY in the evidence file** — never silent, never skippable-looking.
- **Image expiry**: the published image inherits the base's past `Expires`
  (P1 §9.4) — `image-info` captures it into evidence; setting a new expiry is an
  operator decision at publish time (documented, not auto-mutated).
- **`/usr/local/install/cache` 249 MiB** prunable (P1 §2) — left in place: the image
  stays byte-parity with the tested artifact until an operator asks for the diet.
- **su-vs-root note**: §8.3's FAST sketch shows `su - debian -c` for the install;
  this runner installs as root (incus exec default) to match bake.sh's proven
  /usr/local flow — `su - debian` is used where the spec means it: the identity
  pipe in VALIDATE. Flagged for the lead; bake-parity won.

## Layout

```
skills/incus-repackager/
  SKILL.md            this file (the interface)
  tsconfig.json       own tsc gate (root tsconfig has rootDir:src — skills live outside it)
  assets/bake.sh      vendored canonical P1 bake (md5 b26d423d… — see reconciliation above)
  src/pins.ts         pins + alias names + both bake md5s
  src/asserts.ts      assert registry (failable by construction)
  src/steps.ts        step model + plan invariant checker (the REJECT enforcement)
  src/plan.ts         fast/clean/validate plans as data
  src/alias.ts        ADD→FLIP→SOAK→DROP state machine
  src/exec.ts         the ONLY spawner; dry-run default; abort-on-RED; stdin ignored
  src/evidence.ts     runs/*.md — refuses fabrication
  runs/               real-run evidence (empty until the operator-gated timed run)
```

Tests: `agent-sdk/test/unit/repackager-{plan,asserts,alias,exec}.test.ts` (35 tests).
Gates: `bunx tsc -p skills/incus-repackager` · scoped vitest · SDK-wide `tsc --noEmit` unaffected.
