#!/bin/bash
# ============================================================================
# vcx-p1 bake script v4 — builds the Incus image vclaw-agent/trixie-prime
# Runs INSIDE throwaway container vcx-p1-1 (Debian 13 trixie, cloud variant).
# Contract mirrors agent-sdk landing/src/lib/join-script.ts installPrimeAgent().
#
# Findings that shape this script (all OBSERVED on ct17):
#   * ct17 CPU = Intel Celeron G4900, NO AVX2 -> bun MUST be the x64 **baseline**
#     build; the plain bun-linux-x64 binary dies with SIGILL (rc=132).
#   * UV_INSTALL_DIR=/usr/local lands the binary at /usr/local/uv (not bin/);
#     UV_INSTALL_DIR=/usr/local/bin is required.
#   * python urllib gets HTTP 403 from the CDN; curl does not. Downloads use curl.
#   * `bun install -g` creates /usr/local/bin/prime-agent as a SYMLINK into the
#     package. Writing the wrapper through that path DESTROYS dist/bundle/cli.js.
#     The symlink must be removed before the wrapper is written.
#   * The BASE IMAGE itself ships the July prototype's NATS artifacts
#     (/etc/profile.d/pi-agent.sh + /etc/systemd/system/pi-auto.service, enabled,
#     with Environment=NATS_URL=...). They are purged here — the spec requires
#     NO NATS_URL anywhere.
#   * No extension, no ~/.vclaw, no config.json are created or left behind.
# ============================================================================
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
export TMPDIR=/tmp/vcx-p1                 # short TMPDIR
export LC_ALL=C

VCLAW_BASE="https://vclawhub.com/prime-agent"
BUN_VER="1.3.14"                          # pinned 1.3.x (baseline build)
UV_VER="0.12.14"                          # pinned
WANT_PRIME_VER="0.9.4"                    # expected from latest.json
WORK=/tmp/vcx-p1
CURL="curl -fsSL --retry 6 --retry-delay 3 --retry-all-errors --connect-timeout 20"
mkdir -p "$WORK"; cd "$WORK"

echo "################ 1. apt: unzip curl ca-certificates ################"
apt-get update -qq
apt-get install -y --no-install-recommends unzip curl ca-certificates
echo "apt OK"

echo "################ 2. bun ${BUN_VER} baseline (pinned) -> /usr/local/bin/bun ################"
$CURL --max-time 900 -o "$WORK/bun.zip" \
  "https://github.com/oven-sh/bun/releases/download/bun-v${BUN_VER}/bun-linux-x64-baseline.zip"
rm -rf "$WORK/bunx"; mkdir -p "$WORK/bunx"
unzip -q -o "$WORK/bun.zip" -d "$WORK/bunx"
install -m 0755 "$WORK/bunx/bun-linux-x64-baseline/bun" /usr/local/bin/bun
BUN_V="$(/usr/local/bin/bun --version)"
test "$BUN_V" = "$BUN_VER" || { echo "FATAL: bun version '$BUN_V' != '$BUN_VER'"; exit 1; }
echo "bun: $BUN_V  (x64 baseline)"

echo "################ 3. uv ${UV_VER} (standalone installer) -> /usr/local/bin/uv ################"
$CURL --max-time 300 -o "$WORK/uv-install.sh" "https://astral.sh/uv/${UV_VER}/install.sh"
env UV_INSTALL_DIR=/usr/local/bin UV_NO_MODIFY_PATH=1 sh "$WORK/uv-install.sh"
UV_V="$(/usr/local/bin/uv --version)"
case "$UV_V" in *"$UV_VER"*) echo "uv: $UV_V";; *) echo "FATAL: uv version '$UV_V' != '$UV_VER'"; exit 1;; esac

echo "################ 4. prime-agent v${WANT_PRIME_VER} (manifest + sha256 verify) ################"
$CURL --max-time 120 -o "$WORK/latest.json" "$VCLAW_BASE/latest.json"
cat "$WORK/latest.json"

python3 - "$WORK/latest.json" "$WANT_PRIME_VER" "$WORK" <<'PYEOF'
import json, sys
mp, want, work = sys.argv[1:4]
m = json.load(open(mp))
ver = str(m.get("version", "")).lstrip("v")
if ver != want:
    sys.exit("FATAL: manifest version %r != expected %r" % (ver, want))
tb = [t for t in (m.get("tarballs") or []) if t.get("file") and t.get("sha256")]
if not tb:
    sys.exit("FATAL: manifest lists no tarballs")
pub = next((t for t in tb if t.get("package") == "prime-agent"), tb[0])
with open(work + "/tarballs.txt", "w") as f:
    for t in tb:
        f.write("%s %s\n" % (t["file"], t["sha256"].lower()))
open(work + "/ver.txt", "w").write(ver)
open(work + "/public.txt", "w").write(pub["file"])
print("manifest version=v%s artifacts=%d public=%s" % (ver, len(tb), pub["file"]))
PYEOF
VER="$(cat "$WORK/ver.txt")"

while read -r file sha; do
  $CURL --max-time 900 -o "$WORK/$file" "$VCLAW_BASE/releases/v$VER/$file"
  got="$(sha256sum "$WORK/$file" | awk '{print $1}')"
  test "${#sha}" = 64 || { echo "FATAL: bad sha length in manifest for $file"; exit 1; }
  case "$sha" in *[!0-9a-f]*) echo "FATAL: non-hex sha in manifest for $file"; exit 1;; esac
  test "$got" = "$sha" || { echo "FATAL: sha256 mismatch for $file (want ${sha:0:12} got ${got:0:12})"; exit 1; }
  echo "  VERIFIED $(printf '%-28s' "$file") $(stat -c%s "$WORK/$file") B  sha256=$got"
done < "$WORK/tarballs.txt"

PUBLIC_TGZ="$WORK/$(cat "$WORK/public.txt")"
echo "public tarball: $PUBLIC_TGZ"

echo "---- bun install -g (BUN_INSTALL=/usr/local) ----"
rm -rf /usr/local/install /usr/local/bin/prime-agent      # clean slate: no stale symlink
rm -rf "$WORK/staging"; mkdir -p "$WORK/staging"
export BUN_INSTALL=/usr/local
( cd "$WORK/staging" && /usr/local/bin/bun install -g "$PUBLIC_TGZ" )

PKG=/usr/local/install/global/node_modules/prime-agent
BUNDLE="$PKG/dist/bundle/cli.js"
test -f "$BUNDLE" || { echo "FATAL: bundle $BUNDLE missing"; exit 1; }
echo "bundle: $BUNDLE"
echo "bun-made bin entry:"; ls -la /usr/local/bin/prime-agent || true

# CRITICAL: remove the bun-created SYMLINK before writing the wrapper, or the
# write follows the symlink and overwrites dist/bundle/cli.js itself.
rm -f /usr/local/bin/prime-agent
cat > /usr/local/bin/prime-agent <<'WRAP'
#!/bin/sh
exec "/usr/local/bin/bun" "/usr/local/install/global/node_modules/prime-agent/dist/bundle/cli.js" "$@"
WRAP
chmod 0755 /usr/local/bin/prime-agent
test -f "$BUNDLE" || { echo "FATAL: wrapper write corrupted the bundle"; exit 1; }

echo "################ 4b. purge the BASE IMAGE's July-prototype NATS artifacts ################"
systemctl disable pi-auto.service 2>&1 || true
systemctl stop pi-auto.service 2>&1 || true
rm -f /etc/systemd/system/pi-auto.service /etc/profile.d/pi-agent.sh
rm -rf /var/lib/pi-agent
systemctl daemon-reload
echo "purged: pi-auto.service, /etc/profile.d/pi-agent.sh, /var/lib/pi-agent"

echo "################ 4c. purge the BASE IMAGE's cached cloud-init instance data ################"
# The July golden image (instance-id 'pi-golden-v2') baked cloud-init's OWN cached
# user-data, which still carries NATS_URL. A published image must not ship it.
ls -la /var/lib/cloud/instances/ 2>/dev/null || true
grep -rIl -i 'NATS_URL' /var/lib/cloud 2>/dev/null || true
# `cloud-init clean --logs` is the correct golden-image reset: it removes
# instances/ AND the /var/lib/cloud/instance SYMLINK. A manual `rm -rf instances`
# leaves that symlink DANGLING, and the next boot fails with
# FileExistsError: [Errno 17] File exists: '/var/lib/cloud/instance'
# -> cloud-init reports `extended_status: degraded done`. OBSERVED, then fixed here.
cloud-init clean --logs
ls -la /var/lib/cloud/
echo "purged: cloud-init instance state + logs (first boot re-seeds from Incus)"

echo "################ 5. cleanup ################"
rm -rf "$WORK/staging" "$WORK/bunx" "$WORK/bun.zip"
rm -f /root/.bash_history
echo "-- NATS_URL scan (must be empty) --"
grep -rIl -i 'NATS_URL' /etc /usr/local /root /home /opt /var 2>/dev/null || echo "  (none)"
echo "-- 'nats' scan in /etc (must be empty) --"
grep -rIl -i 'nats' /etc 2>/dev/null || echo "  (none)"
echo "-- ~/.vclaw / config.json / extensions --"
ls -d /root/.vclaw /home/*/.vclaw 2>/dev/null || echo "  no ~/.vclaw"
find /root /home -name 'config.json' 2>/dev/null | grep . || echo "  no config.json"
ls -d /root/.pi/agent/extensions /home/*/.pi/agent/extensions 2>/dev/null || echo "  no extensions dir"

echo "################ 6. GATE ################"
set -x
/usr/local/bin/prime-agent --version
/usr/local/bin/uv --version
/usr/local/bin/bun --version
python3 --version
env | grep -i nats || echo "NO_NATS_IN_ENV"
bash -lc 'env | grep -i nats || echo "NO_NATS_IN_LOGIN_ENV"'
systemctl is-enabled pi-auto.service 2>&1 || echo "pi-auto.service ABSENT"
ls /etc/profile.d/pi-agent.sh 2>&1 || echo "profile.d/pi-agent.sh ABSENT"
set +x
echo "GATE-DONE"
