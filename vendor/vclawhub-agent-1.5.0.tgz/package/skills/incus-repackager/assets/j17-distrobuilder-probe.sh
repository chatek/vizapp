#!/bin/bash
# ============================================================================
# j17-distrobuilder-probe.sh — J17 CLEAN-path candidate B: timed trixie build
#                              on THIS fleet (ct17 vantage), from a throwaway
#                              privileged builder container.
# Eval doc: agent-sdk/docs/J17_DISTROBUILDER_EVAL.md (D1-D6 findings govern).
#
# Modes (dry-run is the DEFAULT — nothing executes without --execute-timed-build):
#   --plan                  read-only preflights + print the exact sequence (safe anywhere)
#   --execute-timed-build   THE J17 RUN — operator-gated; ct17 vantage only
#   --skip-old-base-control optional: skip stage 9 (P1 report already holds that
#                           evidence; the skip is recorded in the result JSON)
#
# Contract:
#   * every number in the result JSON is measured HERE or absent — never a vendor
#     figure (RUNTIME_incus.md §8.2 vantage rule).
#   * every gate can fail; both negative controls are RUN, not described — a run
#     that cannot go red is inert-profile, and this probe refuses to look green.
#   * no identity anywhere: no join.ts, no onboard (§3.1 invariant) — J17 builds
#     a BASE, not an agent.
#   * no vclaw-agent:* alias is ever written; promotion stays the operator's.
#   * NATS_URL scans print FILENAMES ONLY (grep -rIl) — the value never enters a log.
#   * bake.sh is pushed UNMODIFIED (J17 is surgical; see D1/D2 in the EVAL doc).
#   * cleanup deletes everything this probe created; fingerprints recorded first.
#   * the operator prompt runs on the HOST shell (deliberate — the "nothing may
#     prompt" rule governs `incus exec` paths, where stdin is swallowed).
# ============================================================================
set -uo pipefail
LC_ALL=C
TS="$(date +%Y%m%d-%H%M%S)"
WORK="/tmp/vcx-j17"; RESULT="${WORK}/result-${TS}.json"; TIMERS="${WORK}/timings-${TS}.txt"
BUILDLOG="${WORK}/build-${TS}.log"; BAKELOG="${WORK}/bake-out-${TS}.log"
BUILDER="vcx-j17-builder"; BASEC="vcx-j17-base"; BAKEC="vcx-j17-bake"
IMGALIAS="vcx-j17-distrobuilder-${TS}"; CHAINALIAS="vcx-j17-image-${TS}"; TRUNCALIAS="vcx-j17-trunc-${TS}"
PROFILE="vclaw-agent"
BUILDER_IMAGE="images:debian/trixie/cloud"
DEBIAN_URL="http://deb.debian.org/debian"
OLD_BASE="debian-trixie-pi-agent"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEF_RECORD="${SCRIPT_DIR}/distrobuilder/trixie-cloud.yml"
BAKE_SH="${SCRIPT_DIR}/bake.sh"
MODE="plan"; SKIP_OLD_CONTROL=0
for arg in "$@"; do
  case "$arg" in
    --plan) MODE="plan";;
    --execute-timed-build) MODE="execute";;
    --skip-old-base-control) SKIP_OLD_CONTROL=1;;
    *) echo "unknown arg: $arg"; echo "usage: $0 --plan | --execute-timed-build [--skip-old-base-control]"; exit 2;;
  esac
done
mkdir -p "$WORK"; : > "$TIMERS"

say(){ printf '%s\n' "$*"; }
die(){ say "J17-RED: $*" >&2; EXITNOTE="$*"; exit 1; }
now(){ date +%s.%N; }
elapsed(){ awk -v a="$1" -v b="$2" 'BEGIN{printf "%.2f", b-a}'; }
timer(){ local t; t="$(now)"; printf 'J17_STAGE %s %s\n' "$1" "$(elapsed "$2" "$t")" | tee -a "$TIMERS"; }
record(){ printf '%s\n' "$*" | tee -a "$TIMERS"; }
gate(){ local n="$1"; shift
  if "$@" >/dev/null 2>&1; then say "  GATE ${n}: PASS"; record "J17_GATE ${n} PASS"; return 0
  else say "  GATE ${n}: FAIL"; record "J17_GATE ${n} FAIL"; die "gate ${n} failed"; fi }
control_flip(){ say "  CONTROL ${1}: FAILED AS DESIGNED"; record "J17_CONTROL ${1} FLIPPED"; }
control_broke(){ say "  CONTROL ${1}: UNEXPECTED PASS (detector inert)"; record "J17_CONTROL ${1} BROKE"; die "control ${1} passed — the detector cannot be trusted; run is RED"; }
waitboot(){ incus exec "$1" -- bash -c 'while ! [ -e /run/systemd/system ]; do sleep 1; done'; }
cexec(){ incus exec "$1" --env DEBIAN_FRONTEND=noninteractive -- "$@"; }

emit_result(){
  local verdict="$1"
  {
    printf '{\n  "probe": "j17-distrobuilder", "verdict": "%s", "mode": "%s", "ts": "%s",\n' "$verdict" "$MODE" "$TS"
    printf '  "note": "%s",\n' "$(printf '%s' "${EXITNOTE:-}" | tr -d '"')"
    printf '  "timings": {\n'
    grep "^J17_STAGE" "$TIMERS" | awk 'NR>1{printf ",\n"} {printf "    \"%s %s\": %s", $3, $4, $5}'
    printf '\n  },\n  "gates_and_controls": [\n'
    grep -E "^J17_(GATE|CONTROL|NOTE|TOOL)" "$TIMERS" | sed 's/^/    "/; s/$/"/' | paste -sd, -
    printf '\n  ]\n}\n'
  } > "$RESULT" 2>/dev/null
  say "result json: $RESULT"
}
FP=""; EXITNOTE=""
cleanup(){
  incus delete -f "$BUILDER" >/dev/null 2>&1; incus delete -f "$BASEC" >/dev/null 2>&1; incus delete -f "$BAKEC" >/dev/null 2>&1
  local a
  for a in "$TRUNCALIAS" "$IMGALIAS" "$CHAINALIAS"; do incus image delete "$a" >/dev/null 2>&1; done
  [ -n "$FP" ] && say "deleted test artefacts; base-image fingerprint had been ${FP} (recorded above in the log)"
  return 0
}
trap 'rc=$?; cleanup; emit_result "$([ "$rc" = 0 ] && echo GREEN || echo RED)"; exit "$rc"' EXIT

# ── stage 1: preflight (read-only; both modes) ──────────────────────────────
say "== J17 distrobuilder probe — mode: ${MODE} — $(date -u +%FT%TZ) =="
P0="$(now)"
command -v incus >/dev/null 2>&1 || { say "J17-RED: incus not on PATH (no ct17 vantage)"; EXITNOTE="incus absent"; exit 1; }
say "incus: $(incus --version 2>/dev/null | head -1)"
if command -v distrobuilder >/dev/null 2>&1; then
  say "distrobuilder ALREADY PRESENT: $(distrobuilder --version 2>&1 | head -1) — refutes the §8.1 absence premise; RECORD this"
  record "J17_NOTE distrobuilder_preexisting"
else
  say "distrobuilder: absent (read-only check confirms the §8.1 premise — nothing installed)"
fi
say "pool: $(incus storage info sda-data 2>/dev/null | tr '\n' ' ')"
curl -fsSI --connect-timeout 10 -o /dev/null "$DEBIAN_URL" && say "mirror ${DEBIAN_URL}: reachable" || { EXITNOTE="mirror unreachable"; say "J17-RED: mirror unreachable"; exit 1; }
curl -fsSI --connect-timeout 10 -o /dev/null https://github.com && say "github: reachable" || { EXITNOTE="github unreachable"; say "J17-RED: github unreachable (release fetch would fail)"; exit 1; }
[ -f "$DEF_RECORD" ] || { EXITNOTE="definition record missing"; die "missing $DEF_RECORD"; }
[ -f "$BAKE_SH" ] || { EXITNOTE="bake.sh missing"; die "missing $BAKE_SH"; }
timer preflight "$P0"

if [ "$MODE" = "plan" ]; then
  say "-- plan of the operator-gated run (--execute-timed-build) --"
  say " 2. incus launch ${BUILDER_IMAGE} ${BUILDER} --config security.privileged=true -c limits.memory=4GiB"
  say " 3. builder: apt debootstrap squashfs-tools curl xz-utils; fetch distrobuilder latest release (version+sha256 RECORDED; pin is v2)"
  say " 4. builder: fetch upstream debian.yaml@<tag> (D4 anchor); compose overrides per assets/distrobuilder/trixie-cloud.yml; sha256 logged; TIMED build-incus --type container -> T_base (total; sub-stage split read from ${BUILDLOG})"
  say " 5. host: incus image import out/{incus.tar.xz,rootfs.squashfs} --alias ${IMGALIAS}"
  say " 6. gates: launch ${BASEC} --profile ${PROFILE}: cloud-init clean | su - debian | python3 (D1: visible apt if absent) | DHCP+route | getent vchat3 | TCP vchat3:4223 | NATS_URL grep EMPTY (filenames only) | /usr/bin/pi ABSENT | is-system-running recorded"
  say " 7. chain: push bake.sh UNMODIFIED -> run (GATE-DONE, FATAL-free) -> STOP -> incus publish --alias ${CHAINALIAS} (T_downstream measured)"
  say " 8. controls: (a) package mutation MUST FAIL the build; (b) truncated rootfs MUST FAIL import"
  say " 9. detector control: NATS_URL grep on a launch of ${OLD_BASE} MUST find July artifacts$([ "$SKIP_OLD_CONTROL" = 1 ] && echo '  [SKIP requested — P1 evidence cited instead]')"
  say " 10. cleanup: delete builder/containers + ${TRUNCALIAS}/${IMGALIAS}/${CHAINALIAS} (fingerprints logged first); NO vclaw-agent:* alias touched"
  say "-- nothing executed. T_base comes from THIS fleet or it does not exist. --"
  exit 0
fi

# ── operator gate (execute mode) ────────────────────────────────────────────
say "EXECUTE MODE — timed build on THIS host (ct17 vantage assumed)."
say "Creates throwaways ${BUILDER}/${BASEC}/${BAKEC} + images ${TRUNCALIAS}/${IMGALIAS}/${CHAINALIAS}; touches no vclaw-agent:* alias."
if ! read -r -p "operator: proceed? [yes/no] " GO || [ "$GO" != "yes" ]; then
  say "aborted by operator (anything but literal 'yes' aborts — fail-closed)"
  EXITNOTE="operator declined"; exit 3
fi

# ── stage 2: builder ────────────────────────────────────────────────────────
S="$(now)"
incus launch "$BUILDER_IMAGE" "$BUILDER" --config security.privileged=true -c limits.memory=4GiB || die "builder launch failed"
waitboot "$BUILDER"
timer builder_up "$S"

# ── stage 3: tools ──────────────────────────────────────────────────────────
S="$(now)"
cexec "$BUILDER" bash -c 'apt-get update -qq && apt-get install -y --no-install-recommends debootstrap squashfs-tools curl xz-utils ca-certificates' || die "builder tool apt failed"
cexec "$BUILDER" bash -c '
  set -e
  API=$(curl -fsSL https://api.github.com/repos/lxc/distrobuilder/releases/latest)
  TAG=$(printf "%s" "$API" | grep -o "\"tag_name\": *\"[^\"]*\"" | head -1 | cut -d\" -f4)
  FILE="distrobuilder-${TAG#v}.linux.amd64.tar.xz"
  URL=$(printf "%s" "$API" | grep -o "\"browser_download_url\": *\"[^\"]*${FILE}\"" | head -1 | cut -d\" -f4)
  [ -n "$URL" ] || exit 9
  curl -fsSL -o /tmp/db.tar.xz "$URL"
  echo "J17_TOOL distrobuilder version=${TAG} sha256=$(sha256sum /tmp/db.tar.xz | cut -d" " -f1) url=${URL}"
  tar -xJf /tmp/db.tar.xz -C /usr/local/bin distrobuilder && chmod 0755 /usr/local/bin/distrobuilder
  /usr/local/bin/distrobuilder --version
' | tee -a "$TIMERS" || die "distrobuilder install failed"
grep -q "J17_TOOL distrobuilder" "$TIMERS" || die "distrobuilder version/sha256 not recorded — refusing to build unpinned-and-unrecorded"
DBTAG="$(grep -o "J17_TOOL distrobuilder version=[^ ]*" "$TIMERS" | head -1 | cut -d= -f2)"
timer tool_install "$S"

# ── stage 4: THE TIMED BUILD (T_base) ───────────────────────────────────────
S="$(now)"
# D4: upstream-definition anchor. TAG resolved ON THE HOST and injected literally
# (the builder cannot see the host's $TIMERS path).
cexec "$BUILDER" bash -c "
  set -e
  for BR in \"${DBTAG:-main}\" main; do
    curl -fsSL -o /root/debian-upstream.yaml \"https://raw.githubusercontent.com/lxc/distrobuilder/\${BR}/distrobuilder/debian.yaml\" && break
  done
  test -s /root/debian-upstream.yaml || exit 9
  sha256sum /root/debian-upstream.yaml
" | tee -a "$TIMERS" || die "upstream definition fetch failed (D4 anchor)"
say "-- T_base build begins (log: ${BUILDLOG}) — override mechanics are a verify-at-run fact (D4); any -o rejection here is itself the finding --"
if ! cexec "$BUILDER" bash -c "
  set -e
  mkdir -p /root/out
  distrobuilder build-incus /root/debian-upstream.yaml /root/out \
    -o image.release=trixie -o image.variant=cloud \
    -o image.description='Debian trixie (cloud) - VClaw J17 probe' \
    --type container
" > "$BUILDLOG" 2>&1; then
  record "J17_NOTE build_failed_see_log"
  die "distrobuilder build failed — full log ${BUILDLOG} (this is a legitimate RED: the probe reports facts, not hopes)"
fi
cexec "$BUILDER" sha256sum /root/debian-upstream.yaml | tee -a "$TIMERS"
timer base_build_total "$S"
S="$(now)"
incus file pull -r "${BUILDER}/root/out" "${WORK}/" || die "artefact pull failed"
say "artefacts: $(ls "${WORK}/out/" 2>/dev/null | tr '\n' ' ')"
timer artefact_pull "$S"

# ── stage 5: import ─────────────────────────────────────────────────────────
S="$(now)"
incus image import "${WORK}/out/incus.tar.xz" "${WORK}/out/rootfs.squashfs" --alias "$IMGALIAS" || die "import failed"
FP="$(incus image info "$IMGALIAS" 2>/dev/null | awk '/^Fingerprint/{print $2}')"
say "imported: ${IMGALIAS} fingerprint ${FP:-?} packed $(incus image info "$IMGALIAS" 2>/dev/null | awk '/^Size/{print $2}')"
record "J17_NOTE base_packed_size=$(incus image info "$IMGALIAS" 2>/dev/null | awk '/^Size/{print $2}')"
timer import "$S"

# ── stage 6: base gates ─────────────────────────────────────────────────────
S="$(now)"
incus launch "$IMGALIAS" "$BASEC" --profile "$PROFILE" || die "base container launch failed"
waitboot "$BASEC"; sleep 5
gate cloud_init_clean   cexec "$BASEC" cloud-init status --wait
gate debian_user        cexec "$BASEC" su - debian -c id -un
if ! cexec "$BASEC" bash -c 'command -v python3' >/dev/null 2>&1; then
  say "  D1: python3 absent from the pristine base — VISIBLE apt install (bake.sh untouched)"
  record "J17_NOTE python3_provisioned=apt"
  cexec "$BASEC" bash -c 'apt-get update -qq && apt-get install -y --no-install-recommends python3' || die "python3 provisioning failed"
fi
gate python3_present    cexec "$BASEC" python3 --version
gate dhcp_route         cexec "$BASEC" bash -c 'ip -4 route show default | grep -q default'
gate tailnet_dns        cexec "$BASEC" getent hosts vchat3
gate tailnet_tcp_4223   cexec "$BASEC" bash -c 'printf > /dev/tcp/vchat3/4223'   # /dev/tcp is a bash-ism — dash would silently not fail-open here, it would error: bash is deliberate
gate nats_url_absent    cexec "$BASEC" bash -c '! grep -rIl -i NATS_URL /etc /usr/local /root /home /opt /var 2>/dev/null | grep -q .'
gate pi_binary_absent   cexec "$BASEC" bash -c '! test -e /usr/bin/pi'
ISRUN="$(cexec "$BASEC" systemctl is-system-running 2>/dev/null || true)"
say "  is-system-running: ${ISRUN:-unknown} (recorded, judged by the operator — a minimal base may say degraded with zero unit failures)"
record "J17_NOTE is_system_running=${ISRUN:-unknown}"
timer base_gates "$S"

# ── stage 7: bake + full downstream chain (T_downstream) ────────────────────
S="$(now)"
incus file push "$BAKE_SH" "${BASEC}/root/bake.sh" || die "bake.sh push failed"
cexec "$BASEC" chmod 0755 /root/bake.sh
cexec "$BASEC" /root/bake.sh > "$BAKELOG" 2>&1 || die "bake.sh failed — log ${BAKELOG}"
grep -q "GATE-DONE" "$BAKELOG" || die "bake.sh did not reach GATE-DONE"
if grep -q "FATAL" "$BAKELOG"; then die "bake.sh log contains FATAL — see ${BAKELOG}"; fi
incus stop -f "$BASEC" || die "stop failed (publish requires STOPPED — §1.5)"
incus publish "$BASEC" --alias "$CHAINALIAS" --description "J17 chain: distrobuilder base + unmodified bake.sh" >/dev/null || die "publish failed"
say "chain image: ${CHAINALIAS} fingerprint $(incus image info "$CHAINALIAS" 2>/dev/null | awk '/^Fingerprint/{print $2}') packed $(incus image info "$CHAINALIAS" 2>/dev/null | awk '/^Size/{print $2}')"
record "J17_NOTE chain_packed_size=$(incus image info "$CHAINALIAS" 2>/dev/null | awk '/^Size/{print $2}')"
timer downstream_chain "$S"

# ── stage 8: negative controls — MUST FAIL AS DESIGNED ──────────────────────
S="$(now)"
if cexec "$BUILDER" bash -c '
  set -e
  if grep -q "python3" /root/debian-upstream.yaml; then
    sed "s/python3/python3-nonexistent-xyz/g" /root/debian-upstream.yaml > /root/debian-mutated.yaml
  else
    # no python3 entry upstream: append a broken package to the first "- " package line instead
    awk "{print} /^- /&&!done{sub(/^- /,\"- python3-nonexistent-xyz\\n- \"); done=1; print; next}{print}" /root/debian-upstream.yaml > /dev/null 2>&1 || true
    cp /root/debian-upstream.yaml /root/debian-mutated.yaml.tmp
    awk "!done && /packages:/{print; getline; print \"  - python3-nonexistent-xyz\"; done=1; next} {print}" /root/debian-upstream.yaml > /root/debian-mutated.yaml || cp /root/debian-upstream.yaml /root/debian-mutated.yaml
  fi
  diff -q /root/debian-upstream.yaml /root/debian-mutated.yaml >/dev/null && exit 9   # a no-op mutation would be an inert control
  rm -rf /root/out-mutated
  ! distrobuilder build-incus /root/debian-mutated.yaml /root/out-mutated -o image.release=trixie -o image.variant=cloud --type container
'; then
  control_flip package_mutation
else
  control_broke package_mutation
fi
head -c 4096 "${WORK}/out/rootfs.squashfs" > "${WORK}/rootfs-trunc.squashfs"
if incus image import "${WORK}/out/incus.tar.xz" "${WORK}/rootfs-trunc.squashfs" --alias "$TRUNCALIAS" >/dev/null 2>&1; then
  control_broke truncated_import
else
  control_flip truncated_import
fi
timer controls "$S"

# ── stage 9: detector control — the old base MUST be dirty ──────────────────
S="$(now)"
if [ "$SKIP_OLD_CONTROL" = 1 ]; then
  say "  detector control SKIPPED by flag — evidence by citation: D-incus-P1-bake.md (bake stages 4b/4c found the artifacts on ${OLD_BASE})"
  record "J17_CONTROL old_base_detector SKIPPED_CITED_P1"
else
  incus launch "$OLD_BASE" "$BAKEC" || die "old-base launch failed (is ${OLD_BASE} present on this host?)"
  waitboot "$BAKEC"; sleep 3
  if cexec "$BAKEC" bash -c 'grep -rIl -i NATS_URL /etc /var/lib/cloud 2>/dev/null | grep -q .'; then
    control_flip old_base_detector
  else
    record "J17_CONTROL old_base_detector FOUND_NOTHING"
    die "detector found NOTHING on ${OLD_BASE} — either the base changed or the detector is broken; run is RED either way"
  fi
fi
timer detector_control "$S"

record "J17_NOTE T_base=${TIMERS#*base_build_total }"
say "J17-GREEN: timed run complete."
say "T_base/T_downstream are the base_build_total / downstream_chain stage values above."
say "Hand RUNTIME_incus.md §6 the decision with these numbers — never a vendor figure."
