# E2E_tests.md — End-to-end test SOP for `agent-sdk` and its release channel

**Owner:** vchat-email-lead (agent-sdk + the `join.ts` release channel)
**Target:** repeatable, evidence-producing E2E tests on disposable containers
**Status:** DRAFT for operator review — §10 lists the decisions this SOP is blocked on
**Last verified against reality:** 2026-09-13

---

## 1. Purpose and scope

The product surface is one command:

```bash
curl -fsSL https://vclawhub.com/join.ts | bun -
```

This SOP tests **that command and everything behind it**, end to end, on a clean host, and
produces evidence a reviewer can re-run. Three things must work:

1. **agent-sdk installation** — the pipe installs the vclaw-agent CLI bundle and writes an identity.
2. **prime-agent installation** — the runtime the daemon will spawn (currently **not implemented**; §4.2).
3. **vclaw IDP onboarding** — `/v1/agent/introduce` → claim session → `vclaw-agent onboard`.

**Out of scope** (separate SOPs): the IDP's own config (`deploy/authelia/*`), the fabric/A2A protocol,
and `vclaw-agent` daemon worker behaviour under load.

---

## 2. The rule that makes this SOP worth having

> **Test the documented command verbatim, from a clean host, as the FIRST test.**

Every serious defect found so far was invisible to the repo's own test suite and visible only from a
clean host running the documented command:

| Defect | Why the test suite missed it |
|---|---|
| `… \| bun` (no dash) is a **no-op** — bun prints help | nothing ran the documented command; unit tests call the emitter directly |
| the install chain was **never committed** — live `join.ts` was the Aug-31 build | tests pass against source, not against what is served |
| **prime-agent has no install path at all** | no test asserted the feature existed |
| pi.dev install **fails on a fresh host** (needs Node ≥22.19, prompts on `/dev/tty`) | tests ran where node already existed |
| the daemon **doesn't re-read** `models.json`/`settings.json` | verified interactively, where a fresh process reads them |

> **This table is history (2026-09-13 and earlier), not current status** — two of its rows have since been
> closed: the `\| bun` no-op is fixed and deployed, and an install path exists in the pipe. Current status
> for each is in §4, which carries the re-check dates. Do not cite this table as a live gap list.

**Consequence:** the acceptance test is *always* the documented command on a clean host, never a
direct invocation of an internal function. A green unit suite is not evidence about the funnel.

---

## 3. Environment

### 3.1 Topology (verified 2026-09-13)

| | |
|---|---|
| **Host** | `kuai` — `tailscale ssh debian@kuai` (Debian 13, x86_64) |
| **Container manager** | **Incus 6.0.4** (`sudo incus …`; `debian` is not in `incus-admin`, passwordless sudo works) |
| **Pool / bridge** | pool `kuai`; bridge `incusbr0` = `10.29.101.1/24` |
| **Image** | `e433df1996ac` — Debian trixie amd64 (20260913_05:24). **Verify before use — see the drift note below.** |
| **Test containers** | `pa-test1`, `pa-test2` (unprivileged, `boot.autostart=true`) |
| **Network** | **DHCP via systemd-networkd — works and survives reboot** (verified) |
| **Egress** | unrestricted: `bun.sh`, `github.com`, `registry.npmjs.org`, `api.deepseek.com` all reachable |

> **Why `kuai` and not `ct17`.** `ct17`'s `debian-trixie` image has **no working network management**
> (`systemd-networkd` exits `243/CREDENTIALS`; no DHCP client, no ifupdown, no cloud-init). Containers
> there boot IPv6-only with **no IPv4 and no default route**, while `network-online.target` still
> reports *"Network is Online"* and services started `After=` it report `active`. The ct17 `pa-test*`
> pair was decommissioned for this reason. **`kuai` has no GFW problem either**, which matters because
> `bun.sh/install` and GitHub releases fail from `ct17`.

> ⚠️ **Image drift is real and it will break a run.** The image fingerprint recorded here (`50661fc47920`,
> 20260912) **no longer exists** — it was replaced by `e433df1996ac` (20260913_05:24) within 24 hours.
> A run that trusts this file blindly fails at `incus launch`. **Always verify the fingerprint is present
> before launching, and record the one you actually used in the run record** — a run whose base image is
> gone is not reproducible, however green its results.

### 3.2 Provisioning a clean container (reference implementation)

```bash
IMG=e433df1996ac               # VERIFY — see the image-drift note below; this reference did not exist 24h ago
sudo incus image list --format csv -c f,l,d   # confirm the fingerprint is present BEFORE launching
sudo incus launch $IMG pa-testN
sudo incus config set pa-testN boot.autostart true
# network is automatic (DHCP) — verify, do not assume:
sudo incus exec pa-testN -- ip -4 -br a show eth0        # expect 10.29.101.x/24
sudo incus exec pa-testN -- ip r | head -1               # expect default via 10.29.101.1 proto dhcp
sudo incus exec pa-testN -- curl -s -o /dev/null -w '%{http_code}\n' https://api.deepseek.com   # 401
```

**bun 1.4.2** — download the release directly; the `bun.sh/install` script hung once during
provisioning:

```bash
curl -fsSL -o /tmp/bun.zip https://github.com/oven-sh/bun/releases/latest/download/bun-linux-x64-baseline.zip
unzip -q /tmp/bun.zip -d /tmp/bunx
BUN=$(find /tmp/bunx -name bun -type f | head -1)
sudo incus file push "$BUN" pa-testN/usr/local/bin/bun --mode 0755
sudo incus exec pa-testN -- ln -sf /usr/local/bin/bun /usr/local/bin/node
```

### 3.3 prime-agent install layout

> **This section was rewritten 2026-09-13.** What it said before — `/opt/prime-agent` with a 16,051,328 B
> `agent.js` at sha `d525eb05…` — described the **stale vendored 0.7.1** artifact. Nothing about that
> layout holds at 0.9.4. Treat the old numbers as historical.

**Two things are settled:**

**1. The install is USER-LEVEL by default.** The rest of the join pipe is user-level
(`~/.vclaw/identity.json`, `~/.vclaw/agent.js`, `~/.local/bin/vclaw-agent`), so the runtime installs into
the same tree:

```
${XDG_DATA_HOME:-$HOME/.local/share}/vclaw/prime-agent/   <- the runtime
$HOME/.local/bin/prime-agent                              <- wrapper (a regular file, not a symlink)
$HOME/.config/vclaw/config.json                           <- runtime, mode 0600
```

`VCLAW_PRIME_AGENT_DIR` / `VCLAW_PRIME_AGENT_BIN_DIR` override it for a system-level install.
**A writability preflight MUST run before the manifest fetch and before the ~24 MB download** — an
elevated target must fail up front, naming the env var, never half-install. Verified non-root end to end
(real unprivileged user, no sudo; `find ~/.local ~/.config -not -user <user>` → empty, i.e. no root-owned
residue; real model call succeeded).

**2. Whatever the shape, the files must sit together.** The entry resolves resources **relative to its own
location**, so:
- a **symlink** in `$HOME/.local/bin` **re-roots the lookup** — always use a wrapper
- **`package.json` must be present beside the entry** — the bundle reads it relative to itself. Omitting
  it produced `ENOENT …/prime-agent/package.json`, a defect a synthetic test payload **could not detect**
  because it contained only `dist/`. **The test payload must carry what the real one does.**
- the entry's shebang is `#!/usr/bin/env node`, so a host with only bun needs a `node` shim

**SETTLED AND SHIPPED — the official contract is the channel.** No longer a candidate list; this is what
runs today. Evidence, not preference: `bun install -g` on the official tarball **runs without node**
(`BUNNODE_OK`), so the official path adds **no** prerequisite — it differs from the bun-only shape only in
**registry access**, and it is feature-complete.

| | shape | prerequisite | notes |
|---|---|---|---|
| **official** — *implemented* | 4 tarballs + `latest.json` (`pack-prime-agent-release.mjs`) → `bun install -g` | **bun only** | feature-complete; needs **registry** access to resolve ~20 npm deps |
| **bun-only** — *documented fallback* | normalised single-file bundle + deterministic payload → unpack beside it | **bun only** | our-CDN-only (no registry), but **photon/image features absent** and clipboard degrades to OSC 52 |

**The fallback is a RECORD, not a second implementation.** It is documented in
`.prime/handoff/e2e-blockers/L1-official-contract.md` §10 and is **deliberately absent from the manifest** —
the manifest is the integrity record of what is actually *served*, and pinning bytes we don't ship would
make it describe an intention and let it drift from reality. If the fallback is ever staged, it earns its
own entry then.

**Implemented at:** landing `b87c9f5` (emitter) + `f8d4990` (bash fallback, agent-sdk), with the publish
pipeline at `4a674da` and the Node descriptor corrected at `1bcdca4`. The channel is live code, not a plan —
but nothing is **published** until the operator's `pnpm deploy`, so the end-to-end run is still gated on that.

#### ⚠️ The base URL is BAKED INTO the artifacts — an override is only half-effective

Verified by comparing producer against consumer, not by reading either alone:

```
installer default PRIME_BASE : https://vclawhub.com/prime-agent
manifest  baseUrl            : https://vclawhub.com/prime-agent
pipeline packs with          : --base-url manifest.baseUrl        ← single source
```

The four tarballs reference **each other** by **absolute** URLs baked at pack time, e.g.
`"@earendil-works/pi-ai": "https://vclawhub.com/prime-agent/releases/v0.9.4/prime-agent-ai-0.9.4.tgz"`,
and the installer **does not rewrite them** — it fetches the tarball and hands it to `bun install -g` as-is.

**Consequence:** setting `VCLAW_PRIME_AGENT_URL` (or the `VCHAT_*` / `PRIME_AGENT_DOWNLOAD_BASE_URL`
aliases) to a **mirror** redirects the manifest and the four tarball fetches, but **not** the internal
dependency resolution — `bun` still resolves `pi-ai` / `pi-agent-core` / `pi-tui` from the **baked**
`vclawhub.com` URL. On an air-gapped or registry-restricted mirror the install therefore fails **inside**
`bun install -g`, after the manifest fetch has already succeeded — a delayed, misleading failure.

**A true mirror requires REPACKING with `--base-url <mirror>`.** The base URL is a pack-time input, not a
runtime knob. Record this before anyone tries to stand up a mirror and concludes the override is broken.

*(Cross-check to keep: the consumer strips a leading `v` from `latest.json`'s version
(`String(manifest.version).replace(/^v/, "")`), so `releases/v` + `0.9.4` matches the producer's
`releases/v0.9.4`. Verified — this is why `latest.json`'s `v0.9.4` does not produce `vv0.9.4`.)*

**Known-graceful degradations in the bun-only shape** (measured, not assumed — record them if that shape is used):
`koffi` is unreachable on Linux/macOS (its only call site returns early unless `win32`, and is `try/catch`ed);
`@mariozechner/clipboard` falls back to `pbcopy`/`clip`/`wl-copy`/`xclip`/`xsel` → **OSC 52**;
`photon` (`loadPhoton()` → `null`, all 4 callers guarded) means **image features are simply absent**.
> ⚠️ **The clipboard caveat matters:** on headless Linux the OSC-52 path **reports success** while doing
> nothing outside a terminal TUI — a silent no-op in a daemon. Never read "copy succeeded" as evidence a
> clipboard exists.

### 3.4 Credentials — hard rules

- **The harness blocks `@.env`; do not attempt to read it.** Source the DeepSeek key from pi's own
  store (`~/.pi/agent/auth.json`, provider `deepseek`) and transform it file-to-file.
- **No secret-derived bytes in any output** — no value, no prefix, no digest, no length. Confirm a
  credential by *presence and mode* only.
- prime-agent reads **`~/.prime/agent/auth.json` (0600)** — **not** `~/.pi/agent/auth.json`. The pi
  path is silently ignored; the only symptom is *"No API key found for the selected model."*
- Remove credential copies from `/tmp` when a run finishes.

### 3.5 Endpoints and their overrides (for stubbing)

| Purpose | Default | Override |
|---|---|---|
| `POST /v1/agent/introduce` | `https://api.vclawhub.com` | `VCLAW_API_URL` |
| claim URL base | `https://login.vclawhub.com` | `VCLAW_CLAIM_BASE_URL` |
| CLI bundle | `https://vclawhub.com/agent.js` | `VCLAW_AGENT_BUNDLE_URL` |
| installer runtime seed | — | `VCLAW_RUNTIME` |
| resolver override | — | `VCLAW_PI_BIN` |
| pi.dev opt-in | off | `--install-pi` / `INSTALL_PI=1` (truthy only) |

### 3.6 prime-agent source of truth — Forgejo on `vmaker-pi`

**The E2E starts from Forgejo, not from the vendored fork.**

| Field | Value |
|---|---|
| Web / API base | `https://vmaker-pi.ruffe-court.ts.net/forgejo` · `/api/v1` |
| Server | Forgejo `16.0.2+gitea-1.22.0` |
| Repo | **`chatek/prime-agent`** (id 197) — `mirror: true`, default branch `main` |
| Auth | `Authorization: token $FORGEJO_TOKEN` |
| Freshness (2026-09-13) | HEAD **`e6b79144c23e`**, **version `0.9.4`** |

**⚠️ It is REST, not MCP** — verified, see §4.9. **Mirrors are read-only** (403 on writes); fine for fetching.

**The fetch requires a BUILD.** There are **0 releases** and **no `.jsr-release/`** in the repo (404 on a direct
path probe, not inferred from a truncated listing). What exists is the build path:

```
package.json  ·  package-lock.json  ·  packages/coding-agent/package.json
packages/coding-agent/scripts/bundle.mjs      # esbuild: dist/cli.js -> dist/bundle/
```

So a run clones (or raw-fetches) the repo and **builds** the bundle. If we want a prebuilt fetch instead,
someone must publish a release with assets — see Q1 in §10.

### 3.7 IDP onboarding target (production, scoped)

Onboarding runs against **production**, onto the **`openkuai` segment only**, which only the admin user
**`chance@vchat.email`** owns. Every live run therefore creates a **real agent identity on the live
fabric** — record the agent id in the run record so it can be traced and cleaned up.

### 3.8 Exit node for external egress (prerequisite, currently FAILING)

The operator's designated exit node is `kuai-exit.finch-iwato.ts.net`. **It does not work today:**

```
$ tailscale set --exit-node=kuai-exit.finch-iwato.ts.net
node "kuai-exit.finch-iwato.ts.net" is not advertising an exit node
```

The node exists (`100.79.114.0`, tagged `tagged-devices`) but **no peer advertises `ExitNodeOption`**.
Consequence: from `kuai` and from its containers, `https://www.google.com` is **HTTP 000** (DNS resolves,
traffic is dropped). **T0 must assert this as a gate**, so the day the exit node is fixed the gate fails
and the tier is extended to cover external egress. Fixing it is operator-side: advertise on the node
(`tailscale set --advertise-exit-node`), approve it in the admin console, then set it on `kuai`.

---

## 4. Current verified truth — assertions, not assumptions

The test suite must **assert these today**, so that a silent change fails a test instead of shipping.
Each entry is a gate of one of two kinds, and the entry says which:

- **GAP gate** — the gap is real today. The gate *passes* while it is known and documented, and fails
  loudly when reality moves. A failing gap gate is a **signal to convert the entry**, not a bug.
- **CLOSED + regression gate** — the gap was fixed and measured. The entry records the measurement, the
  date, and the probe that re-takes it; the gate now **fails on regression**.

**Reality has already moved twice under this table** (B1/B2/B4 closed 2026-09-14; the A2 kernel premise
corrected 2026-09-13), so every entry carries a **re-check date** and the rule is: **re-probe before
citing an entry, and when the probe disagrees with the entry, the probe wins and the entry is converted
in the same session.** A gate asserting a gap that no longer exists is worse than no gate — it turns a
fix into a documented falsehood.

### 4.1 The documented command must carry the dash — **CLOSED 2026-09-14** (regression gate)

**The mechanism (unchanged, and why the dash is mandatory):** bare `bun` reading piped stdin prints its
help and executes nothing; only `bun -` (or `bun run -`) executes the piped source, and curl reports
`(23) Failure writing output to destination` because bun closes stdin unread. This mechanism is the
*reason* the gate exists — it is not itself the gate.

**Closed in production**, measured 2026-09-14T15:15Z by content probe (not by reading the source):

| probe | result |
|---|---|
| served `join.ts`, bare-form occurrences | **0** |
| served `join.ts`, `\| bun -` occurrences | 2 (usage string + error text) |
| served landing page + `/join` (what the copy button takes) | 6× `\| bun -`, 0 bare |
| served `join.sh` (the fallback twin) | 2× `\| bun -`, 0 bare |
| repo `landing/src` + non-historical `agent-sdk` | 0 bare |

**Regression gate (fails on regression):**

- `landing/test/join-command-docs.test.ts` — scans **`landing/src` and `agent-sdk`** for the bare form in
  any non-historical file, with a matcher control and a vacuity guard. Widened 2026-09-14 from
  `landing/src` only, and mutation-proven (a bare form re-introduced in `agent-sdk/README.md` and in
  `agent-sdk/bin/join.sh` fails it; both were outside the original root).
- **E2E tier T1a** probes the *served* artifact — the unit test cannot see the deploy, so a deploy of an
  older build would pass the unit test and fail T1a.

What replaced the old "assert the bare form is a no-op" gate, since a deleted gate is how a class of bug
returns: the no-op *mechanism* stays documented here and is still demonstrated on demand by T1c, while
its *consequence* (the dash must be present in every authored location) is now enforced by the widened
source gate plus T1a. **Re-check:** 2026-09-14 · probe: `curl -fsSL https://vclawhub.com/join.ts` then
count the bare form — must be **0**.

### 4.2 The pipe installs prime-agent; the SDK's own CLI does not — **CLOSED (emitter) / OPEN (CLI)**

**Closed — the emitter/pipe (2026-09-14, content probe).** `--runtime prime-agent` is now an install path
in the *served* emitter: served `join.ts` contains `--runtime`×6, `prime-agent`×19, and the
`PRIME_BASE` / `PRIME_DIR` / `PRIME_PACKAGE` constants; repo `landing/src/lib/join-script.ts` is 35,721 B
with 8× `--runtime`. The old claim — *"the emitter's `--runtime` writes config and stops"* — is **false**
and was retired here. **Regression gate:** T2a now expects `--runtime prime-agent` to leave `prime-agent`
on PATH with a real model call; the pre-2026-09-14 T2a expectation ("installs nothing") asserted the
wrong thing and is retired with it. Nothing else is deleted: the install-path gate is the same gate,
pointed at the fixed state.

**Still open — the SDK's own CLI.** `prime-agent` appears **once** in `agent-sdk/src`, in a comment
(`src/lib/runtime.ts:6`; re-verified 2026-09-14: `grep -rn prime-agent agent-sdk/src | wc -l` → `1`). The
`agent-sdk` CLI has no install command — only the pipe does. **GAP gate (narrowed):** assert the CLI still
has no install command, so that if one appears the E2E is extended deliberately.

### 4.3 prime-agent is unpublished

`@vclawhub/coding-agent` → **404 on npm and jsr**; `@vclawhub/agent` is on jsr (1.2.4).
**Gate:** a registry probe test.

### 4.4 The served artifacts now match the current source — **CLOSED 2026-09-14** (regression gate)

| | served 2026-09-13 (pre-fix) | served 2026-09-14 (measured) | repo |
|---|---|---|---|
| `join.ts` | 12,707 B, `--runtime` **0**, `prime-agent` 0 | **33,716 B, `--runtime` 6, `prime-agent` 19, bare form 0** | 35,721 B (8× `--runtime`) |
| `agent.js` | 904,974 B, `resolveRuntime` **0** | **969,705 B, `resolveRuntime` 5** | present in 3 files |
| `join.sh` | — | 7,695 B, 2× `\| bun -` | — |

**A version comparison cannot detect drift** — `join.ts`, `agent.js` and `jsr.json` all declare the
*same* version (`agent.js` declares `VERSION = "0.1"`; `agent-sdk/jsr.json` 1.2.4 vs `package.json`
1.2.0). **Regression gate: a content probe** — assert served `join.ts` still contains `--runtime` and
`prime-agent`, and served `agent.js` still contains `resolveRuntime`; if any drops to 0 the CDN is
serving a stale build again and the gate fails. **Never** a version compare. **Re-check:** 2026-09-14 ·
probe: `curl -fsSL https://vclawhub.com/join.ts | grep -c -- --runtime` (must be ≥1) and
`curl -fsSL https://vclawhub.com/agent.js | grep -c resolveRuntime` (≥1).

### 4.5 pi.dev installs only interactively

The upstream installer requires Node ≥22.19 + npm and prompts on `/dev/tty` with no non-interactive
flag. No TTY → *"No terminal detected"*, exit 1. TTY with no input → **hangs on `dd`**.

### 4.6 The served model name is NOT what the catalog lists

- **Served:** `deepseek-flash` (= V4.1-Flash) — *the correct default*
- Legacy `deepseek-v4-flash` is **retired**; `deepseek-v4-pro` retires **2026-09-14**
- The bundle's catalog knows it only as `deepseek-v4.1-flash-beta` → **one rename behind**, so it must
  be **injected via `~/.prime/agent/models.json`**

**Rule: never source a model id from a bundle, and never treat `model list` as authority.**
`defined ≠ listed ≠ served`, and only *served* is real.

### 4.7 A running daemon does not re-read config

Config must be written **then the service restarted**. Write-and-continue leaves a stale daemon — this
is exactly how an earlier verification was misleading.

### 4.8 The kernel is `python -m rlm.repl`, not ipykernel — **premise CORRECTED 2026-09-13**, execution PROVEN

**The premise was wrong, and the wrong premise cost a day.** At 0.9.4 `repl-manager.ts:315` launches
**`python -m rlm.repl`** (the `prime-agent-runtime` package), and `core/kernel/bootstrap.ts`
auto-bootstraps its own `uv` venv at `~/.prime/agent/kernel-venv`. So apt `python3` + `ipykernel` is
**neither sufficient nor necessary**; the real prerequisites are **`uv` plus egress to astral.sh/PyPI**
(or `PRIME_AGENT_KERNEL_PYTHON` pointing at a Python that already has `prime-agent-runtime`).
`import ipykernel` inside that venv → `ModuleNotFoundError`, which is how the mechanism was identified.

**Execution is proven** (2026-09-13, external and model-independent): the kernel wrote
`/tmp/l3-kernel-proof.txt` containing `L3_KERNEL_EXECUTED_42` — the `42` computed by the kernel, not
narrated by the model. The old assertion ("prime-agent converses but cannot execute anything") is
**disproved** and retired.

**Regression gate (fails on regression):** T2c must assert an **artifact written by the kernel**, not a
model reply that *says* code ran. An install that produces a talking-but-not-acting agent is still not a
pass — that part of the old entry was right.

**UNVERIFIED, stated plainly:** the `uv` auto-install path (`PRIME_AGENT_INSTALL_UV=1` / astral.sh) was
not exercised (uv was pre-installed via pip); `PRIME_AGENT_KERNEL_PYTHON` was not tested; a registry
install of `prime-agent-runtime` was not tested (the venv used the local source). **Re-check:**
2026-09-13.

### 4.9 Forgejo on `vmaker-pi` offers REST, **not MCP** — verified

The operator's premise was that the Forgejo host "supposedly offers MCP APIs". **It does not.** Eight
path probes on the `vmaker-pi` vhost returned 404 (`/mcp`, `/forgejo/mcp`, `/.well-known/mcp`,
`/api/mcp`, `/forgejo/api/mcp`, `/mcp/sse`, `/sse`, `/api/v1/mcp`); `/gitmcp` and `/` return **502**; no
service answers on 3001/3002/8000/8080/9090. The MCP belief traces to two real but different things:

- **`vmaker-git-mcp/SKILL.md`** — frontmatter reads *"[RETIRED] GitStore MCP server has been removed —
  all Git operations go through the Forgejo REST API… **do not use**."*
- **A live GitStore MCP exists elsewhere**: `https://omaker-git.great-larch.ts.net/gitmcp/sse` → **200**
  (configured in `~/.pi/agent/settings.json`). `omaker-pi.great-larch.ts.net` → 000 (dead).

**Gate:** assert that `vmaker-pi` has no MCP surface, so that if one is ever added the E2E is extended
deliberately rather than silently. **Use the REST API** (the `forgejo-api` skill) — it serves
`chatek/prime-agent` correctly (tree of 23 top-level entries verified).

---

## 5. Test tiers

Each tier is independently runnable and independently falsifiable. **T0 and T1 must pass before
anything else is believed.**

### T0 — Provisioning and network (no product code)

| | |
|---|---|
| **Steps** | launch clean container; verify DHCP address, default route, egress; **probe the designated exit node** |
| **Evidence** | `ip -4 -br a`, `ip r`, `curl -w '%{http_code}' https://api.deepseek.com` (401), and the `tailscale set --exit-node=` result |
| **Pass** | address in `10.29.101.0/24`, `proto dhcp` default route, HTTP 401; **exit node: expected to FAIL today** (`not advertising`), recorded as a gate |
| **Falsifies** | the §3.1 claim that kuai's networking is sound; and §3.8 once the exit node is fixed |

### T1 — The served artifact and the documented command

| | |
|---|---|
| **T1a** | **content probe first** (no execution): fetch the served `join.ts` and assert the bare form count is **0**, `\| bun -` ≥1, and `--runtime` ≥1 — this is the regression gate for §4.1/§4.4, because the unit test cannot see the deploy |
| **T1b** | `curl -fsSL https://vclawhub.com/join.ts \| bun -` — **expect the install to run** |
| **T1c** | *(mechanism control, not a gap gate)* `curl -fsSL https://vclawhub.com/join.ts \| bun` — **expect a no-op** (help text, no files). This documents *why* the dash is mandatory; it is not the gate, and it must keep failing-to-install forever |
| **Evidence** | T1a: byte count + sha256 + the two grep counts. T1b/T1c: full stdout/stderr; before/after inventory of `~/.vclaw`, `~/.local/bin`, `~/.npmrc`, `~/.config/vclaw`, `command -v` for pi/node/vclaw-agent |
| **Pass** | T1a sees 0 bare / ≥1 dash; T1b writes `~/.vclaw/identity.json` (0600) and installs the CLI bundle + shim; T1c changes nothing |
| **Falsifies** | T1a firing means a stale build was deployed (§4.4) — re-deploy, do not soften T1a. T1c firing means bun changed its stdin behaviour, which would make the whole dash convention obsolete |

**Stub the endpoints by default** (`VCLAW_API_URL`/`VCLAW_CLAIM_BASE_URL` → a local listener) so a
mechanical run creates **no real agent identity**. See T3 for the live tier.

### T2 — Runtime installation and resolution

| | |
|---|---|
| **T2a** | `--runtime prime-agent` → **expect a working install**: `prime-agent` ON PATH, config written, **and a real model call succeeds** (regression gate for §4.2, closed 2026-09-14; the pre-fix expectation "installs nothing" is retired) |
| **T2b** | fresh config `runtime` → daemon spawns the **resolved** binary; `VCLAW_PI_BIN` beats config |
| **T2c** | install prime-agent by the §3.3 recipe → **real model call succeeds AND the kernel writes an external artifact** (e.g. a file whose contents only computation could produce) — regression gate for §4.8; a model *saying* it ran code is not evidence |
| **T2d** | assert the **`agent-sdk` CLI still has no install command** (§4.2's open half): `grep -rn prime-agent agent-sdk/src \| wc -l` → `1` |
| **Evidence** | `cat ~/.config/vclaw/config.json`; observed **argv** of the spawned process; the model's reply; the kernel-written file, read back from outside the agent |
| **Pass** | T2a installs and answers; T2c returns a real completion *and* the artifact exists with the expected content; T2d finds no install path in the CLI |
| **Falsifies** | T2a failing means the install path regressed (§4.2). T2d firing means the CLI gained an install path — extend the E2E deliberately. T2c's artifact missing while the model claims success is the "talking but not acting" failure this tier exists to catch |

**`--version` is never evidence.** It prints an inlined constant and touches neither assets nor auth —
both prime-agent failures today were invisible to it.

### T3 — vclaw IDP onboarding (LIVE, gated)

| | |
|---|---|
| **Steps** | run T1b against the **real** endpoints with `--token` / `--name`; complete the claim; run `vclaw-agent onboard` |
| **Evidence** | agent id, claim URL, onboard exit code, and the resulting identity |
| **Pass** | an agent is introduced, identity saved 0600, claim URL resolves, onboard completes |
| **Cost** | creates a **real identity** on production — see §10 Q2 |

### T4 — Boot persistence (the tier that catches "active but dead")

| | |
|---|---|
| **Steps** | `sudo incus restart pa-testN`; then check address, route, unit state, **and a real model call** |
| **Pass** | address/route back; `prime-agent` **enabled and active with a NEW MainPID**; **real call succeeds** |
| **Falsifies** | any runtime-only fix — `ip addr add`, a config write without a restart, a unit missing `Environment=` |

**`systemctl is-active` is not evidence.** The recurring failure mode is a green signal whose provider
is absent from the failing path (`active` while `unreachable`; `network-online.target` active with no
route; telemetry "disabled" by a file systemd never reads).

### T5 — Cleanup and hygiene

| | |
|---|---|
| **Steps** | remove `/tmp` credential copies; record final state; either destroy the container or mark it dirty |
| **Pass** | zero credential copies in `/tmp`; the container's state is explicitly labelled |

---

### T6 — Funnel identity semantics (hermetic dry-run; spec: `docs/JOIN_FUNNEL.md`)

Runs the emitted pipe against a **local mock vgate** (introduce/status/claim
controls + mocked bundle/JSR URLs) under a fake `HOME` and `VCLAW_RUNTIME=none`
— no real identity is created, no production endpoint is touched. Mock and
driver pattern: `.prime/handoff/funnel-core/REPORT.md` §3c.

| | | Status |
|---|---|---|
| **F1** | **Pipe dry-run vs mock.** Fresh `--no-wait` → exit 0; `~/.config/vclaw/credentials.json` 0600 with 58-char S-form seed, U-form public_key, `steward:"unknown"`, no `template`/`jwt`; `~/.vclaw/identity.json` 0600; `.pending` 0600 (U-form); **no seed (S-form or hex) on stdout**; `?proof=` URL printed exactly once. Claim-wait run → poll ticks never reprint the URL; claimed → `.pending` cleared + summary + exit 0. Re-run with claimed creds → exit 0, summary, **no second claim URL**. `--force` → `credentials.json.bak-<ts>` (0600, holds the OLD seed) + fresh key. | **EXECUTED 2026-10-02** (lane docs-e2e; evidence `.prime/handoff/docs-e2e/REPORT.md` §A — same scenarios first executed by funnel-core §3c T1/T2/T3/T8 and re-verified by lead REVIEW-2) |
| **F2** | **One-introduce assertion.** Across the F1 sequence (fresh → claim → re-run → `--force`), the mock's introduce ledger must show **exactly one introduce per keypair**: fresh = 1; claimed re-run = 0 new; `--force` = 1 new (new key). Also `fromSeed(pipe seed).getPublicKey() === recorded public_key` (SDK parity). | **EXECUTED 2026-10-02** (same run; ledger counts in REPORT §A) |
| **F3** | **Host-wiring idempotency.** With fake `pi` (≥ 0.99.0) and `prime-agent` on PATH: confirmed-claim exit writes `~/.pi/agent/mcp.json` and `~/.prime/agent/settings.json` with server `vclaw` (stdio → `<bun> ~/.vclaw/agent.js mcp`; pi entry `exposure:"deferred"`; prime entry absolute paths + `startupTimeoutMs: 10000`); **re-run leaves both files byte-identical** (merge, not rewrite); pre-existing foreign keys survive in both files; an **UNCONFIRMED** claim (fresh `--no-wait`, timeout, rejected) writes NEITHER file — while a `--no-wait` re-run resuming an already-claimed identity DOES wire (server-confirmed D exit; host-wiring report §2 delta 3). | **EXECUTED 2026-10-02** (lane docs-e2e, own run against emitted bytes sha256 24a18ad8…, fake-HOME + fake host binaries; evidence `.prime/handoff/docs-e2e/REPORT.md` §B) |

**Pass** for the tier: every EXECUTED row's assertions hold against the
recorded evidence; a PLANNED row is never cited as run.
**Falsifies:** F1 failing means the emitted `join.ts` no longer matches
`docs/JOIN_FUNNEL.md`; F2 failing means the orphan-row fork (second keypair per
re-run) is back; F3 failing means a re-run rewrites host configs it should
merge (or wires on unconfirmed claims).

---

## 6. Hard rules (distilled from defects that actually cost time)

1. **Test the documented command verbatim, from a clean host, first.** A no-op entrypoint makes every
   downstream claim vacuous.
2. **`--version` and `is-active` are not evidence.** Exercise the real path; assert the *effect*.
3. **Verify in the regime that fails**, not the regime you built in. Login-shell fixes don't reach
   systemd; interactive proofs don't cover daemon workers; a fresh process doesn't prove a restart.
4. **Every check needs a known-positive and a known-negative control.** A too-broad and a too-narrow
   check are the same bug.
5. **Never source a model id from a bundle**; `defined ≠ listed ≠ served`.
6. **A mitigation must be valid in the failing regime** — name what *reads* your fix.
7. **Push before pin; the container is not the artifact** — record what was tested by content probe,
   not by version string.
8. **No secret-derived bytes in output.** Presence and mode only.
9. **Enumerate by property, not by name** — a hand-written list always misses the member nobody listed.
10. **State the source and filter with any set you report** ("18 regex hits across 3 namespaces", not
    "18 models").

---

## 7. Container lifecycle and naming

- **Default: clean-room.** Destroy and relaunch per run (`sudo incus delete --force pa-testN`), then
  re-provision. Repeat runs against a reused container accumulate sessions, locks and config, and
  produce results nobody can attribute.
- **Fast iteration:** a documented reset (stop the unit, clear `/tmp/prime-agent-*` and
  `~/.prime/agent/sessions`, remove config) is acceptable **for development**, and every result from
  such a container must be labelled `dirty`.
- **Naming:** `pa-test<N>` on `kuai`. **Two more hosts may host same-named containers — always state
  the host with the name.** Record the image fingerprint per run; images drift.

---

## 8. Evidence and record format

Every run produces one record. Narrative is not evidence.

```
RUN: <date> host=<kuai|ct17> container=<pa-testN> image=<fingerprint> tier=<T0..T5>
SERVED: join.ts=<bytes> sha256[:12]  agent.js=<bytes> sha256[:12]   # content probe, not version
STEPS:  each command + observed result (stdout captured, not summarised)
PASS/FAIL per criterion, with the criterion QUOTED from §5
CONTROLS: what known-positive and known-negative were run
UNVERIFIED: what was NOT tested — say so explicitly; never round up
DIRTY: yes/no + what was left behind
```

**`UNVERIFIED` is a required field.** A run that claims everything verified and names nothing
unverified has not looked hard enough.

---

## 9. Lane split for the 3 buddies

| Lane | Session | Owns | Must produce |
|---|---|---|---|
| **L1 — funnel & served artifacts** | `c7a8c6` | T1; the content-probe of what is actually served; the §4.1/§4.4 gates | T1 report + the served-artifact probe as a script |
| **L2 — runtime install & resolution** | `419da7` | T2; the §4.2/§4.3 gap gates; the §3.3 install recipe as an idempotent script | T2 report + a reproducible install script |
| **L3 — IDP onboarding & boot** | `1d9904` | T3 (gated); T4; the §4.7 restart rule; §4.8 kernel reality | T3/T4 report + the boot-persistence harness |
| **Lead** | this session | T0, §5 tier definitions, §6 rules, the record format, review and merge | this SOP, kept true |

Each lane: **read-only on the repo** unless given a file; report by file under `.prime/handoff/`, not
by message alone; state `UNVERIFIED` explicitly.

---

## 10. Decisions — resolved 2026-09-13 (operator)

| Q | Decision | Consequence |
|---|---|---|
| **Q1** | Source of truth is **Forgejo at `vmaker-pi`**, so the E2E **always starts from there** | §3.6. Forgejo is **REST not MCP** (§4.9). No releases and no committed bundle → **a run builds from source**. Open sub-question: build-from-source every run, or publish a release so runs fetch a prebuilt artifact? |
| **Q2** | **Production testing**, onto the **`openkuai` segment only**, owned solely by admin `chance@vchat.email` | §3.7. Live runs create real identities — record each agent id. No stubbing as the default. |
| **Q3** | Yes — test external access via exit node `kuai-exit.finch-iwato.ts.net` | §3.8. **Currently fails**: the node is not advertising. Gate it in T0; fix is operator-side. |
| **Q4** | Agreed — recreate per run, keep one untouched known-good control | §7 |
| **Q5** | This SOP **also owns `ct17`**, but as **backup** (LXC, not incus) | §3.1 — `ct17` remains the documented networking negative control, not a primary target |
| **Q6** | Lanes stay **read-only** and hand the lead **patches** | §9 |

### 10.1 New gate introduced by Q1 — the version drift

Forgejo's mirror is **`prime-agent 0.9.4`** (HEAD `e6b79144`, 2026-09-08) while the artifact we vendored and
deployed is **`0.7.1`** (gitSha `a18809e`, bundle manifest version `1.3.0`). **Two minor versions of drift**
between the source of truth and everything we have tested.

The E2E must therefore **record the source revision it built** and refuse to compare results across
revisions. A pass against `a18809e` says nothing about `0.9.4`, and the earlier prime-agent findings
(the bundle layout, the `~/.prime` credential path, the model catalog) may or may not hold at `0.9.4`.

**Gate:** assert the built revision; fail the run if the source revision moved mid-suite.

**Status: this drift is what the new channel FIXES.** The installer no longer vendors a stale bundle — it
resolves the version from `<base>/latest.json` and installs the packed release, so a run gets the published
revision rather than whatever was committed to the tree. The gate above still applies and is now cheap:
`latest.json` names the version, and the manifest pins the source revision it was built from.
