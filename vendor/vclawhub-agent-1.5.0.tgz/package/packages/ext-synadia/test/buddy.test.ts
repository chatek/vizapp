/**
 * buddy.test.ts — buddy protocol round-trips between two in-process agents
 * (lane F): request → auto-accept → mutual stores; explicit accept/reject;
 * re-request idempotence (re-buddy semantics); store durability; subjects.
 */

import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { NatsConnection } from "@nats-io/nats-core";

import { MockNats, flush } from "./mock-nats.js";
import {
  BuddyStore,
  buddiesFilePath,
  startBuddyProtocol,
  type BuddyProtocolHandle,
} from "../src/buddy.js";
import {
  buddyAcceptSubject,
  buddyRejectSubject,
  buddyRequestSubject,
} from "../src/subjects.js";

const dirs: string[] = [];
afterEach(() => {
  for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true });
});

function tmpStore(): { store: BuddyStore; dir: string; file: string } {
  const dir = mkdtempSync(join(tmpdir(), "ext-syn-buddy-"));
  dirs.push(dir);
  const file = join(dir, "buddies.json");
  return { store: new BuddyStore(file), dir, file };
}

interface Pair {
  nc: MockNats;
  a: BuddyProtocolHandle;
  b: BuddyProtocolHandle;
  aStore: BuddyStore;
  bStore: BuddyStore;
  bFile: string;
}

/** Two agents on one mock mesh: A(me.owner/a1) ↔ B(you.owner/b1). */
function makePair(overrides: Partial<Parameters<typeof startBuddyProtocol>[1]> = {}): Pair {
  const nc = new MockNats();
  const aS = tmpStore();
  const bS = tmpStore();
  const a = startBuddyProtocol(nc as unknown as NatsConnection, {
    self: { owner: "me", name: "a1" },
    store: aS.store,
    ...overrides,
  });
  const b = startBuddyProtocol(nc as unknown as NatsConnection, {
    self: { owner: "you", name: "b1" },
    store: bS.store,
    ...overrides,
  });
  return { nc, a, b, aStore: aS.store, bStore: bS.store, bFile: bS.file };
}

describe("subjects (pi-a2a grammar)", () => {
  it("buddy verbs follow agents.{verb}.pi.{owner}.{name}", () => {
    expect(buddyRequestSubject("o", "n")).toBe("agents.buddy_request.pi.o.n");
    expect(buddyAcceptSubject("o", "n")).toBe("agents.buddy_accept.pi.o.n");
    expect(buddyRejectSubject("o", "n")).toBe("agents.buddy_reject.pi.o.n");
  });
});

describe("BuddyStore", () => {
  it("add is idempotent; remove deletes; persists to disk", () => {
    const { store, file } = tmpStore();
    expect(store.add("you", "b1")).toBe(true);
    expect(store.add("you", "b1")).toBe(false); // idempotent
    expect(store.isBuddy("you", "b1")).toBe(true);

    const onDisk = JSON.parse(readFileSync(file, "utf8")) as { buddies: Array<{ owner: string; name: string }> };
    expect(onDisk.buddies).toEqual([expect.objectContaining({ owner: "you", name: "b1" })]);

    expect(store.remove("you", "b1")).toBe(true);
    expect(store.isBuddy("you", "b1")).toBe(false);
  });

  it("file path lives under the identity dir", () => {
    expect(buddiesFilePath("/base/identity")).toBe("/base/identity/buddies.json");
  });
});

describe("round-trip: two in-process agents", () => {
  it("request → skeleton auto-accept → BOTH stores hold the relationship", async () => {
    const { a, b, aStore, bStore } = makePair();

    a.request("you", "b1");
    await flush(6); // request delivered → B auto-accepts → accept delivered → A records B

    expect(bStore.isBuddy("me", "a1")).toBe(true); // B accepted + recorded A
    expect(aStore.isBuddy("you", "b1")).toBe(true); // A recorded B on the inbound accept
    a.stop();
    b.stop();
  });

  it("explicit onRequest accept path", async () => {
    const seen: Array<{ owner: string; name: string }> = [];
    const nc = new MockNats();
    const aS = tmpStore();
    const bS = tmpStore();
    const a = startBuddyProtocol(nc as unknown as NatsConnection, { self: { owner: "me", name: "a1" }, store: aS.store });
    const b = startBuddyProtocol(nc as unknown as NatsConnection, {
      self: { owner: "you", name: "b1" },
      store: bS.store,
      onRequest: (from, reply) => {
        seen.push(from);
        reply.accept();
      },
    });

    a.request("you", "b1");
    await flush(6);

    expect(seen).toEqual([{ owner: "me", name: "a1" }]);
    expect(bS.store.isBuddy("me", "a1")).toBe(true);
    expect(aS.store.isBuddy("you", "b1")).toBe(true);
    a.stop();
    b.stop();
  });

  it("explicit onRequest reject path — no relationship recorded", async () => {
    const nc = new MockNats();
    const aS = tmpStore();
    const bS = tmpStore();
    const rejections: Array<{ owner: string; name: string }> = [];
    const a = startBuddyProtocol(nc as unknown as NatsConnection, {
      self: { owner: "me", name: "a1" },
      store: aS.store,
      onReject: (from) => rejections.push(from),
    });
    const b = startBuddyProtocol(nc as unknown as NatsConnection, {
      self: { owner: "you", name: "b1" },
      store: bS.store,
      onRequest: (_from, reply) => reply.reject(),
    });

    a.request("you", "b1");
    await flush(6);

    expect(rejections).toEqual([{ owner: "you", name: "b1" }]); // A heard the reject
    expect(bS.store.isBuddy("me", "a1")).toBe(false);
    expect(aS.store.isBuddy("you", "b1")).toBe(false);
    a.stop();
    b.stop();
  });

  it("re-request from an existing buddy is idempotently re-accepted (re-buddy semantics)", async () => {
    const nc = new MockNats();
    const aS = tmpStore();
    const bS = tmpStore();
    const requests: Array<{ owner: string; name: string }> = [];
    const a = startBuddyProtocol(nc as unknown as NatsConnection, { self: { owner: "me", name: "a1" }, store: aS.store });
    const b = startBuddyProtocol(nc as unknown as NatsConnection, {
      self: { owner: "you", name: "b1" },
      store: bS.store,
      onRequest: (from, reply) => {
        requests.push(from);
        reply.accept();
      },
    });

    // First handshake
    a.request("you", "b1");
    await flush(6);
    expect(bS.store.isBuddy("me", "a1")).toBe(true);
    expect(requests).toEqual([{ owner: "me", name: "a1" }]); // fired ONCE on first contact

    // Re-request (e.g. A forgot state) → B re-accepts WITHOUT surfacing onRequest
    a.request("you", "b1");
    await flush(6);
    expect(requests).toEqual([{ owner: "me", name: "a1" }]); // still ONE — no new dialog on the re-request
    expect(bS.store.list().filter((r) => r.owner === "me").length).toBe(1); // no duplicate records
    a.stop();
    b.stop();
  });

  it("malformed wire payloads are ignored (no crash, no state change)", async () => {
    const nc = new MockNats();
    const { store } = tmpStore();
    const a = startBuddyProtocol(nc as unknown as NatsConnection, { self: { owner: "me", name: "a1" }, store });

    nc.publish(buddyRequestSubject("me", "a1"), new TextEncoder().encode("garbage"));
    nc.publish(
      buddyAcceptSubject("me", "a1"),
      new TextEncoder().encode(JSON.stringify({ type: "buddy_accept", fromOwner: "", fromName: "", conversationId: "c", ts: "t" })),
    );
    await flush(4);

    expect(store.list()).toEqual([]); // nothing recorded
    a.stop();
  });
});
