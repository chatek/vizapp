/**
 * fake-peer.test.ts — self-contained headless round-trip: ephemeral
 * nats-server + in-process fake Micro peers, then the FULL client path
 * (discovery §4.3 → a2aSend §6) against them.
 *
 * Two peers exercise both wire dialects:
 *   "spec-peer"    — spec-conformant §6 stream (ack {data}, string response)
 *   "variant-peer" — pi-a2a's @synadia-ai/agent-service@0.5.2 dialect
 *                    (ack {status}, keepalive re-ack, {text} object response;
 *                    dist/index.js:425-436,49,467)
 *
 * Skipped when no nats-server binary (portable CI) — the pure client units
 * live in outbound.test.ts.
 */

import { spawn, type ChildProcess } from "node:child_process";
import { createServer } from "node:net";

import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { connect, type NatsConnection } from "@nats-io/transport-node";
import { Svcm } from "@nats-io/services";

import { a2aSend, A2aError } from "../src/bridge.js";
import { discoverAgents } from "../src/discovery.js";

function hasNatsServer(): boolean {
  try {
    spawn("nats-server", ["--version"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

async function freePort(): Promise<number> {
  return await new Promise((resolve) => {
    const srv = createServer();
    srv.listen(0, "127.0.0.1", () => {
      const port = (srv.address() as { port: number }).port;
      srv.close(() => resolve(port));
    });
  });
}

let server: ChildProcess | undefined;
let nc: NatsConnection | undefined;
let url = "";

async function startServer(): Promise<void> {
  const port = await freePort();
  url = `nats://127.0.0.1:${port}`;
  server = spawn("nats-server", ["-a", "127.0.0.1", "-p", String(port)], {
    stdio: "ignore",
  });
  for (let i = 0; i < 50; i++) {
    try {
      nc = await connect({ servers: url });
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 100));
    }
  }
  throw new Error("ephemeral nats-server never came up");
}

/** Register a fake protocol agent whose prompt handler streams `script`. */
async function registerFakePeer(name: string, script: (respond: (b: Uint8Array) => void) => void) {
  const enc = new TextEncoder();
  const svc = await new Svcm(nc!).add({
    name: "agents",
    version: "0.9.9",
    description: `fake peer ${name}`,
    metadata: { agent: "pi", owner: "faketest", protocol_version: "0.3" },
  });
  svc.addEndpoint("prompt", {
    subject: `agents.prompt.pi.faketest.${name}`,
    queue: "agents",
    metadata: { max_payload: "1MB", attachments_ok: "true" },
    handler: (_e, msg) => script((b) => msg.respond(b)),
  });
  return svc;
}

const chunk = (o: unknown) => new TextEncoder().encode(JSON.stringify(o));

beforeAll(async () => {
  if (!hasNatsServer()) return;
  await startServer();
  if (!nc) return;

  // Spec-conformant peer: ack → two response chunks → terminator.
  await registerFakePeer("spec-peer", (respond) => {
    respond(chunk({ type: "status", data: "ack" }));
    respond(chunk({ type: "response", data: "hello " }));
    respond(chunk({ type: "response", data: "from spec" }));
    respond(new Uint8Array(0));
  });

  // pi-a2a-dialect peer: {status:"ack"} ack, keepalive re-ack, {text} form.
  await registerFakePeer("variant-peer", (respond) => {
    respond(chunk({ type: "status", status: "ack" }));
    respond(chunk({ type: "response", data: { text: "variant says hi" } }));
    respond(chunk({ type: "status", status: "ack" })); // keepalive repeat
    respond(new Uint8Array(0));
  });
}, 15_000);

afterAll(async () => {
  try { await nc?.drain(); await nc?.close(); } catch { /* */ }
  server?.kill("SIGKILL");
});

describe.skipIf(!hasNatsServer())("discovery (§4.3) + a2aSend (§6) — headless", () => {
  it("discovers both fake peers with endpoint facts parsed", async () => {
    const agents = await discoverAgents(nc!);
    const spec = agents.find((a) => a.descriptor.name === "spec-peer");
    expect(spec).toBeTruthy();
    expect(spec!.descriptor.owner).toBe("faketest");
    expect(spec!.descriptor.agent).toBe("pi");
    expect(spec!.promptEndpoint?.subject).toBe("agents.prompt.pi.faketest.spec-peer");
    expect(spec!.promptEndpoint?.maxPayload).toBe("1MB");
    expect(spec!.promptEndpoint?.attachmentsOk).toBe(true);
    expect(spec!.descriptor.metadata?.protocol_version).toBe("0.3");
    expect(agents.find((a) => a.descriptor.name === "variant-peer")).toBeTruthy();
  });

  it("full round-trip against the spec-conformant peer", async () => {
    const agents = await discoverAgents(nc!);
    const target = agents.find((a) => a.descriptor.name === "spec-peer")!;
    const reply = await a2aSend(
      nc!,
      { descriptor: target.descriptor, promptEndpoint: target.promptEndpoint! },
      "greetings",
      { from: { agent: "pi", owner: "caller", name: "c1" } },
    );
    expect(reply.text).toBe("hello from spec");
    expect(reply.ackSeen).toBe(true);
    expect(reply.chunkCount).toBe(3);
  });

  it("round-trip against the pi-a2a-dialect peer (tolerance proof)", async () => {
    const agents = await discoverAgents(nc!);
    const target = agents.find((a) => a.descriptor.name === "variant-peer")!;
    const reply = await a2aSend(
      nc!,
      { descriptor: target.descriptor, promptEndpoint: target.promptEndpoint! },
      "greetings",
      { from: { agent: "pi", owner: "caller", name: "c1" } },
    );
    expect(reply.text).toBe("variant says hi");
    expect(reply.ackSeen).toBe(true); // via the {status:"ack"} variant
  });

  it("enforces max_payload client-side (§5.4) before publishing", async () => {
    const agents = await discoverAgents(nc!);
    const target = agents.find((a) => a.descriptor.name === "spec-peer")!;
    const tiny: typeof target = {
      ...target,
      promptEndpoint: { ...target.promptEndpoint!, maxPayload: "16B" },
    };
    await expect(
      a2aSend(nc!, { descriptor: tiny.descriptor, promptEndpoint: tiny.promptEndpoint! },
        "this prompt is far longer than sixteen bytes", { from: { agent: "pi", owner: "c", name: "c" } }),
    ).rejects.toThrowError(/max_payload/);
  });

  it("rejects attachments to an attachments_ok=false target (§2.1)", async () => {
    const agents = await discoverAgents(nc!);
    const target = agents.find((a) => a.descriptor.name === "spec-peer")!;
    const noAtt: typeof target = {
      ...target,
      promptEndpoint: { ...target.promptEndpoint!, attachmentsOk: false },
    };
    await expect(
      a2aSend(nc!, { descriptor: noAtt.descriptor, promptEndpoint: noAtt.promptEndpoint! },
        "with attachment", {
          from: { agent: "pi", owner: "c", name: "c" },
          attachments: [{ filename: "f.txt", content: "aGk=" }],
        }),
    ).rejects.toThrowError(/attachments_ok/);
  });

  it("surfaces §9 error headers as A2aError", async () => {
    const errSvc = await new Svcm(nc!).add({
      name: "agents",
      version: "0.9.9",
      description: "erroring peer",
      metadata: { agent: "pi", owner: "faketest", protocol_version: "0.3" },
    });
    errSvc.addEndpoint("prompt", {
      subject: "agents.prompt.pi.faketest.err-peer",
      queue: "agents",
      metadata: { max_payload: "1MB", attachments_ok: "true" },
      handler: (_e, msg) => {
        msg.respondError(418, "I am a teapot");
        msg.respond(new Uint8Array(0));
      },
    });
    try {
      const agents = await discoverAgents(nc!);
      const target = agents.find((a) => a.descriptor.name === "err-peer")!;
      await expect(
        a2aSend(nc!, { descriptor: target.descriptor, promptEndpoint: target.promptEndpoint! },
          "brew", { from: { agent: "pi", owner: "c", name: "c" } }),
      ).rejects.toMatchObject({ code: 418 });
      expect(true).toBe(true);
    } finally {
      await errSvc.stop();
    }
  });

  it("A2aError is exported and carries its code", () => {
    const e = new A2aError("x", 42);
    expect(e).toBeInstanceOf(A2aError);
    expect(e.code).toBe(42);
  });
});
