/**
 * registration.test.ts — §8.3 payload shape + subjects (pure units; the live
 * round-trip against 127.0.0.1:14222 is in live-probe.test.ts, env-gated).
 */

import { describe, expect, it } from "vitest";

import { EXT_SYNADIA_VERSION, PROTOCOL_VERSION, heartbeatPayload } from "../src/registration.js";
import { AGENT_PARTICLE, hbSubject, promptSubject, statusSubject } from "../src/subjects.js";

describe("heartbeatPayload (spec §8.3)", () => {
  it("required fields present, session omitted when unset", () => {
    const p = heartbeatPayload({ owner: "local", instanceId: "INS1", intervalS: 30 });
    expect(p.agent).toBe("pi");
    expect(p.owner).toBe("local");
    expect(p.instance_id).toBe("INS1");
    expect(p.interval_s).toBe(30);
    expect(typeof p.ts).toBe("string");
    expect("session" in p).toBe(false); // §8.3: present iff metadata.session set
  });

  it("session included when session-aware (pi is, per §3.2)", () => {
    const p = heartbeatPayload({ owner: "o", session: "s1", instanceId: "I", intervalS: 5 });
    expect(p.session).toBe("s1");
  });

  it("protocol version is MAJOR.MINOR (0.3) and harness version is semver", () => {
    expect(PROTOCOL_VERSION).toMatch(/^\d+\.\d+$/);
    expect(EXT_SYNADIA_VERSION).toMatch(/^\d+\.\d+\.\d+$/);
  });
});

describe("default subjects (spec §2 + C3)", () => {
  it("token order: agents.{verb}.{agent}.{owner}.{name}", () => {
    expect(promptSubject("myowner", "sess1")).toBe(`agents.prompt.${AGENT_PARTICLE}.myowner.sess1`);
    expect(hbSubject("myowner", "sess1")).toBe(`agents.hb.${AGENT_PARTICLE}.myowner.sess1`);
    expect(statusSubject("myowner", "sess1")).toBe(`agents.status.${AGENT_PARTICLE}.myowner.sess1`);
  });

  it("tokens never start with $ and use [a-z0-9_-] only (§2.2)", () => {
    for (const s of [promptSubject("o", "n"), hbSubject("o", "n"), statusSubject("o", "n")]) {
      expect(s.startsWith("$")).toBe(false);
      expect(s).toMatch(/^agents\.(prompt|hb|status)\.[a-z0-9_-]+\.[a-z0-9_-]+\.[a-z0-9_-]+$/);
    }
  });
});
