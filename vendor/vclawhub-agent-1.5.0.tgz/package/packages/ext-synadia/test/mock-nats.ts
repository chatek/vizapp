/**
 * mock-nats.ts — minimal in-memory NATS for protocol tests (lane F).
 *
 * Supports subscribe(pattern) with `>` wildcard matching + publish routing —
 * exactly the surface presence.ts/buddy.ts use (structural NatsConnection
 * slice; cast at the call site). No JetStream, no request/reply.
 */

export interface MockMsg {
  subject: string;
  data: Uint8Array;
  reply?: string;
}

export class MockSub implements AsyncIterable<MockMsg> {
  readonly pattern: string;
  #buf: MockMsg[] = [];
  #waiters: Array<() => void> = [];
  #closed = false;

  constructor(pattern: string) {
    this.pattern = pattern;
  }

  [Symbol.asyncIterator](): AsyncIterator<MockMsg> {
    return {
      next: async (): Promise<IteratorResult<MockMsg>> => {
        while (this.#buf.length === 0) {
          if (this.#closed) return { done: true, value: undefined as never };
          await new Promise<void>((resolve) => this.#waiters.push(resolve));
        }
        return { done: false, value: this.#buf.shift()! };
      },
    };
  }

  push(m: MockMsg): void {
    this.#buf.push(m);
    this.#waiters.splice(0).forEach((w) => w());
  }

  unsubscribe(): void {
    this.#closed = true;
    this.#waiters.splice(0).forEach((w) => w());
  }
}

/** `>` matches one-or-more trailing tokens (NATS semantics). */
export function subjectMatches(pattern: string, subject: string): boolean {
  const p = pattern.split(".");
  const s = subject.split(".");
  for (let i = 0; i < p.length; i++) {
    if (p[i] === ">") return i < s.length; // needs ≥1 remaining token
    if (p[i] !== s[i]) return false;
  }
  return p.length === s.length;
}

export class MockNats {
  #subs: MockSub[] = [];

  subscribe(pattern: string): MockSub {
    const sub = new MockSub(pattern);
    this.#subs.push(sub);
    return sub;
  }

  publish(subject: string, data: Uint8Array, reply?: string): void {
    for (const sub of this.#subs) {
      if (subjectMatches(sub.pattern, subject)) sub.push({ subject, data, reply });
    }
  }

  /** Test hook: active subscription patterns. */
  patterns(): string[] {
    return this.#subs.map((s) => s.pattern);
  }
}

/** Let async-iterator consumers drain queued messages (microtask turns). */
export async function flush(turns = 4): Promise<void> {
  for (let i = 0; i < turns; i++) await Promise.resolve();
}
