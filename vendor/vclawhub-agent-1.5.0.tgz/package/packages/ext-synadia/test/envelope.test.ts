/**
 * envelope.test.ts — inbound decode (§5.1 both forms) + §6 chunk stream +
 * protocol-core tolerance behaviors ext-synadia depends on.
 */

import { describe, expect, it } from "vitest";

import {
  TERMINATOR,
  createBridge,
  decodeChunk,
  decodeInbound,
  emitReplyStream,
  encodeChunk,
  replyText,
} from "../src/bridge.js";

function bytes(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

describe("decodeInbound (Synadia §5.1)", () => {
  it("decodes a JSON envelope via protocol-core parseCore", () => {
    const env = decodeInbound(
      bytes(JSON.stringify({
        type: "a2a_request",
        id: "req-1",
        from: { agent: "pi", owner: "local", name: "abc123" },
        ts: "2026-08-16T00:00:00Z",
        prompt: "hello there",
      })),
    );
    expect(env.prompt).toBe("hello there");
    expect(env.type).toBe("a2a_request");
    expect(env.from.owner).toBe("local");
  });

  it("plain UTF-8 text is the shorthand for {prompt} only (§5.1)", () => {
    const env = decodeInbound(bytes("just some text"));
    expect(env.prompt).toBe("just some text");
    expect(env.type).toBe("a2a_request");
  });

  it("snake_case tolerated on read (canon §4: camel canonical, snake accepted)", () => {
    const env = decodeInbound(
      bytes(JSON.stringify({
        type: "a2a_request",
        id: "r2",
        from: { agent: "pi", owner: "o", name: "n" },
        ts: "now",
        prompt: "p",
        a2a: { reply_subject: "_INBOX.x", fabric: "f" },
      })),
    );
    // normalized to the canonical top-level home (protocol-core §4 layout;
    // routing keeps the non-reply keys)
    expect(env.replySubject).toBe("_INBOX.x");
    expect(env.routing?.fabric).toBe("f");
  });

  it("unknown fields survive parse, keys camel-normalized (§5.6)", () => {
    const env = decodeInbound(
      bytes(JSON.stringify({
        type: "a2a_request",
        id: "r3",
        from: {},
        ts: "now",
        prompt: "p",
        future_field_xyz: { deep: true },
      })),
    );
    // value preserved verbatim; key normalized per canon §4 (snake read, camel kept)
    expect((env as Record<string, unknown>).futureFieldXyz).toEqual({ deep: true });
  });

  it("invalid JSON that starts with { falls back to plain text", () => {
    const env = decodeInbound(bytes("{oops not json"));
    expect(env.prompt).toBe("{oops not json");
  });
});

describe("§6 response stream", () => {
  it("ack chunk MUST be first (§6.4)", () => {
    const chunks: Uint8Array[] = [];
    emitReplyStream((d) => chunks.push(d), "the reply");
    expect(chunks.length).toBe(3);
    expect(decodeChunk(chunks[0]!)).toEqual({ type: "status", data: "ack" });
    expect(decodeChunk(chunks[1]!)).toEqual({ type: "response", data: "the reply" });
  });

  it("terminator is zero-byte (§6.5)", () => {
    expect(TERMINATOR.byteLength).toBe(0);
    const chunks: Uint8Array[] = [];
    emitReplyStream((d) => chunks.push(d), "x");
    expect(chunks[2]!.byteLength).toBe(0);
  });

  it("response chunk data may be bare string (§6.3 string form)", () => {
    expect(decodeChunk(encodeChunk({ type: "response", data: "hi" })))
      .toEqual({ type: "response", data: "hi" });
  });
});

describe("replyText (turn_end host shapes)", () => {
  it("string content", () => {
    expect(replyText({ content: "direct" })).toBe("direct");
  });
  it("block array content (assistant message blocks)", () => {
    expect(replyText({ content: [{ text: "a" }, { text: "b" }] })).toBe("ab");
  });
  it("null message → empty string", () => {
    expect(replyText(null)).toBe("");
  });
});

describe("createBridge (session + echo modes)", () => {
  it("echo mode: no sendUserMessage → immediate ack/response/terminator", () => {
    const b = createBridge(undefined);
    const chunks: Uint8Array[] = [];
    b.onInbound(
      { type: "a2a_request", id: "1", from: { owner: "o", name: "n" }, ts: "t", prompt: "ping" },
      (d) => chunks.push(d),
    );
    expect(chunks.length).toBe(3);
    expect(decodeChunk(chunks[1]!)).toEqual({ type: "response", data: "echo: ping" });
    expect(b.pending()).toBe(0);
  });

  it("session mode: queues reply, turn_end emits the stream FIFO", () => {
    const sent: string[] = [];
    const b = createBridge((m) => sent.push(m));
    const chunks: Uint8Array[] = [];
    b.onInbound(
      { type: "a2a_request", id: "1", from: { owner: "o", name: "n" }, ts: "t", prompt: "do it" },
      (d) => chunks.push(d),
    );
    expect(sent).toEqual(["[a2a from o/n]: do it"]);
    expect(chunks.length).toBe(0); // nothing until the turn ends
    expect(b.pending()).toBe(1);
    b.onTurnEnd("done working");
    expect(chunks.length).toBe(3);
    expect(decodeChunk(chunks[1]!)).toEqual({ type: "response", data: "done working" });
    expect(b.pending()).toBe(0);
    // a stray turn_end with empty queue is a no-op
    b.onTurnEnd("orphan");
    expect(chunks.length).toBe(3);
  });
});
