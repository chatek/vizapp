/**
 * identity.test.ts — the INDEPENDENT nonce chain (ruling Q1).
 *
 * Independence is the point: these tests pin the ext-synadia chain's own
 * storage dir + env override, mirroring pi-a2a's loadOrCreateNonce semantics
 * (env → persisted → random; A2A/pi-a2a/src/index.ts:3674-3705) WITHOUT
 * sharing pi-a2a's files.
 */

import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it } from "vitest";

import {
  EXT_SYNADIA_IDENTITY_DIR_ENV,
  EXT_SYNADIA_NONCE_ENV,
  identityDir,
  loadOrCreateNonce,
  resetNonceCache,
} from "../src/identity.js";

let dir: string;
const savedEnv: Record<string, string | undefined> = {};

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), "ext-synadia-id-"));
  for (const k of [EXT_SYNADIA_IDENTITY_DIR_ENV, EXT_SYNADIA_NONCE_ENV]) {
    savedEnv[k] = process.env[k];
  }
  process.env[EXT_SYNADIA_IDENTITY_DIR_ENV] = dir;
  delete process.env[EXT_SYNADIA_NONCE_ENV];
  resetNonceCache();
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
  for (const [k, v] of Object.entries(savedEnv)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  resetNonceCache();
});

describe("loadOrCreateNonce", () => {
  it("env override wins (explicit identity for a process)", () => {
    process.env[EXT_SYNADIA_NONCE_ENV] = "custom1";
    expect(loadOrCreateNonce()).toBe("custom1");
  });

  it("persists a generated nonce — the chain survives process restarts", () => {
    const first = loadOrCreateNonce();
    expect(first).toMatch(/^[0-9a-f]{6}$/);
    expect(existsSync(join(dir, "nonce"))).toBe(true);
    resetNonceCache(); // simulate a fresh process
    expect(loadOrCreateNonce()).toBe(first); // same chain, not a new one
    expect(readFileSync(join(dir, "nonce"), "utf8").trim()).toBe(first);
  });

  it("reads an existing chain file (pre-seeded identity)", () => {
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, "nonce"), "seeded\n");
    expect(loadOrCreateNonce()).toBe("seeded");
  });

  it("identity dir is ext-synadia's own (not pi-a2a's, not ~/.vchat)", () => {
    delete process.env[EXT_SYNADIA_IDENTITY_DIR_ENV];
    const p = identityDir();
    expect(p).toContain("ext-synadia");
    expect(p).not.toContain("pi-a2a");
    expect(p).not.toContain(".vchat");
  });
});
