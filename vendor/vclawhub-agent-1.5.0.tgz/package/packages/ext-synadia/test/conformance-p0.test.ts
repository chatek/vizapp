/**
 * conformance-p0.test.ts — the v11 P0 fixes, pinned.
 *
 * Covers G2 (§12/§9.2 refusals on the prompt endpoint), G3 (truthful
 * `attachments_ok`), G8 (§3.1 version = harness semver). G11 (publish set) is
 * verified by `jsr publish --dry-run`, not here.
 */

import { describe, expect, it } from "vitest";

import { validateInbound } from "../src/bridge.js";
import { EXT_SYNADIA_VERSION, promptEndpointMetadata, serviceVersion } from "../src/registration.js";

const enc = (s: string): Uint8Array => new TextEncoder().encode(s);

/** Narrow to the refusal shape, failing loudly if the verdict was "ok". */
function refusal(v: ReturnType<typeof validateInbound>): { code: number; message: string } {
  if (v.ok) throw new Error("expected a refusal, got ok");
  return v;
}

describe("§12 prompt validation — refusals are §9.2-coded", () => {
  it("empty payload → 400", () => {
    expect(refusal(validateInbound(new Uint8Array())).code).toBe(400);
  });

  it("oversize → 400 and names both sizes", () => {
    const v = refusal(validateInbound(new Uint8Array(2048), { maxPayload: "1KB" }));
    expect(v.code).toBe(400);
    expect(v.message).toMatch(/exceeds max_payload/);
    expect(v.message).toMatch(/2048/);
  });

  it("malformed JSON envelope → 400, NOT silently downgraded to plain text", () => {
    // decodeInbound alone would accept this as shorthand; validation must not.
    expect(refusal(validateInbound(enc('{"type":"a2a_request",'))).code).toBe(400);
  });

  it("plain-text shorthand is valid input (§5.1)", () => {
    expect(validateInbound(enc("hello there")).ok).toBe(true);
  });

  it("valid envelope passes", () => {
    expect(validateInbound(enc('{"type":"a2a_request","prompt":"hi"}')).ok).toBe(true);
  });

  it("unknown envelope fields are tolerated (§5.6)", () => {
    expect(validateInbound(enc('{"type":"a2a_request","prompt":"hi","future":{"x":1}}')).ok).toBe(true);
  });

  it("attachments refused when attachments_ok=false", () => {
    const body = JSON.stringify({
      type: "a2a_request",
      prompt: "hi",
      attachments: [{ filename: "a.txt", content: "aGk=" }],
    });
    const v = refusal(validateInbound(enc(body), { attachmentsOk: false }));
    expect(v.code).toBe(400);
    expect(v.message).toMatch(/attachments not accepted/);
  });

  it("invalid base64 attachment refused even when attachments are allowed", () => {
    const body = JSON.stringify({
      type: "a2a_request",
      prompt: "hi",
      attachments: [{ filename: "a.txt", content: "not base64!!" }],
    });
    const v = refusal(validateInbound(enc(body), { attachmentsOk: true }));
    expect(v.code).toBe(400);
    expect(v.message).toMatch(/invalid base64/);
  });

  it("well-formed attachment accepted when attachments are allowed", () => {
    const body = JSON.stringify({
      type: "a2a_request",
      prompt: "hi",
      attachments: [{ filename: "a.txt", content: "aGVsbG8=" }],
    });
    expect(validateInbound(enc(body), { attachmentsOk: true }).ok).toBe(true);
  });
});

describe("§3.1 version and §2.1 endpoint metadata", () => {
  it("version is the harness semver when supplied, else the bundle version", () => {
    expect(serviceVersion("1.4.0")).toBe("1.4.0");
    expect(serviceVersion("  2.0.1 ")).toBe("2.0.1");
    expect(serviceVersion(undefined)).toBe(EXT_SYNADIA_VERSION);
    expect(serviceVersion("   ")).toBe(EXT_SYNADIA_VERSION);
  });

  it("attachments_ok defaults to FALSE (no false advertisement) and tracks the host", () => {
    expect(promptEndpointMetadata().attachments_ok).toBe("false");
    expect(promptEndpointMetadata({ attachmentsOk: true }).attachments_ok).toBe("true");
    expect(promptEndpointMetadata({ maxPayload: "64KB" }).max_payload).toBe("64KB");
    expect(promptEndpointMetadata().max_payload).toBe("1MB");
  });
});
