/**
 * outbound.test.ts — pure units for the a2aSend client path:
 * §5.1 payload building, §2.1 max_payload parsing, §6 chunk consumption
 * (spec shapes + pi-a2a agent-service@0.5.2 variants).
 */

import { describe, expect, it } from "vitest";

import {
  A2aError,
  buildOutboundPayload,
  consumeChunk,
} from "../src/bridge.js";
import { parseMaxPayload } from "../src/discovery.js";

const FROM = { agent: "pi", owner: "tester", name: "unit1" } as const;

describe("buildOutboundPayload (§5.1)", () => {
  it("short single-line prompt uses the plain-text shorthand", () => {
    const { payload, shorthand } = buildOutboundPayload(FROM, "ping");
    expect(shorthand).toBe(true);
    expect(new TextDecoder().decode(payload)).toBe("ping");
  });

  it("long / multiline / attachment-bearing prompts use the JSON envelope", () => {
    for (const prompt of ["a".repeat(200), "line one\nline two"]) {
      const { payload, shorthand } = buildOutboundPayload(FROM, prompt);
      expect(shorthand).toBe(false);
      const env = JSON.parse(new TextDecoder().decode(payload));
      expect(env.type).toBe("a2a_request");
      expect(env.prompt).toBe(prompt);
      expect(env.from.owner).toBe("tester");
      expect(env.ttlS).toBe(300); // TTL_MAX_S guard rides the envelope
      expect(env.ts).toBeTruthy();
    }
  });

  it("attachments force the envelope and ride §5.2", () => {
    const { payload, shorthand } = buildOutboundPayload(FROM, "see attached", {
      attachments: [{ filename: "a.txt", content: "aGVsbG8=" }],
    });
    expect(shorthand).toBe(false);
    const env = JSON.parse(new TextDecoder().decode(payload));
    expect(env.attachments).toEqual([{ filename: "a.txt", content: "aGVsbG8=" }]);
  });

  it("envelope is canonical camelCase (protocol-core serializeCore)", () => {
    const { payload } = buildOutboundPayload(FROM, "multi\nline", { forceEnvelope: true });
    const raw = JSON.parse(new TextDecoder().decode(payload)) as Record<string, unknown>;
    expect(Object.keys(raw)).not.toContain("reply_subject");
    expect(Object.keys(raw)).not.toContain("ttl_s");
  });
});

describe("parseMaxPayload (§2.1)", () => {
  it.each([
    ["1MB", 1024 * 1024],
    ["512KB", 512 * 1024],
    ["4GB", 4 * 1024 ** 3],
    ["128B", 128],
  ])("%s → %d bytes", (s, n) => {
    expect(parseMaxPayload(s)).toBe(n);
  });
  it("malformed/absent → undefined (no enforcement)", () => {
    expect(parseMaxPayload(undefined)).toBeUndefined();
    expect(parseMaxPayload("lots")).toBeUndefined();
    expect(parseMaxPayload("")).toBeUndefined();
  });
});

function chunkMsg(obj: unknown, headers?: Record<string, string>) {
  return {
    data: new TextEncoder().encode(JSON.stringify(obj)),
    ...(headers ? { headers: { get: (k: string) => headers[k] } } : {}),
  };
}

describe("consumeChunk (§6, tolerant)", () => {
  it("spec ack shape: {type:'status', data:'ack'} (§6.4)", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    consumeChunk(acc, chunkMsg({ type: "status", data: "ack" }));
    expect(acc).toEqual({ text: "", ackSeen: true, chunkCount: 1 });
  });

  it("pi-a2a variant: {type:'status', status:'ack'} (agent-service 0.5.2 dist/index.js:425) + keepalive repeats", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    consumeChunk(acc, chunkMsg({ type: "status", status: "ack" }));
    consumeChunk(acc, chunkMsg({ type: "status", status: "ack" })); // keepalive resend
    expect(acc.ackSeen).toBe(true);
    expect(acc.chunkCount).toBe(2);
  });

  it("response chunks: bare string AND {text} object forms concatenated in order (§6.3)", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    consumeChunk(acc, chunkMsg({ type: "response", data: "Hello, " }));
    consumeChunk(acc, chunkMsg({ type: "response", data: { text: "world." } }));
    expect(acc.text).toBe("Hello, world.");
  });

  it("unknown chunk types silently skipped (§6.6)", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    consumeChunk(acc, chunkMsg({ type: "query", data: { q: "?" } }));
    consumeChunk(acc, chunkMsg({ type: "future_thing", data: 1 }));
    expect(acc.text).toBe("");
    expect(acc.chunkCount).toBe(2);
  });

  it("§9 error headers throw A2aError with the code", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    expect(() =>
      consumeChunk(acc, chunkMsg({ type: "response", data: "x" }, {
        "Nats-Service-Error": "boom",
        "Nats-Service-Error-Code": "500",
      })),
    ).toThrowError(A2aError);
    try {
      consumeChunk(acc, chunkMsg({}, { "Nats-Service-Error": "boom", "Nats-Service-Error-Code": "422" }));
    } catch (e) {
      expect((e as A2aError).code).toBe(422);
    }
  });

  it("non-JSON chunk bodies are skipped defensively (§6.2 is JSON-only)", () => {
    const acc = { text: "", ackSeen: false, chunkCount: 0 };
    consumeChunk(acc, { data: new TextEncoder().encode("not json") });
    expect(acc.chunkCount).toBe(1);
    expect(acc.text).toBe("");
  });
});
