/**
 * live-probe.test.ts — skeleton acceptance: connect + register + hb +
 * prompt-echo round-trip against the LIVE local site fabric
 * (127.0.0.1:14222 — nats-ipc.conf:12, token-gated :41).
 *
 * Env-gated: skipped unless SYNADIA_PROBE_LIVE=1, so `vitest run` stays
 * green on machines without the local fabric. Run with `npm run test:live`.
 *
 * The probe registers the real service in ECHO mode (no pi session), then
 * acts as a spec §4.3 caller: discovers via $SRV.INFO.agents, subscribes the
 * reply inbox, publishes a JSON envelope to the discovered prompt subject,
 * and consumes the §6 chunk stream until the empty terminator. It also
 * captures one §8.1 heartbeat and exercises the §8.7 status endpoint.
 *
 * ADDITIONAL (lane E): outbound client against a REAL pi-a2a agent on the
 * running fabric — see "outbound to a live pi-a2a agent" below.
 */

import { describe, expect, it } from "vitest";

import { connect } from "@nats-io/transport-node";
import { Svcm, type ServiceInfo } from "@nats-io/services";

import { connectLocalFabric, resolveToken } from "../src/connect.js";
import { loadOrCreateNonce } from "../src/identity.js";
import { startSynadiaAgent } from "../src/registration.js";
import { hbSubject, statusSubject } from "../src/subjects.js";
import { a2aSend } from "../src/bridge.js";
import { discoverAgents } from "../src/discovery.js";

const LIVE = process.env.SYNADIA_PROBE_LIVE === "1";

describe.skipIf(!LIVE)("outbound to a live pi-a2a agent (client path)", () => {
  // Target selection: the least-intrusive live agent — vmaker-slave (the
  // dev-coordination subordinate, not a worker/lead session). Its reply is
  // produced by @synadia-ai/agent-service@0.5.2 whose §6 dialect differs
  // from the spec in the ack shape: {type:'status',status:'ack'} vs spec
  // §6.4 {type:'status',data:'ack'} (dist/index.js:425) — a2aSend tolerates
  // both (see bridge.ts consumeChunk + outbound.test.ts). The LM turn can
  // take a while → generous overall timeout, still under TTL_MAX_S.
  it(
    "discovers real agents and completes a §6 round-trip with vmaker-slave",
    { timeout: 240_000 },
    async () => {
      const caller = await connect({
        servers: "nats://127.0.0.1:14222",
        ...(resolveToken() ? { token: resolveToken()! } : {}),
      });
      try {
        const agents = await discoverAgents(caller);
        expect(agents.length).toBeGreaterThan(0);
        expect(agents.every((a) => a.promptEndpoint?.subject.startsWith("agents.prompt."))).toBe(true);

        const target =
          agents.find((a) => a.descriptor.name === "vmaker-slave") ?? agents[0]!;
        const reply = await a2aSend(
          caller,
          { descriptor: target.descriptor, promptEndpoint: target.promptEndpoint! },
          "ext-synadia lane E interop probe — reply with the single word: pong",
          {
            from: { agent: "pi", owner: "probe", name: loadOrCreateNonce() },
            overallTimeoutMs: 180_000, // LM turn latency; < TTL_MAX_S guard
          },
        );
        // Dialect facts recorded for the report: ack may arrive via the
        // {status:'ack'} variant; response text is the agent's turn output.
        //
        // Lead integration note (CORRECTED per lane E's source verification):
        // pi-a2a's §6 prompt path is DELIVERY-ONLY — h2aPendingResponse (the
        // PromptResponse carrier that would stream the turn's text back) is
        // declared at A2A/pi-a2a/src/index.ts:299 and NEVER assigned (zero
        // non-null assignments; read sites :493/:1806 are dead). Empty text
        // on a resolved stream is therefore NOT "async-pending" — it is an
        // unwired response path (mirrors agent-sdk's own pre-B gap). The
        // cross-fabric fix belongs to pi-a2a (out of scope, ruling Q3/REF).
        // Mechanics gate: streamCompleted=true on terminator-resolve;
        // protocol errors reject via A2aError; timeouts via TTL guard.
        expect(reply.streamCompleted).toBe(true);
        expect(typeof reply.ackSeen).toBe("boolean");
        if (reply.text.trim().length > 0) {
          // eslint-disable-next-line no-console
          console.log(`[live-probe] vmaker-slave replied synchronously: ${reply.text.trim().slice(0, 80)}`);
        }
      } finally {
        await caller.drain();
        await caller.close();
      }
    },
  );
});

describe.skipIf(!LIVE)("live round-trip (local site fabric)", () => {
  it("connect → register → hb observed → prompt-echo stream → status", { timeout: 20_000 }, async () => {
    const owner = "probe";
    const name = loadOrCreateNonce();

    // 1. Agent side: connect + register in echo mode.
    const agentNc = await connectLocalFabric();
    const reg = await startSynadiaAgent({
      nc: agentNc,
      owner,
      name,
      session: `probe-${name}`,
      hbIntervalS: 1, // fast beats for the probe
      onPrompt: ({ raw, respond }) => {
        const text = new TextDecoder().decode(raw);
        respond(new TextEncoder().encode(JSON.stringify({ type: "status", data: "ack" })));
        respond(new TextEncoder().encode(JSON.stringify({ type: "response", data: `echo: ${JSON.parse(text).prompt}` })));
        respond(new Uint8Array(0));
      },
    });

    try {
      // 2. Caller side: fresh connection, discover via $SRV.INFO (spec §4.3).
      const caller = await connect({
        servers: "nats://127.0.0.1:14222",
        ...(resolveToken() ? { token: resolveToken() } : {}),
      });
      try {
        const svcm = new Svcm(caller);
        const client = svcm.client({ strategy: "stall", maxWait: 2000, maxMessages: 200 });
        const iter = await client.info("agents");
        const infos: ServiceInfo[] = [];
        for await (const si of iter) infos.push(si);
        const mine = infos.find(
          (si) => si.endpoints?.some((ep) => ep.subject === `agents.prompt.pi.${owner}.${name}`),
        );
        expect(mine, "registered service discoverable via $SRV.INFO.agents").toBeTruthy();
        expect(mine!.metadata?.protocol_version).toBe("0.3");

        // 3. Heartbeat observed on the fixed subject (§8.1) within ~2 beats.
        const hbWaiter = await new Promise<unknown>((resolve, reject) => {
          const sub = caller.subscribe(hbSubject(owner, name), { max: 1 });
          const t = setTimeout(() => reject(new Error("no heartbeat within 2.5s")), 2500);
          (async () => {
            for await (const m of sub) {
              clearTimeout(t);
              resolve(JSON.parse(new TextDecoder().decode(m.data)));
            }
          })().catch(reject);
        });
        expect(hbWaiter).toMatchObject({ agent: "pi", owner, instance_id: reg.instanceId });

        // 4. Prompt round-trip: subscribe inbox, publish envelope, read §6 stream.
        const inbox = caller.subscribe("probe.inbox.>");
        const stream = (async () => {
          const out: Array<{ bytes: number; body?: unknown }> = [];
          for await (const m of inbox) {
            if (m.data.byteLength === 0) return out;
            out.push({ bytes: m.data.byteLength, body: JSON.parse(new TextDecoder().decode(m.data)) });
          }
          return out;
        })();
        caller.publish(
          `agents.prompt.pi.${owner}.${name}`,
          new TextEncoder().encode(JSON.stringify({
            type: "a2a_request",
            id: "probe-1",
            from: { agent: "pi", owner: "probe-caller", name: "caller" },
            ts: new Date().toISOString(),
            prompt: "round trip please",
          })),
          { reply: "probe.inbox.reply1" },
        );
        await caller.flush();
        const chunks = await Promise.race([
          stream,
          new Promise<never>((_, rej) => setTimeout(() => rej(new Error("stream timeout")), 5000)),
        ]);
        expect(chunks[0]).toMatchObject({ body: { type: "status", data: "ack" } });
        expect(chunks.at(-1)).toMatchObject({ body: { type: "response", data: "echo: round trip please" } });

        // 5. §8.7 status endpoint: heartbeat-shaped reply.
        const st = await caller.request(statusSubject(owner, name), new Uint8Array(0), { timeout: 3000 });
        expect(JSON.parse(new TextDecoder().decode(st.data))).toMatchObject({
          agent: "pi",
          owner,
          instance_id: reg.instanceId,
        });
      } finally {
        await caller.drain();
        await caller.close();
      }
    } finally {
      await reg.stop();
      await agentNc.drain();
      await agentNc.close();
    }
  });
});
