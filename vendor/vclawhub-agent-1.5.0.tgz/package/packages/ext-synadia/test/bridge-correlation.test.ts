/**
 * bridge-correlation.test.ts — G14: one prompt in flight, so a turn end maps to
 * the inbound that caused it and a LOCAL operator turn never answers a remote caller.
 */

import { describe, expect, it } from "vitest";

import { createBridge, decodeChunk, type Chunk } from "../src/bridge.js";

function collector(): { respond: (d: Uint8Array) => void; chunks: () => Chunk[] } {
  const frames: Uint8Array[] = [];
  return {
    respond: (d) => frames.push(d),
    chunks: () => frames.filter((f) => f.length > 0).map(decodeChunk),
  };
}

const env = (prompt: string, owner = "o", name = "n") => ({ prompt, from: { owner, name } }) as never;

describe("session bridge — reply correlation (G14)", () => {
  it("only injects one prompt at a time; the second waits", () => {
    const sent: string[] = [];
    const b = createBridge((m) => sent.push(m));
    b.onInbound(env("first"), collector().respond);
    b.onInbound(env("second"), collector().respond);
    expect(sent).toHaveLength(1);
    expect(sent[0]).toContain("first");
    expect(b.pending()).toBe(2);
  });

  it("each turn end answers ITS OWN caller, in order", () => {
    const sent: string[] = [];
    const b = createBridge((m) => sent.push(m));
    const a = collector();
    const c = collector();
    b.onInbound(env("first"), a.respond);
    b.onInbound(env("second"), c.respond);

    b.onTurnEnd("answer-A");
    expect(a.chunks()[0]).toEqual({ type: "status", data: "ack" });
    expect(a.chunks()[1]).toEqual({ type: "response", data: "answer-A" });
    expect(sent).toHaveLength(2); // the second prompt is injected only now
    expect(sent[1]).toContain("second");
    expect(c.chunks()).toHaveLength(0);

    b.onTurnEnd("answer-B");
    expect(c.chunks()[1]).toEqual({ type: "response", data: "answer-B" });
    expect(b.pending()).toBe(0);
  });

  it("a LOCAL operator turn with nothing in flight answers nobody", () => {
    const sent: string[] = [];
    const b = createBridge((m) => sent.push(m));
    b.onTurnEnd("the operator typed this");
    expect(b.pending()).toBe(0);
    expect(sent).toHaveLength(0);
  });

  it("KNOWN LIMIT: a local turn typed while a remote prompt is in flight IS attributed to it", () => {
    // The host API carries no correlation id, so once a prompt is injected the
    // next turn_end is by definition its answer. Serialising (one in flight)
    // removes the two-callers-crossing defect; it cannot remove this one. The
    // reference's queue has the same constraint — it tracks queued/active, not
    // provenance of each turn.
    const b = createBridge(() => undefined);
    const a = collector();
    b.onInbound(env("remote"), a.respond);
    b.onTurnEnd("the operator's unrelated turn");
    expect(a.chunks()[1]).toEqual({ type: "response", data: "the operator's unrelated turn" });
  });

  it("echo mode answers immediately and never queues", () => {
    const b = createBridge(undefined);
    const a = collector();
    b.onInbound(env("hi"), a.respond);
    expect(a.chunks()[1]).toEqual({ type: "response", data: "echo: hi" });
    expect(b.pending()).toBe(0);
  });
});
