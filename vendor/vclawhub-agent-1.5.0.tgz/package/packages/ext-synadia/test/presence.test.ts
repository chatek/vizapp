/**
 * presence.test.ts — hb presence map (lane F): tracking, self-filter,
 * snapshot ordering, TTL sweep (fake timers), adaptive 3×interval TTL.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { NatsConnection } from "@nats-io/nats-core";

import { MockNats, flush } from "./mock-nats.js";
import {
  encodeHeartbeat,
  isStale,
  parseHbSubject,
  startPresenceMap,
  PRESENCE_TTL_MS,
} from "../src/presence.js";

const hb = (owner: string, name: string, extra: Record<string, unknown> = {}) => {
  const { subject, data } = encodeHeartbeat(owner, name, {
    instance_id: `INS-${name}`,
    interval_s: 30,
    ts: new Date().toISOString(),
    ...extra,
  });
  return { subject, data };
};

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-08-16T03:00:00Z"));
});

afterEach(() => {
  vi.useRealTimers();
});

describe("parseHbSubject", () => {
  it("parses agents.hb.pi.{owner}.{name}", () => {
    expect(parseHbSubject("agents.hb.pi.chance.worker-1")).toEqual({
      agent: "pi",
      owner: "chance",
      name: "worker-1",
    });
  });

  it("rejects foreign subjects", () => {
    expect(parseHbSubject("agents.prompt.pi.o.n")).toBeNull();
    expect(parseHbSubject("agents.hb.pi.o")).toBeNull(); // missing name
  });
});

describe("isStale (adaptive TTL)", () => {
  it("default window = 90s; 3×interval widens it", () => {
    const now = 1_000_000;
    expect(isStale({ lastSeenMs: now - 91_000, intervalS: 30 }, now)).toBe(true); // just past 90s
    expect(isStale({ lastSeenMs: now - 91_000, intervalS: 60 }, now)).toBe(false); // 3×60s = 180s
    expect(isStale({ lastSeenMs: now - 181_000, intervalS: 60 }, now)).toBe(true);
  });
});

describe("startPresenceMap (direct publishes)", () => {
  it("tracks + self-filters + orders freshest first", async () => {
    const nc = new MockNats() as unknown as NatsConnection;
    const pm = startPresenceMap(nc, { self: { owner: "me", name: "self" } });

    const m1 = hb("chance", "w1");
    nc.publish(m1.subject, m1.data);

    vi.advanceTimersByTime(5_000);
    const m2 = hb("chance", "w2");
    nc.publish(m2.subject, m2.data); // 5s fresher

    const mSelf = hb("me", "self");
    nc.publish(mSelf.subject, mSelf.data); // must be filtered

    await flush();

    const snap = pm.snapshot();
    expect(snap.map((e) => e.name)).toEqual(["w2", "w1"]); // freshest first, no self
    expect(snap[0]!.owner).toBe("chance");
    expect(snap[0]!.instanceId).toBe("INS-w2");
    expect(snap[0]!.intervalS).toBe(30);
    expect(snap[0]!.elapsedMs).toBeGreaterThanOrEqual(0);
    pm.stop();
  });

  it("TTL sweep evicts stale agents on the sweep cadence (fake timers)", async () => {
    const nc = new MockNats() as unknown as NatsConnection;
    const pm = startPresenceMap(nc, { sweepMs: 5_000 });

    const m = hb("chance", "w1", { ts: new Date(Date.now()).toISOString() });
    nc.publish(m.subject, m.data);
    await flush();
    expect(pm.snapshot().length).toBe(1);

    // Advance past the 90s TTL; the 5s sweep timer fires and evicts.
    vi.advanceTimersByTime(95_000);
    await flush();

    expect(pm.snapshot()).toEqual([]); // swept
    expect(pm.snapshot({ includeStale: true })).toEqual([]); // gone from the map entirely
    pm.stop();
  });

  it("snapshot hides-but-keeps stale entries before the sweep fires (includeStale)", async () => {
    const nc = new MockNats() as unknown as NatsConnection;
    const pm = startPresenceMap(nc, { sweepMs: 60_000 }); // slow sweep

    const m = hb("chance", "w1");
    nc.publish(m.subject, m.data);
    await flush();

    const later = Date.now() + 91_000;
    expect(pm.snapshot({ nowMs: later })).toEqual([]); // hidden lazily
    expect(pm.snapshot({ nowMs: later, includeStale: true }).length).toBe(1); // still there
    pm.stop();
  });

  it("malformed payloads and foreign subjects are ignored", async () => {
    const nc = new MockNats() as unknown as NatsConnection;
    const pm = startPresenceMap(nc);

    nc.publish("agents.hb.pi.chance.w1", new TextEncoder().encode("not-json"));
    nc.publish("agents.hb.pi.o", new TextEncoder().encode("{}")); // 4 tokens — parseHbSubject null
    nc.publish("agents.hb.pi.chance.w2", new TextEncoder().encode(JSON.stringify({ no_ts: true })));
    await flush();

    // w2 still tracked (no ts → receipt time fallback); w1/w-foreign dropped
    const names = pm.snapshot().map((e) => e.name);
    expect(names).toEqual(["w2"]);
    pm.stop();
  });
});

describe("PRESENCE_TTL_MS contract", () => {
  it("default is 90s (3× the 30s default hb interval)", () => {
    expect(PRESENCE_TTL_MS).toBe(90_000);
  });
});
