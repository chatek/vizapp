# @vclawhub/ext-synadia

Synadia-native pi extension: connects to the LOCAL site fabric
(127.0.0.1:14222 token auth) and registers per Synadia Agent Protocol v0.3 —
Micro service `agents` (prompt + status endpoints, queue group `agents`),
fixed-subject heartbeat, envelope via `@vclawhub/protocol-core`.

Hosted on [jsr.io/@vclawhub/ext-synadia](https://jsr.io/@vclawhub/ext-synadia).
See `docs/UNIFIED_A2A_FABRIC.md` §4.
