/**
 * registration.ts — Synadia v0.3 agent registration over @nats-io/services
 * (Micro). One function: start the 'agents' Micro service with the spec's
 * required endpoints + metadata, plus the §8 heartbeat publisher.
 *
 * Spec map (Synadia Agent Protocol v0.3, core-protocol.md):
 *   §3.1  service name MUST be "agents"; version = harness semver
 *   §3.2  service metadata: agent / owner / session? / protocol_version
 *   §2.1  prompt endpoint metadata: max_payload / attachments_ok
 *   §3.3  prompt endpoint queue group MUST be "agents"
 *         ("addEndpoint('prompt', { subject, handler, queue: 'agents', metadata })")
 *   §8.7  status endpoint: queue "agents", replies §8.3-shaped payload
 *   §8.1  hb subject protocol-fixed agents.hb.{agent}.{owner}.{name} — NO queue
 *   §8.2  heartbeats begin AFTER registration; interval in payload (interval_s)
 *   §8.3  payload: {agent, owner, session?, instance_id, ts, interval_s}
 *
 * C3 (UNIFIED_A2A_FABRIC.md §7): default subjects only — built via ./subjects.
 *
 * Library version: @nats-io/services 3.4.0 (verified in this package's
 * node_modules; NOT previously in agent-sdk root deps — added here).
 */

import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm, type Service, type ServiceMsg } from "@nats-io/services";
import { hbSubject, promptSubject, statusSubject } from "./subjects.js";
import { TERMINATOR } from "./bridge.js";

export const PROTOCOL_VERSION = "0.3";
/** Harness semver surfaced in $SRV.INFO (spec §3.1 — harness, not protocol). */
export const EXT_SYNADIA_VERSION = "0.1.0";

export const HB_INTERVAL_S_DEFAULT = 30; // spec §8.2 recommended default

/** Fresh §8.3-shaped payload (also the §8.7 status reply body). */
export function heartbeatPayload(args: {
  owner: string;
  session?: string;
  instanceId: string;
  intervalS: number;
}): Record<string, unknown> {
  const p: Record<string, unknown> = {
    agent: "pi",
    owner: args.owner,
    instance_id: args.instanceId,
    ts: new Date().toISOString(),
    interval_s: args.intervalS,
  };
  if (args.session !== undefined) p.session = args.session;
  return p;
}

export interface OnPromptArgs {
  /** Decoded request payload — JSON object bytes (envelope) or raw text. */
  raw: Uint8Array;
  /** NATS reply subject (the §6 chunk stream goes here). */
  reply: string;
  /** Send the §6 response stream: ack → response chunk(s) → empty terminator. */
  respond: (data: Uint8Array) => void;
  /**
   * Refuse the request per §9.3: a message carrying `Nats-Service-Error-Code`
   * from the §9.2 taxonomy, FOLLOWED BY the empty terminator. Callers must not
   * publish anything else on the reply subject afterwards.
   */
  respondError: (code: number, description: string) => void;
}

/**
 * §3.1: `version` is the HARNESS semver, never the protocol's and not this
 * bundle's. Hosts pass their own; otherwise we fall back to ours and say so in
 * the docs (a conformant caller reads it but must not infer capabilities).
 */
export function serviceVersion(harnessVersion?: string): string {
  const v = harnessVersion?.trim();
  return v && v.length > 0 ? v : EXT_SYNADIA_VERSION;
}

/**
 * §2.1 prompt-endpoint metadata. `attachments_ok` is `false` unless the host
 * actually consumes attachments — declaring `true` while ignoring them is a
 * false capability advertisement (§5.2) and §12 requires the 400 instead.
 */
export function promptEndpointMetadata(opts: { maxPayload?: string; attachmentsOk?: boolean } = {}): {
  max_payload: string;
  attachments_ok: string;
} {
  return {
    max_payload: opts.maxPayload ?? "1MB",
    attachments_ok: String(opts.attachmentsOk ?? false),
  };
}

export interface RegistrationHandle {
  service: Service;
  instanceId: string;
  /** Stop heartbeat + close the service (idempotent-ish; Svcm close). */
  stop: () => Promise<void>;
}

/**
 * Register this agent on the local site fabric per Synadia v0.3.
 *
 * `onPrompt` receives raw request bytes + the §6 stream responder; wiring it
 * to the pi session bridge (or an echo fallback) is the caller's job —
 * see ./bridge.ts and ./index.ts.
 */
export async function startSynadiaAgent(opts: {
  nc: NatsConnection;
  owner: string;
  name: string;
  session?: string;
  hbIntervalS?: number;
  maxPayload?: string;
  attachmentsOk?: boolean;
  /**
   * §3.1: `version` is the semver of the HARNESS implementation (e.g. the pi/omp
   * build), not this extension's and not the protocol's. Hosts that know their
   * own version pass it; otherwise we fall back to this bundle's version.
   */
  harnessVersion?: string;
  onPrompt: (args: OnPromptArgs) => void;
}): Promise<RegistrationHandle> {
  const intervalS = opts.hbIntervalS ?? HB_INTERVAL_S_DEFAULT;

  const svc = await new Svcm(opts.nc).add({
    name: "agents",
    version: serviceVersion(opts.harnessVersion),
    description: "ext-synadia — pi extension on the local site fabric",
    metadata: {
      agent: "pi",
      owner: opts.owner,
      ...(opts.session ? { session: opts.session } : {}),
      protocol_version: PROTOCOL_VERSION,
    },
  });

  // §2.1 + §3.3: prompt endpoint, default subject, queue group "agents".
  svc.addEndpoint("prompt", {
    subject: promptSubject(opts.owner, opts.name),
    queue: "agents",
    metadata: promptEndpointMetadata({ maxPayload: opts.maxPayload, attachmentsOk: opts.attachmentsOk }),
    handler: (_err: Error | null, msg: ServiceMsg) => {
      opts.onPrompt({
        raw: msg.data,
        reply: msg.reply || "",
        respond: (data: Uint8Array) => {
          msg.respond(data);
        },
        respondError: (code: number, description: string) => {
          msg.respondError(code, description);
          msg.respond(TERMINATOR); // §9.3: error-headered message, then the terminator
        },
      });
    },
  });

  // §8.7: status endpoint — reply = freshly built §8.3 payload.
  // (instanceId captured once from the synchronous info() — ServiceIdentity.id.)
  const instanceId = svc.info().id;
  svc.addEndpoint("status", {
    subject: statusSubject(opts.owner, opts.name),
    queue: "agents",
    handler: (_err: Error | null, msg: ServiceMsg) => {
      msg.respond(
        new TextEncoder().encode(
          JSON.stringify(
            heartbeatPayload({
              owner: opts.owner,
              session: opts.session,
              instanceId,
              intervalS,
            }),
          ),
        ),
      );
    },
  });

  // §8.2 SHOULD: heartbeats only after registration is complete (we're past
  // `add` here). §8.1: fixed subject, pub/sub — no queue group.
  const hb = heartbeatPayload({
    owner: opts.owner,
    session: opts.session,
    instanceId,
    intervalS,
  });
  const enc = new TextEncoder();
  const pub = () => {
    hb.ts = new Date().toISOString();
    opts.nc.publish(hbSubject(opts.owner, opts.name), enc.encode(JSON.stringify(hb)));
  };
  pub(); // first beat immediately (bootstrap trackers, §8.5 caller side)
  const timer = setInterval(pub, intervalS * 1000);

  return {
    service: svc,
    instanceId,
    stop: async () => {
      clearInterval(timer);
      try {
        await svc.stop();
      } catch { /* already stopped */ }
    },
  };
}
