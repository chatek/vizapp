/**
 * presence.ts — hb-subscription presence map (KV-free, lane F).
 *
 * Subscribes `agents.hb.>` (the site-mesh visibility verb — SITE_MESH sub
 * allows it per UNIFIED_A2A_FABRIC.md §3; C3: hb is the one protocol-fixed
 * subject), tracks per-agent lastSeen from §8.3 heartbeat payloads
 * (registration.ts heartbeatPayload: {agent, owner, instance_id, ts,
 * interval_s, session?}), and exposes snapshot() with elapsed.
 *
 * Model per pi-a2a's roster lastSeen semantics (A2A/pi-a2a/src/a2a/roster.ts:50
 * lastSeen field; :365-370 upsert refreshes it on every sighting) — but this
 * skeleton is a plain in-memory map with a TTL sweep: no roster file, no KV.
 *
 * TTL: an agent is stale when now − lastSeen > max(DEFAULT_TTL_MS, 3 × its
 * interval_s) — the 3× slack matches discovery-poll churn tolerance
 * (pi-a2a index.ts:45-51's rationale: point-in-time churn must not purge).
 */

import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { hbSubject, AGENT_PARTICLE } from "./subjects.js";

/** Default staleness window (3× the 30s default hb interval — registration.ts). */
export const PRESENCE_TTL_MS = 90_000;
/** Sweep cadence. */
export const PRESENCE_SWEEP_MS = 30_000;

export interface PresenceEntry {
  owner: string;
  name: string;
  agent: string;
  instanceId?: string;
  intervalS?: number;
  session?: string;
  /** Milliseconds since the last heartbeat (at snapshot time). */
  elapsedMs: number;
  /** ISO timestamp of the last heartbeat (payload ts, else receipt time). */
  lastSeenIso: string;
  lastSeenMs: number;
}

export interface PresenceSnapshotOptions {
  /** Include stale entries (default false — stale are swept/hidden). */
  includeStale?: boolean;
  /** Override "now" (tests). */
  nowMs?: number;
}

export interface PresenceMapHandle {
  /** Live entries (stale hidden unless includeStale), freshest first. */
  snapshot(opts?: PresenceSnapshotOptions): PresenceEntry[];
  /** Stop sweeping + unsubscribe (idempotent). */
  stop(): void;
}

/** Parse `agents.hb.{agent}.{owner}.{name}` → parts, or null when foreign. */
export function parseHbSubject(subject: string): { agent: string; owner: string; name: string } | null {
  const parts = subject.split(".");
  if (parts.length !== 5 || parts[0] !== "agents" || parts[1] !== "hb") return null;
  return { agent: parts[2], owner: parts[3], name: parts[4] };
}

interface Tracked {
  owner: string;
  name: string;
  agent: string;
  instanceId?: string;
  intervalS?: number;
  session?: string;
  lastSeenMs: number;
  lastSeenIso: string;
}

/** Stale test (unit-exported for tests): max(defaultTtl, 3×interval) window. */
export function isStale(entry: { lastSeenMs: number; intervalS?: number }, nowMs: number, defaultTtlMs = PRESENCE_TTL_MS): boolean {
  const ttl = Math.max(defaultTtlMs, (entry.intervalS ?? 0) * 3 * 1000);
  return nowMs - entry.lastSeenMs > ttl;
}

/**
 * Start the presence map on a connected fabric client.
 *
 * `self` is filtered out (an agent's own heartbeat is not "presence").
 */
export function startPresenceMap(
  nc: NatsConnection,
  opts: { self?: { owner: string; name: string }; ttlMs?: number; sweepMs?: number } = {},
): PresenceMapHandle {
  const self = opts.self;
  const ttlDefault = opts.ttlMs ?? PRESENCE_TTL_MS;
  const byKey = new Map<string, Tracked>();
  const enc = new TextDecoder();

  const sub: Subscription = nc.subscribe("agents.hb.>");
  (async () => {
    for await (const msg of sub) {
      const parts = parseHbSubject(msg.subject);
      if (!parts) continue;
      if (self && parts.owner === self.owner && parts.name === self.name) continue;
      let payload: Record<string, unknown> = {};
      try {
        payload = JSON.parse(enc.decode(msg.data)) as Record<string, unknown>;
      } catch {
        continue; // malformed hb — ignore
      }
      const ts = typeof payload.ts === "string" ? Date.parse(payload.ts) : NaN;
      const now = Date.now();
      const lastSeenMs = Number.isFinite(ts) ? ts : now;
      byKey.set(`${parts.owner}.${parts.name}`, {
        owner: parts.owner,
        name: parts.name,
        agent: parts.agent,
        instanceId: typeof payload.instance_id === "string" ? payload.instance_id : undefined,
        intervalS: typeof payload.interval_s === "number" ? payload.interval_s : undefined,
        session: typeof payload.session === "string" ? payload.session : undefined,
        lastSeenMs,
        lastSeenIso: new Date(lastSeenMs).toISOString(),
      });
    }
  })().catch(() => { /* subscription closed */ });

  const sweep = () => {
    const now = Date.now();
    for (const [k, e] of byKey) {
      if (isStale(e, now, ttlDefault)) byKey.delete(k);
    }
  };
  const timer = setInterval(sweep, opts.sweepMs ?? PRESENCE_SWEEP_MS);

  return {
    snapshot(snapOpts: PresenceSnapshotOptions = {}): PresenceEntry[] {
      const now = snapOpts.nowMs ?? Date.now();
      const out: PresenceEntry[] = [];
      for (const e of byKey.values()) {
        if (!snapOpts.includeStale && isStale(e, now, ttlDefault)) continue;
        out.push({ ...e, elapsedMs: Math.max(0, now - e.lastSeenMs) });
      }
      out.sort((a, b) => a.lastSeenMs - b.lastSeenMs);
      return out.reverse(); // freshest first
    },
    stop(): void {
      clearInterval(timer);
      try { sub.unsubscribe(); } catch { /* already closed */ }
      byKey.clear();
    },
  };
}

/** Convenience: build an hb publish (tests + host smoke). */
export function encodeHeartbeat(subjectOwner: string, subjectName: string, payload: Record<string, unknown>): { subject: string; data: Uint8Array } {
  return {
    subject: hbSubject(subjectOwner, subjectName),
    data: new TextEncoder().encode(JSON.stringify({ agent: AGENT_PARTICLE, ...payload })),
  };
}
