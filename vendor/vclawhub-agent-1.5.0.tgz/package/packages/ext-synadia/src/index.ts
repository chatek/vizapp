/**
 * ext-synadia — pi extension for the LOCAL site fabric (Synadia v0.3).
 *
 * The lighter cousin of pi-a2a's extension (A2A/pi-a2a/src/index.ts — the
 * full buddy/roster/panel/bridge stack): this skeleton does exactly four
 * things per the build-sprint lane D dispatch —
 *   1. connect to the local site fabric (127.0.0.1:14222 token auth)
 *   2. register the Synadia v0.3 Micro service 'agents' (prompt + status,
 *      queue group "agents") + §8 heartbeat
 *   3. bridge inbound prompts into the pi session and stream the turn_end
 *      reply back as a §6 chunk stream (shared bridge pattern)
 *   4. identity from the INDEPENDENT ext-synadia nonce chain (ruling Q1)
 *
 * OUT OF SCOPE (skeleton; documented, not wired): pi-a2a's buddy protocol,
 * roster/KV presence, offline queue, TUI panel, group messaging,
 * mid-stream §7 queries, JetStream. The host type below is a structural
 * slice of @earendil-works/pi-coding-agent's ExtensionAPI (0.82.1,
 * dist/index.d.ts:7) — the real object satisfies it; no host dep needed.
 *
 * Env: SYNADIA_LOCAL_NATS_URL · SYNADIA_LOCAL_NATS_TOKEN · SYNADIA_OWNER ·
 *      SYNADIA_SESSION · SYNADIA_HB_INTERVAL_S · EXT_SYNADIA_NONCE ·
 *      SYNADIA_AUTOSTART=0 to opt out.
 */

import { loadOrCreateNonce } from "./identity.js";
import { connectLocalFabric, localNatsUrl } from "./connect.js";
import { startSynadiaAgent, type RegistrationHandle } from "./registration.js";
import { createBridge, validateInbound, decodeInbound, replyText, a2aSend, A2aError, type SessionBridge } from "./bridge.js";
import { discoverAgents } from "./discovery.js";
import { startPresenceMap, type PresenceMapHandle } from "./presence.js";
import { BuddyStore, startBuddyProtocol, type BuddyProtocolHandle } from "./buddy.js";

/** Structural slice of the host's ExtensionAPI (see header note). */
interface PiExtensionHost {
  sendUserMessage(msg: string): unknown;
  on(event: string, cb: (...args: never[]) => void): unknown;
  registerCommand(name: string, opts: {
    description: string;
    handler: (args: string, ctx: unknown) => Promise<void> | void;
  }): unknown;
}

let nc: import("@nats-io/nats-core").NatsConnection | undefined;
let reg: RegistrationHandle | undefined;
let bridge: SessionBridge | undefined;
let presence: PresenceMapHandle | undefined;
let buddy: BuddyProtocolHandle | undefined;
let buddyStore: BuddyStore | undefined;

function state(): string {
  if (!nc) return "disconnected";
  if (nc.isClosed()) return "closed";
  return reg ? `registered (instance ${reg.instanceId})` : "connected (no registration)";
}

async function start(pi: PiExtensionHost): Promise<void> {
  if (nc) return; // already up (session reload guard)

  const owner = process.env.SYNADIA_OWNER?.trim() || "local";
  const session = process.env.SYNADIA_SESSION?.trim() || undefined;
  const name = loadOrCreateNonce(); // Q1: independent nonce chain

  bridge = createBridge((msg) => {
    void pi.sendUserMessage(msg);
  });

  nc = await connectLocalFabric();

  reg = await startSynadiaAgent({
    nc,
    owner,
    name,
    session,
    hbIntervalS: Number(process.env.SYNADIA_HB_INTERVAL_S) || undefined,
    // §5.2 honesty: this extension consumes no attachments, so it declares none
    // and refuses any (§12 → 400) instead of accepting and dropping them.
    attachmentsOk: false,
    maxPayload: process.env.SYNADIA_MAX_PAYLOAD?.trim() || undefined,
    // §3.1: the harness's own semver, when the host knows it (VCLAW_HARNESS_VERSION).
    harnessVersion: process.env.VCLAW_HARNESS_VERSION?.trim() || undefined,
    onPrompt: ({ raw, respond, respondError }) => {
      const verdict = validateInbound(raw, { maxPayload: process.env.SYNADIA_MAX_PAYLOAD?.trim() || undefined, attachmentsOk: false });
      if (!verdict.ok) {
        respondError(verdict.code, verdict.message); // §9.3: error headers, then terminator
        return;
      }
      if (!bridge) return;
      bridge.onInbound(decodeInbound(raw), respond);
    },
  });

  // Lane F: presence map (agents.hb.> sub) + buddy protocol (own verbs),
  // both scoped to the session — stopped in stop().
  buddyStore = new BuddyStore();
  presence = startPresenceMap(nc, { self: { owner, name } });
  buddy = startBuddyProtocol(nc, {
    self: { owner, name },
    store: buddyStore,
    onRequest: (from, reply) => {
      console.error(`[ext-synadia] buddy request from ${from.owner}/${from.name} — auto-accepting`);
      reply.accept(); // skeleton: accept inbound (same-site mesh trust); host dialogs later
    },
    onAccept: (from) => {
      console.error(`[ext-synadia] buddy accepted: ${from.owner}/${from.name}`);
    },
    onReject: (from) => {
      console.error(`[ext-synadia] buddy rejected by ${from.owner}/${from.name}`);
    },
  });

  console.error(`[ext-synadia] online: ${owner}/${name} @ ${localNatsUrl()} (${state()})`);
}

async function stop(): Promise<void> {
  try { buddy?.stop(); } catch { /* */ } buddy = undefined;
  try { presence?.stop(); } catch { /* */ } presence = undefined;
  try { await reg?.stop(); } catch { /* */ } reg = undefined;
  bridge = undefined;
  if (nc) {
    try { await nc.drain(); } catch { /* */ }
    try { await nc.close(); } catch { /* */ }
    nc = undefined;
  }
}

export default function extSynadia(pi: PiExtensionHost): void {
  pi.on("session_start", () => {
    if (process.env.SYNADIA_AUTOSTART === "0") return;
    start(pi).catch((e) => {
      console.error(`[ext-synadia] start failed: ${(e as Error).message}`);
    });
  });

  pi.on("session_shutdown", () => {
    void stop();
  });

  pi.on("turn_end", (event: unknown) => {
    if (!bridge) return;
    const text = replyText((event as { message?: unknown }).message);
    bridge.onTurnEnd(text);
  });

  pi.registerCommand("synadia-buddies", {
    description: "ext-synadia: list buddies (with presence) or send a buddy request: /synadia-buddies [add <owner> <name>]",
    handler: async (args: string) => {
      const parts = args.trim().split(/\s+/).filter(Boolean);
      if (parts[0] === "add") {
        const [, owner, name] = parts;
        if (!owner || !name) {
          console.error("[ext-synadia] usage: /synadia-buddies add <owner> <name>");
          return;
        }
        if (!buddy) {
          console.error("[ext-synadia] not connected — session not started");
          return;
        }
        buddy.request(owner, name);
        console.error(`[ext-synadia] buddy request sent to ${owner}/${name}`);
        return;
      }
      const list = buddyStore?.list() ?? [];
      if (list.length === 0) {
        console.error("[ext-synadia] no buddies — add one: /synadia-buddies add <owner> <name>");
        return;
      }
      const snap = presence?.snapshot() ?? [];
      for (const b of list) {
        const live = snap.find((e) => e.owner === b.owner && e.name === b.name);
        const ago = live ? ` · hb ${Math.round(live.elapsedMs / 1000)}s ago` : " · no recent hb";
        console.error(`  ${b.owner}/${b.name} (buddy since ${b.addedAt})${ago}`);
      }
    },
  });

  pi.registerCommand("synadia-status", {
    description: "ext-synadia: local site fabric registration status",
    handler: async () => {
      console.error(`[ext-synadia] ${state()}; pending replies: ${bridge?.pending() ?? 0}`);
    },
  });

  // /synadia-send <name> <prompt…> — discover the target by name (§4.3),
  // send via a2aSend (subject VERBATIM from discovery), report the §6 reply.
  pi.registerCommand("synadia-send", {
    description: "ext-synadia: send an A2A prompt to a discovered agent by name",
    handler: async (args: string) => {
      const parts = args.trim().split(/\s+/);
      const name = parts[0];
      const prompt = parts.slice(1).join(" ");
      if (!name || !prompt) {
        console.error("[ext-synadia] usage: /synadia-send <agent-name> <prompt…>");
        return;
      }
      let clientNc = nc;
      if (!clientNc || clientNc.isClosed()) {
        try {
          clientNc = await connectLocalFabric();
        } catch (e) {
          console.error(`[ext-synadia] connect failed: ${(e as Error).message}`);
          return;
        }
      }
      try {
        const agents = await discoverAgents(clientNc);
        const target = agents.find((a) => a.descriptor.name === name);
        if (!target || !target.promptEndpoint) {
          console.error(
            `[ext-synadia] agent "${name}" not found (discovered: ${agents.map((a) => a.descriptor.name).join(", ") || "none"})`,
          );
          return;
        }
        console.error(`[ext-synadia] → ${target.promptEndpoint.subject} (${target.instanceId})`);
        const reply = await a2aSend(
          clientNc,
          { descriptor: target.descriptor, promptEndpoint: target.promptEndpoint },
          prompt,
          { from: { agent: "pi", owner: process.env.SYNADIA_OWNER?.trim() || "local", name: loadOrCreateNonce() } },
        );
        console.error(`[ext-synadia] ← ${reply.ackSeen ? "ack " : ""}${reply.text}`);
      } catch (e) {
        console.error(`[ext-synadia] send failed: ${e instanceof A2aError ? `(${e.code ?? "?"}) ` : ""}${(e as Error).message}`);
      }
    },
  });
}
