/**
 * bridge.ts — inbound Synadia prompt → pi session, and the reply stream back.
 *
 * The shared bridge pattern (agent-sdk/src/pi-extension/index.ts:191-204 +
 * 243-260, the /vchat extension): inbound A2A prompt is injected into the pi
 * session via `sessionPi.sendUserMessage`; the NEXT turn_end captures the
 * assistant reply and publishes it to the pending reply subject (FIFO —
 * one a2a at a time per session). ext-synadia is the Synadia-grammar cousin:
 * the outbound side is a §6 chunk stream (ack → response → empty terminator)
 * instead of a single JSON response message.
 *
 * Envelope: @vclawhub/protocol-core parseCore — Synadia §5 shape with
 * §5.6-tolerated extension fields, camelCase canonical / snake_case
 * tolerated on read. Plain-UTF-8 shorthand (§5.1) is decoded here: protocol-
 * core assumes JSON, so the fallback synthesizes {type, prompt}.
 */

import { randomUUID } from "node:crypto";
import { parseCore, serializeCore, type CoreEnvelope } from "@jsr/vclawhub__protocol-core";
import { parseMaxPayload } from "./discovery.js";

/** Decode an inbound request payload (§5.1: JSON envelope OR plain text). */
export function decodeInbound(raw: Uint8Array): CoreEnvelope {
  const text = new TextDecoder().decode(raw);
  const trimmed = text.trim();
  if (trimmed.startsWith("{")) {
    try {
      return parseCore(JSON.parse(trimmed));
    } catch {
      // fall through to plain-text shorthand
    }
  }
  return {
    type: "a2a_request",
    id: "",
    from: {},
    ts: new Date().toISOString(),
    prompt: text,
  };
}

/** Result of the §12 prompt check: pass, or a §9.2-coded refusal. */
export type InboundVerdict = { ok: true } | { ok: false; code: number; message: string };

const B64_RE = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate an inbound prompt BEFORE it reaches the bridge (§12 + §9.2).
 *
 * ORDER MATTERS: `decodeInbound` deliberately falls back to plain-text
 * shorthand (§5.1), so a malformed JSON envelope would otherwise be accepted
 * as a prompt instead of refused. A refusal is published §9.3-shaped by the
 * caller — error-headered message, then the empty terminator.
 */
export function validateInbound(
  raw: Uint8Array,
  opts: { maxPayload?: string; attachmentsOk?: boolean } = {},
): InboundVerdict {
  if (raw.length === 0) return { ok: false, code: 400, message: "empty payload" };

  const limit = parseMaxPayload(opts.maxPayload ?? "1MB");
  if (limit !== undefined && raw.length > limit) {
    return { ok: false, code: 400, message: `request exceeds max_payload (${raw.length} > ${limit} bytes)` };
  }

  const trimmed = new TextDecoder().decode(raw).trim();
  if (!trimmed.startsWith("{")) return { ok: true }; // §5.1 plain-text shorthand is valid input

  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    return { ok: false, code: 400, message: "malformed envelope: invalid JSON" };
  }

  const attachments = (parsed as { attachments?: unknown } | null)?.attachments;
  if (Array.isArray(attachments) && attachments.length > 0) {
    if (opts.attachmentsOk === false) {
      return { ok: false, code: 400, message: "attachments not accepted (attachments_ok=false)" };
    }
    for (const a of attachments) {
      const content = (a as { content?: unknown } | null)?.content;
      if (typeof content !== "string" || content.length === 0 || !B64_RE.test(content)) {
        return { ok: false, code: 400, message: "invalid base64 in attachment" };
      }
    }
  }
  return { ok: true };
}

/** Extract the reply text from a turn_end-ish event message (host shape varies). */
export function replyText(message: unknown): string {
  if (message == null) return "";
  const m = message as { content?: unknown; text?: unknown };
  if (typeof m.content === "string") return m.content;
  if (typeof m.text === "string") return m.text;
  if (Array.isArray(m.content)) {
    return m.content
      .map((b) =>
        typeof b === "string"
          ? b
          : (b as { text?: unknown })?.text != null && typeof (b as { text?: unknown }).text === "string"
            ? String((b as { text: string }).text)
            : "",
      )
      .join("");
  }
  return String(message);
}

// ── §6 chunk stream encoder ─────────────────────────────────────────────

export type Chunk =
  | { type: "status"; data: string } // §6.4 ("ack" first, before any work)
  | { type: "response"; data: string | { text: string } }; // §6.3

export function encodeChunk(chunk: Chunk): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(chunk));
}

/** Decode a §6 chunk (tests / callers consuming our own stream). */
export function decodeChunk(data: Uint8Array): Chunk {
  return JSON.parse(new TextDecoder().decode(data)) as Chunk;
}

/** §6.5 terminator: zero-byte body, no headers. */
export const TERMINATOR = new Uint8Array(0);

/** Drive a full §6 stream for a completed reply (ack + one response + terminator). */
export function emitReplyStream(
  respond: (data: Uint8Array) => void,
  text: string,
): void {
  respond(encodeChunk({ type: "status", data: "ack" })); // §6.4: MUST be first
  respond(encodeChunk({ type: "response", data: text })); // §6.3
  respond(TERMINATOR); // §6.5
}

// ── §6 outbound: discovery-driven prompt send (a2aSend) ─────────────────

/** Receiver-side TTL cap (pi-a2a protocol.ts:112 — TTL_MAX_S = 300). */
export const TTL_MAX_S = 300;
/** Per-stream inactivity timeout (spec §6.6 recommended default). */
export const INACTIVITY_TIMEOUT_MS_DEFAULT = 60_000;
/** Prompt byte size above which we always send the full JSON envelope. */
const SHORTHAND_MAX_LEN = 80;

/** Assembled outcome of one §6 response stream. */
export interface A2aSendResult {
  /** Concatenated `response` chunk text (§6.3 — publication order). */
  text: string;
  /** True iff at least one §6.4 ack-shaped chunk arrived. */
  ackSeen: boolean;
  /** Total non-terminator chunks consumed (incl. unknown/skipped types). */
  chunkCount: number;
  /** True iff the stream resolved via the §6.5 terminator (always true on
   *  resolve — timeouts/§9 errors REJECT instead; exposed so live tests can
   *  assert mechanics independent of target text delivery). */
  streamCompleted: boolean;
}

export class A2aError extends Error {
  constructor(
    message: string,
    public code: number | undefined,
  ) {
    super(message);
  }
}

/** Build the outbound request payload (§5.1: plain-text shorthand OR JSON envelope). */
export function buildOutboundPayload(
  myDescriptor: CoreEnvelope["from"],
  prompt: string,
  opts?: { attachments?: { filename: string; content: string }[]; forceEnvelope?: boolean },
): { payload: Uint8Array; shorthand: boolean } {
  const enc = new TextEncoder();
  const oneLiner =
    !opts?.forceEnvelope &&
    !opts?.attachments?.length &&
    prompt.length <= SHORTHAND_MAX_LEN &&
    !prompt.includes("\n");
  if (oneLiner) {
    return { payload: enc.encode(prompt), shorthand: true };
  }
  const core: CoreEnvelope = {
    type: "a2a_request",
    id: randomUUID().slice(0, 8),
    from: myDescriptor,
    ts: new Date().toISOString(),
    prompt,
    ...(opts?.attachments?.length ? { attachments: opts.attachments } : {}),
    ttlS: TTL_MAX_S,
  };
  return { payload: enc.encode(JSON.stringify(serializeCore(core))), shorthand: false };
}

/** Assemble a §6 chunk stream into a reply. Exported for the §6.x tolerant reads. */
export function consumeChunk(
  acc: { text: string; ackSeen: boolean; chunkCount: number },
  msg: { data: Uint8Array; headers?: unknown },
): void {
  // §9 error headers surface as micro error headers on a chunk-bearing msg.
  // NOTE: header check MUST precede the empty-data skip — error replies
  // (respondError) are EMPTY-BODIED with headers; checking data-length first
  // swallows the error and the stream resolves empty (integration catch).
  const h = msg.headers as { get?: (k: string) => string | undefined } | undefined;
  const errCode = h?.get?.("Nats-Service-Error-Code");
  const errMsg = h?.get?.("Nats-Service-Error");
  if (errMsg !== undefined) {
    throw new A2aError(errMsg, errCode !== undefined ? Number(errCode) : undefined);
  }
  if (msg.data.byteLength === 0) return; // caller handles terminator separately
  acc.chunkCount++;
  let chunk: { type?: string; data?: unknown; status?: unknown };
  try {
    chunk = JSON.parse(new TextDecoder().decode(msg.data));
  } catch {
    return; // §6.2: response side is JSON-only; tolerate and skip (defensive)
  }
  if (chunk.type === "response") {
    // §6.3: data is bare string OR {text, attachments?} — both accepted
    const d = chunk.data;
    if (typeof d === "string") acc.text += d;
    else if (d !== null && typeof d === "object" && typeof (d as { text?: unknown }).text === "string") {
      acc.text += (d as { text: string }).text;
    }
  } else if (chunk.type === "status") {
    // §6.4: {type:"status", data:"ack"}. pi-a2a's agent-service@0.5.2 emits
    // {type:"status", status:"ack"} (dist/index.js:425) and re-sends it as a
    // keepalive — tolerate both shapes, idempotently.
    const v = chunk.data ?? chunk.status;
    if (v === "ack") acc.ackSeen = true;
  }
  // §6.6: unknown chunk types silently ignored
}

/**
 * Send a prompt to a DISCOVERED agent and assemble its §6 reply stream.
 *
 * §4.3: the target's endpoint subject is used VERBATIM from discovery —
 * never constructed from identity. §5.4: max_payload enforced client-side.
 * §6.6: per-stream inactivity timeout + overall TTL guard (TTL_MAX_S).
 */
export async function a2aSend(
  nc: import("@nats-io/nats-core").NatsConnection,
  target: {
    descriptor: CoreEnvelope["from"];
    promptEndpoint: { subject: string; maxPayload?: string; attachmentsOk?: boolean };
  },
  prompt: string,
  opts?: {
    from?: CoreEnvelope["from"];
    attachments?: { filename: string; content: string }[];
    forceEnvelope?: boolean;
    inactivityTimeoutMs?: number;
    overallTimeoutMs?: number;
  },
): Promise<A2aSendResult> {
  // §5.4 client-side max_payload enforcement
  const maxBytes = parseMaxPayload(target.promptEndpoint.maxPayload);
  const built = buildOutboundPayload(opts?.from ?? {}, prompt, {
    attachments: opts?.attachments,
    forceEnvelope: opts?.forceEnvelope || (opts?.attachments?.length ?? 0) > 0,
  });
  if (maxBytes !== undefined && built.payload.byteLength > maxBytes) {
    throw new A2aError(
      `payload ${built.payload.byteLength}B exceeds target max_payload ` +
        `${target.promptEndpoint.maxPayload} (§5.4)`,
      400,
    );
  }
  if ((opts?.attachments?.length ?? 0) > 0 && target.promptEndpoint.attachmentsOk === false) {
    throw new A2aError("target advertises attachments_ok=false (§2.1)", 400);
  }

  const inbox = `_extsyn.inbox.${randomUUID().replaceAll("-", "").slice(0, 16)}`;
  const sub = nc.subscribe(inbox);
  const acc = { text: "", ackSeen: false, chunkCount: 0 };

  const inactivityMs = opts?.inactivityTimeoutMs ?? INACTIVITY_TIMEOUT_MS_DEFAULT;
  const deadlineMs = opts?.overallTimeoutMs ?? TTL_MAX_S * 1000;
  const startedAt = Date.now();

  nc.publish(target.promptEndpoint.subject, built.payload, { reply: inbox });
  await nc.flush();

  return await new Promise<A2aSendResult>((resolve, reject) => {
    let inactivity: ReturnType<typeof setTimeout> | undefined;
    const armInactivity = () => {
      if (inactivity) clearTimeout(inactivity);
      inactivity = setTimeout(
        () => done(new A2aError(`inactivity timeout (${inactivityMs}ms since last chunk, §6.6)`, undefined)),
        inactivityMs,
      );
    };
    const overall = setTimeout(
      () => done(new A2aError(`overall timeout (${deadlineMs}ms, TTL_MAX_S guard)`, undefined)),
      deadlineMs,
    );
    let settled = false;
    const done = (err: Error | null, result?: A2aSendResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(overall);
      if (inactivity) clearTimeout(inactivity);
      try { sub.unsubscribe(); } catch { /* */ }
      if (err) reject(err);
      else resolve(result!);
    };
    armInactivity();
    (async () => {
      for await (const m of sub) {
        if (settled) return;
        // §9/§6.5: an error-headered message is NOT the terminator (the
        // terminator carries NO headers) — and respondError() sends a
        // ZERO-BODY message with headers (services lib service.js:78-83), so
        // headers MUST be checked before the byteLength===0 terminator test.
        const h = m.headers as { get?: (k: string) => string | undefined } | undefined;
        const errMsg = h?.get?.("Nats-Service-Error");
        if (errMsg !== undefined) {
          const codeRaw = h?.get?.("Nats-Service-Error-Code");
          done(new A2aError(errMsg, codeRaw !== undefined ? Number(codeRaw) : undefined));
          return;
        }
        if (m.data.byteLength === 0) {
          // §6.5 terminator — zero-byte body, no headers
          done(null, {
            text: acc.text,
            ackSeen: acc.ackSeen,
            chunkCount: acc.chunkCount,
            streamCompleted: true,
          });
          return;
        }
        try {
          consumeChunk(acc, m);
        } catch (e) {
          done(e as Error);
          return;
        }
        armInactivity();
      }
      // subscription closed without terminator (server gone / drain)
      if (!settled) done(new A2aError("reply stream ended without terminator", undefined));    })().catch((e) => done(e as Error));
    void startedAt; // (diagnostics hook: elapsed since publish)
  });
}

// ── session bridge state ────────────────────────────────────────────────

export interface SessionBridge {
  /** Queue an inbound prompt for the pi session (sendUserMessage). */
  onInbound: (env: CoreEnvelope, respond: (data: Uint8Array) => void) => void;
  /** Host calls this on turn_end — replies to the oldest pending stream. */
  onTurnEnd: (text: string) => void;
  /** How many replies are pending (diagnostics). */
  pending: () => number;
}

/**
 * Create the bridge. `sendUserMessage` is pi's ExtensionAPI method; when
 * absent (headless/tests/echo mode) the reply is emitted immediately with a
 * deterministic echo — the skeleton's prompt-echo round-trip.
 */
export function createBridge(sendUserMessage?: (msg: string) => void): SessionBridge {
  // ONE prompt in flight (G14). The old shape pushed every inbound and called
  // sendUserMessage immediately, then replied to `queue.shift()` on EVERY turn
  // end — including a turn the local operator typed. Two inbound callers could
  // receive each other's answer, and a local turn replied to a remote caller
  // with text it never asked for.
  //
  // Serialising is what makes the mapping deterministic: an injected prompt is
  // the only thing that can produce the next turn_end.
  interface Entry {
    prompt: string;
    respond: (data: Uint8Array) => void;
  }
  const waiting: Entry[] = [];
  let active: Entry | null = null;

  const pump = (): void => {
    if (active !== null || waiting.length === 0 || !sendUserMessage) return;
    const next = waiting.shift()!;
    active = next;
    try {
      sendUserMessage(next.prompt);
    } catch {
      // The host refused the message: answer the caller rather than stranding it.
      active = null;
      emitReplyStream(next.respond, "(the session could not accept this prompt)");
      pump();
    }
  };

  return {
    onInbound: (env, respond) => {
      const prompt = env.prompt ?? "";
      if (!sendUserMessage) {
        // Echo mode: ack immediately, respond with the prompt text, terminate.
        emitReplyStream(respond, `echo: ${prompt}`);
        return;
      }
      waiting.push({
        prompt: `[a2a from ${env.from.owner ?? "?"}/${env.from.name ?? "?"}]: ${prompt}`,
        respond,
      });
      pump();
    },
    onTurnEnd: (text) => {
      // No inbound in flight ⇒ this turn belongs to the local operator; replying
      // to a remote caller here would answer a message they never sent.
      if (active === null) return;
      const done = active;
      active = null;
      emitReplyStream(done.respond, text);
      pump();
    },
    pending: () => waiting.length + (active === null ? 0 : 1),
  };
}
