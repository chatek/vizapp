/**
 * identity.ts — ext-synadia's INDEPENDENT nonce chain (sprint ruling Q1,
 * UNIFIED_A2A_FABRIC.md §7: "Separate nonce chain — independent from the
 * onboarded NKey. Trust separation; correlation via metadata `site_id`
 * later").
 *
 * Pattern conceptually mirrors pi-a2a's loadOrCreateNonce
 * (A2A/pi-a2a/src/index.ts:3674-3705: env override → persisted file → random
 * fallback) but is a fresh implementation with its OWN storage directory —
 * deliberately NOT shared with pi-a2a's identity files and NOT the onboarded
 * NKey from ~/.vchat/credentials.json.
 *
 * Resolution order:
 *   1. EXT_SYNADIA_NONCE env var (explicit override)
 *   2. persisted file  ~/.config/ext-synadia/identity/nonce  (the chain —
 *      stable across processes once created)
 *   3. random 6-char hex, persisted best-effort (file may be unwritable)
 */

import { randomUUID } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

export const EXT_SYNADIA_NONCE_ENV = "EXT_SYNADIA_NONCE";

/** Identity dir override (tests point this at a tmpdir). */
export const EXT_SYNADIA_IDENTITY_DIR_ENV = "EXT_SYNADIA_IDENTITY_DIR";

export function identityDir(): string {
  const base = process.env[EXT_SYNADIA_IDENTITY_DIR_ENV];
  if (base) return base;
  const home = process.env.XDG_CONFIG_HOME || join(process.env.HOME || "~", ".config");
  return join(home, "ext-synadia", "identity");
}

function freshNonce(): string {
  return randomUUID().replaceAll("-", "").slice(0, 6);
}

let cached: string | undefined;

/** Load-or-create this extension's nonce (stable per machine-user). */
export function loadOrCreateNonce(): string {
  if (cached) return cached;

  // 1. Env override
  const env = process.env[EXT_SYNADIA_NONCE_ENV]?.trim();
  if (env) {
    cached = env;
    return cached;
  }

  // 2. Persisted chain
  const file = join(identityDir(), "nonce");
  try {
    const prev = readFileSync(file, "utf8").trim();
    if (prev.length >= 6) {
      cached = prev;
      return cached;
    }
  } catch { /* no file yet — create below */ }

  // 3. Random + persist (best effort)
  cached = freshNonce();
  try {
    mkdirSync(identityDir(), { recursive: true, mode: 0o700 });
    writeFileSync(file, cached + "\n", { mode: 0o600 });
  } catch { /* best effort — nonce still valid in-memory */ }
  return cached;
}

/** Test hook: clear the in-process cache. */
export function resetNonceCache(): void {
  cached = undefined;
}
