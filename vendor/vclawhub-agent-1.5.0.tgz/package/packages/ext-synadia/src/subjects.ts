/**
 * subjects.ts — Synadia v0.3 default-subject builders (spec §2).
 *
 * C3 ruling (UNIFIED_A2A_FABRIC.md §7): implementations MUST use the default
 * subjects; only `agents.hb.*` is protocol-fixed. Callers still learn endpoint
 * subjects from `$SRV.INFO` (spec §4.3) — these builders are for the agent's
 * OWN registration side.
 *
 * Token order (spec §2): agents.{verb}.{agent}.{owner}.{name}
 */

export type SynadiaVerb =
  | "prompt"
  | "hb"
  | "status"
  | "buddy_request"
  | "buddy_accept"
  | "buddy_reject";

/** The harness subject particle (spec Appendix C conventional abbreviation). */
export const AGENT_PARTICLE = "pi";

/** Default subject for a verb, per spec §2 table. */
export function defaultSubject(verb: SynadiaVerb, owner: string, name: string): string {
  return `agents.${verb}.${AGENT_PARTICLE}.${owner}.${name}`;
}

/** Fixed heartbeat subject (§8.1 — the one protocol-fixed endpoint). */
export function hbSubject(owner: string, name: string): string {
  return defaultSubject("hb", owner, name);
}

/** Default prompt endpoint subject (§2 — discoverable via $SRV.INFO). */
export function promptSubject(owner: string, name: string): string {
  return defaultSubject("prompt", owner, name);
}

/** Default status endpoint subject (§8.7 — request/reply, heartbeat-shaped reply). */
export function statusSubject(owner: string, name: string): string {
  return defaultSubject("status", owner, name);
}

// ── Buddy protocol verbs (pi-a2a lineage — lane-F hoist from buddy.ts) ────
// Grammar identical to pi-a2a (A2A/pi-a2a/src/a2a/protocol.ts:84-86,141-154):
// agents.buddy_{request,accept,reject}.pi.{owner}.{name}

/** Buddy request — ask another agent to become a buddy. */
export function buddyRequestSubject(owner: string, name: string): string {
  return defaultSubject("buddy_request", owner, name);
}

/** Buddy accept — confirm a buddy relationship. */
export function buddyAcceptSubject(owner: string, name: string): string {
  return defaultSubject("buddy_accept", owner, name);
}

/** Buddy reject — decline a buddy relationship. */
export function buddyRejectSubject(owner: string, name: string): string {
  return defaultSubject("buddy_reject", owner, name);
}
