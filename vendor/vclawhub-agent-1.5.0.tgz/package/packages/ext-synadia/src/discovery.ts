/**
 * discovery.ts — Synadia v0.3 §4.3 discovery client.
 *
 * Discovers protocol agents via the Micro `agents` service sweep and returns
 * them as protocol-core AgentDescriptors + the caller-facing endpoint facts
 * (subject, max_payload, attachments_ok).
 *
 * Spec map (core-protocol.md):
 *   §4.3  callers read metadata.agent/owner(/session) + the `prompt`
 *         endpoint's subject + metadata; publish to the subject VERBATIM —
 *         "no construction" (also §2). ext-synadia CANNOT send without this
 *         record (unless the target handed us its subject out-of-band).
 *   §2.1  prompt endpoint metadata: max_payload / attachments_ok
 *   §8.3  instance name lives in the 5th subject token (never metadata)
 *
 * Library facts (@nats-io/services 3.4.0, lib/mod.d.ts:2 +
 * lib/serviceclient.d.ts:8-11): `new Svcm(nc).client(opts).info(name?)` →
 * Promise<QueuedIterator<ServiceInfo>> where ServiceInfo = { id, version,
 * description?, metadata?, endpoints: EndpointInfo[] } (lib/types.d.ts:86-150).
 * Same sweep pattern as pi-a2a's fabric.ts:130-141 (discoverAll).
 */

import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { AgentDescriptor } from "@jsr/vclawhub__protocol-core";

/** Caller-facing facts for a discovered prompt endpoint (§2.1 + §4.3). */
export interface DiscoveredEndpoint {
  /** The subject to publish requests to, VERBATIM (§4.3). */
  subject: string;
  /** max_payload as advertised, e.g. "1MB" (client enforces locally, §5.4). */
  maxPayload?: string;
  /** attachments accepted? (§2.1 — stringified in endpoint metadata). */
  attachmentsOk?: boolean;
}

/** A discovered protocol agent. */
export interface DiscoveredAgent {
  /** Identity in the Synadia grammar (agent/owner/name from §4.3 sources). */
  descriptor: AgentDescriptor;
  /** Micro instance id — matches hb/status `instance_id` (§8.3). */
  instanceId: string;
  /** Harness semver from $SRV.INFO (§3.1). */
  version: string;
  promptEndpoint?: DiscoveredEndpoint;
}

/** Parse "1MB"-style sizes (§2.1: integer + B|KB|MB|GB) to bytes. */
export function parseMaxPayload(s: string | undefined): number | undefined {
  const m = /^(\d+)\s*(B|KB|MB|GB)$/.exec((s ?? "").trim());
  if (!m) return undefined;
  const mult = { B: 1, KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3 }[m[2] as "B" | "KB" | "MB" | "GB"];
  return Number(m[1]) * mult;
}

/**
 * Instance name = last token of the endpoint subject (§8.3 names live in the
 * subject, not metadata). Path-embedded identities normalized to the final
 * segment — pi-a2a fabric.ts:139-141 precedent ("vmaker-pi/chance/x" → "x").
 */
export function nameFromSubject(subject: string): string | undefined {
  const last = subject.split(".").pop() ?? "";
  return last.split("/").pop() || undefined;
}

/**
 * Sweep $SRV.INFO.agents and return every agent exposing a `prompt` endpoint.
 * (Services without one are not protocol agent surfaces — skipped.)
 */
export async function discoverAgents(
  nc: NatsConnection,
  opts?: { maxWaitMs?: number; maxMessages?: number },
): Promise<DiscoveredAgent[]> {
  const svcm = new Svcm(nc);
  const client = svcm.client({
    strategy: "stall",
    maxWait: opts?.maxWaitMs ?? 1500,
    maxMessages: opts?.maxMessages ?? 200,
  });
  const iter = await client.info("agents");
  const out: DiscoveredAgent[] = [];
  for await (const si of iter) {
    const promptEp = si.endpoints?.find((e) => e.name === "prompt");
    if (!promptEp) continue;
    const meta = si.metadata ?? {};
    const tokens = promptEp.subject.split(".");
    out.push({
      descriptor: {
        // §4.3 order: metadata first; default-subject tokens as fallback.
        agent: meta["agent"] || tokens[2] || "pi",
        owner: meta["owner"] || tokens[3] || "?",
        name: nameFromSubject(promptEp.subject) || meta["session"] || "?",
        metadata: {
          instance_id: si.id,
          ...(meta["protocol_version"] ? { protocol_version: meta["protocol_version"] } : {}),
          ...(meta["fabric"] ? { fabric: meta["fabric"] } : {}),
        },
      },
      instanceId: si.id,
      version: si.version,
      promptEndpoint: {
        subject: promptEp.subject,
        maxPayload: promptEp.metadata?.["max_payload"],
        attachmentsOk: promptEqAttachmentsOk(promptEp.metadata?.["attachments_ok"]),
      },
    });
  }
  return out;
}

/** attachments_ok is stringified in Micro endpoint metadata ("true"/"false"). */
function promptEqAttachmentsOk(v: string | undefined): boolean | undefined {
  if (v === "true") return true;
  if (v === "false") return false;
  return undefined;
}
