/**
 * buddy.ts — buddy protocol on the site mesh (lane F).
 *
 * Subjects follow the Synadia grammar with pi-a2a's buddy verbs
 * (A2A/pi-a2a/src/a2a/protocol.ts:84-86,141-154):
 *   agents.buddy_request.pi.{owner}.{name}
 *   agents.buddy_accept.pi.{owner}.{name}
 *   agents.buddy_reject.pi.{owner}.{name}
 * (Dispatch said "subjects.ts builders exist" — they don't at time of
 * writing, so they live here; hoisting into subjects.ts is a trivial move
 * for whoever owns that file next.)
 *
 * Wire payload mirrors pi-a2a's shipping shape
 * (A2A/pi-a2a/src/index.ts:2714 request, :2017 accept, :2028 reject):
 *   { type: "buddy_request"|"buddy_accept"|"buddy_reject",
 *     fromOwner, fromName, conversationId, ts }
 *
 * Durability: the buddy list is a plain JSON file at
 * ~/.config/ext-synadia/identity/buddies.json — same dir discipline as the
 * nonce (identity.ts identityDir()). Re-buddy-on-rediscovery semantics per
 * pi-a2a's model: relationships persist (roster.ts:389-402 markBuddy keeps
 * buddy=true across sightings; index.ts:2082-2091 same-fabric contact
 * upserts buddy:true idempotently) — so a buddy's heartbeat reappearing
 * requires NO re-handshake, and an inbound request from an existing buddy
 * is auto-re-accepted (idempotent).
 */

import { randomUUID } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { NatsConnection, Subscription } from "@nats-io/nats-core";

import { identityDir } from "./identity.js";
import { buddyAcceptSubject, buddyRejectSubject, buddyRequestSubject } from "./subjects.js";

// Buddy subject builders live in ./subjects.ts (lane-L hoist — one subject
// grammar, one home; zero behavior change).

// ── Wire payloads (pi-a2a interop shape) ────────────────────────────────

export type BuddyWireType = "buddy_request" | "buddy_accept" | "buddy_reject";

export interface BuddyWire {
  type: BuddyWireType;
  fromOwner: string;
  fromName: string;
  conversationId: string;
  ts: string;
}

export type BuddyKind = "buddy_request" | "buddy_accept" | "buddy_reject";

// ── Durable buddy store ─────────────────────────────────────────────────

export interface BuddyRecord {
  owner: string;
  name: string;
  addedAt: string;
}

export function buddiesFilePath(base = identityDir()): string {
  return join(base, "buddies.json");
}

/** Tiny JSON-file store. All ops synchronous (the file is small). */
export class BuddyStore {
  #file: string;
  #records: BuddyRecord[] | undefined;

  constructor(file?: string) {
    this.#file = file ?? buddiesFilePath();
  }

  #load(): BuddyRecord[] {
    if (this.#records) return this.#records;
    try {
      const parsed = JSON.parse(readFileSync(this.#file, "utf8")) as { buddies?: BuddyRecord[] };
      this.#records = Array.isArray(parsed.buddies) ? parsed.buddies : [];
    } catch {
      this.#records = [];
    }
    return this.#records!;
  }

  #save(): void {
    try {
      mkdirSync(join(this.#file, ".."), { recursive: true, mode: 0o700 });
      writeFileSync(this.#file, JSON.stringify({ version: 1, buddies: this.#load() }, null, 2), { mode: 0o600 });
    } catch { /* best effort — in-memory list still serves the session */ }
  }

  list(): readonly BuddyRecord[] {
    return this.#load();
  }

  isBuddy(owner: string, name: string): boolean {
    return this.#load().some((b) => b.owner === owner && b.name === name);
  }

  /** Idempotent add (pi-a2a markBuddy semantics — roster.ts:389-402). Returns true when newly added. */
  add(owner: string, name: string): boolean {
    if (this.isBuddy(owner, name)) return false;
    this.#load().push({ owner, name, addedAt: new Date().toISOString() });
    this.#save();
    return true;
  }

  remove(owner: string, name: string): boolean {
    const before = this.#load().length;
    this.#records = this.#load().filter((b) => !(b.owner === owner && b.name === name));
    if (this.#records.length !== before) this.#save();
    return this.#records.length !== before;
  }
}

// ── Protocol (send/receive over the site mesh) ──────────────────────────

export interface BuddyProtocolHandlers {
  /** Inbound request from a NOT-yet-buddy. Absent → auto-accept (skeleton). */
  onRequest?(from: { owner: string; name: string }, reply: { accept(): void; reject(): void }): void;
  /** Inbound accept — the sender is now in the store. */
  onAccept?(from: { owner: string; name: string }): void;
  /** Inbound reject (no state change — no pending list in the skeleton). */
  onReject?(from: { owner: string; name: string }): void;
}

export interface BuddyProtocolHandle {
  /** Send a buddy request to owner/name. */
  request(owner: string, name: string): void;
  /** Send an accept to owner/name (and record them). */
  accept(owner: string, name: string): void;
  /** Send a reject to owner/name. */
  reject(owner: string, name: string): void;
  /** Stop subscriptions (idempotent). */
  stop(): void;
}

/**
 * Start the buddy protocol: subscribes OUR request/accept/reject subjects
 * (pi-a2a index.ts:1107-1136 pattern — each agent listens on its own verbs)
 * and exposes send helpers.
 */
export function startBuddyProtocol(
  nc: NatsConnection,
  opts: { self: { owner: string; name: string }; store?: BuddyStore } & BuddyProtocolHandlers,
): BuddyProtocolHandle {
  const store = opts.store ?? new BuddyStore();
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  const publish = (kind: BuddyKind, toOwner: string, toName: string) => {
    const subject =
      kind === "buddy_request" ? buddyRequestSubject(toOwner, toName)
      : kind === "buddy_accept" ? buddyAcceptSubject(toOwner, toName)
      : buddyRejectSubject(toOwner, toName);
    const wire: BuddyWire = {
      type: kind,
      fromOwner: opts.self.owner,
      fromName: opts.self.name,
      conversationId: randomUUID().slice(0, 8),
      ts: new Date().toISOString(),
    };
    nc.publish(subject, enc.encode(JSON.stringify(wire)));
  };

  const handle = (kind: BuddyKind, data: Uint8Array) => {
    let w: BuddyWire;
    try {
      w = JSON.parse(dec.decode(data)) as BuddyWire;
    } catch {
      return;
    }
    if (w.type !== kind || !w.fromOwner || !w.fromName) return;
    const from = { owner: w.fromOwner, name: w.fromName };

    if (kind === "buddy_request") {
      // Re-buddy: an existing buddy's re-request is idempotently re-accepted
      // (durable relationship — pi-a2a index.ts:2082-2091 same-fabric semantics).
      if (store.isBuddy(from.owner, from.name)) {
        publish("buddy_accept", from.owner, from.name);
        return;
      }
      const reply = {
        accept: () => {
          store.add(from.owner, from.name);
          publish("buddy_accept", from.owner, from.name);
        },
        reject: () => publish("buddy_reject", from.owner, from.name),
      };
      if (opts.onRequest) opts.onRequest(from, reply);
      else reply.accept(); // skeleton default: auto-accept
    } else if (kind === "buddy_accept") {
      store.add(from.owner, from.name);
      opts.onAccept?.(from);
    } else {
      opts.onReject?.(from);
    }
  };

  const subs: Subscription[] = [
    nc.subscribe(buddyRequestSubject(opts.self.owner, opts.self.name)),
    nc.subscribe(buddyAcceptSubject(opts.self.owner, opts.self.name)),
    nc.subscribe(buddyRejectSubject(opts.self.owner, opts.self.name)),
  ];
  const drain = async (s: Subscription, kind: BuddyKind) => {
    for await (const msg of s) handle(kind, msg.data);
  };
  for (let i = 0; i < subs.length; i++) {
    drain(subs[i]!, (["buddy_request", "buddy_accept", "buddy_reject"] as const)[i]!).catch(() => { /* closed */ });
  }

  return {
    request: (owner, name) => publish("buddy_request", owner, name),
    accept: (owner, name) => {
      store.add(owner, name);
      publish("buddy_accept", owner, name);
    },
    reject: (owner, name) => publish("buddy_reject", owner, name),
    stop: () => {
      for (const s of subs) {
        try { s.unsubscribe(); } catch { /* closed */ }
      }
    },
  };
}
