/**
 * connect.ts — LOCAL site fabric connection (UNIFIED_A2A_FABRIC.md §6:
 * "local plane = token-auth site NATS (dev-box model generalized)").
 *
 * The dev-box instance of that plane is the pi-a2a local server
 * (127.0.0.1:14222, token-gated — ~/.config/pi-a2a/nats-ipc.conf:12,41).
 * ext-synadia connects as a CLIENT of the site plane — it never mints
 * identities (auth-at-connection-point; sprint ruling Q1).
 *
 * Auth resolution:
 *   1. SYNADIA_LOCAL_NATS_TOKEN env (explicit)
 *   2. the site token seed ~/.config/pi-a2a/server.seed
 *      (pi-a2a's TOKEN_SEED_FILE pattern, A2A/pi-a2a/src/index.ts:132,516-518)
 *   3. unauthenticated (server may run open in dev)
 */

import { readFileSync } from "node:fs";
import { join } from "node:path";
import { connect, type NatsConnection } from "@nats-io/transport-node";

export const LOCAL_NATS_URL_ENV = "SYNADIA_LOCAL_NATS_URL";
export const LOCAL_NATS_TOKEN_ENV = "SYNADIA_LOCAL_NATS_TOKEN";
export const DEFAULT_LOCAL_NATS = "nats://127.0.0.1:14222";

export function localNatsUrl(): string {
  return process.env[LOCAL_NATS_URL_ENV]?.trim() || DEFAULT_LOCAL_NATS;
}

function tryReadTokenSeed(): string | undefined {
  const base = process.env.XDG_CONFIG_HOME || join(process.env.HOME || "~", ".config");
  try {
    return readFileSync(join(base, "pi-a2a", "server.seed"), "utf8").trim();
  } catch {
    return undefined;
  }
}

/** Resolve the site-plane token (env → seed file → none). */
export function resolveToken(env = process.env): string | undefined {
  const explicit = env[LOCAL_NATS_TOKEN_ENV]?.trim();
  if (explicit) return explicit;
  return tryReadTokenSeed();
}

/** Connect to the LOCAL site fabric. Throws on failure (caller reports). */
export async function connectLocalFabric(opts?: {
  url?: string;
  token?: string;
}): Promise<NatsConnection> {
  const url = opts?.url ?? localNatsUrl();
  const token = opts?.token ?? resolveToken();
  return connect({ servers: url, ...(token ? { token } : {}), name: "ext-synadia" });
}
