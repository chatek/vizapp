/**
 * @vclawhub/protocol-core — the one A2A wire core.
 *
 * Synadia Agent Protocol v0.3 §5 envelope + §5.6 extension fields
 * (`from`, `replySubject`, `ts`); canonical camelCase (snake tolerated on
 * read). pi-a2a and agent-sdk envelopes are serializations of this core.
 * See dash/docs/sprint-unified-a2a/01-agent-sdk-meta-package.md and
 * docs/UNIFIED_A2A_FABRIC.md §4.
 */

export { snakeToCamel, isSnakeCase, normalizeCasing } from "./casing.js";
export {
  type AgentDescriptor,
  type SynadiaFrom,
  type TenantFrom,
  toSynadiaFrom,
  toTenantFrom,
  fromSynadia,
  fromTenant,
  describeAgent,
} from "./descriptor.js";
export {
  type Attachment,
  type Routing,
  type CoreEnvelope,
  type PiA2aEnvelope,
  type AgentSdkEnvelope,
  serializeCore,
  parseCore,
  serializePiA2a,
  parsePiA2a,
  serializeAgentSdk,
  parseAgentSdk,
} from "./envelope.js";

export {
  type AgentSenderFields,
  SHA256_EMPTY_HEX,
  sha256Hex,
  agentSenderSignedInput,
  signAgentSender,
  verifyAgentSender,
} from "./agent-sender.js";
