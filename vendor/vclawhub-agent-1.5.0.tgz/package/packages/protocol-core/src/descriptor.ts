/**
 * descriptor.ts — AgentDescriptor: the one identity shape unifying the two
 * subject grammars (UNIFIED_A2A_FABRIC.md §3-§4, 00-PLAN ruling 3).
 *
 *   Synadia grammar (ext-synadia / agent mesh):
 *     subjects  agents.{verb}.{agent}.{owner}.{name}
 *     discovery $SRV.INFO.agents Micro registration
 *
 *   tenant/IDP grammar (ext-segment / V3 planes):
 *     announcement $SRV.INFO.agents.{segment}.{nkey}   (plain pub/sub, NO Micro)
 *     mailboxes    tenant.{seg}.a2a.{nkey}.>
 *
 * The two grammars are NOT merged at the subject layer — this type is the
 * in-memory bridge adapters translate to/from at each transport edge.
 */

export interface AgentDescriptor {
  /** Synadia grammar: subject particle, e.g. "pi". */
  agent?: string;
  /** Synadia grammar: owner (org/user) segment of the subject. */
  owner?: string;
  /** Synadia grammar: per-session/role name. */
  name?: string;
  /** Tenant/IDP grammar: fabric segment the agent is admitted to. */
  segment?: string;
  /** Tenant/IDP grammar: the agent's NKey public form. */
  nkey?: string;
  /** Correlation bag — e.g. Q1's `site_id` (cross-site attribution later). */
  metadata?: Record<string, string>;
}

/** The Synadia `from` wire shape (pi-a2a A2aRequest.from — protocol.ts:180). */
export interface SynadiaFrom {
  agent: string;
  owner: string;
  name: string;
}

/** The tenant `from` wire shape (agent-sdk A2aRequest.from — net/types.ts:80). */
export interface TenantFrom {
  nkey: string;
  name?: string;
}

/** Project a descriptor onto the Synadia wire `from` shape. */
export function toSynadiaFrom(d: AgentDescriptor): SynadiaFrom {
  return {
    agent: d.agent ?? "pi",
    owner: d.owner ?? "",
    name: d.name ?? "",
  };
}

/** Project a descriptor onto the tenant wire `from` shape. */
export function toTenantFrom(d: AgentDescriptor): TenantFrom {
  const out: TenantFrom = { nkey: d.nkey ?? "" };
  const name = d.name ?? d.metadata?.display;
  if (name !== undefined) out.name = name;
  return out;
}

/** Lift a Synadia wire `from` into a descriptor. */
export function fromSynadia(f: SynadiaFrom, extra: Partial<AgentDescriptor> = {}): AgentDescriptor {
  return { agent: f.agent, owner: f.owner, name: f.name, ...extra };
}

/** Lift a tenant wire `from` into a descriptor. */
export function fromTenant(f: TenantFrom, segment?: string, extra: Partial<AgentDescriptor> = {}): AgentDescriptor {
  return { nkey: f.nkey, name: f.name, ...(segment ? { segment } : {}), ...extra };
}

/** Human-readable one-liner for panels/logs — prefers the name, falls back per grammar. */
export function describeAgent(d: AgentDescriptor): string {
  const base = d.name || d.metadata?.display;
  if (base) return base;
  if (d.nkey) return d.nkey.slice(0, 12);
  if (d.owner) return `${d.agent ?? "pi"}/${d.owner}`;
  return "(anonymous)";
}
