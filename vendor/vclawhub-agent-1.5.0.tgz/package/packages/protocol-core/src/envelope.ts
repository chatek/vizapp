/**
 * envelope.ts — the one wire envelope (00-PLAN ruling 1; canon §4).
 *
 * Core = Synadia Agent Protocol v0.3 §5 shape `{prompt, attachments?}` plus
 * the §5.6-tolerated extension fields `from`, `replySubject`, `ts`
 * (canonical casing camelCase; snake_case tolerated on read, never emitted).
 *
 * The two shipping envelopes are serializations of this core:
 *   pi-a2a    A2aRequest/A2aResponse — A2A/pi-a2a/src/a2a/protocol.ts:178-190, 275-283
 *             (from = {agent,owner,name}; replySubject rides inside `a2a`)
 *   agent-sdk A2aRequest/A2aResponse — agent-sdk/src/net/types.ts:76-95
 *             (from = {nkey,name?};   replySubject rides inside `a2a`)
 *
 * Parsers are tolerant: unknown fields are preserved in the envelope bag
 * (never dropped — forward compatibility), snake_case keys normalized
 * recursively, and both `type` discriminated unions are accepted.
 */

import { normalizeCasing } from "./casing.js";
import {
  type AgentDescriptor,
  fromSynadia,
  fromTenant,
  toSynadiaFrom,
  toTenantFrom,
  type SynadiaFrom,
  type TenantFrom,
} from "./descriptor.js";

/** Shared attachment shape (pi-a2a protocol.ts:312-315). */
export interface Attachment {
  filename: string;
  content: string;
}

/** The routing block both stacks carry as `a2a` (pi-a2a A2aRouting, protocol.ts:183-208). */
export interface Routing {
  intent?: "question" | "request" | "handoff" | "reply" | "sync" | "buddy_request" | "buddy_accept" | "buddy_reject" | (string & {});
  fromType?: string;
  fromAgent?: string;
  fromOwner?: string;
  fromName?: string;
  /** Project/fabric name for same-project auto-buddy detection. */
  fabric?: string;
  conversationId?: string;
  inReplyTo?: string;
  /** Stable reply inbox for this session. */
  replySubject?: string;
  /** "silent" suppresses receiver-side logging. Defaults "normal". */
  sensitivity?: "normal" | "silent" | (string & {});
}

/** The canonical core envelope. Unknown fields survive parse → serialize. */
export interface CoreEnvelope {
  /** Discriminator: "a2a_request" | "a2a_response" | future string. */
  type: string;
  id: string;
  /** §5.6 from — identity in either grammar (see AgentDescriptor). */
  from: AgentDescriptor;
  /** §5.6 ts — ISO timestamp. */
  ts: string;
  /** §5.6 replySubject — stable reply inbox (canonical top-level home). */
  replySubject?: string;
  /** §5 payload — the prompt (requests). */
  prompt?: string;
  /** Response text (responses). */
  text?: string;
  /** §5 attachments. */
  attachments?: Attachment[];
  /** Routing/intent block (both stacks' `a2a`). */
  routing?: Routing;
  /** TTL seconds, receiver-capped. */
  ttlS?: number;
  /** Error responses. */
  error?: boolean;
  errorCode?: number;
  /** Forward-compat bag — unknown fields preserved verbatim (camel-normalized). */
  [key: string]: unknown;
}

// ── internal helpers ─────────────────────────────────────────────────────

function asRecord(v: unknown): Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {};
}

const KNOWN_KEYS = new Set([
  "type", "id", "from", "ts", "replySubject", "prompt", "text",
  "attachments", "a2a", "ttlS", "error", "errorCode",
]);

/** Copy non-known top-level fields into a bag (collision-safe). */
function carryBag(source: Record<string, unknown>): Record<string, unknown> {
  const bag: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(source)) {
    if (!KNOWN_KEYS.has(k) && !(k in bag)) bag[k] = v;
  }
  return bag;
}

function asRouting(v: unknown): Routing | undefined {
  const r = asRecord(v);
  if (Object.keys(r).length === 0) return undefined;
  return r as Routing;
}

// ── core (canonical) ─────────────────────────────────────────────────────

/** Serialize the core to canonical wire form (camelCase only, §5.6 layout). */
export function serializeCore(env: CoreEnvelope): Record<string, unknown> {
  const out: Record<string, unknown> = { type: env.type, id: env.id, from: { ...env.from }, ts: env.ts };
  if (env.replySubject !== undefined) out.replySubject = env.replySubject;
  if (env.prompt !== undefined) out.prompt = env.prompt;
  if (env.text !== undefined) out.text = env.text;
  if (env.attachments !== undefined) out.attachments = env.attachments;
  if (env.routing !== undefined) out.a2a = { ...env.routing };
  if (env.ttlS !== undefined) out.ttlS = env.ttlS;
  if (env.error !== undefined) out.error = env.error;
  if (env.errorCode !== undefined) out.errorCode = env.errorCode;
  for (const [k, v] of Object.entries(env)) {
    if (!KNOWN_KEYS.has(k) && !CORE_EXPANDED.has(k) && !(k in out)) out[k] = v;
  }
  return out;
}
const CORE_EXPANDED = new Set(["routing", "metadata"]); // core-side aliases never re-emitted at top level

/** Parse a canonical-form object into the core (tolerant: casing + unknowns). */
export function parseCore(raw: unknown): CoreEnvelope {
  const src = asRecord(normalizeCasing(raw));
  const a2a = asRouting(src.a2a);
  const from = asRecord(src.from);
  const descriptor: AgentDescriptor = {
    ...from,
    metadata: asRecord(from.metadata) as Record<string, string> | undefined,
  };
  delete (descriptor as Record<string, unknown>).metadata;
  const md = asRecord(from.metadata);
  if (Object.keys(md).length > 0) descriptor.metadata = md as Record<string, string>;

  const env: CoreEnvelope = {
    type: String(src.type ?? ""),
    id: String(src.id ?? ""),
    from: descriptor,
    ts: String(src.ts ?? ""),
  };
  const reply = src.replySubject ?? a2a?.replySubject;
  if (reply !== undefined) env.replySubject = String(reply);
  // replySubject's canonical home is top-level (§5.6); strip it from the
  // routing copy so core.routing stays clean and round-trips losslessly.
  if (a2a && a2a.replySubject !== undefined) {
    const { replySubject: _lifted, ...rest } = a2a;
    env.routing = Object.keys(rest).length > 0 ? (rest as Routing) : undefined;
  } else if (a2a) {
    env.routing = a2a;
  }
  if (src.prompt !== undefined) env.prompt = String(src.prompt);
  if (src.text !== undefined) env.text = String(src.text);
  if (Array.isArray(src.attachments)) env.attachments = src.attachments as Attachment[];
  if (typeof src.ttlS === "number") env.ttlS = src.ttlS;
  if (typeof src.error === "boolean") env.error = src.error;
  if (typeof src.errorCode === "number") env.errorCode = src.errorCode;
  Object.assign(env, carryBag(src));
  return env;
}

// ── pi-a2a serialization ─────────────────────────────────────────────────

/** Wire shape: pi-a2a A2aRequest (protocol.ts:178-190) / A2aResponse (:275-283). */
export interface PiA2aEnvelope {
  type: "a2a_request" | "a2a_response" | (string & {});
  id: string;
  from: SynadiaFrom;
  ts: string;
  prompt?: string;
  text?: string;
  attachments?: Attachment[];
  a2a?: Routing;
  ttlS?: number;
  error?: boolean;
  errorCode?: number;
  [key: string]: unknown;
}

/** Serialize the core into pi-a2a's shipping shape (replySubject → a2a block). */
export function serializePiA2a(env: CoreEnvelope): PiA2aEnvelope {
  const out: PiA2aEnvelope = {
    type: env.type as PiA2aEnvelope["type"],
    id: env.id,
    from: toSynadiaFrom(env.from),
    ts: env.ts,
  };
  if (env.prompt !== undefined) out.prompt = env.prompt;
  if (env.text !== undefined) out.text = env.text;
  if (env.attachments !== undefined) out.attachments = env.attachments;
  const routing = { ...env.routing };
  if (env.replySubject !== undefined) routing.replySubject = env.replySubject;
  if (Object.keys(routing).length > 0) out.a2a = routing;
  if (env.ttlS !== undefined) out.ttlS = env.ttlS;
  if (env.error !== undefined) out.error = env.error;
  if (env.errorCode !== undefined) out.errorCode = env.errorCode;
  for (const [k, v] of Object.entries(env)) {
    if (!KNOWN_KEYS.has(k) && !CORE_EXPANDED.has(k) && !(k in out)) out[k] = v;
  }
  return out;
}

/** Parse pi-a2a's shipping shape into the core. */
export function parsePiA2a(raw: unknown): CoreEnvelope {
  return parseCore(raw); // same layout modulo from-grammar, handled below
}

// ── agent-sdk serialization ──────────────────────────────────────────────

/** Wire shape: agent-sdk A2aRequest/A2aResponse (net/types.ts:76-95). */
export interface AgentSdkEnvelope {
  type: "a2a_request" | "a2a_response" | (string & {});
  id: string;
  from: TenantFrom;
  ts: string;
  prompt?: string;
  text?: string;
  attachments?: Attachment[];
  a2a?: Routing;
  ttlS?: number;
  error?: boolean;
  errorCode?: number;
  [key: string]: unknown;
}

/** Serialize the core into agent-sdk's shipping shape (from → {nkey,name}). */
export function serializeAgentSdk(env: CoreEnvelope): AgentSdkEnvelope {
  const out: AgentSdkEnvelope = {
    type: env.type as AgentSdkEnvelope["type"],
    id: env.id,
    from: toTenantFrom(env.from),
    ts: env.ts,
  };
  if (env.prompt !== undefined) out.prompt = env.prompt;
  if (env.text !== undefined) out.text = env.text;
  if (env.attachments !== undefined) out.attachments = env.attachments;
  const routing = { ...env.routing };
  if (env.replySubject !== undefined) routing.replySubject = env.replySubject;
  if (Object.keys(routing).length > 0) out.a2a = routing;
  if (env.ttlS !== undefined) out.ttlS = env.ttlS;
  if (env.error !== undefined) out.error = env.error;
  if (env.errorCode !== undefined) out.errorCode = env.errorCode;
  for (const [k, v] of Object.entries(env)) {
    if (!KNOWN_KEYS.has(k) && !CORE_EXPANDED.has(k) && !(k in out)) out[k] = v;
  }
  return out;
}

/** Parse agent-sdk's shipping shape into the core. */
export function parseAgentSdk(raw: unknown): CoreEnvelope {
  return parseCore(raw);
}
