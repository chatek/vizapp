/**
 * casing.ts — canonical casing normalizer (UNIFIED_A2A_FABRIC.md §4).
 *
 * Canonical casing is camelCase (pi-a2a's shipping form). Spec-example
 * snake_case is TOLERATED ON READ, never emitted.
 */

/** Convert a snake_case identifier to camelCase. Non-snake input passes through. */
export function snakeToCamel(s: string): string {
  return s.replace(/_([a-z])/g, (_m, c: string) => c.toUpperCase());
}

/** True when the key is snake_case (contains `_` before a lowercase letter). */
export function isSnakeCase(s: string): boolean {
  return /_[a-z]/.test(s);
}

/**
 * Recursively normalize an unknown JSON value: object keys snake→camel
 * (first-wins on collision), arrays descended into. Primitives returned
 * as-is. Used by envelope parsers to accept spec-example casing.
 */
export function normalizeCasing(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(normalizeCasing);
  if (value !== null && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      const key = snakeToCamel(k);
      if (!(key in out)) out[key] = normalizeCasing(v);
    }
    return out;
  }
  return value;
}
