/**
 * agent-sender.ts — Synadia Agent Protocol §13 (sender identity): the canonical + sign/verify half.
 *
 * SPEC: Synadia Agent Protocol for NATS, version **0.3.0**.
 * Source of truth: `vendors/synadia-agent-sdk-docs/core-protocol.md`
 *   §13.6.1  the signed-input byte string
 *   §13.5.1  the wire header (counted toward max_payload) — emitted elsewhere; `name` is OUTSIDE the signature
 *   B.13     the published known-answer vector (`operator-account-signed`) reproduced in the test
 *   §13.3.3  the agent-id parse fixtures (parsing is NOT in this module yet — see the test's note)
 *
 * ⚠ PORTED, NOT RE-DERIVED. The test's vectors are the spec's own published values; if a test here fails,
 * compare against the spec text before changing the fixture.
 *
 * Relationship to the vclaw announcement signing (src/contracts/contracts.ts): that is a DIFFERENT canonical
 * scheme (JSON field-order over an announcement). Both are ed25519/NKEY and both must route through exactly
 * ONE implementation per scheme — this module is the §13 scheme's one home, and callers must not hand-roll it.
 */

const TAG = "AGENT-SENDER-V1";
const LF = 0x0a;

export interface AgentSenderFields {
  /** NKEY account (or account name); §13.3 canonical text form. */
  account: string;
  /** NKEY user. */
  user: string;
  /** The header's `sub`: the subject the message is published to. */
  subject: string;
  /** RFC3339 UTC timestamp, as carried in the header (byte-for-byte). */
  ts: string;
  /** Replay guard, as carried in the header. */
  nonce: string;
  /** The RAW message payload. An empty payload hashes to the SHA-256 of zero bytes. */
  payload: Uint8Array;
}

/** SHA-256 of zero bytes — the empty-payload case named in §13.6.1. */
export const SHA256_EMPTY_HEX = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

/** Lowercase-hex SHA-256 of the raw payload bytes. WebCrypto keeps this module dependency-free. */
export async function sha256Hex(payload: Uint8Array): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", payload as unknown as BufferSource);
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * §13.6.1 — the bytes the caller signs. Seven lines, each terminated by exactly one LF (the last included):
 *   AGENT-SENDER-V1 \n account \n user \n subject \n ts \n nonce \n sha256(payload) lowercase hex \n
 * The signed input is NEVER sent: only `sig` travels, and the receiver rebuilds this from the header + payload.
 */
export async function agentSenderSignedInput(f: AgentSenderFields): Promise<Uint8Array> {
  const digest = await sha256Hex(f.payload);
  const text = [TAG, f.account, f.user, f.subject, f.ts, f.nonce, digest].join("\n") + "\n";
  return new TextEncoder().encode(text);
}

/**
 * Sign the §13.6.1 input with the caller's USER seed. Returns base64url WITHOUT padding (64 bytes → 86 chars),
 * matching the wire form in B.13.
 */
export async function signAgentSender(f: AgentSenderFields, seed: string): Promise<string> {
  const { fromSeed } = await import("@nats-io/nkeys");
  const kp = fromSeed(new TextEncoder().encode(seed));
  const input = await agentSenderSignedInput(f);
  const sig = kp.sign(input);
  return Buffer.from(sig).toString("base64url");
}

/**
 * §13.7 receiver side: verify `sig` against the sender's public key over the REBUILT input.
 * Callers own the policy decisions (acceptable `sub`, trust class) — this only answers "does the signature
 * cover these bytes for this key".
 */
export async function verifyAgentSender(
  f: AgentSenderFields,
  sigB64url: string,
  publicKey: string,
): Promise<boolean> {
  const { fromPublic } = await import("@nats-io/nkeys");
  const kp = fromPublic(publicKey);
  const input = await agentSenderSignedInput(f);
  try {
    return kp.verify(input, Buffer.from(sigB64url, "base64url"));
  } catch {
    return false;
  }
}
