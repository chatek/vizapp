# @vclawhub/protocol-core

The one A2A wire core: Synadia Agent Protocol v0.3 §5 envelope + §5.6 extension
fields. The `agent-sdk` envelope is a serialization of it.

Hosted on [jsr.io/@vclawhub/protocol-core](https://jsr.io/@vclawhub/protocol-core).
Design history: `dash/docs/sprint-unified-a2a/01-agent-sdk-meta-package.md`.
